# @ilia-ae/site-kit

_Docs snapshot: `2026-06-16` · `9d75d63e864b` · `feat(inventory): surface license-bank build in the manifest → panel shows it per-project`._

Shared Angular 21 building blocks for ilia.ae sites: multilingual status/error
pages (with timer-redirect + browser-lang detect), nav (desktop + mobile),
projects directory, generated contact-QR, footer with auto-copyright, social
links, cookie consent, language & theme toggles, a favicon icon-set (whole set
from one SVG), full SEO (head meta + Open Graph + Twitter + hreflang + JSON-LD

- sitemap/robots), build-integrity / verify surfaces, license rendering, and an
  installable-app PWA module (manifest + ngsw + install prompt + splash —
  Angular-only). One config drives content, structure AND design.

> Private package — published to GitHub Packages. See the
> [repository README](https://github.com/ilia-ae/ilia-site-kit#readme) for the
> full guide (including the static-HTML generator for non-Angular sites).

## Install

```ini
# .npmrc
@ilia-ae:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

```bash
npm i @ilia-ae/site-kit
```

The published package also ships a static CLI:

```bash
npx site-kit-static --config site-kit.static.json --out public/kit
```

## Use

```ts
import { provideSiteKit, StatusPage, Footer } from '@ilia-ae/site-kit';

// app.config.ts
providers: [
    provideSiteKit({
        brand: { name: 'ilia.ae', url: 'https://ilia.ae' },
        copyright: { startYear: 2018 },
        contact: { qr: { src: '/assets/contact-qr.svg' } },
    }),
];
```

```html
<ik-status-page [code]="404" /> <ik-footer />
```

## Theming

Components read CSS custom properties (`--brand`, `--bg`, `--border`, `--sp-4`,
`--r-lg`, …) and inherit your app's theme automatically. Import the bundled
defaults only if your app doesn't define them:

```css
@import '@ilia-ae/site-kit/src/lib/styles/site-kit-tokens.css';
```

Or put the design **in the config** (`theme` → applied to `<html>`):

```ts
provideSiteKit({ brand: { name: 'monolith' }, theme: { '--brand': '#5b43ad' } });
```

Multi-domain: one build, config auto-picked by hostname —
`provideSiteKitForHost({ 'ilia.ae': iliaCfg, 'mayday.software': maydayCfg }, { fallback: 'ilia.ae' })`.

## Exports

- **Config:** `provideSiteKit`, `provideSiteKitForHost`, `pickHostKey`,
  `DEFAULT_REDIRECT_SECONDS`, `SITE_KIT_CONFIG`, `resolveSiteKitConfig`,
  `SITE_KIT_SCHEMA_VERSION`, `SITE_KIT_VERSION`
- **i18n:** `IK_LANGUAGES`, `ikLanguage`, `ikLanguages`, `isRtl`, `localizeUrl`,
  `localizeText`, `resolveLinkHref`, `formatPhone`, `IK_STRINGS`, `ikString`,
  `SITE_KIT_BUILD_DATE`
- **Status:** `StatusPage`, `STATUS_ENTRIES`, `STATUS_LANGUAGES`, `statusEntry`, `statusCopy`
- **Blocks:** `Nav`, `Projects`, `ProjectsList`, `Technologies`, `Footer`,
  `ContactQr`, `SocialLinks`, `CookieConsent`, `IkClose`, `IkCountdown`,
  `LangSwitcher`, `ThemeToggle`, `TechnoBg`
- **Favicon:** `faviconTags`, `faviconSourceSvg`, `applyFaviconTags` (icon-set head
  tags from one SVG; assets rasterized at build time by `tools/lib/favicon.mjs`)
- **SEO:** `Seo` (live head service), `buildSeoTags` (meta · OG · Twitter · hreflang · JSON-LD)
- **SEO assets:** `buildOgSvg` (auto-generated OG banner source for `seo.ogImage`)
- **PWA (Angular-only):** `provideSiteKitPwa`, `Pwa` (install/standalone/update service),
  `Install` (`<ik-install>`), `buildManifest`, `pwaMetaTags`, `pwaSplashLinks`,
  `applyPwaTags`, `isStandalone`, `isIos`, `splashMedia`, `PWA_SPLASH_DEVICES`
- **Verification:** `AuthorshipValidator`, `VerifyBadge`, `VerifyMark`,
  `IntegrityService`, `sha256OfFile`, `sha256OfString`, `parseManifestHashes`,
  `checkWhat`, `checkWhen`, `parseOts`, `parseTsr`, `verifyGpg`, `gpgAvailable`,
  `needsPassphrase`
- **License:** `IkLicense`, `resolveLicense`, `LICENSE_CATALOG`, `LICENSE_BUILD`
- **Types:** `SiteKitConfig`, `SiteKitNavItem`, `SiteKitProject`, `SiteKitLink`,
  `SiteKitQr`, `SiteKitFavicon`, `SiteKitSeo`, `SiteKitSeoEntity`, `SiteKitPwa`,
  `SiteKitPwaShortcut`, `SiteKitCookie`, `SiteKitLocalizedUrl`, `FaviconTag`,
  `SeoTag`, `SeoContext`, `PwaMetaTag`, `PwaLinkTag`, `VerifyStatus`,
  `VerifyMarkLabels`, `IntegrityManifest`, `IntegrityBundle`, `IntegrityCheck`,
  `IntegrityDeps`, `ResolvedLicense`, `LicenseEntry`, `StatusKey`, `IkLanguage`,
  `IkThemeMode`, `IkConsent`, `IkStringKey`, `TechMeta`, `GpgResult`, … (+ the rest).

## Peer dependencies

`@angular/core`, `@angular/common`, `@angular/platform-browser` — `^21`.

`openpgp` is an optional peer dependency. Install it only if you use
`AuthorshipValidator` / `verifyGpg` in the browser.

`@angular/service-worker` (`^21`) is an optional peer dependency — required only if
you enable the PWA module via `provideSiteKitPwa()`.
