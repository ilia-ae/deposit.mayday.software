import * as i0 from '@angular/core';
import { input, output, ChangeDetectionStrategy, Component } from '@angular/core';

/**
 * The footer's dialog: the policy panel (a legal link with `body`) or the build-integrity result
 * (opened from ©). Private to the footer, which renders it in a `@defer` block, so it is a chunk
 * of its own, fetched when a dialog first opens: a page that never opens one doesn't carry its
 * markup or styles (tools/bundle-size.mjs).
 *
 * It imports nothing from the kit but types, on purpose: a consumer's bundler treats every lazy
 * chunk as an entry point, so whatever a chunk imports from the rest of the kit becomes live in
 * every app that imports the kit at all. The footer hands it plain data and projects the close
 * button (<ik-close>, which stays in the footer's own code).
 */
class FooterDialog {
    /** The policy panel to show, or null. */
    policy = input(null, ...(ngDevMode ? [{ debugName: "policy" }] : /* istanbul ignore next */ []));
    /** The build-integrity result to show (when there's no policy), or null. */
    verify = input(null, ...(ngDevMode ? [{ debugName: "verify" }] : /* istanbul ignore next */ []));
    /** "Open full version ↗", localized. */
    fullLabel = input('', ...(ngDevMode ? [{ debugName: "fullLabel" }] : /* istanbul ignore next */ []));
    /** Escape or the backdrop; the projected close button reports to the footer itself. */
    closed = output();
    title() {
        return this.policy()?.label ?? this.verify()?.title ?? '';
    }
    /** One-line summary for a bundle check (✓ matched / ✗ mismatch / — inconclusive). */
    checkLine(c) {
        if (c.matched === true)
            return `✓ ${String(c.actual).slice(0, 16)}…`;
        if (c.matched === false)
            return `✗ ${c.expected.slice(0, 12)}…`;
        return `— ${c.expected.slice(0, 12)}…`;
    }
    /** Keep Tab focus inside the open dialog — bound on the dialog box's keydown. */
    trapFocus(ev) {
        if (ev.key !== 'Tab')
            return;
        const box = ev.currentTarget;
        const f = Array.from(box.querySelectorAll('a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'));
        if (!f.length)
            return;
        const first = f[0];
        const last = f[f.length - 1];
        const active = box.ownerDocument.activeElement;
        if (ev.shiftKey && active === first) {
            ev.preventDefault();
            last.focus();
        }
        else if (!ev.shiftKey && active === last) {
            ev.preventDefault();
            first.focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: FooterDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: FooterDialog, isStandalone: true, selector: "ik-footer-dialog", inputs: { policy: { classPropertyName: "policy", publicName: "policy", isSignal: true, isRequired: false, transformFunction: null }, verify: { classPropertyName: "verify", publicName: "verify", isSignal: true, isRequired: false, transformFunction: null }, fullLabel: { classPropertyName: "fullLabel", publicName: "fullLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closed: "closed" }, ngImport: i0, template: `
        <!-- eslint-disable-next-line @angular-eslint/template/interactive-supports-focus -->
        <div class="ik-modal" (keydown.escape)="closed.emit()">
            <!-- decorative backdrop; keyboard close is handled by the dialog's Escape handler -->
            <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
            <div class="ik-modal__scrim" (click)="closed.emit()"></div>
            <div
                class="ik-modal__box"
                role="dialog"
                aria-modal="true"
                [attr.aria-label]="title()"
                (keydown)="trapFocus($event)"
            >
                <header class="ik-modal__head">
                    <h2 class="ik-modal__title">{{ title() }}</h2>
                    <ng-content select="ik-close" />
                </header>
                @if (policy(); as doc) {
                    <!-- Policy panel — same UX as the cookie policy. -->
                    @if (doc.updated) {
                        <p class="ik-modal__meta">{{ doc.updated }}</p>
                    }
                    <div class="ik-modal__body">
                        @for (para of doc.paras; track $index) {
                            <p>{{ para }}</p>
                        }
                    </div>
                    @if (doc.href) {
                        <a
                            class="ik-modal__full"
                            [href]="doc.href"
                            [attr.target]="doc.external ? '_blank' : null"
                            [attr.rel]="doc.external ? 'noopener noreferrer' : null"
                            >{{ fullLabel() }}</a
                        >
                    }
                } @else if (verify(); as v) {
                    <!-- Build integrity: the LIVE check (status + manifest commit + per-bundle SHA-256). -->
                    <p class="ik-verify__status ik-verify__status--{{ v.status }}">
                        <span class="ik-verify__dot" aria-hidden="true"></span>{{ v.statusLabel }}
                    </p>
                    @if (v.summary; as sum) {
                        <p class="ik-modal__meta">{{ sum }}</p>
                    }
                    @for (c of v.checks; track c.name) {
                        <div class="ik-verify__check ik-verify__check--{{ c.matched }}">
                            <span class="ik-verify__name">{{ c.name }}</span>
                            <span class="ik-verify__sha">{{ checkLine(c) }}</span>
                        </div>
                    }
                }
            </div>
        </div>
    `, isInline: true, styles: [".ik-modal{position:fixed;inset:0;z-index:var(--z-modal, 1000);display:grid;place-items:center;padding:var(--sp-4, 1rem)}.ik-modal__scrim{position:absolute;inset:0;background:#09090f8c;-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px)}.ik-modal__box{position:relative;width:100%;max-width:34rem;max-height:min(82vh,48rem);overflow:auto;display:flex;flex-direction:column;gap:var(--sp-3, .75rem);padding:var(--sp-6, 1.5rem);background:var(--bg-elev, #fff);color:var(--text, #09090f);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);box-shadow:var(--shadow-lg, 0 20px 48px rgba(9, 9, 15, .2));text-align:left;font-size:var(--fs-sm, .875rem);line-height:1.6}.ik-modal__box--wide{max-width:52rem}.ik-modal__head{display:flex;align-items:flex-start;justify-content:space-between;gap:var(--sp-4, 1rem)}.ik-modal__title{margin:0;font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-bold, 700);color:var(--text, #09090f)}.ik-modal__meta{margin:0;font-size:var(--fs-xs, .75rem);color:var(--text-dim, #74747f);font-family:var(--font-mono, ui-monospace, monospace)}.ik-modal__body{display:flex;flex-direction:column;gap:var(--sp-3, .75rem);color:var(--text-mute, #51515e)}.ik-modal__body p{margin:0;white-space:pre-line}.ik-modal__full{align-self:flex-start;color:var(--brand, #6d28d9);font-weight:var(--fw-semi, 600);text-decoration:none}.ik-modal__full:hover{text-decoration:underline}.ik-verify__status{display:flex;align-items:center;gap:.5rem;margin:0;font-weight:var(--fw-bold, 700);color:var(--text, #09090f)}.ik-verify__dot{width:9px;height:9px;border-radius:50%;background:var(--text-dim, #74747f);flex-shrink:0}.ik-verify__status--verified{color:#4ade80}.ik-verify__status--verified .ik-verify__dot{background:#4ade80;box-shadow:0 0 8px #4ade80}.ik-verify__status--mismatch{color:#f87171}.ik-verify__status--mismatch .ik-verify__dot{background:#f87171;box-shadow:0 0 8px #f87171}.ik-verify__status--dev{color:#fbbf24}.ik-verify__status--dev .ik-verify__dot{background:#fbbf24}.ik-verify__meta{display:grid;grid-template-columns:auto 1fr;gap:.15rem .75rem;margin:0;font-size:var(--fs-xs, .75rem)}.ik-verify__meta div{display:contents}.ik-verify__meta dt{color:var(--text-dim, #74747f)}.ik-verify__meta dd{margin:0;color:var(--text-mute, #51515e);font-family:var(--font-mono, ui-monospace, monospace)}.ik-verify__check{display:flex;align-items:baseline;justify-content:space-between;gap:.75rem;padding:.4rem 0;border-top:1px solid var(--border-soft, #f0f0f2);font-size:var(--fs-xs, .75rem)}.ik-verify__name{font-weight:var(--fw-semi, 600);color:var(--text, #09090f)}.ik-verify__sha{color:var(--text-mute, #51515e);font-family:var(--font-mono, ui-monospace, monospace);word-break:break-all;text-align:right}.ik-verify__check--true .ik-verify__sha{color:#4ade80}.ik-verify__check--false .ik-verify__sha{color:#f87171}.ik-modal__full:focus-visible{outline:none;border-radius:4px;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: FooterDialog, decorators: [{
            type: Component,
            args: [{ selector: 'ik-footer-dialog', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <!-- eslint-disable-next-line @angular-eslint/template/interactive-supports-focus -->
        <div class="ik-modal" (keydown.escape)="closed.emit()">
            <!-- decorative backdrop; keyboard close is handled by the dialog's Escape handler -->
            <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
            <div class="ik-modal__scrim" (click)="closed.emit()"></div>
            <div
                class="ik-modal__box"
                role="dialog"
                aria-modal="true"
                [attr.aria-label]="title()"
                (keydown)="trapFocus($event)"
            >
                <header class="ik-modal__head">
                    <h2 class="ik-modal__title">{{ title() }}</h2>
                    <ng-content select="ik-close" />
                </header>
                @if (policy(); as doc) {
                    <!-- Policy panel — same UX as the cookie policy. -->
                    @if (doc.updated) {
                        <p class="ik-modal__meta">{{ doc.updated }}</p>
                    }
                    <div class="ik-modal__body">
                        @for (para of doc.paras; track $index) {
                            <p>{{ para }}</p>
                        }
                    </div>
                    @if (doc.href) {
                        <a
                            class="ik-modal__full"
                            [href]="doc.href"
                            [attr.target]="doc.external ? '_blank' : null"
                            [attr.rel]="doc.external ? 'noopener noreferrer' : null"
                            >{{ fullLabel() }}</a
                        >
                    }
                } @else if (verify(); as v) {
                    <!-- Build integrity: the LIVE check (status + manifest commit + per-bundle SHA-256). -->
                    <p class="ik-verify__status ik-verify__status--{{ v.status }}">
                        <span class="ik-verify__dot" aria-hidden="true"></span>{{ v.statusLabel }}
                    </p>
                    @if (v.summary; as sum) {
                        <p class="ik-modal__meta">{{ sum }}</p>
                    }
                    @for (c of v.checks; track c.name) {
                        <div class="ik-verify__check ik-verify__check--{{ c.matched }}">
                            <span class="ik-verify__name">{{ c.name }}</span>
                            <span class="ik-verify__sha">{{ checkLine(c) }}</span>
                        </div>
                    }
                }
            </div>
        </div>
    `, styles: [".ik-modal{position:fixed;inset:0;z-index:var(--z-modal, 1000);display:grid;place-items:center;padding:var(--sp-4, 1rem)}.ik-modal__scrim{position:absolute;inset:0;background:#09090f8c;-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px)}.ik-modal__box{position:relative;width:100%;max-width:34rem;max-height:min(82vh,48rem);overflow:auto;display:flex;flex-direction:column;gap:var(--sp-3, .75rem);padding:var(--sp-6, 1.5rem);background:var(--bg-elev, #fff);color:var(--text, #09090f);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);box-shadow:var(--shadow-lg, 0 20px 48px rgba(9, 9, 15, .2));text-align:left;font-size:var(--fs-sm, .875rem);line-height:1.6}.ik-modal__box--wide{max-width:52rem}.ik-modal__head{display:flex;align-items:flex-start;justify-content:space-between;gap:var(--sp-4, 1rem)}.ik-modal__title{margin:0;font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-bold, 700);color:var(--text, #09090f)}.ik-modal__meta{margin:0;font-size:var(--fs-xs, .75rem);color:var(--text-dim, #74747f);font-family:var(--font-mono, ui-monospace, monospace)}.ik-modal__body{display:flex;flex-direction:column;gap:var(--sp-3, .75rem);color:var(--text-mute, #51515e)}.ik-modal__body p{margin:0;white-space:pre-line}.ik-modal__full{align-self:flex-start;color:var(--brand, #6d28d9);font-weight:var(--fw-semi, 600);text-decoration:none}.ik-modal__full:hover{text-decoration:underline}.ik-verify__status{display:flex;align-items:center;gap:.5rem;margin:0;font-weight:var(--fw-bold, 700);color:var(--text, #09090f)}.ik-verify__dot{width:9px;height:9px;border-radius:50%;background:var(--text-dim, #74747f);flex-shrink:0}.ik-verify__status--verified{color:#4ade80}.ik-verify__status--verified .ik-verify__dot{background:#4ade80;box-shadow:0 0 8px #4ade80}.ik-verify__status--mismatch{color:#f87171}.ik-verify__status--mismatch .ik-verify__dot{background:#f87171;box-shadow:0 0 8px #f87171}.ik-verify__status--dev{color:#fbbf24}.ik-verify__status--dev .ik-verify__dot{background:#fbbf24}.ik-verify__meta{display:grid;grid-template-columns:auto 1fr;gap:.15rem .75rem;margin:0;font-size:var(--fs-xs, .75rem)}.ik-verify__meta div{display:contents}.ik-verify__meta dt{color:var(--text-dim, #74747f)}.ik-verify__meta dd{margin:0;color:var(--text-mute, #51515e);font-family:var(--font-mono, ui-monospace, monospace)}.ik-verify__check{display:flex;align-items:baseline;justify-content:space-between;gap:.75rem;padding:.4rem 0;border-top:1px solid var(--border-soft, #f0f0f2);font-size:var(--fs-xs, .75rem)}.ik-verify__name{font-weight:var(--fw-semi, 600);color:var(--text, #09090f)}.ik-verify__sha{color:var(--text-mute, #51515e);font-family:var(--font-mono, ui-monospace, monospace);word-break:break-all;text-align:right}.ik-verify__check--true .ik-verify__sha{color:#4ade80}.ik-verify__check--false .ik-verify__sha{color:#f87171}.ik-modal__full:focus-visible{outline:none;border-radius:4px;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}\n"] }]
        }], propDecorators: { policy: [{ type: i0.Input, args: [{ isSignal: true, alias: "policy", required: false }] }], verify: [{ type: i0.Input, args: [{ isSignal: true, alias: "verify", required: false }] }], fullLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "fullLabel", required: false }] }], closed: [{ type: i0.Output, args: ["closed"] }] } });

export { FooterDialog };
//# sourceMappingURL=ilia-ae-site-kit-footer-dialog-Cfdz3T1q.mjs.map
