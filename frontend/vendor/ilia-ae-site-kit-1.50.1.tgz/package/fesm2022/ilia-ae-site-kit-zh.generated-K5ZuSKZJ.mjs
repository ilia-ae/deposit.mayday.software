/** Title + message of each status in "zh". */
const STATUS_COPY = {
    "400": {
        "title": "请求无效",
        "message": "服务器无法处理此请求——请检查地址后重试。"
    },
    "401": {
        "title": "需要登录",
        "message": "查看此页面需要先登录。"
    },
    "403": {
        "title": "禁止访问",
        "message": "您没有权限查看此页面。"
    },
    "404": {
        "title": "页面未找到",
        "message": "链接可能已失效，或地址输入有误。"
    },
    "405": {
        "title": "方法不被允许",
        "message": "此类请求在这里不可用。"
    },
    "408": {
        "title": "请求超时",
        "message": "请求耗时过长。请重试。"
    },
    "410": {
        "title": "已删除",
        "message": "此内容已不再可用。"
    },
    "429": {
        "title": "请求过于频繁",
        "message": "您发送请求过于频繁。请稍候。"
    },
    "500": {
        "title": "服务器内部错误",
        "message": "我们这边出了点问题，我们正在处理。"
    },
    "502": {
        "title": "网关错误",
        "message": "服务暂时不可用。请一分钟后重试。"
    },
    "503": {
        "title": "服务不可用",
        "message": "正在进行维护。我们很快回来。"
    },
    "504": {
        "title": "网关超时",
        "message": "服务器响应时间过长。请尝试刷新。"
    },
    "maintenance": {
        "title": "正在维护",
        "message": "我们正在短暂更新。请稍后再来。"
    },
    "offline": {
        "title": "您已离线",
        "message": "连接似乎已断开。请检查网络后刷新。"
    }
};

export { STATUS_COPY };
//# sourceMappingURL=ilia-ae-site-kit-zh.generated-K5ZuSKZJ.mjs.map
