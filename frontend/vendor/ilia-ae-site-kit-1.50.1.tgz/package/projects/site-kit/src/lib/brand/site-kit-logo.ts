/**
 * "IA kit" — the library's brand mark. A 2×2 cluster of distinct primitives:
 *   ◣ triangle (top-left) · ▢ square (top-right) · ▢ square (bottom-left) · ● circle (bottom-right)
 * The diagonal triangle↔circle gives it identity; the two squares read as "modular blocks".
 * Trusted library constant (rendered via innerHTML); `currentColor` so it adapts to its mark.
 */
// Pure-math 2×2 grid in a 24 box: shapes inset to [3,10] & [14,21] (cluster centre 12 =
// viewBox centre); the 1px outline grows the footprint back out to ~[2.25,21.75]. Outline-only.
export const SITE_KIT_GLYPH = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" xmlns="http://www.w3.org/2000/svg"><path d="M6.5 3 10 10 3 10Z"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><circle cx="17.5" cy="17.5" r="3.5"/></svg>`;

/** The library's signature accent — warm sand (the IA kit brand colour); tints the badge hover. */
export const SITE_KIT_ACCENT = '#ad7729';

/** Display name of the library's signature badge. */
export const SITE_KIT_NAME = 'IA kit';
