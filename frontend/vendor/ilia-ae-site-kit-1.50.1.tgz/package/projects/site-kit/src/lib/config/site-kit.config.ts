import { InjectionToken } from '@angular/core';
import { IK_LANGUAGES } from '../i18n/languages';

/**
 * @ilia-ae/site-kit — shared configuration contract.
 *
 * ONE settings object per site, provided via `provideSiteKit({...})`. Two layers:
 *   • Look & feel  → CSS custom properties (defined by the host app; inherited).
 *   • Content/data → this object (brand, links, projects, contact, copyright…).
 *
 * Content AND design are both modifiable: design via CSS variables / per-block
 * class hooks; content via this config. Multi-domain sites use
 * `provideSiteKitForHost({...})` to auto-pick the right config by hostname.
 */

// ─── Localized text ───────────────────────────────────────────
/**
 * A user-facing string that may be a single value OR a per-language map, so one
 * config holds every translation: `'Privacy'` or `{ en: 'Privacy', ru: 'Конфиденциальность' }`.
 * Resolved by the active language via `localizeText()`.
 */
export type LocalizedString = string | Record<string, string>;

// ─── Links (locale-aware) ─────────────────────────────────────
/**
 * A link whose URL adapts to the active language. Resolution precedence (see
 * `resolveLinkHref`): `urls` → `pathByLang` → `localize` → `url`.
 *   { url: 'https://ilia.ae', localize: true }              → ru: ilia.ae · en: ilia.ae/en
 *   { url: 'https://ilia.ae', pathByLang: { en: '/en/' } }  → ru: ilia.ae · en: ilia.ae/en/
 *   { url: 'https://ilia.ae', pathByLang: { ru: '/', en: '/en/' } } → both get a modifier
 *   { url: '...', urls: { en: 'https://ilia.ae/en' } }      → explicit full per-lang URL
 * `label` may itself be a per-language map (LocalizedString).
 */
export interface SiteKitLink {
    label: LocalizedString;
    url: string;
    /** Insert `/<lang>` for non-default languages. */
    localize?: boolean;
    /**
     * Per-language path modifier appended to the URL's domain: `domain(url) + modifier`.
     * Languages absent from the map fall back to the bare `url`, so a modifier can apply
     * to one language, none, or both. E.g. `{ en: '/en/' }` → ru: domain · en: domain/en/.
     */
    pathByLang?: Record<string, string>;
    /** Explicit per-language URLs (wins over everything). */
    urls?: Record<string, string>;
    /** Force open in a new tab. Auto-detected for http(s) when omitted. */
    external?: boolean;
}

// ─── Brand / copyright ────────────────────────────────────────
export interface SiteKitBrand {
    name: string;
    /** Logo URL or inline SVG data-uri. */
    logoUrl?: string;
    /**
     * Inline SVG glyph whose paths use `currentColor` (e.g. a brand mark/icon).
     * Rendered in the QR card's header mark (in `--brand`) and centre emblem (in
     * white on the brand gradient), so it inherits the right colour in each spot.
     * Preferred over `logoUrl` for those two places; `logoUrl` still drives nav/footer.
     */
    glyph?: string;
    /** Single-letter/short monogram fallback when there's no logo. */
    monogram?: string;
    url?: string;
    tagline?: LocalizedString;
    /**
     * Hide the brand NAME label in nav + footer, leaving only the logo/glyph/monogram
     * mark. For minimal, icon-only brands (e.g. a tool whose mark stands alone). The
     * name still feeds alt text, OG, the QR card and copyright — only the visible
     * topbar/footer label is suppressed.
     */
    nameHidden?: boolean;
}

export interface SiteKitCopyright {
    holder?: string;
    startYear?: number;
    suffix?: LocalizedString;
}

// ─── Contact / QR (rich, vCard-style) ─────────────────────────
export interface SiteKitQr {
    /** Value ENCODED into the generated QR (URL or vCard). Defaults to `brand.url`. */
    data?: string;
    /**
     * Make the encoded value locale-aware (like SiteKitLink): for non-default
     * languages the QR points to `/<lang>` of `data`. Lets one QR page serve a
     * different target per language — `?lang=en` → site/en, `?lang=ru` → site.
     */
    localize?: boolean;
    /** Explicit per-language QR targets (wins over `localize`): `{ en: 'https://site/en' }`. */
    urls?: Record<string, string>;
    /** Pre-rendered image instead of generating (URL / data-uri). Overrides `data`. */
    src?: string;
    /**
     * Lede text shown ABOVE the QR (value proposition). A plain string, or a
     * per-language map `{ en: '…', ru: '…' }` so it translates with `[lang]`.
     */
    lede?: string | Record<string, string>;
    /**
     * Hint shown BELOW the QR (italic). String or per-language map. Falls back
     * to a localized "Scan to connect".
     */
    caption?: string | Record<string, string>;
    alt?: string;
    /** Click-through target wrapping the QR. */
    href?: string;
    /**
     * Overlay a small brand badge (monogram/logo) at the QR center. Stays
     * scannable thanks to 'H' error-correction (~30%). Defaults ON when the
     * brand has a monogram or logo; set `false` to opt out.
     */
    badge?: boolean;
    /** Decorative L-corner accents around the white QR frame. Default 'none'. */
    corners?: 'none' | 'dashed' | 'solid';
}

export interface SiteKitContact {
    qr?: SiteKitQr;
    email?: string;
    telegram?: string;
    /** WhatsApp: a phone number or a wa.me link. */
    whatsapp?: string;
    phone?: string;
    /** The site itself, shown as a contact channel (e.g. "Website"). */
    website?: string;
    /** Link to a contact form / "write us" page. */
    contactForm?: string;
    /** Person / role / company / location for a contact card. */
    person?: string;
    role?: string;
    company?: string;
    location?: string;
    /** Quick links shown under the QR (site, blog, …) — locale-aware. */
    quickLinks?: SiteKitLink[];
    /** Which share channels to offer (defaults to a sensible set). */
    share?: SiteKitShareKind[];
    /**
     * Per-channel accent OVERRIDES (any CSS colour), keyed by share kind:
     * `{ linkedin: '#0a66c2', telegram: '#229ED9' }`. By default every chip inherits
     * the theme `--brand` (one colour for all); set a channel here to opt it into a
     * custom tint. Surfaced as `--chip-accent` (icon tint in the 'color' theme, hover
     * tint everywhere).
     */
    shareColors?: Partial<Record<SiteKitShareKind, string>>;
    /**
     * Share-button layout: 'grid' (vertical icon-over-label tiles, default) or
     * 'inline' (horizontal icon-left/label-right rows). The `ik-contact-qr`
     * `shareLayout` input overrides this per-usage.
     */
    shareLayout?: 'grid' | 'inline';
    /**
     * Share icon colour theme: 'mono' (neutral icons, brand accent only on hover,
     * default) or 'color' (icons tinted with the theme `--brand` at rest — one colour
     * for all chips unless `shareColors` overrides a channel). Overridable via the
     * `ik-contact-qr` `shareTheme` input.
     */
    shareTheme?: 'mono' | 'color';
    /**
     * Section-divider style for the share/links headers under the QR:
     *   • 'top'           — small label left-aligned with a rule above it (default)
     *   • 'center'        — label centred, a solid hairline runs left & right of it
     *   • 'center-dashed' — same, but the flanking rule is dashed
     * Overridable via the `ik-contact-qr` `sectionDivider` input.
     */
    sectionDivider?: 'top' | 'center' | 'center-dashed';
}

export type SiteKitShareKind =
    | 'native'
    | 'copy'
    | 'telegram'
    | 'whatsapp'
    | 'x'
    | 'linkedin'
    | 'facebook'
    | 'vk'
    | 'email';

// ─── Social ───────────────────────────────────────────────────
export type SiteKitSocialKind =
    | 'telegram'
    | 'whatsapp'
    | 'email'
    | 'phone'
    | 'github'
    | 'linkedin'
    | 'x'
    | 'instagram'
    | 'youtube'
    | 'website'
    | 'custom';

export interface SiteKitSocialLink {
    kind: SiteKitSocialKind;
    url: string;
    /** Accessible name; a string or per-language map. Default: the channel's name in the active
     *  language (Russian for `ru`, else English — "Сайт" / "Website"). */
    label?: LocalizedString;
    /** Inline SVG markup or icon URL. Required only for `kind: 'custom'`. */
    icon?: string;
    /** Locale-aware URL, same rules as SiteKitLink: `urls` → `pathByLang` → `localize` → `url`. */
    localize?: boolean;
    pathByLang?: Record<string, string>;
    urls?: Record<string, string>;
}

export interface SiteKitLegalLink {
    label: LocalizedString;
    /** Link target. With `body` set this becomes the OPTIONAL "open full version" link in the panel. */
    href?: string;
    /**
     * Inline policy text shown in an in-app panel (same UX as the cookie policy panel) when the
     * link is clicked — a string or per-language map; blank lines separate paragraphs. Omit for a
     * plain link to `href`. When both are set, the panel shows `body` + an "open full" link to `href`.
     */
    body?: LocalizedString;
    /**
     * ISO-8601 timestamp of the last revision. Rendered in the panel as a full UTC datetime
     * ("Last updated: 16 Jun 2026, 18:30 UTC") — not just a year. Omit to hide the line.
     */
    updated?: string;
}

// ─── Verify / live build-integrity ────────────────────────────
export interface SiteKitVerify {
    /**
     * URL of the integrity manifest (JSON `{ commit, bundles: [{ name, sha256, url? }] }`). The
     * kit's `IntegrityService` fetches it, SHA-256-hashes the running bundles and compares —
     * surfacing verified/mismatch/… on `ik-verify-mark`. Omit to leave the mark static.
     */
    manifestUrl?: string;
    /** Hostnames treated as dev (check suppressed → `dev` status). Defaults to localhost / 127.* / *.local. */
    devHosts?: string[];
}

// ─── Footer (rich, multi-column) ──────────────────────────────
export interface SiteKitFooterColumn {
    /** Column heading (e.g. "Proof", "Source", "Legal") — per-language aware. */
    title: LocalizedString;
    /**
     * Column entries. A plain `SiteKitLink`, OR a `SiteKitLegalLink` (one with `body`) that opens
     * the in-app policy panel on click — so About / Privacy can live INSIDE a column instead of the
     * bottom bar. Body-less entries render as normal links; `body` entries render as a panel button.
     */
    links: (SiteKitLink | SiteKitLegalLink)[];
    /**
     * Append every `config.legal` entry (About / Privacy …) to this column, rendered as policy-panel
     * buttons. A convenience for hosting the legal links inside a column without duplicating them;
     * pair with `footer.barLegal: false` to remove them from the bottom bar.
     */
    appendLegal?: boolean;
    /**
     * Expose this column as its own `<nav>` landmark (aria-label = title). Defaults to `true`
     * (backward-compatible). Set `false` for utility/legal columns so the landmark menu isn't
     * flooded — the column still renders its `<h4>` heading + `<ul>`, just not as a landmark.
     */
    landmark?: boolean;
}

/**
 * Optional rich footer: brand column (logo + subtitle + disclaimer + social
 * slot) · link columns · a bottom bar (copyright + brand tagline + tech badges).
 * With no `columns`, the footer degrades to a brand + bottom-bar strip.
 */
/** The library's signature badge ("IA · site-kit") shown in the footer by default. */
export interface SiteKitSignature {
    /** Link target. Default `https://ilia.ae`. */
    href?: string;
    /** Visible label next to the monogram. Default `site-kit`. */
    label?: string;
    /** Monogram chip text. Default `IA`. */
    mono?: string;
}

/**
 * PageSpeed Insights performance score(s) shown as footer badge chip(s) — you fill the numbers in
 * by hand from your latest PSI run (no live API call), and each chip links back to PSI to RE-TEST
 * the site (`https://pagespeed.web.dev/report?url=…`). Give `mobile` and/or `desktop` — a chip is
 * rendered for each one provided (so one or both). Numbers are colour-banded like Lighthouse
 * (green ≥90 · amber 50–89 · red <50). Omit the whole object to show nothing.
 */
export interface SiteKitPageSpeed {
    /** Performance score (0–100) for the mobile form factor. Omit to skip the mobile chip. */
    mobile?: number;
    /** Performance score (0–100) for the desktop form factor. Omit to skip the desktop chip. */
    desktop?: number;
    /** URL fed to the re-test link. Defaults to `seo.siteUrl` → `brand.url`. */
    url?: string;
    /** Visible label prefix on the chip tooltip. Default `PageSpeed`. */
    label?: string;
}

export interface SiteKitFooter {
    /** Small line under the brand name (e.g. "by mayday.software") — per-language aware. */
    subtitle?: LocalizedString;
    /** Privacy/disclaimer paragraph shown in the brand column — per-language aware. */
    disclaimer?: LocalizedString;
    /** Link columns. Falls back to a "Legal" column built from `config.legal`. */
    columns?: SiteKitFooterColumn[];
    /**
     * Single-strip footer: drop the brand column + link columns and render ONE compact
     * row — brand mark (glyph/logo, if any) · © year · disclaimer · tech badges. For
     * minimal sites whose footer is just a bottom bar. `subtitle`/`columns` are ignored
     * in this mode; the disclaimer moves inline into the strip.
     */
    compact?: boolean;
    /**
     * Drop the brand column (logo · name · subtitle · disclaimer · social slot) in the FULL
     * footer and go straight to the link columns. For sites whose header already shows the
     * brand, so repeating it in the footer is redundant. Ignored when `compact`.
     */
    hideBrand?: boolean;
    /**
     * Render the link columns stacked in ONE column instead of the responsive auto-fit grid.
     * A tidy single-column footer (headings + links flow vertically). Ignored when `compact`.
     */
    stackColumns?: boolean;
    /**
     * Show the legal links (`config.legal`) in the bottom bar. Default `true`. Set `false` to keep
     * the bar clean (just © · disclaimer · badges) — e.g. when a column uses `appendLegal` to host
     * About / Privacy instead. Applies to both the full and compact footer.
     */
    barLegal?: boolean;
    /**
     * Built-in "our projects" row — the ILIA family of sites as real-logo chips (from the kit's
     * `IK_FAMILY` catalogue) with per-active-language URLs. `true`/`'all'` → the whole family;
     * an array picks/orders specific keys (`['mayday','deposit']`); omit/`false` → off. The CURRENT
     * site is auto-excluded (its `brand.url` origin is dropped) so a footer never links to itself.
     * Keys: ilia · mayday · deposit · aliro · monolith · netcheck · integra.
     */
    projects?: boolean | 'all' | string[];
    /**
     * Opt-in utility affordances rendered in the footer (all default off — backward-compatible):
     */
    /** Show a "Cookie settings" link in the legal cluster that re-opens the consent banner
     *  (`ik-cookie-consent.reopen()`, wired via a document `ik:cookie-settings` event + the
     *  footer's `(cookieSettings)` output). GDPR/CCPA: withdrawing consent must be as easy as giving it. */
    cookieSettings?: boolean;
    /** Render the built-in `ik-lang-switcher` in a footer utility row; re-emits via `(langChange)`. */
    langSwitcher?: boolean;
    /** Render the built-in `ik-theme-toggle` in a footer utility row; re-emits via `(themeChange)`. */
    themeToggle?: boolean;
    /** Surface a contact block (company · location · phone · email) from `config.contact`, with
     *  schema.org Organization microdata. */
    contact?: boolean;
    /** Show a labelled "Back to top" button (moves focus to `<main>`/top, honours reduced-motion). */
    backToTop?: boolean;
}

// ─── Navigation (full desktop + mobile accordion) ─────────────
export interface SiteKitNavItem extends SiteKitLink {
    /** Highlighted call-to-action styling. */
    cta?: boolean;
    /** Nested items → dropdown (desktop) / accordion section (mobile). */
    children?: SiteKitNavItem[];
}

// ─── Technologies (footer tech-stack badges) ──────────────────
/**
 * A technology used by the site — rendered as a linked badge (icon + name) by
 * `ik-technologies` (and auto-shown in the footer). `kind` picks a built-in icon
 * + a canonical URL; `name`/`url`/`icon` override those.
 *   { kind: 'angular' }                              → Angular · angular.dev · built-in icon
 *   { name: 'PrimeNG', url: 'https://primeng.org' }  → custom badge, fallback glyph
 *   { name: 'Acme', icon: '<svg…>' or 'https://…png' } → custom icon
 */
export interface SiteKitTech {
    /** Known tech slug for a built-in icon + default URL (e.g. 'angular', 'typescript', 'cloudflare'). */
    kind?: string;
    /** Display name. Defaults to the kind's label. */
    name?: string;
    /** Link to the technology's site. Defaults to the kind's canonical URL. */
    url?: string;
    /** Inline SVG markup or an icon image URL — overrides the built-in kind icon. */
    icon?: string;
    /** Brand accent (hex) used to tint the badge on hover. Defaults to the kind's colour. */
    color?: string;
    /** Optional version (e.g. `'21'`, `'5.9'`) — shown as a tooltip on the badge (`Name v21`). */
    version?: string;
}

// ─── Projects directory ───────────────────────────────────────
export interface SiteKitProject {
    name: string;
    description?: string;
    url: string;
    /** Locale-aware URL (see SiteKitLink). */
    localize?: boolean;
    urls?: Record<string, string>;
    tags?: string[];
    status?: 'live' | 'wip' | 'archived';
    /** Logo/icon URL; falls back to a monogram of `name`. */
    logoUrl?: string;
}

// ─── Status pages ─────────────────────────────────────────────
/** Default auto-redirect countdown (seconds) when `status.redirect` is not configured. */
export const DEFAULT_REDIRECT_SECONDS = 15;

export interface SiteKitStatusRedirect {
    /** Seconds before auto-redirecting to home (live countdown). Omit → {@link DEFAULT_REDIRECT_SECONDS}; `0` = disabled. */
    delaySeconds?: number;
    /** Where to go. Defaults to `status.homeHref`. */
    href?: string;
}

export interface SiteKitStatusOptions {
    homeHref?: string;
    /** "Home" button label. Localized; omit to use the built-in localized "home". */
    homeLabel?: LocalizedString;
    /** Support line under the error. Localized. */
    supportLine?: LocalizedString;
    /** Languages to render simultaneously on a status page. Defaults to `languages`. */
    languages?: string[];
    /** Auto-redirect to home after a visible countdown. ON by default ({@link DEFAULT_REDIRECT_SECONDS}s);
     *  set `{ delaySeconds: 0 }` to turn it off, or `{ delaySeconds }` to customise. */
    redirect?: SiteKitStatusRedirect;
    /** Show a "back" button (browser history.back). Default true. */
    showBack?: boolean;
}

// ─── Deploy (how the static /kit/ bundle reaches each site) ───
/**
 * Delivery method for a site's generated error/QR pages + public config.
 *   • git        — pages committed to the site's repo, shipped to disk by its git
 *                  pipeline (aaPanel / Coolify); updates (incl. config) via git.
 *   • cloudflare — a Worker with the HTML hardcoded inline; intercepts origin
 *                  responses (incl. origin-down → 5xx). Everything lives in git.
 *   • wp         — a ready bundle the user uploads manually + edits config by hand.
 */
export type SiteKitDeployTarget = 'git' | 'cloudflare' | 'wp';

export interface SiteKitDeploy {
    target: SiteKitDeployTarget;
    /** Base folder, relative to the site root. Default '/kit'. */
    path?: string;
    /**
     * Per-route absolute-path overrides so a page can live OUTSIDE the base folder:
     * `{ qr: '/qr', '404': '/404.html' }`. Keys: status codes, 'qr', 'verify',
     * 'manifest', 'config', 'tokens'. A route with no extension (`/qr`) → served as
     * `<route>/`. `verify` is where `ik-verify-badge` points (default `<base>/verify.html`).
     */
    routes?: Record<string, string>;
    /** Cloudflare zone/route the Worker guards (informational; used by wrangler.toml). */
    zone?: string;
}

// ─── Favicon / app icons (the whole set derived from ONE square SVG) ──
/**
 * Favicon + web-app-icon set, generated "from one SVG" the modern way (the 2026
 * evilmartians/RealFaviconGenerator minimal standard — no legacy 16-file bloat):
 *   • icon.svg               — scalable, dark-mode aware (primary for desktop tabs)
 *   • favicon.ico            — single 32×32, legacy + the bare `/favicon.ico` convention
 *   • apple-touch-icon.png   — 180×180, opaque background (iOS flattens alpha)
 *   • icon-192/512.png       — PWA install / Android (`purpose: any`)
 *   • icon-mask.png          — 512×512 maskable (separate file, 80% safe zone)
 *   • manifest.webmanifest   — name/short_name/icons/theme — PWA installability
 * The raster set is produced at build time (`tools/lib/favicon.mjs`, via sharp);
 * the runtime/static side only emits the `<link>`/`<meta theme-color>` head tags.
 * Adaptive: with no `favicon`, nothing is emitted; with `favicon: {}` the source
 * falls back to `brand.glyph` (tinted on the theme `--brand`) then a monogram tile.
 */
export interface SiteKitFavicon {
    /**
     * Source SQUARE SVG the whole set is rasterized from — a path (resolved against
     * the config/CWD), inline `<svg…>` markup, or a `data:image/svg+xml` URI. Omit to
     * derive one from `brand.glyph` (on a `--brand` tile) or `brand.monogram`/initial.
     */
    src?: string;
    /**
     * Solid background for the rasterized PNGs (apple-touch MUST be opaque; the
     * maskable icon needs full-bleed). Any CSS colour. Defaults to the theme
     * `--brand`, then `#ffffff`.
     */
    background?: string;
    /** Foreground/tint when the icon is DERIVED from `brand.glyph` (the glyph uses currentColor). Defaults to `#ffffff`. */
    color?: string;
    /** Browser-UI `theme-color`. A single colour, or `{ light, dark }` for `prefers-color-scheme`. Defaults to the theme `--brand`. */
    themeColor?: string | { light?: string; dark?: string };
    /** Public base path the generated assets are served from (e.g. `/`, `/kit`). Defaults to `deploy.path` or `/`. */
    path?: string;
    /** Emit a web manifest + 192/512/maskable icons for PWA installability. Default true. */
    manifest?: boolean;
    /** Manifest `display` mode. Default `standalone`. */
    display?: 'standalone' | 'minimal-ui' | 'fullscreen' | 'browser';
    /** Manifest `name` (defaults to `brand.name`); `short_name` defaults to `name`. */
    name?: string;
    shortName?: string;
}

// ─── SEO (head meta · Open Graph · Twitter · hreflang · JSON-LD) ──────
/**
 * The entity a site represents — drives the JSON-LD entity node. `Organization`/`Person`
 * emit an org/person node (+ `WebSite`); `SoftwareApplication`/`Product` emit a product
 * rich-result node (with `offers`, `applicationCategory`, …). The product-only fields are
 * ignored for `Organization`/`Person`, and vice-versa.
 */
export interface SiteKitSeoEntity {
    /**
     * `Organization` (company), `Person` (personal site), or `SoftwareApplication`/`Product`
     * (product rich-results). Default `Organization`.
     */
    type?: 'Organization' | 'Person' | 'SoftwareApplication' | 'Product';
    /** Entity name. Defaults to `brand.name`. */
    name?: string;
    /** Job title — `Person` only. Localized. */
    jobTitle?: LocalizedString;
    /** Logo/avatar/app icon (absolute URL or path resolved against `siteUrl`). Defaults to `brand.logoUrl`. ≥112×112 for Google. */
    image?: string;
    /** Profile URLs (`sameAs`). Defaults to the `social[]` URLs. `Organization`/`Person` only. */
    sameAs?: string[];
    /** Contact email. Defaults to `contact.email`. `Organization`/`Person` only. */
    email?: string;

    // ── SoftwareApplication / Product only (all optional) ──
    /** App category, e.g. `'BusinessApplication'`. `SoftwareApplication`/`Product`. */
    applicationCategory?: string;
    /** App sub-category, e.g. `'AI Business Process Management'`. */
    applicationSubCategory?: string;
    /** Supported OS, e.g. `'Any'`. Defaults to `'Any'` for `SoftwareApplication`. */
    operatingSystem?: string;
    /** Languages the app supports (`inLanguage`). Defaults to `config.languages`. */
    inLanguage?: string[];
    /** A single `Offer` (price + availability) for product rich-results. */
    offers?: {
        /** Numeric price as a string, e.g. `'100'`. */
        price: string;
        /** ISO 4217 currency code, e.g. `'USD'`. */
        priceCurrency: string;
        /** Schema.org availability URL, e.g. `'https://schema.org/PreOrder'` | `InStock`. */
        availability?: string;
        /** Optional offer URL. */
        url?: string;
    };
}

/**
 * Everything-SEO for a site: head meta + Open Graph + Twitter/X cards + multilingual
 * hreflang + JSON-LD structured data, plus `sitemap.xml`/`robots.txt` generation. All
 * externally validatable (Rich Results Test, schema.org validator, Lighthouse SEO).
 * Content fields accept a `LocalizedString` so one config covers every language.
 * Adaptive: with no `seo`, only sensible derivations from `brand` are emitted.
 */
export interface SiteKitSeo {
    /** `<title>`. Localized. Falls back to `brand.name` (+ `· tagline`). */
    title?: LocalizedString;
    /** Title template for inner pages, `%s` = page title: `'%s — ilia.ae'`. */
    titleTemplate?: string;
    /** Meta description (~150–160 chars). Localized. Falls back to `brand.tagline`. */
    description?: LocalizedString;
    /**
     * Absolute site origin, no trailing slash: `'https://ilia.ae'`. Drives canonical,
     * `og:url`, hreflang and the sitemap. Falls back to `brand.url`.
     */
    siteUrl?: string;
    /** `robots` directive. Default `'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'`. */
    robots?: string;
    /** `<meta name="author">` (e.g. the company/person behind the site). */
    author?: string;
    /** `<meta name="referrer">` policy (e.g. `'strict-origin-when-cross-origin'`). */
    referrer?: string;
    /** Social share image — 1200×630 (absolute URL or path resolved against `siteUrl`). */
    image?: string;
    /**
     * Auto-generate the OG banner (1200×630) from brand + theme (no hand-made image):
     * the build emits `og.svg`/`og.png` next to the favicons and `og:image` points at
     * `<favicon.path>/og.png`. An explicit `image` always wins. See tools/lib/og.mjs.
     */
    ogImage?: boolean;
    /** `og:image:alt` / `twitter:image:alt`. Localized. */
    imageAlt?: LocalizedString;
    /** `og:type`. Default `'website'`. */
    ogType?: string;
    /** Twitter card type. Default `'summary_large_image'` when an image exists, else `'summary'`. */
    twitterCard?: 'summary' | 'summary_large_image';
    /** `@handle` for `twitter:site` (the site's account). */
    twitterSite?: string;
    /** `@handle` for `twitter:creator` (the author). */
    twitterCreator?: string;
    /** Structured-data entity → JSON-LD `@graph` (entity + `WebSite`). Omit to skip JSON-LD. */
    entity?: SiteKitSeoEntity;
    /** Emit `hreflang` alternates (incl. `x-default`) from `languages`/`defaultLang`. Default true when >1 language. */
    hreflang?: boolean;
    /**
     * Map a language code to an `og:locale` territory value (underscore form):
     * `{ en: 'en_US', ru: 'ru_RU' }`. Built-in defaults cover the kit's 7 languages.
     */
    locales?: Record<string, string>;
    /** Emit `sitemap.xml` + `robots.txt` (static generator). Default true when `siteUrl` is known. */
    sitemap?: boolean;
}

// ─── PWA — installable app (ANGULAR-ONLY) ────────────────────────────
/** A manifest app-shortcut (jump-list entry). */
export interface SiteKitPwaShortcut {
    name: string;
    shortName?: string;
    description?: string;
    /** In-app URL the shortcut opens (e.g. `/verify`, `/#contact`). */
    url: string;
}

/**
 * Installable-app (PWA) module — **Angular sites only** (uses `@angular/service-worker`
 * / ngsw; not available for the static WP/aaPanel output). Turns a kit-driven Angular
 * app into an installable PWA: an enriched web manifest (display/shortcuts/categories…),
 * a service worker (ngsw), an install prompt (`ik-install` + `Pwa` service), iOS
 * `apple-mobile-web-app-*` chrome + splash screens. Icons come from `config.favicon`.
 *
 * Enable with `provideSiteKitPwa()` in the app config (+ `serviceWorker: "ngsw-config.json"`
 * in angular.json). The static generator ignores this block.
 */
export interface SiteKitPwa {
    /** Manifest `name` (defaults to `favicon.name` / `brand.name`). */
    name?: string;
    /** Manifest `short_name` (defaults to `name`). */
    shortName?: string;
    /** Manifest `description`. Localized. Falls back to `seo.description` / `brand.tagline`. */
    description?: LocalizedString;
    /** `display` mode. Default `standalone`. */
    display?: 'standalone' | 'minimal-ui' | 'fullscreen' | 'browser';
    /** `display_override` progressive list, e.g. `['window-controls-overlay', 'standalone']`. */
    displayOverride?: string[];
    /** `orientation`. Default `any`. */
    orientation?: 'any' | 'natural' | 'portrait' | 'landscape' | 'portrait-primary' | 'landscape-primary';
    /** `start_url`. Default `/`. */
    startUrl?: string;
    /** `scope`. Default `/`. */
    scope?: string;
    /** App-store `categories`, e.g. `['productivity', 'utilities']`. */
    categories?: string[];
    /** App `shortcuts` (jump list). */
    shortcuts?: SiteKitPwaShortcut[];
    /** Splash `background_color` (default `favicon.background` → theme `--brand` → `#ffffff`). */
    backgroundColor?: string;
    /** iOS status-bar style. Default `black-translucent`. */
    appleStatusBarStyle?: 'default' | 'black' | 'black-translucent';
    /** Generate + link `apple-touch-startup-image` splash screens (from the favicon SVG). Default true. */
    splash?: boolean;
    /** Register the service worker (ngsw). Default true. */
    serviceWorker?: boolean;
    /** Show the install UI (`ik-install`). Default true. */
    install?: boolean;
}

/**
 * Cookie / privacy consent banner — ANGULAR-ONLY (`ik-cookie-consent`). Self-contained:
 * remembers the choice in localStorage, GDPR-symmetric Accept/Reject, a close (×) that
 * means "essential only" (= reject), an optional `autoCloseMs` timer (also = reject), and
 * a "learn more" button that opens the FULL localized cookie policy in-app (`policyBody`),
 * optionally with a per-language link to the official full version (`policyHref`). Built-in
 * texts localize across the 7 languages; override any per language. Non-Angular sites use
 * their own banner.
 */
/** A locale-aware URL (no label) — the URL adapts to the site language. Resolved by `resolveLinkHref`. */
export interface SiteKitLocalizedUrl {
    url: string;
    /** Insert `/<lang>` for non-default languages. */
    localize?: boolean;
    /** Per-language path modifier appended to the URL's domain. */
    pathByLang?: Record<string, string>;
    /** Explicit per-language URLs (wins over everything). */
    urls?: Record<string, string>;
}

export interface SiteKitCookie {
    /** The FULL cookie policy, shown in the in-app "learn more" panel. Localized; blank lines separate paragraphs. Omit to use the built-in localized full policy. */
    policyBody?: LocalizedString;
    /**
     * Optional link to the OFFICIAL full policy, shown inside the panel. Locale-aware, same
     * rules as {@link SiteKitLink}: `urls` → `pathByLang` → `localize` → `url`. The URL adapts
     * to the site language (e.g. `{ url: 'https://site/privacy', localize: true }` → en: `/en/privacy`).
     */
    policyHref?: SiteKitLocalizedUrl;
    /** Banner body text. Localized; omit to use the built-in localized copy. */
    message?: LocalizedString;
    /** Accept-all button label. Localized. */
    accept?: LocalizedString;
    /** Reject (essential-only) button label. Localized. */
    reject?: LocalizedString;
    /** "Learn more" link label. Localized. */
    more?: LocalizedString;
    /** Banner placement. `bottom` (centered bar, default) or `corner` (bottom-left card). */
    position?: 'bottom' | 'corner';
    /** Auto-dismiss after N ms — treated as REJECT (essential only). Omit/0 = no timer. */
    autoCloseMs?: number;
}

/**
 * Schema version of the config CONTRACT. Bump when the shape gains/changes fields.
 * Each site's data file should declare the `schemaVersion` it was written for; the
 * inventory dashboard (tools/inventory.mjs) compares it to this to flag stale data.
 *   1 = initial config (status/footer/contact/social/legal)
 *   2 = + nav, projects, languages/defaultLang, locale links, rich contact
 *   3 = + theme design layer, status redirect/back, strings overrides
 *   4 = + deploy layer: target git/cloudflare/wp, configurable /kit path
 *   5 = + technologies tech-stack block / footer badges
 *   6 = + favicon icon-set + seo head/OG/Twitter/hreflang/JSON-LD/sitemap
 *   7 = + pwa installable-app module — Angular-only: manifest/ngsw/install/splash
 *   8 = + seo.ogImage — auto-generated OG banner from brand/theme
 *   9 = + cookie consent module (Angular-only) — config.cookie
 *  10 = + cookie.policyBody — in-app localized "learn more" policy panel
 *  11 = cookie "learn more" = FULL in-app localized policy; removed cookie.policyHref
 *  12 = status auto-redirect ON by default (DEFAULT_REDIRECT_SECONDS); { delaySeconds: 0 } disables
 *  13 = cookie.policyHref — optional locale-aware link to the official full policy
 *  14 = config.license — license type key (text pulled from the license bank)
 *  15 = brand.nameHidden / footer.compact — minimal chrome + compact footer mode
 *  16 = verify — live build-integrity status on the brand/footer surfaces
 *  17 = footer.projects — built-in "our projects" family row (real-logo chips)
 *  18 = seo.entity.type 'SoftwareApplication'/'Product' — product rich-results (offers, category)
 */
export const SITE_KIT_SCHEMA_VERSION = 18;

/** Module version (kept in sync with package.json; stamped into a <meta> for the live dashboard check). */
export const SITE_KIT_VERSION = '1.50.1';

// ─── Root config ──────────────────────────────────────────────
export interface SiteKitConfig {
    /** Schema version this data file targets (see SITE_KIT_SCHEMA_VERSION). */
    schemaVersion?: number;
    brand: SiteKitBrand;
    copyright?: SiteKitCopyright;
    contact?: SiteKitContact;
    social?: SiteKitSocialLink[];
    legal?: SiteKitLegalLink[];
    /** License type key (e.g. 'mit', 'proprietary', 'source-available-commercial') — its text
     *  lives in the license bank (../main/github_inventory/licenses); shown as a footer/notice. */
    license?: string;
    /** Rich multi-column footer (brand + columns + bottom bar). */
    footer?: SiteKitFooter;
    /**
     * "IA · site-kit" signature badge in the footer — the library's own mark (this kit IS
     * the badge). Shown by DEFAULT in every project; set `false` to hide, or pass an object
     * to customise the link/label/monogram.
     */
    signature?: boolean | SiteKitSignature;
    nav?: SiteKitNavItem[];
    projects?: SiteKitProject[];
    /** Tech stack — rendered as linked badges by `ik-technologies` (and the footer). */
    technologies?: SiteKitTech[];
    /** PageSpeed Insights score badge(s) in the footer bottom-bar (mobile/desktop), with a re-test link. */
    pageSpeed?: SiteKitPageSpeed;
    status?: SiteKitStatusOptions;
    /** Codes of languages this site offers (subset of IK_LANGUAGES). Defaults to all 7. */
    languages?: string[];
    /** Default language — links for it are NOT prefixed. */
    defaultLang?: string;
    /** Override built-in UI strings per language: `{ ru: { share: '…' } }`. */
    strings?: Record<string, Record<string, string>>;
    /**
     * DESIGN layer — CSS custom properties applied to <html> for this bundle, so
     * one config drives content AND design: `{ '--brand': '#5b43ad', '--r-lg': '20px' }`.
     * Base these on each site's real brand (e.g. mayday red, monolith #5b43ad).
     */
    theme?: Record<string, string>;
    /** How the static error/QR bundle is delivered (git / cloudflare / wp) + its path. */
    deploy?: SiteKitDeploy;
    /** Favicon + app-icon set generated from one SVG (head `<link>`s + manifest). */
    favicon?: SiteKitFavicon;
    /** All-site SEO: head meta + Open Graph + Twitter + hreflang + JSON-LD + sitemap. */
    seo?: SiteKitSeo;
    /** Installable-app (PWA) module — ANGULAR-ONLY (ngsw + manifest + install + splash). */
    pwa?: SiteKitPwa;
    /** Cookie/privacy consent banner — ANGULAR-ONLY (localized text, policy link, auto-close). */
    cookie?: SiteKitCookie;
    /** Live build-integrity check (manifest fetch + SHA-256 of running bundles) → `ik-verify-mark`. */
    verify?: SiteKitVerify;
}

/** Resolved shape: defaults applied so components never face `undefined` for derivable fields. */
export interface ResolvedSiteKitConfig extends SiteKitConfig {
    copyright: Required<Pick<SiteKitCopyright, 'holder'>> & SiteKitCopyright;
    social: SiteKitSocialLink[];
    legal: SiteKitLegalLink[];
    nav: SiteKitNavItem[];
    projects: SiteKitProject[];
    technologies: SiteKitTech[];
    languages: string[];
    defaultLang: string;
    status: Required<Pick<SiteKitStatusOptions, 'homeHref' | 'languages'>> & SiteKitStatusOptions;
    deploy: Required<Pick<SiteKitDeploy, 'target' | 'path'>> & SiteKitDeploy;
}

/** DI token holding the resolved, defaults-applied configuration. */
export const SITE_KIT_CONFIG = new InjectionToken<ResolvedSiteKitConfig>('SITE_KIT_CONFIG');

/**
 * Applies derived defaults so consumers can pass a minimal config. Pure, no side effects.
 * NOTE: `static/generate.mjs` mirrors this logic inline (a .mjs can't import this .ts) —
 * keep the two in sync when changing defaults.
 */
export function resolveSiteKitConfig(config: SiteKitConfig): ResolvedSiteKitConfig {
    const languages = config.languages?.length ? config.languages : IK_LANGUAGES.map((l) => l.code);
    // safe: `languages` is guaranteed non-empty above (falls back to every IK_LANGUAGES code), so languages[0] is always defined.
    const defaultLang = config.defaultLang ?? languages[0]!;
    return {
        ...config,
        copyright: {
            holder: config.copyright?.holder ?? config.brand.name,
            startYear: config.copyright?.startYear,
            suffix: config.copyright?.suffix,
        },
        social: config.social ?? [],
        legal: config.legal ?? [],
        nav: config.nav ?? [],
        projects: config.projects ?? [],
        technologies: config.technologies ?? [],
        languages,
        defaultLang,
        status: {
            homeHref: config.status?.homeHref ?? config.brand.url ?? '/',
            homeLabel: config.status?.homeLabel, // left undefined → status page localizes via ikString
            languages: config.status?.languages ?? languages,
            supportLine: config.status?.supportLine,
            redirect: config.status?.redirect,
            showBack: config.status?.showBack ?? true,
        },
        deploy: {
            target: config.deploy?.target ?? 'git',
            path: config.deploy?.path ?? '/kit',
            routes: config.deploy?.routes,
            zone: config.deploy?.zone,
        },
    };
}
