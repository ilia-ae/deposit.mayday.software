/**
 * Built-in technology catalog — label + canonical URL + inline SVG (currentColor)
 * per known `kind`. Trusted constants (rendered via innerHTML), exactly like
 * social-icons. A config tech with an unknown/absent kind falls back to TECH_FALLBACK
 * (a generic tag glyph) and can override the icon/url itself.
 *
 * Brand marks (angular/typescript/go/bitcoin) are real single-path logos (Simple Icons, CC0); the rest use
 * clean geometric glyphs — the badge always shows the NAME, so meaning never depends
 * on the icon alone. Override any with `{ icon: '<svg…>' | 'https://…' }`.
 */
export interface TechMeta {
    label: string;
    url: string;
    svg: string;
}

export const TECH_ICONS: Record<string, TechMeta> = {
    angular: {
        label: 'Angular',
        url: 'https://angular.dev',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9.931 12.645h4.138l-2.07-4.908m0-7.737L.68 3.982l1.726 14.771L12 24l9.596-5.247L23.32 3.982 11.999 0zm7.064 18.31h-2.638l-1.422-3.503H8.996l-1.422 3.504h-2.64L12 2.65z"/></svg>`,
    },
    typescript: {
        label: 'TypeScript',
        url: 'https://www.typescriptlang.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M1.125 0C.502 0 0 .502 0 1.125v21.75C0 23.498.502 24 1.125 24h21.75c.623 0 1.125-.502 1.125-1.125V1.125C24 .502 23.498 0 22.875 0zm17.363 9.75c.612 0 1.154.037 1.627.111a6.38 6.38 0 0 1 1.306.34v2.458a3.95 3.95 0 0 0-.643-.361 5.093 5.093 0 0 0-.717-.26 5.453 5.453 0 0 0-1.426-.2c-.3 0-.573.028-.819.086a2.1 2.1 0 0 0-.623.242c-.17.104-.3.229-.393.374a.888.888 0 0 0-.14.49c0 .196.053.373.156.529.104.156.252.304.443.444s.423.276.696.41c.273.135.582.274.926.416.47.197.892.407 1.266.628.374.222.695.473.963.753.268.279.472.598.614.957.142.359.214.776.214 1.253 0 .657-.125 1.21-.373 1.656a3.033 3.033 0 0 1-1.012 1.085 4.38 4.38 0 0 1-1.487.596c-.566.12-1.163.18-1.79.18a9.916 9.916 0 0 1-1.84-.164 5.544 5.544 0 0 1-1.512-.493v-2.63a5.033 5.033 0 0 0 3.237 1.2c.333 0 .624-.03.872-.09.249-.06.456-.144.623-.25.166-.108.29-.234.373-.38a1.023 1.023 0 0 0-.074-1.089 2.12 2.12 0 0 0-.537-.5 5.597 5.597 0 0 0-.807-.444 27.72 27.72 0 0 0-1.007-.436c-.918-.383-1.602-.852-2.053-1.405-.45-.553-.676-1.222-.676-2.005 0-.614.123-1.141.369-1.582.246-.441.58-.804 1.004-1.089a4.494 4.494 0 0 1 1.47-.629 7.536 7.536 0 0 1 1.77-.201zm-15.113.188h9.563v2.166H9.506v9.646H6.789v-9.646H3.375z"/></svg>`,
    },
    javascript: {
        label: 'JavaScript',
        url: 'https://developer.mozilla.org/docs/Web/JavaScript',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
    },
    node: {
        label: 'Node.js',
        url: 'https://nodejs.org',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 2 21 7v10l-9 5-9-5V7l9-5Z"/></svg>`,
    },
    cloudflare: {
        label: 'Cloudflare',
        url: 'https://www.cloudflare.com',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 17.5H7.2a4 4 0 1 1 1-7.87A6 6 0 0 1 19.8 11.6 3.45 3.45 0 0 1 19 17.5Z"/></svg>`,
    },
    wordpress: {
        label: 'WordPress',
        url: 'https://wordpress.org',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m5.5 8 3 8.5L11 9l2.5 7.5 3-8.5"/></svg>`,
    },
    bitcoin: {
        label: 'Bitcoin',
        url: 'https://bitcoin.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.638 14.904c-1.602 6.43-8.113 10.34-14.542 8.736C2.67 22.05-1.244 15.525.362 9.105 1.962 2.67 8.475-1.243 14.9.358c6.43 1.605 10.342 8.115 8.738 14.546zm-6.35-4.613c.24-1.59-.974-2.45-2.64-3.03l.54-2.153-1.315-.33-.525 2.107c-.345-.087-.7-.17-1.053-.252l.53-2.12-1.313-.33-.54 2.152c-.286-.065-.567-.13-.84-.2l.001-.007-1.812-.452-.35 1.407s.975.224.955.238c.535.136.63.494.614.778l-.614 2.456c.037.01.083.024.135.046l-.137-.035-.86 3.456c-.065.16-.23.4-.6.308.013.02-.956-.239-.956-.239l-.652 1.514 1.71.427.937.24-.546 2.19 1.313.328.54-2.157c.36.1.708.19 1.05.273l-.538 2.155 1.315.33.546-2.183c2.245.424 3.93.253 4.64-1.774.57-1.637-.03-2.58-1.217-3.196.867-.2 1.52-.77 1.694-1.94z"/></svg>`,
    },
    ethereum: {
        label: 'Ethereum',
        url: 'https://ethereum.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 6 12l6 3.5L18 12 12 2Zm-6 11.3L12 22l6-8.7-6 3.5-6-3.5Z"/></svg>`,
    },
    ton: {
        label: 'TON',
        url: 'https://ton.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 7h16L12 21 4 7Zm3.2 1.6L12 17l4.8-8.4H7.2Z"/></svg>`,
    },
    postgres: {
        label: 'PostgreSQL',
        url: 'https://www.postgresql.org',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.66 3.58 3 8 3s8-1.34 8-3V5"/><path d="M4 12c0 1.66 3.58 3 8 3s8-1.34 8-3"/></svg>`,
    },
    redis: {
        label: 'Redis',
        url: 'https://redis.io',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="6" rx="9" ry="3"/><path d="M3 6v12c0 1.66 4.03 3 9 3s9-1.34 9-3V6"/><path d="M3 12c0 1.66 4.03 3 9 3s9-1.34 9-3"/></svg>`,
    },
    go: {
        label: 'Go',
        url: 'https://go.dev',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M1.811 10.231c-.047 0-.058-.023-.035-.059l.246-.315c.023-.035.081-.058.128-.058h4.172c.046 0 .058.035.035.07l-.199.303c-.023.036-.082.07-.117.07zM.047 11.306c-.047 0-.059-.023-.035-.058l.245-.316c.023-.035.082-.058.129-.058h5.328c.047 0 .07.035.058.07l-.093.28c-.012.047-.058.07-.105.07zm2.828 1.075c-.047 0-.059-.035-.035-.07l.163-.292c.023-.035.07-.07.117-.07h2.337c.047 0 .07.035.07.082l-.023.28c0 .047-.047.082-.082.082zm12.129-2.36c-.736.187-1.239.327-1.963.514-.176.046-.187.058-.34-.117-.174-.199-.303-.327-.548-.444-.737-.362-1.45-.257-2.115.175-.795.514-1.204 1.274-1.192 2.22.011.935.654 1.706 1.577 1.835.795.105 1.46-.175 1.987-.77.105-.13.198-.27.315-.434H10.47c-.245 0-.304-.152-.222-.35.152-.362.432-.97.596-1.274a.315.315 0 01.292-.187h4.253c-.023.316-.023.631-.07.947a4.983 4.983 0 01-.958 2.29c-.841 1.11-1.94 1.8-3.33 1.986-1.145.152-2.209-.07-3.143-.77-.865-.655-1.356-1.52-1.484-2.595-.152-1.274.222-2.419.993-3.424.83-1.086 1.928-1.776 3.272-2.02 1.098-.2 2.15-.07 3.096.571.62.41 1.063.97 1.356 1.648.07.105.023.164-.117.2m3.868 6.461c-1.064-.024-2.034-.328-2.852-1.029a3.665 3.665 0 01-1.262-2.255c-.21-1.32.152-2.489.947-3.529.853-1.122 1.881-1.706 3.272-1.95 1.192-.21 2.314-.095 3.33.595.923.63 1.496 1.484 1.648 2.605.198 1.578-.257 2.863-1.344 3.962-.771.783-1.718 1.273-2.805 1.495-.315.06-.63.07-.934.106zm2.78-4.72c-.011-.153-.011-.27-.034-.387-.21-1.157-1.274-1.81-2.384-1.554-1.087.245-1.788.935-2.045 2.033-.21.912.234 1.835 1.075 2.21.643.28 1.285.244 1.905-.07.923-.48 1.425-1.228 1.484-2.233z"/></svg>`,
    },
    docker: {
        label: 'Docker',
        url: 'https://www.docker.com',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="11" width="3" height="3" rx=".4"/><rect x="6.6" y="11" width="3" height="3" rx=".4"/><rect x="10.2" y="11" width="3" height="3" rx=".4"/><rect x="10.2" y="7.4" width="3" height="3" rx=".4"/><rect x="13.8" y="11" width="3" height="3" rx=".4"/><path d="M17.5 12.5c.9-.6 1.6-.2 1.9.1.3-.7 1.1-.6 1.4-.3-.2 1.6-1.6 2.7-3.6 2.7-3 .2-5.6-1-6.9-3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>`,
    },
    rust: {
        label: 'Rust',
        url: 'https://www.rust-lang.org',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="9.2"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4" stroke-linecap="round"/></svg>`,
    },
    tailwind: {
        label: 'Tailwind',
        url: 'https://tailwindcss.com',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12.001,4.8c-3.2,0-5.2,1.6-6,4.8c1.2-1.6,2.6-2.2,4.2-1.8c.913,.228,1.565,.89,2.288,1.624C13.666,10.618,15.027,12,18.001,12c3.2,0,5.2-1.6,6-4.8-1.2,1.6-2.6,2.2-4.2,1.8-.913-.228-1.565-.89-2.288-1.624C16.337,6.182,14.976,4.8,12.001,4.8ZM6.001,12c-3.2,0-5.2,1.6-6,4.8,1.2-1.6,2.6-2.2,4.2-1.8,.913,.228,1.565,.89,2.288,1.624,1.177,1.194,2.538,2.576,5.512,2.576,3.2,0,5.2-1.6,6-4.8-1.2,1.6-2.6,2.2-4.2,1.8-.913-.228-1.565-.89-2.288-1.624C10.337,13.382,8.976,12,6.001,12Z"/></svg>`,
    },
    // Tabler's own mark (icon "brand-tabler" from @tabler/icons, MIT).
    tabler: {
        label: 'Tabler',
        url: 'https://tabler.io',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 9l3 3l-3 3"/><path d="M13 15h3"/><path d="M4 8a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v8a4 4 0 0 1-4 4h-8a4 4 0 0 1-4-4z"/></svg>`,
    },
    selectel: {
        label: 'Selectel',
        url: 'https://selectel.ru',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M2 5h20v3H2zm0 5.5h20v3H2zM2 16h20v3H2zM4 6.5h2v1H4zm4 0h8v1H8zM4 12h2v1H4zm4 0h8v1H8zM4 17.5h2v1H4zm4 0h8v1H8z"/></svg>`,
    },
    // Common site/footer marks (not strictly "tech", but frequently badged next to the stack).
    brandbook: {
        label: 'Brandbook',
        url: '',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 2h11a3 3 0 0 1 3 3v15a2 2 0 0 1-2 2H7a3 3 0 0 1-3-3V5a3 3 0 0 1 2-2.83V2zm0 2.17C5.4 4.39 5 4.94 5 5.5V18a2 2 0 0 1 2-2h11V5a2 2 0 0 0-2-2H6v1.17zM7 17a1 1 0 0 0 0 2h11v-2H7z"/></svg>`,
    },
    onion: {
        label: '.onion',
        url: 'https://www.torproject.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 4a8 8 0 1 1 0 16 8 8 0 0 1 0-16zm0 3a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 3a2 2 0 1 1 0 4 2 2 0 0 1 0-4z"/></svg>`,
    },
};

/** Generic tag glyph for technologies without a built-in icon. */
export const TECH_FALLBACK = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 13.4 11 3.8a2 2 0 0 0-1.4-.6H4a1 1 0 0 0-1 1v5.6a2 2 0 0 0 .6 1.4l9.6 9.6a2 2 0 0 0 2.8 0l4.6-4.6a2 2 0 0 0 0-2.8Z"/><circle cx="7.5" cy="7.5" r="1.3" fill="currentColor"/></svg>`;

/** Brand accent per known kind — used to tint a badge on hover (like the reference footer). */
export const TECH_COLORS: Record<string, string> = {
    angular: '#dd0031',
    typescript: '#3178c6',
    javascript: '#f7df1e',
    node: '#5fa04e',
    cloudflare: '#f38020',
    wordpress: '#21759b',
    bitcoin: '#f7931a',
    ethereum: '#627eea',
    ton: '#0098ea',
    postgres: '#336791',
    redis: '#dc382d',
    go: '#00add8',
    docker: '#2496ed',
    rust: '#ce422b',
    tailwind: '#38bdf8',
    tabler: '#066fd1',
    onion: '#7d4698',
};
