#!/usr/bin/env node
/**
 * site-kit-static — generate branded STATIC error/status pages from a SiteKitConfig,
 * straight out of the installed @ilia-ae/site-kit package, into a consumer's webroot.
 *
 * The companion to the in-app `<ik-status-page>`: an Angular SPA on nginx/aaPanel can't
 * serve `error_page 500 …` from a runtime component, so this emits the same pages as
 * self-contained .html (+ an nginx snippet) that ride the site's ordinary git deploy.
 *
 * Usage:
 *   npx site-kit-static --config <file.json|.mjs|.js> --out <dir> [--base /kit] [--target git]
 *
 *   --config   SiteKitConfig: a .json file, OR an .mjs/.js with `export default <config>`.
 *   --out      output directory — becomes the `/kit` folder in your webroot
 *              (e.g. Angular `public/kit`, shipped to disk by `ng build`).
 *   --base     public base path the pages live at (default /kit) — must match --out's
 *              served location so the generated nginx `error_page` paths resolve.
 *   --target   git | cloudflare | wp (default git).
 *
 *   npx site-kit-static --footer-bar --config <file> --out <dir> [--lang ru] [--icons-only]
 *
 *   --footer-bar  only the compact footer as static HTML + CSS (static/footer-bar.mjs): for an admin
 *                 panel that wants the kit's footer without the kit — no JS, strict-CSP safe.
 *   --icons-only  with --footer-bar: one line, the badges as bare icons with the name and version as
 *                 a tooltip on hover/focus (CSS only).
 *   --into        with --footer-bar: also put the bar into this HTML file, between
 *                 <!-- ik-footer-bar --> and <!-- /ik-footer-bar --> (added before </body> the first
 *                 time), so a re-run replaces it in place.
 *
 * It wraps the repo's static generator (generate.mjs) — same single source of truth — by
 * pointing it at a resolved temp config + temp out (its env interface), then lifting the
 * deploy bundle into --out. `npm run build:static` (env-driven) keeps working unchanged.
 */
import { parseArgs } from 'node:util';
import { readFileSync, writeFileSync, mkdirSync, rmSync, cpSync, existsSync, readdirSync } from 'node:fs';
import { dirname, join, resolve, isAbsolute, extname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { tmpdir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));

const USAGE = `site-kit-static — branded static error/status pages from a SiteKitConfig

Usage:
  site-kit-static --config <file.json|.mjs|.js> --out <dir> [--base /kit] [--target git]

  --config, -c   SiteKitConfig: .json, or .mjs/.js with \`export default\`
  --out,    -o   output dir (becomes the /kit folder in your webroot)
  --base         public base path for the pages (default /kit)
  --target       git | cloudflare | wp (default git)
  --footer-bar   only footer-bar.html + footer-bar.css (the compact footer, no JS)
  --lang         language of the footer bar's text (default: the config's defaultLang)
  --icons-only   with --footer-bar: one line, icons with a tooltip instead of labelled badges
  --into         with --footer-bar: put the bar into this HTML file (between ik-footer-bar markers)
  --help,   -h   show this help`;

const { values } = parseArgs({
    options: {
        config: { type: 'string', short: 'c' },
        out: { type: 'string', short: 'o' },
        base: { type: 'string' },
        target: { type: 'string' },
        'footer-bar': { type: 'boolean' },
        'icons-only': { type: 'boolean' },
        lang: { type: 'string' },
        into: { type: 'string' },
        help: { type: 'boolean', short: 'h' },
    },
});

if (values.help) {
    console.log(USAGE);
    process.exit(0);
}
if (!values.config || !values.out) {
    console.error('✗ --config and --out are required.\n');
    console.error(USAGE);
    process.exit(1);
}

const abs = (p) => (isAbsolute(p) ? p : resolve(process.cwd(), p));
const configPath = abs(values.config);
const outDir = abs(values.out);

if (!existsSync(configPath)) {
    console.error(`✗ config not found: ${configPath}`);
    process.exit(1);
}

/** Load a SiteKitConfig from JSON, or an .mjs/.js module's default export. */
async function loadConfig(p) {
    const ext = extname(p).toLowerCase();
    if (ext === '.json') return JSON.parse(readFileSync(p, 'utf8'));
    if (ext === '.mjs' || ext === '.js') {
        const mod = await import(pathToFileURL(p).href);
        if (!mod.default) {
            throw new Error(`${p} has no default export — use \`export default yourSiteKitConfig\``);
        }
        return mod.default;
    }
    throw new Error(`unsupported --config extension "${ext}" (use .json, .mjs or .js)`);
}

let config;
try {
    config = await loadConfig(configPath);
} catch (e) {
    console.error(`✗ could not load config: ${e.message}`);
    process.exit(1);
}

if (values['footer-bar']) {
    const { buildFooterBar } = await import(pathToFileURL(join(HERE, 'footer-bar.mjs')).href);
    // the kit's version: the installed package's root package.json, else the repo's library one
    const pkgOf = (p) => (existsSync(p) ? JSON.parse(readFileSync(p, 'utf8')) : null);
    const pkg = [join(HERE, '..', 'package.json'), join(HERE, '..', 'projects/site-kit/package.json')]
        .map(pkgOf)
        .find((p) => p?.name === '@ilia-ae/site-kit');
    const { html, css, warnings } = buildFooterBar(config, {
        kitVersion: pkg?.version ?? '',
        lang: values.lang,
        iconsOnly: values['icons-only'] ?? false,
    });
    mkdirSync(outDir, { recursive: true });
    writeFileSync(join(outDir, 'footer-bar.html'), html);
    writeFileSync(join(outDir, 'footer-bar.css'), css);
    for (const w of warnings) console.warn(`⚠ ${w}`);
    console.log(`✓ footer bar → ${join(outDir, 'footer-bar.html')} + footer-bar.css`);
    if (values.into) {
        const page = abs(values.into);
        const doc = readFileSync(page, 'utf8');
        const block = `<!-- ik-footer-bar -->\n${html}<!-- /ik-footer-bar -->`;
        const marked = /<!-- ik-footer-bar -->[\s\S]*?<!-- \/ik-footer-bar -->/;
        let next;
        if (marked.test(doc)) next = doc.replace(marked, () => block);
        else if (/<\/body>/i.test(doc))
            next = doc.replace(/([ \t]*)<\/body>/i, (m, indent) => `${block}\n${indent}</body>`);
        else {
            console.error(`✗ ${page}: no </body> and no ik-footer-bar markers to put the bar between`);
            process.exit(1);
        }
        writeFileSync(page, next);
        console.log(`✓ footer bar put into ${page}`);
    }
    console.log(
        '  paste the HTML where the footer goes; link the CSS once (<link rel="stylesheet" href="…/footer-bar.css">)',
    );
    process.exit(0);
}

const target = values.target ?? config.deploy?.target ?? 'git';
const base = (values.base ?? config.deploy?.path ?? '/kit').replace(/\/+$/, '') || '/kit';
// Flags win over the config's own deploy block so the generator emits at the requested base/target.
config.deploy = { ...(config.deploy ?? {}), target, path: base };

// Temp workspace: a resolved config JSON + an out dir for the generator's env interface.
const work = join(tmpdir(), `site-kit-static-${process.pid}-${Date.now()}`);
const tmpConfig = join(work, 'config.json');
const tmpOut = join(work, 'out');
mkdirSync(work, { recursive: true });
writeFileSync(tmpConfig, JSON.stringify(config, null, 2));

// generate.mjs is a one-shot script that reads SITE_KIT_CONFIG/OUT at module-eval — set
// them BEFORE the dynamic import so the run targets our temp workspace.
process.env.SITE_KIT_CONFIG = tmpConfig;
process.env.SITE_KIT_OUT = tmpOut;
try {
    await import(pathToFileURL(join(HERE, 'generate.mjs')).href);
} catch (e) {
    console.error(`✗ generation failed: ${e.message}`);
    rmSync(work, { recursive: true, force: true });
    process.exit(1);
}

// Lift the deploy bundle into --out. For git/wp the pages live under <base>/; the deploy
// helpers sit at the bundle root. For cloudflare the whole bundle (worker.js …) is the unit.
const bundle = join(tmpOut, target);
const baseFolder = base.replace(/^\/+/, '');
mkdirSync(outDir, { recursive: true });
const copyInto = (srcDir, dstDir) => {
    for (const entry of readdirSync(srcDir, { withFileTypes: true })) {
        cpSync(join(srcDir, entry.name), join(dstDir, entry.name), { recursive: true });
    }
};

if (target === 'cloudflare') {
    copyInto(bundle, outDir);
} else {
    const pagesDir = join(bundle, baseFolder);
    if (!existsSync(pagesDir)) {
        console.error(`✗ expected bundle pages at ${pagesDir} — nothing generated.`);
        rmSync(work, { recursive: true, force: true });
        process.exit(1);
    }
    copyInto(pagesDir, outDir);
    // Deploy helpers that live at the bundle root (not under <base>).
    for (const extra of ['deploy', '.htaccess', 'UPLOAD.md']) {
        const s = join(bundle, extra);
        if (existsSync(s)) cpSync(s, join(outDir, extra), { recursive: true });
    }
}

rmSync(work, { recursive: true, force: true });

const pages = readdirSync(outDir).filter((f) => f.endsWith('.html'));
console.log(`✓ site-kit-static → ${outDir}`);
console.log(`  ${pages.length} pages · target=${target} · base=${base}`);
if (target === 'git' && existsSync(join(outDir, 'deploy', 'nginx.snippet.conf'))) {
    console.log(`  nginx: paste ${join(outDir, 'deploy', 'nginx.snippet.conf')} into your server { } block`);
}
