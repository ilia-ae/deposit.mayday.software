<?php
/**
 * WordPress drop-in (wp-content/db-error.php) — the @ilia-ae/site-kit 503 page when the database
 * is unreachable. Included by wpdb::db_connect() / dead_db() before most of WordPress is loaded,
 * so only wp-includes/load.php functions; WordPress dies right after. 503 + Retry-After tells
 * crawlers it's temporary.
 *
 * Source: ilia-site-kit/static/deploy/wordpress/ — edit there, not on the server.
 */

defined( 'ABSPATH' ) || exit;

// WP-CLI and cron scripts must still see a failure, not an HTML page and exit code 0.
if ( ( defined( 'WP_CLI' ) && WP_CLI ) || 'cli' === PHP_SAPI ) {
	fwrite( STDERR, "Error: Error establishing a database connection.\n" );
	exit( 1 );
}

$site_kit_page = ( defined( 'SITE_KIT_ERROR_DIR' ) ? SITE_KIT_ERROR_DIR : ABSPATH . 'kit' ) . '/503.html';
$site_kit_uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
$site_kit_json = false !== strpos( $site_kit_uri, '/wp-json/' )
	|| isset( $_GET['rest_route'] )
	|| wp_doing_ajax()
	|| ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST )
	|| false !== strpos( isset( $_SERVER['HTTP_ACCEPT'] ) ? (string) $_SERVER['HTTP_ACCEPT'] : '', 'application/json' );

if ( ! headers_sent() ) {
	http_response_code( 503 );
	header( 'Retry-After: 300' );
	header( 'Cache-Control: no-store' );
	header( 'Content-Type: ' . ( $site_kit_json ? 'application/json' : 'text/html' ) . '; charset=UTF-8' );
}

if ( $site_kit_json ) {
	echo '{"code":"db_connect_fail","message":"Error establishing a database connection.","data":{"status":503}}';
} elseif ( is_readable( $site_kit_page ) ) {
	readfile( $site_kit_page );
} else {
	echo '<!doctype html><meta charset="utf-8"><title>Database Error</title><h1>Error establishing a database connection</h1>';
}
