<?php
/**
 * WordPress drop-in (wp-content/maintenance.php) — the @ilia-ae/site-kit maintenance page while
 * `.maintenance` exists (core / plugin / theme updates). Included by wp_maintenance() before most
 * of WordPress is loaded, so only wp-includes/load.php functions; WordPress dies right after, so
 * the 503 is sent here.
 *
 * Source: ilia-site-kit/static/deploy/wordpress/ — edit there, not on the server.
 */

defined( 'ABSPATH' ) || exit;

$site_kit_page = ( defined( 'SITE_KIT_ERROR_DIR' ) ? SITE_KIT_ERROR_DIR : ABSPATH . 'kit' ) . '/maintenance.html';
$site_kit_uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
$site_kit_json = false !== strpos( $site_kit_uri, '/wp-json/' )
	|| isset( $_GET['rest_route'] )
	|| wp_doing_ajax()
	|| ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST )
	|| false !== strpos( isset( $_SERVER['HTTP_ACCEPT'] ) ? (string) $_SERVER['HTTP_ACCEPT'] : '', 'application/json' );

if ( ! headers_sent() ) {
	http_response_code( 503 );
	header( 'Retry-After: 600' );
	header( 'Cache-Control: no-store' );
	header( 'Content-Type: ' . ( $site_kit_json ? 'application/json' : 'text/html' ) . '; charset=UTF-8' );
}

if ( $site_kit_json ) {
	echo '{"code":"maintenance","message":"Briefly unavailable for scheduled maintenance. Check back in a minute.","data":{"status":503}}';
} elseif ( is_readable( $site_kit_page ) ) {
	readfile( $site_kit_page );
} else {
	echo '<!doctype html><meta charset="utf-8"><title>Maintenance</title><h1>Briefly unavailable for scheduled maintenance. Check back in a minute.</h1>';
}
