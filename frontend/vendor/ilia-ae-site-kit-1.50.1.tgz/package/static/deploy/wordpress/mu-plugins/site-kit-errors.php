<?php
/**
 * Plugin Name: site-kit error pages
 * Description: Serves the @ilia-ae/site-kit status page (/kit/404.html, /kit/410.html) for WordPress 404s, with the real status.
 * Version:     1.0.0
 * Author:      @ilia-ae/site-kit
 *
 * Source: ilia-site-kit/static/deploy/wordpress/ — edit there, not on the server.
 *
 * nginx maps only ITS OWN errors to /kit/*.html (fastcgi_intercept_errors off), so WordPress keeps
 * real JSON errors on REST/AJAX and this plugin brands the front-end 404 instead. When the page is
 * not deployed it does nothing and the theme's 404.php renders as usual.
 */

defined( 'ABSPATH' ) || exit;

/** Absolute path of a deployed kit page, or '' when it is missing. */
function site_kit_error_page( $name ) {
	$dir  = defined( 'SITE_KIT_ERROR_DIR' ) ? SITE_KIT_ERROR_DIR : ABSPATH . 'kit';
	$file = $dir . '/' . $name . '.html';
	return is_readable( $file ) ? $file : '';
}

// Rank Math's 404 Monitor logs on `get_header`, which a static page never fires — move its capture
// onto our hook (only while the kit page is deployed) so 404s keep being recorded.
add_filter(
	'rank_math/404_monitor/hook',
	static function ( $hook ) {
		return site_kit_error_page( '404' ) ? 'site_kit_render_404' : $hook;
	}
);

// Last on template_redirect: canonical / old-slug / Rank Math redirects have already had their turn.
add_action(
	'template_redirect',
	static function () {
		if ( ! is_404() || is_feed() || is_robots() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		$logged = 'HEAD' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' );
		if ( is_embed() ) { // WordPress's own embed 404 template stays — but Rank Math still logs it
			if ( $logged && site_kit_error_page( '404' ) ) {
				do_action( 'site_kit_render_404' );
			}
			return;
		}
		// Rank Math redirections answer 410 Gone / 451 through set_404() — keep their status.
		$status = in_array( http_response_code(), array( 410, 451 ), true ) ? http_response_code() : 404;
		$page   = site_kit_error_page( (string) $status );
		$page   = $page ? $page : site_kit_error_page( '404' );
		if ( ! $page ) {
			return;
		}
		// WordPress never reaches get_header for HEAD, so stock Rank Math doesn't log those either.
		if ( $logged ) {
			do_action( 'site_kit_render_404' );
		}
		status_header( $status );
		nocache_headers();
		header( 'Content-Type: text/html; charset=UTF-8' );
		readfile( $page );
		exit;
	},
	PHP_INT_MAX
);
