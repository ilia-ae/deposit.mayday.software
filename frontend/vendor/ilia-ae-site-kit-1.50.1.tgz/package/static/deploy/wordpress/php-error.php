<?php
/**
 * WordPress drop-in (wp-content/php-error.php) — the @ilia-ae/site-kit 500 page for fatal errors.
 *
 * Included from WP_Fatal_Error_Handler::display_error_template(), so $this, $error and $handled
 * are in scope; it may run very early, so only wp-includes/load.php functions are used.
 * Visitors get the branded page; admin, REST/AJAX/XML-RPC, cron and CLI keep WordPress's default
 * template (JSON-aware, with the recovery-mode hint for admins).
 *
 * Source: ilia-site-kit/static/deploy/wordpress/ — edit there, not on the server.
 */

defined( 'ABSPATH' ) || exit;

$site_kit_page = ( defined( 'SITE_KIT_ERROR_DIR' ) ? SITE_KIT_ERROR_DIR : ABSPATH . 'kit' ) . '/500.html';
$site_kit_uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';

$site_kit_branded = ! headers_sent()
	&& is_readable( $site_kit_page )
	&& ! is_admin()
	&& ! wp_doing_ajax()
	&& ! wp_doing_cron()
	&& ! wp_is_json_request()
	&& ! wp_is_xml_request()
	&& ! ( defined( 'REST_REQUEST' ) && REST_REQUEST )
	&& ! ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST )
	&& ! ( defined( 'WP_CLI' ) && WP_CLI )
	&& false === strpos( $site_kit_uri, '/wp-json/' )
	&& ! isset( $_GET['rest_route'] );

if ( ! $site_kit_branded ) {
	$this->display_default_error_template( $error, $handled );
	return;
}

// Classic themes render the template into an output buffer (WP 6.9+), so a template-time fatal
// leaves half a page in it — drop that, or the 500 page lands after the broken theme markup.
while ( ob_get_level() > 0 ) {
	if ( ! @ob_end_clean() ) { // a non-removable buffer: empty it and stop there
		@ob_clean();
		break;
	}
}
if ( function_exists( 'status_header' ) ) {
	status_header( 500 );
} else {
	http_response_code( 500 );
}
header( 'Content-Type: text/html; charset=UTF-8' );
header( 'Cache-Control: no-store' );
readfile( $site_kit_page );
