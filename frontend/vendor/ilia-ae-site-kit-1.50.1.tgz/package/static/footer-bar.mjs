/**
 * The footer bar for an admin panel: the kit's compact footer (ik-footer with footer.compact) as
 * plain HTML + one stylesheet, from the same SiteKitConfig — no Angular, no JavaScript at all.
 *
 *   ● © 2025–2026 Ilia Arestov · legal links
 *   [Angular] [TypeScript] [Go] … [IA kit]
 *
 * Made for panels under a strict CSP (style-src 'self'): the markup carries no style attribute
 * and no <style>; everything is in footer-bar.css, served as a file. Colours come from the page:
 * Tabler's variables (--tblr-* or the unprefixed Sass build), else the kit's tokens, else neutral
 * defaults — and each can be set directly (--ik-bar-fg, --ik-bar-border, --ik-bar-brand,
 * --ik-bar-bg, --ik-bar-dot). Light/dark follows the page.
 *
 * What the Angular footer does with JS is left out or becomes a link: the year links to the QR
 * page (deploy.routes.qr), a legal entry links to its href (one with only a `body` panel has no
 * page to link to and is skipped), no verify dialog, no marquee.
 *
 *   site-kit-static --footer-bar --config site-kit.config.json --out web/src/kit
 *   → footer-bar.html (paste into index.html) + footer-bar.css (link it)
 *
 * `iconsOnly` (--icons-only) makes it one line: the badges become bare icons, and the name with
 * its version shows as a tooltip on hover and keyboard focus — CSS only (::after with
 * attr(data-tip)), read out through aria-label. A technology with no icon (no known `kind`, no
 * `icon`) shows its name in place of the generic tag glyph.
 */
import { readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const LIB = join(ROOT, 'projects/site-kit/src/lib');

const esc = (s) =>
    String(s ?? '').replace(
        /[&<>"']/g,
        (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c],
    );
const safeHref = (u) =>
    /^\s*(javascript|data|vbscript|file):/i.test(String(u ?? '')) ? '#' : String(u ?? '#');
const isExternal = (u) => /^https?:\/\//i.test(String(u ?? ''));
/** A LocalizedString in a language: the string itself, else lang → default → the first. */
const text = (v, lang, def) =>
    v == null ? '' : typeof v === 'string' ? v : (v[lang] ?? v[def] ?? Object.values(v)[0] ?? '');
/** A CSS colour the stylesheet may carry verbatim (a hex, rgb()/hsl()/oklch(), or a name). */
const safeColor = (c) =>
    /^(#[0-9a-f]{3,8}|(rgb|rgba|hsl|hsla|oklch|oklab)\([\d\s.,%/-]+\)|[a-z]+)$/i.test(String(c ?? '').trim())
        ? String(c).trim()
        : null;

/** One line, bare icons, a CSS tooltip (the name and version) on hover and keyboard focus. The tooltip
 * is the page's text colour on its background colour, inverted, so it reads in light and dark. */
const ICONS_CSS = `.ik-bar--icons{
  --ikb-tip-bg:var(--ik-bar-tip-bg,var(--tblr-body-color,var(--body-color,var(--text,#1f2937))));
  --ikb-tip-fg:var(--ik-bar-tip-fg,var(--tblr-body-bg,var(--body-bg,var(--bg,#fff))));
  flex-direction:row;flex-wrap:wrap;justify-content:center;gap:.35rem 1rem;padding-block:.6rem}
.ik-bar--icons .ik-bar__tech{gap:.15rem}
.ik-bar__b--icon{position:relative;padding:.3rem;border-color:transparent;background:none}
.ik-bar__b--icon .ik-bar__i{width:1rem;height:1rem}
.ik-bar__w{font-size:.64rem;line-height:1rem;font-weight:600;letter-spacing:.02em}
.ik-bar__b--icon::after{content:attr(data-tip);position:absolute;bottom:calc(100% + 4px);left:50%;z-index:10;
  padding:.3em .55em;border-radius:6px;background:var(--ikb-tip-bg);color:var(--ikb-tip-fg);
  font-size:.7rem;line-height:1.2;white-space:nowrap;pointer-events:none;
  opacity:0;transform:translate(-50%,3px);transition:opacity .12s,transform .12s}
.ik-bar__b--icon:hover::after,.ik-bar__b--icon:focus-visible::after{opacity:1;transform:translate(-50%,0)}
`;

/**
 * The technology catalogue and the kit's own badge, read from the library sources (the one source of
 * truth, as static/generate.mjs reads them): { icons: {kind: {label, url, svg}}, colors, fallback, kit }.
 */
export function techCatalog() {
    const ti = readFileSync(join(LIB, 'technologies/tech-icons.ts'), 'utf8');
    const icons = {};
    for (const m of ti.matchAll(
        /(\w+):\s*\{\s*label:\s*'([^']*)',\s*url:\s*'([^']*)',\s*svg:\s*`([\s\S]*?)`/g,
    )) {
        icons[m[1]] = { label: m[2], url: m[3], svg: m[4] };
    }
    const colors = {};
    const cm = /TECH_COLORS[^{]*\{([\s\S]*?)\};/.exec(ti);
    if (cm) for (const c of cm[1].matchAll(/(\w+):\s*'([^']+)'/g)) colors[c[1]] = c[2];
    const fallback = (/TECH_FALLBACK\s*=\s*`([\s\S]*?)`/.exec(ti) ?? [])[1] ?? '';
    const lg = readFileSync(join(LIB, 'brand/site-kit-logo.ts'), 'utf8');
    const kit = {
        glyph: (/SITE_KIT_GLYPH\s*=\s*`([\s\S]*?)`/.exec(lg) ?? [])[1] ?? '',
        name: (/SITE_KIT_NAME\s*=\s*'([^']+)'/.exec(lg) ?? [])[1] ?? 'IA kit',
        accent: (/SITE_KIT_ACCENT\s*=\s*'([^']+)'/.exec(lg) ?? [])[1] ?? '#9ca3af',
    };
    return { icons, colors, fallback, kit };
}

/**
 * The bar for a config: { html, css, warnings }. `year` is the current year (the range's end),
 * `kitVersion` goes into the IA-kit badge's title, `lang` picks the text of localized fields,
 * `iconsOnly` drops the badges' labels for a tooltip and puts everything on one line.
 */
export function buildFooterBar(
    config,
    { year = new Date().getFullYear(), kitVersion = '', lang, iconsOnly = false } = {},
) {
    const warnings = [];
    const def = config.defaultLang ?? config.languages?.[0] ?? 'en';
    const l = lang ?? def;
    const cr = config.copyright ?? {};
    const holder = cr.holder ?? config.brand?.name ?? '';
    const range = cr.startYear && cr.startYear < year ? `${cr.startYear}–${year}` : String(year);
    const suffix = text(cr.suffix, l, def);
    const rest = config.brand?.nameHidden ? suffix : `${holder}${suffix ? ` — ${suffix}` : ''}`;
    const qrHref = config.deploy?.routes?.qr ?? '/qr';
    const qrLabel = l === 'ru' ? 'Контакт-карта (QR)' : 'Contact card (QR)';
    const disclaimer = text(config.footer?.disclaimer, l, def);

    const legal = [];
    for (const e of config.legal ?? []) {
        const label = text(e.label, l, def);
        if (e.href) legal.push(`<a class="ik-bar__leg" href="${esc(safeHref(e.href))}">${esc(label)}</a>`);
        else
            warnings.push(
                `legal "${label}" has only a body panel — the bar has no JS to open it; give it an href`,
            );
    }

    const cat = techCatalog();
    const accents = [];
    const badge = (name, url, svg, accent, title) => {
        const n = accents.length + 1;
        const c = safeColor(accent);
        if (accent && !c)
            warnings.push(`technology "${name}": colour "${accent}" is not a plain CSS colour — left out`);
        accents.push(c);
        const ext = isExternal(url);
        const tip = esc(title ?? name);
        // icons only: a technology with no icon of its own (the generic tag glyph) shows its name
        // instead — a row of identical tags would say nothing without labels
        const icon =
            iconsOnly && svg === cat.fallback
                ? `<span class="ik-bar__w" aria-hidden="true">${esc(name)}</span>`
                : `<span class="ik-bar__i" aria-hidden="true">${svg}</span>`;
        return iconsOnly
            ? `<li><a class="ik-bar__b ik-bar__b--icon ik-bar__b--${n}" href="${esc(safeHref(url))}"` +
                  `${ext ? ' target="_blank" rel="noopener noreferrer"' : ''} aria-label="${tip}" data-tip="${tip}">` +
                  `${icon}</a></li>`
            : `<li><a class="ik-bar__b ik-bar__b--${n}" href="${esc(safeHref(url))}"` +
                  `${ext ? ' target="_blank" rel="noopener noreferrer"' : ''} title="${tip}">` +
                  `${icon}<span>${esc(name)}</span></a></li>`;
    };
    const items = (config.technologies ?? []).map((t) => {
        const meta = t.kind ? cat.icons[t.kind] : null;
        const name = t.name ?? meta?.label ?? t.kind ?? 'Tech';
        const svg = t.icon
            ? /^\s*<svg/i.test(t.icon)
                ? t.icon
                : `<img src="${esc(safeHref(t.icon))}" alt="">`
            : (meta?.svg ?? cat.fallback);
        return badge(
            name,
            t.url ?? meta?.url ?? '#',
            svg,
            t.color ?? (t.kind ? cat.colors[t.kind] : null),
            t.version ? `${name} v${t.version}` : name,
        );
    });
    if (config.signature !== false) {
        items.push(
            badge(
                cat.kit.name,
                'https://ilia.ae',
                cat.kit.glyph,
                cat.kit.accent,
                kitVersion ? `${cat.kit.name} v${kitVersion}` : cat.kit.name,
            ),
        );
    }
    if (items.some((i) => /\sstyle\s*=/i.test(i)))
        warnings.push(
            'an icon carries a style attribute — a strict CSP (style-src without unsafe-inline) drops it',
        );

    const html =
        `<!-- @ilia-ae/site-kit · footer bar${kitVersion ? ` · v${kitVersion}` : ''} · needs footer-bar.css; no JS, no inline styles -->\n` +
        `<footer class="ik-bar${iconsOnly ? ' ik-bar--icons' : ''}" role="contentinfo">\n` +
        `  <div class="ik-bar__top">\n` +
        `    <span class="ik-bar__cr"><span class="ik-bar__dot" aria-hidden="true"></span>© <a class="ik-bar__year" href="${esc(safeHref(qrHref))}" title="${esc(qrLabel)}" aria-label="${esc(qrLabel)}">${esc(range)}</a>${rest ? ` ${esc(rest)}` : ''}</span>\n` +
        (disclaimer ? `    <span class="ik-bar__disc">${esc(disclaimer)}</span>\n` : '') +
        (legal.length
            ? `    <nav class="ik-bar__legal" aria-label="${l === 'ru' ? 'Правовая информация' : 'Legal'}">${legal.join('<span class="ik-bar__sep" aria-hidden="true">·</span>')}</nav>\n`
            : '') +
        `  </div>\n` +
        (items.length ? `  <ul class="ik-bar__tech" role="list">${items.join('')}</ul>\n` : '') +
        `</footer>\n`;

    const css = `/* @ilia-ae/site-kit · footer bar${kitVersion ? ` · v${kitVersion}` : ''} (static/footer-bar.mjs) — the compact ik-footer, no JS.
 * Colours: --ik-bar-* if set, else Tabler (--tblr-* / unprefixed), else the kit's tokens, else neutral. */
.ik-bar{
  --ikb-fg:var(--ik-bar-fg,var(--tblr-secondary,var(--secondary,var(--text-dim,#74747f))));
  --ikb-border:var(--ik-bar-border,var(--tblr-border-color,var(--border-color,var(--border,#e5e5e9))));
  --ikb-bg:var(--ik-bar-bg,var(--tblr-bg-surface,var(--bg-surface,var(--bg-elev,transparent))));
  --ikb-brand:var(--ik-bar-brand,var(--tblr-primary,var(--primary,var(--brand,#6d28d9))));
  --ikb-dot:var(--ik-bar-dot,var(--ikb-brand));
  display:flex;flex-direction:column;align-items:center;gap:.55rem;
  padding:1rem 1.5rem;border-top:1px solid var(--ikb-border);
  color:var(--ikb-fg);font:.66rem/1.35 system-ui,-apple-system,'Segoe UI',sans-serif;text-align:center}
.ik-bar a{color:inherit;text-decoration:none}
.ik-bar a:hover{color:var(--ikb-brand)}
.ik-bar a:focus-visible{outline:2px solid var(--ikb-brand);outline-offset:2px;border-radius:4px}
.ik-bar__top{display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:.3rem .6rem;max-width:100%}
.ik-bar__cr{display:inline-flex;align-items:center;gap:.35rem;white-space:nowrap}
.ik-bar__dot{width:5px;height:5px;border-radius:50%;background:var(--ikb-dot);flex-shrink:0}
.ik-bar__year{padding-block:4px}
.ik-bar__disc{font-size:.85em;opacity:.85}
.ik-bar__legal{display:inline-flex;flex-wrap:wrap;justify-content:center;gap:.3rem .45rem}
.ik-bar__leg{white-space:nowrap;padding-block:4px}
.ik-bar__sep{opacity:.5}
.ik-bar__tech{display:flex;flex-wrap:wrap;justify-content:center;gap:.5rem;margin:0;padding:0;list-style:none}
.ik-bar__b{--ikb-accent:var(--ikb-brand);display:inline-flex;align-items:center;gap:.45em;padding:.42em .8em;border:1px solid var(--ikb-border);border-radius:999px;background:var(--ikb-bg);font-size:.75rem;line-height:1;transition:color .15s,border-color .15s,background .15s}
.ik-bar .ik-bar__b:hover{color:var(--ikb-accent);border-color:color-mix(in oklch,var(--ikb-accent) 45%,transparent);background:color-mix(in oklch,var(--ikb-accent) 14%,transparent)}
.ik-bar__i{display:inline-flex;width:1.05em;height:1.05em}
.ik-bar__i svg,.ik-bar__i img{display:block;width:100%;height:100%}
${accents
    .map((c, i) => (c ? `.ik-bar__b--${i + 1}{--ikb-accent:${c}}` : ''))
    .filter(Boolean)
    .join('\n')}
${iconsOnly ? ICONS_CSS : ''}@media(max-width:600px){.ik-bar{font-size:clamp(.5rem,2.3vw,.62rem)}.ik-bar__disc{display:none}}
@media(prefers-reduced-motion:reduce){.ik-bar__b,.ik-bar__b--icon::after{transition:none}}
`;
    return { html, css, warnings };
}
