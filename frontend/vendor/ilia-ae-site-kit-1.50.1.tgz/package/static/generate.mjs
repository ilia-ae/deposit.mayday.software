#!/usr/bin/env node
/**
 * Static HTML generator for non-Angular sites (WordPress, aaPanel, plain hosting).
 *
 * Single source of truth shared with the Angular library:
 *   • status copy  ← projects/site-kit/src/lib/status/status-catalog.json  (multilingual)
 *   • design tokens ← projects/site-kit/src/lib/styles/site-kit-tokens.css
 *
 * ONE module, MANY configs: reads ./site-kit.config.json and emits self-contained
 * .html files into ./dist — multilingual status pages (404.html …), reusable
 * partials (footer / contact-qr / social / projects), and a local gallery index.
 *
 * Adaptive: any section whose config slice is missing is simply skipped — an old
 * data file keeps working when the module gains new fields.
 *
 * Usage:  node static/generate.mjs   (or: npm run build:static / npm run gallery)
 */
import { readFileSync, writeFileSync, mkdirSync, rmSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import qrcode from 'qrcode-generator';
import { localizeUrl, localizeText, isRtl } from '../tools/lib/localize.mjs';
import { escapeHtml as esc } from '../tools/lib/escape.mjs';
import { buildFaviconSet, faviconTags, faviconTagsHtml } from '../tools/lib/favicon.mjs';
import { buildSeoTags, seoTagsHtml, buildSitemap, buildRobotsTxt } from '../tools/lib/seo.mjs';
import { buildOgSet } from '../tools/lib/og.mjs';
import { buildFooterBar } from './footer-bar.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');
// Paths may be overridden via env (used by tests; also enables multi-config generation).
const P = {
    catalog:
        process.env.SITE_KIT_CATALOG || join(ROOT, 'projects/site-kit/src/lib/status/status-catalog.json'),
    qrStrings: join(ROOT, 'projects/site-kit/src/lib/i18n/qr-strings.json'),
    tokens: join(ROOT, 'projects/site-kit/src/lib/styles/site-kit-tokens.css'),
    statusTpl: join(HERE, 'templates/status.html'),
    statusCss: join(HERE, 'templates/status.css'),
    config: process.env.SITE_KIT_CONFIG || join(HERE, 'site-kit.config.json'),
    out: process.env.SITE_KIT_OUT || join(HERE, 'dist'),
};

// ── helpers ──────────────────────────────────────────────────
// esc / localizeUrl / localizeText / isRtl imported from ../tools/lib (single JS mirrors)
const read = (p) => readFileSync(p, 'utf8');
// Module version: in-repo it lives in projects/site-kit/package.json; in the PUBLISHED
// package npm strips nested package.json files, so fall back to the package root
// (dist/site-kit/package.json — the published manifest, ROOT here).
const readModuleVersion = () => {
    for (const p of [join(ROOT, 'projects/site-kit/package.json'), join(ROOT, 'package.json')]) {
        try {
            return JSON.parse(readFileSync(p, 'utf8')).version;
        } catch {
            /* try the next location */
        }
    }
    return '0.0.0';
};
const fill = (tpl, vars) => tpl.replace(/\{\{(\w+)\}\}/g, (_, k) => (k in vars ? vars[k] : ''));
const safeHref = (u) =>
    /^(javascript|data|vbscript|file):/i.test(String(u ?? '').trim()) ? '#' : String(u ?? '');
const safeImg = (u) => {
    const s = String(u ?? '').trim();
    if (/^data:image\//i.test(s)) return s;
    return /^(javascript|vbscript|data|file):/i.test(s) ? '#' : s;
};

// Resolve a link href for a language: urls → pathByLang (domain + modifier) → localize → url.
const originOf = (u) => /^(https?:\/\/[^/]+)/i.exec(String(u))?.[1] ?? '';
const resolveLinkHref = (link, lang, def) => {
    if (link.urls?.[lang]) return link.urls[lang];
    if (link.pathByLang) {
        const mod = link.pathByLang[lang];
        if (mod === undefined) return link.url;
        const origin = originOf(link.url);
        if (!origin) return mod || link.url;
        return mod ? origin + (mod.startsWith('/') ? mod : '/' + mod) : origin;
    }
    return link.localize ? localizeUrl(link.url, lang, def) : link.url;
};
const linkHref = (link, lang, def) => safeHref(resolveLinkHref(link, lang, def));
const isExternal = (u) => /^https?:\/\//i.test(String(u));
const genQrSvg = (data) => {
    try {
        const q = qrcode(0, 'M');
        q.addData(String(data));
        q.make();
        return q.createSvgTag({ cellSize: 5, margin: 0, scalable: true });
    } catch {
        return '';
    }
};

// ── load ─────────────────────────────────────────────────────
/** Read + JSON.parse with a descriptive, file-named error instead of a bare SyntaxError. */
const readJson = (p, label) => {
    try {
        return JSON.parse(read(p));
    } catch (e) {
        throw new Error(`Failed to load ${label} (${p}): ${e.message}`, { cause: e });
    }
};
const catalog = readJson(P.catalog, 'status catalog');
// Shared QR / contact labels — single JSON source of truth, also imported by i18n/ik-strings.ts.
const QR_STRINGS = readJson(P.qrStrings, 'QR strings');
const tokens = read(P.tokens);
const statusTpl = read(P.statusTpl);
const statusCss = read(P.statusCss);
const config = readJson(P.config, 'site-kit config');

// ── validate (fail fast instead of degrading to empty pages / "undefined.html") ──
if (!Array.isArray(catalog.entries)) {
    throw new Error(`Status catalog (${P.catalog}) is missing an "entries" array.`);
}
if (!config.brand?.name) {
    console.warn('⚠ site-kit config has no brand.name — output falls back to "Site".');
}

// ── resolve (mirrors resolveSiteKitConfig) ───────────────────
const brand = config.brand?.name ?? 'Site';
const brandUrl = config.brand?.url ?? '/';
const languages = config.languages?.length ? config.languages : catalog.languages;
const defaultLang = config.defaultLang ?? languages[0] ?? 'en';
/** Resolve a LocalizedString (plain string OR { en, ru } map) for a language — mirrors lib localizeText. */
const lt = (v, lang, def = defaultLang) => localizeText(v, lang, def);
const homeHref = config.status?.homeHref ?? config.brand?.url ?? '/';
const statusLangs = config.static?.languages?.length ? config.static.languages : languages;
const primaryLang = config.static?.lang ?? defaultLang;
const want = config.static?.statuses ?? catalog.entries.map((e) => e.code);
const showHomeOnPseudo = config.static?.showHomeOnPseudo ?? false;
const i18nOverride = config.static?.i18n ?? {};
// Reproducible builds: SOURCE_DATE_EPOCH (seconds; e.g. the last commit's time) pins every date the
// output carries, so the same sources give byte-identical pages — Ansible then sees "no change".
const BUILD_TIME = process.env.SOURCE_DATE_EPOCH
    ? new Date(Number(process.env.SOURCE_DATE_EPOCH) * 1000)
    : new Date();
// `static.statusOnly`: the site uses the kit ONLY for its error pages (e.g. WordPress, whose CMS owns
// the QR card, favicon, sitemap and robots) — the deploy bundle carries just the status pages + manifest.
const statusOnly = !!config.static?.statusOnly;
// "back" + "redirect" labels per language — mirror ik-strings.ts.
const BACK_LABELS = { en: 'Back', ru: 'Назад', ar: 'رجوع', kk: 'Артқа', zh: '返回', hi: 'वापस', ur: 'واپس' };
const REDIRECT_TPL = {
    en: 'Redirecting to home in {n}s',
    ru: 'Вы будете перенаправлены на главную через {n} с',
    ar: 'ستتم إعادة توجيهك إلى الرئيسية خلال {n} ثانية',
    kk: '{n} секундтан кейін басты бетке бағытталасыз',
    zh: '{n} 秒后将跳转到首页',
    hi: '{n} सेकंड में होम पर भेजा जा रहा है',
    ur: '{n} سیکنڈ میں ہوم پر بھیجا جا رہا ہے',
};
const HOME_LABELS = {
    en: 'Home',
    ru: 'На главную',
    ar: 'الرئيسية',
    kk: 'Басты бет',
    zh: '首页',
    hi: 'होम',
    ur: 'ہوم',
};
// homeLabel/supportLine: localize to the primary language (config value may be a {lang} map).
const homeLabel = lt(config.status?.homeLabel, primaryLang) ?? HOME_LABELS[primaryLang] ?? HOME_LABELS.en;
const supportLine = lt(config.status?.supportLine, primaryLang) ?? '';
const backLabel = BACK_LABELS[primaryLang] ?? BACK_LABELS.en;
const redirectTpl = REDIRECT_TPL[primaryLang] ?? REDIRECT_TPL.en;
const showBack = config.status?.showBack !== false;
const redirect = config.status?.redirect; // { delaySeconds, href? }
const redirectHref = redirect?.href ?? homeHref;
// DESIGN layer — config.theme overrides tokens for this bundle (last wins).
const cssVal = (v) => String(v).replace(/[<>;{}]/g, ''); // strip chars that could break out of the <style>/declaration
const themeVars = (obj, sel) =>
    obj
        ? `${sel}{${Object.entries(obj)
              .filter(([k]) => k.startsWith('--'))
              .map(([k, v]) => `${k}:${cssVal(v)}`)
              .join(';')}}`
        : '';
// Base overrides on :root (brand + light defaults, applies in both schemes).
const themeCss = themeVars(config.theme, ':root');

// THEME SYNC (config.static.themeSync) — adaptive dark for STANDALONE static pages, in PURE
// CSS via `@media (prefers-color-scheme: dark)`. The page follows the visitor's OS colour
// scheme: no JS, no localStorage — so it can't get "stuck" on a stale stored value, themes
// correctly even with JS off / the backend down, and never flashes. The dark palette is the
// kit's canonical `:root.app-dark` tokens (already inlined) re-emitted under the media query,
// plus `config.themeDark` overrides (e.g. an app's exact #0b0f1a). On a static page there's
// no in-app toggle to conflict with, so the OS media query is the right mechanism here (the
// app itself keeps using its JS `.app-dark` class). Dark OS → dark; light OS → light.
const themeDarkBody = config.themeDark
    ? Object.entries(config.themeDark)
          .filter(([k]) => k.startsWith('--'))
          .map(([k, v]) => `${k}:${cssVal(v)}`)
          .join(';')
    : '';
const kitDarkBody = (/:root\.app-dark\s*\{([\s\S]*?)\}/.exec(tokens)?.[1] ?? '')
    .replace(/\/\*[\s\S]*?\*\//g, '') // drop comments
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/;\s*$/, '');
const darkPalette = [kitDarkBody, themeDarkBody].filter(Boolean).join(';');
const mediaDarkCss =
    config.static?.themeSync && darkPalette
        ? `@media (prefers-color-scheme:dark){:root{${darkPalette}}}`
        : '';
const inlineStyle = `${tokens}\n${statusCss}\n${themeCss}\n${mediaDarkCss}`;
const themeSyncScript = ''; // theme sync is pure CSS now — no inline script injected

const copy = (entry, lang) =>
    entry.i18n?.[lang] ??
    entry.i18n?.[defaultLang] ??
    entry.i18n?.en ??
    Object.values(entry.i18n ?? {})[0] ?? { title: '', message: '' };

// ── deploy resolver (mirrors resolveSiteKitConfig's deploy defaults) ──
const deploy = config.deploy ?? {};
const target = deploy.target ?? 'git'; // git | cloudflare | wp
const basePath = String(deploy.path ?? '/kit').replace(/\/+$/, '') || '/kit';
const dRoutes = deploy.routes ?? {};
const statusRoute = (code) => dRoutes[String(code)] ?? `${basePath}/${code}.html`;
const qrRoute = dRoutes.qr ?? `${basePath}/qr.html`;
const verifyRoute = dRoutes.verify ?? `${basePath}/verify.html`;
const manifestRoute = dRoutes.manifest ?? `${basePath}/manifest.json`;
const configRoute = dRoutes.config ?? `${basePath}/site-kit.config.json`;
const tokensRoute = dRoutes.tokens ?? `${basePath}/site-kit-tokens.css`;
// route ('/kit/404.html' or '/qr') → file path within a bundle ('kit/404.html', 'qr/index.html')
const fileFor = (route) => {
    let p = String(route).replace(/^\/+/, '');
    if (!/\.[a-z0-9]+$/i.test(p)) p = `${p.replace(/\/+$/, '')}/index.html`;
    return p;
};
// module + schema facts (read like tools/inventory.mjs — a .mjs can't import the .ts contract).
const moduleVersion = readModuleVersion();
const schemaVersion = Number(
    /SITE_KIT_SCHEMA_VERSION\s*=\s*(\d+)/.exec(
        read(join(ROOT, 'projects/site-kit/src/lib/config/site-kit.config.ts')),
    )?.[1] ??
        config.schemaVersion ??
        0,
);
// rendered status HTML by code — filled in section 1, reused by the per-target bundle + worker.
const htmlByCode = {};

// NOTE: the PWA module (config.pwa — installable app / ngsw) is ANGULAR-ONLY and is
// intentionally NOT emitted here; static (WP/aaPanel) sites don't get a service worker.
// ── favicon + SEO modules (config-driven; adaptive) ──────────────────────────
// FAVICON: build the icon set once from ONE SVG (sharp) + the shared <head> tags.
// The tags (faviconTags) are the JS mirror of lib/favicon/favicon.ts, so static and
// Angular emit identical markup. Assets/manifest are written to dist + the bundle below.
const favBasePath = config.favicon?.path ?? '/';
// Rasterization needs `sharp` (a build-only dep). When the generator runs from the published
// package in a consumer that didn't install sharp, skip favicon/OG rasterization with a warning
// rather than crashing — the status/error pages (the common case) don't depend on it.
let favSet = null;
if (config.favicon) {
    try {
        favSet = await buildFaviconSet(config, { cwd: HERE, basePath: favBasePath });
    } catch (e) {
        console.warn(`⚠ favicon set skipped (${e.message}). Install "sharp" to rasterize icons.`);
    }
}
// OG banner (seo.ogImage) — generated from brand+theme; written next to the favicons.
let ogSet = null;
if (config.seo?.ogImage) {
    try {
        ogSet = await buildOgSet(config, { cwd: HERE, lang: primaryLang });
    } catch (e) {
        console.warn(`⚠ OG banner skipped (${e.message}). Install "sharp" to rasterize og:image.`);
    }
}
// `faviconHref`: link EXISTING icon files (no generation) — for sites that already ship a favicon
// and just need the generated/inlined pages (status/qr/verify) to reference it. Accepts a string,
// or an array of strings / { href, rel?, type?, sizes? }. Hrefs SHOULD be absolute ("/path") so the
// links still resolve on error pages the Worker serves at arbitrary URLs. `config.favicon` (full
// generation from an SVG) wins when present — except on a statusOnly site, whose bundle doesn't
// ship the generated set, so its pages must point at the icons the site already serves.
const faviconHrefTags = (fav) => {
    const items = (Array.isArray(fav) ? fav : [fav]).filter(Boolean);
    return items
        .map((it) => {
            const o = typeof it === 'string' ? { href: it } : it || {};
            if (!o.href) return '';
            const rel = o.rel || (/apple|webclip/i.test(o.href) ? 'apple-touch-icon' : 'icon');
            const type =
                o.type ??
                (/\.png$/i.test(o.href)
                    ? 'image/png'
                    : /\.svg$/i.test(o.href)
                      ? 'image/svg+xml'
                      : /\.ico$/i.test(o.href)
                        ? 'image/x-icon'
                        : '');
            return `<link rel="${esc(rel)}"${type ? ` type="${esc(type)}"` : ''}${o.sizes ? ` sizes="${esc(o.sizes)}"` : ''} href="${esc(o.href)}">`;
        })
        .filter(Boolean)
        .join('\n    ');
};
if (statusOnly && config.favicon && !config.faviconHref) {
    console.warn('⚠ static.statusOnly ships no favicon set — set faviconHref to the icons the site serves.');
}
const faviconHead =
    config.faviconHref && (statusOnly || !config.favicon)
        ? '\n    ' + faviconHrefTags(config.faviconHref)
        : config.favicon && !statusOnly
          ? '\n    ' +
            faviconTagsHtml(faviconTags(config.favicon, { theme: config.theme }), '    ').trimStart()
          : '';
// SEO: full head per page+language (mirror of lib/seo/seo-core.ts). Emitted on the
// indexable QR page; status/verify stay noindex (favicon only). Pages with no `seo`
// block keep their original minimal head (adaptive — nothing forced).
const seoEnabled = !!config.seo;
const seoHead = (lang, ctx = {}) => {
    if (!seoEnabled) return '';
    // The QR page serves all languages from ONE URL (?lang=), so path-prefixed hreflang
    // alternates don't apply there — keep canonical, drop alternates.
    const tags = buildSeoTags(config, { lang, ...ctx }).filter(
        (t) => !(ctx.dropHreflang && t.tag === 'link' && t.rel === 'alternate'),
    );
    return tags.length ? '\n' + seoTagsHtml(tags) : '';
};

// ── output dir ───────────────────────────────────────────────
// Preserve sibling artifacts (the inventory dashboard) across our wipe so
// `build:static` doesn't 404 the gallery's "inventory →" link.
const preserved = {};
for (const f of ['dashboard.html', 'inventory.json']) {
    try {
        preserved[f] = readFileSync(join(P.out, f), 'utf8');
    } catch {
        /* not present */
    }
}
try {
    rmSync(P.out, { recursive: true, force: true });
} catch {
    /* first run */
}
mkdirSync(join(P.out, 'partials'), { recursive: true });
for (const [f, c] of Object.entries(preserved)) writeFileSync(join(P.out, f), c);

// ── 1) multilingual status pages ─────────────────────────────
const emitted = [];
for (const entry of catalog.entries) {
    if (entry == null || (typeof entry.code !== 'string' && typeof entry.code !== 'number')) {
        console.warn(
            `⚠ skipping status catalog entry with a missing/invalid "code": ${JSON.stringify(entry)}`,
        );
        continue;
    }
    if (!want.includes(entry.code)) continue;
    const ov = i18nOverride[String(entry.code)] ?? {};
    const ordered = [primaryLang, ...statusLangs.filter((l) => l !== primaryLang)];
    const pc = copy(entry, primaryLang);
    const pTitle = ov.title ?? pc.title;
    const pMsg = ov.message ?? pc.message;
    const primary = `<div class="primary" dir="${isRtl(primaryLang) ? 'rtl' : 'ltr'}" lang="${esc(primaryLang)}"><h1 class="title">${esc(pTitle)}</h1><p class="message">${esc(pMsg)}</p></div>`;
    const others = ordered
        .slice(1)
        .map((l) => {
            const c = copy(entry, l);
            return `<div class="other" dir="${isRtl(l) ? 'rtl' : 'ltr'}" lang="${esc(l)}"><span class="other-title">${esc(c.title)}</span><span class="other-message">${esc(c.message)}</span></div>`;
        })
        .join('');
    const isPseudo = entry.code === 'maintenance' || entry.code === 'offline';
    const showHome = isPseudo ? showHomeOnPseudo : true;
    // Auto-redirect (timer): only on real error codes, and only when configured.
    const doRedirect = !isPseudo && redirect?.delaySeconds > 0;
    const n = doRedirect ? Math.max(1, Math.floor(redirect.delaySeconds)) : 0;
    const html = fill(statusTpl, {
        LANG: esc(primaryLang),
        DIR: isRtl(primaryLang) ? 'rtl' : 'ltr',
        CODE: esc(String(entry.code)),
        GLYPH: esc(entry.glyph),
        TITLE: esc(pTitle),
        HEAD:
            themeSyncScript +
            (doRedirect
                ? `<meta http-equiv="refresh" content="${n};url=${esc(safeHref(redirectHref))}">`
                : '') +
            faviconHead,
        PRIMARY: primary,
        OTHERS: others ? `<div class="others">${others}</div>` : '',
        SUPPORT: supportLine ? `<p class="support">${esc(supportLine)}</p>` : '',
        HOME: showHome ? `<a class="btn home" href="${esc(safeHref(homeHref))}">${esc(homeLabel)}</a>` : '',
        BACK: showBack
            ? `<button type="button" class="btn back" onclick="history.back()">← ${esc(backLabel)}</button>`
            : '',
        REDIRECT: doRedirect
            ? `<p class="redirect">${esc(redirectTpl).replace('{n}', `<span id="ik-cd">${n}</span>`)}</p>`
            : '',
        SCRIPT: doRedirect
            ? `<script>(function(){var n=${n},e=document.getElementById('ik-cd'),t=setInterval(function(){if(--n<=0){clearInterval(t)}if(e)e.textContent=n>0?n:0},1000)})()</script>`
            : '',
        BRAND: esc(brand),
        STYLE: inlineStyle,
    });
    writeFileSync(join(P.out, `${entry.code}.html`), html);
    htmlByCode[entry.code] = html;
    emitted.push({ code: entry.code, glyph: entry.glyph, title: pTitle });
}

// ── 2) shared tokens ─────────────────────────────────────────
writeFileSync(join(P.out, 'site-kit-tokens.css'), tokens);

// ── 3) partials (adaptive: emitted only when their data exists) ──
const year = BUILD_TIME.getFullYear();
const skVersion = readModuleVersion();
const skBuild = BUILD_TIME.toISOString().slice(0, 10);
const cr = config.copyright ?? {};
const crHolder = cr.holder ?? brand;
const crRange = cr.startYear && cr.startYear < year ? `${cr.startYear}–${year}` : `${year}`;
const legal = (config.legal ?? [])
    .map((l) => `<a href="${esc(safeHref(l.href))}">${esc(lt(l.label, primaryLang))}</a>`)
    .join('');
// License (config.license → bank catalog; mirrors lib resolveLicense, {{YEARS}} → copyright range)
const licCatalog = (() => {
    const raw = (/LICENSE_CATALOG[^=]*=\s*(\{[\s\S]*\});/.exec(
        read(new URL('../projects/site-kit/src/lib/license/license-catalog.generated.ts', import.meta.url)),
    ) ?? [])[1];
    if (!raw) {
        console.warn('⚠ could not extract LICENSE_CATALOG from the generated file — license text disabled.');
        return {};
    }
    try {
        return JSON.parse(raw);
    } catch (e) {
        console.warn(`⚠ could not parse LICENSE_CATALOG: ${e.message} — license text disabled.`);
        return {};
    }
})();
// License-bank build stamp (hash + date) — surfaced in the manifest so the inventory
// dashboard can show each deployment's license-catalog version (not just the Showcase's).
const licenseBuild =
    (/LICENSE_BUILD\s*=\s*["']([^"']+)["']/.exec(
        read(new URL('../projects/site-kit/src/lib/license/license-catalog.generated.ts', import.meta.url)),
    ) ?? [])[1] ?? null;
const licEntry = config.license ? licCatalog[config.license] : null;
if (config.license && !licEntry) {
    console.warn(`⚠ config.license "${config.license}" not found in the license catalog.`);
}
if (licEntry?.stub) {
    console.warn(
        `⚠ config.license "${config.license}" is a stub (no full text) — a link note ships instead of license text.`,
    );
}
const licName = licEntry?.name ?? null;
const licText = licEntry && !licEntry.stub ? String(licEntry.text).replaceAll('{{YEARS}}', crRange) : null;
const licRoute = dRoutes.license ?? `${basePath}/license.html`;
const footerSnippet = `<!-- @ilia-ae/site-kit · footer · include site-kit-tokens.css once in <head> -->
<footer class="ik-footer" role="contentinfo"><div class="inner">
  <a class="name" href="${esc(safeHref(localizeUrl(brandUrl, primaryLang, defaultLang)))}">${esc(brand)}</a>
  ${config.brand?.tagline ? `<span class="tag">${esc(config.brand.tagline)}</span>` : ''}
  ${legal ? `<nav class="legal" aria-label="Legal">${legal}</nav>` : ''}
  <p class="copyright">© ${crRange} ${esc(crHolder)}.${cr.suffix ? ' ' + esc(cr.suffix) : ''}${licName ? ` · <a class="lic" href="${esc(safeHref(licRoute))}">${esc(licName)}</a>` : ''}</p>
</div></footer>
<style>
.ik-footer{border-top:1px solid var(--border,#e5e5e9);background:var(--bg-elev,#fff);color:var(--text-mute,#5c5c6d);font:var(--fs-sm,.875rem)/1.6 var(--font-display,system-ui,sans-serif)}
.ik-footer .inner{max-width:var(--container,72rem);margin-inline:auto;padding:var(--sp-8,2rem) var(--gutter,1.5rem);display:flex;flex-wrap:wrap;align-items:center;gap:var(--sp-4,1rem) var(--sp-6,1.5rem)}
.ik-footer .name{font-weight:var(--fw-bold,700);color:var(--text,#09090f);text-decoration:none}
.ik-footer .tag{color:var(--text-dim,#8e8ea0)}.ik-footer .legal{display:inline-flex;flex-wrap:wrap;gap:var(--sp-4,1rem)}
.ik-footer .legal a{color:inherit;text-decoration:none}.ik-footer .legal a:hover,.ik-footer .name:hover{color:var(--brand,#6d28d9)}
.ik-footer .copyright{margin:0 0 0 auto;color:var(--text-dim,#8e8ea0)}.ik-footer .lic{color:inherit;text-decoration:none}.ik-footer .lic:hover{color:var(--brand,#6d28d9)}
.ik-build{font-size:.6875rem;font-family:var(--font-mono,monospace);letter-spacing:.02em;color:var(--text-dim,#8e8ea0);text-decoration:none}
.ik-build:hover{color:var(--text-mute,#5c5c6d)}
@media(max-width:640px){.ik-footer .inner{flex-direction:column;align-items:flex-start}.ik-footer .copyright{margin-left:0}}
</style>`;
writeFileSync(join(P.out, 'partials/footer.html'), footerSnippet);
// The compact footer as plain HTML + CSS, no JS (static/footer-bar.mjs) — for admin panels.
{
    const bar = buildFooterBar(config, { year, kitVersion: moduleVersion, lang: primaryLang });
    writeFileSync(join(P.out, 'partials/footer-bar.html'), bar.html);
    writeFileSync(join(P.out, 'partials/footer-bar.css'), bar.css);
}

const qr = config.contact?.qr;
let qrSnippet = '';
if (qr && (qr.src || qr.data || config.brand?.url)) {
    const alt = qr.alt ?? `${brand} — contact QR`;
    const imgOrSvg = qr.src
        ? `<img src="${esc(safeImg(qr.src))}" alt="${esc(alt)}">`
        : genQrSvg(qr.data ?? config.brand.url) || `<img alt="${esc(alt)}">`;
    const inner = qr.href
        ? `<a class="frame" href="${esc(safeHref(qr.href))}" target="_blank" rel="noopener noreferrer">${imgOrSvg}</a>`
        : `<span class="frame">${imgOrSvg}</span>`;
    qrSnippet = `<!-- @ilia-ae/site-kit · contact-qr · include site-kit-tokens.css once -->
<figure class="ik-qr">${inner}${qr.caption ? `<figcaption>${esc(qr.caption)}</figcaption>` : ''}</figure>
<style>
.ik-qr{display:inline-flex;flex-direction:column;align-items:center;gap:var(--sp-4,1rem);margin:0;padding:var(--sp-6,1.5rem);background:var(--bg-elev,#fff);border:1px solid var(--border,#e5e5e9);border-radius:var(--r-lg,16px);box-shadow:var(--shadow-sm,0 2px 8px rgba(0,0,0,.06))}
.ik-qr .frame{display:block;padding:var(--sp-3,.75rem);background:#fff;border-radius:var(--r-md,12px)}
.ik-qr .frame svg,.ik-qr .frame img{display:block;width:var(--ik-qr-size,200px);height:var(--ik-qr-size,200px)}
.ik-qr figcaption{font-weight:var(--fw-semi,600);color:var(--text,#09090f)}
</style>`;
    writeFileSync(join(P.out, 'partials/contact-qr.html'), qrSnippet);
}

const social = config.social ?? [];
if (social.length) {
    const items = social
        .map((s) => {
            const href = linkHref(s, primaryLang, defaultLang);
            const ext = isExternal(href);
            return `<li><a href="${esc(href)}"${ext ? ' target="_blank" rel="noopener noreferrer"' : ''} aria-label="${esc(s.label ?? s.kind)}">${esc(s.label ?? s.kind)}</a></li>`;
        })
        .join('');
    const socialSnippet = `<!-- @ilia-ae/site-kit · social (text variant) -->
<ul class="ik-social">${items}</ul>
<style>.ik-social{display:inline-flex;flex-wrap:wrap;gap:var(--sp-2,.5rem);list-style:none;margin:0;padding:0}
.ik-social a{display:inline-flex;align-items:center;padding:var(--sp-2,.5rem) var(--sp-3,.75rem);border:1px solid var(--border,#e5e5e9);border-radius:var(--r-md,12px);background:var(--bg-elev,#fff);color:var(--text-mute,#5c5c6d);text-decoration:none;font-size:var(--fs-sm,.875rem)}
.ik-social a:hover{color:var(--brand,#6d28d9);border-color:var(--border-strong,#cdcdd4)}</style>`;
    writeFileSync(join(P.out, 'partials/social.html'), socialSnippet);
}

const projects = config.projects ?? [];
if (projects.length) {
    const badge = { live: 'Live', wip: 'WIP', archived: 'Archived' };
    const cards = projects
        .map((p) => {
            const href = linkHref(p, primaryLang, defaultLang);
            const ext = isExternal(href);
            const mono = (p.name ?? '?').trim().charAt(0).toUpperCase();
            const tags = (p.tags ?? []).map((t) => `<li>${esc(t)}</li>`).join('');
            return `<a class="ik-pcard" href="${esc(href)}"${ext ? ' target="_blank" rel="noopener noreferrer"' : ''}>
      <span class="ik-pcard__top">${p.logoUrl ? `<img class="ik-pcard__logo" src="${esc(safeImg(p.logoUrl))}" alt="${esc(p.name)}">` : `<span class="ik-pcard__mono">${esc(mono)}</span>`}${p.status ? `<span class="ik-pcard__badge" data-status="${esc(p.status)}">${esc(badge[p.status] ?? p.status)}</span>` : ''}</span>
      <span class="ik-pcard__name">${esc(p.name)}</span>
      ${p.description ? `<span class="ik-pcard__desc">${esc(p.description)}</span>` : ''}
      ${tags ? `<ul class="ik-pcard__tags">${tags}</ul>` : ''}
    </a>`;
        })
        .join('\n    ');
    const projectsSnippet = `<!-- @ilia-ae/site-kit · projects · include site-kit-tokens.css once -->
<div class="ik-projects">${cards}</div>
<style>
.ik-projects{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,16rem),1fr));gap:var(--sp-4,1rem)}
.ik-pcard{display:flex;flex-direction:column;gap:var(--sp-2,.5rem);padding:var(--sp-5,1.25rem);text-decoration:none;color:var(--text,#09090f);border:1px solid var(--border,#e5e5e9);border-radius:var(--r-lg,16px);background:var(--bg-elev,#fff);transition:transform .15s,border-color .15s,box-shadow .15s}
.ik-pcard:hover{transform:translateY(-3px);border-color:var(--border-strong,#cdcdd4);box-shadow:var(--shadow-md,0 8px 24px rgba(0,0,0,.08))}
.ik-pcard__top{display:flex;align-items:center;justify-content:space-between}
.ik-pcard__mono,.ik-pcard__logo{width:2.25rem;height:2.25rem;border-radius:var(--r-md,12px)}
.ik-pcard__mono{display:grid;place-items:center;background:var(--grad-brand,linear-gradient(135deg,var(--brand,#6d28d9),var(--accent-2,#db2777)));color:#fff;font-weight:var(--fw-bold,700)}
.ik-pcard__badge{font-size:var(--fs-xs,.75rem);padding:.15em .6em;border-radius:var(--r-full,999px);border:1px solid var(--border,#e5e5e9);color:var(--text-mute,#5c5c6d)}
.ik-pcard__badge[data-status=live]{color:var(--success,#16a34a)}.ik-pcard__badge[data-status=wip]{color:var(--accent-3,#ea580c)}.ik-pcard__badge[data-status=archived]{color:var(--text-dim,#8e8ea0)}
.ik-pcard__name{font-weight:var(--fw-bold,700)}
.ik-pcard__desc{font-size:var(--fs-sm,.875rem);color:var(--text-mute,#5c5c6d)}
.ik-pcard__tags{display:flex;flex-wrap:wrap;gap:.35rem;list-style:none;margin:.25rem 0 0;padding:0}
.ik-pcard__tags li{font-size:var(--fs-xs,.75rem);color:var(--text-dim,#8e8ea0);background:var(--bg-mute,#f0f0f2);padding:.1em .5em;border-radius:var(--r-sm,8px)}
</style>`;
    writeFileSync(join(P.out, 'partials/projects.html'), projectsSnippet);
}

// ── technologies badge row — the partial ilia.ae embeds into its WordPress footer ──
const techs = config.technologies ?? [];
if (techs.length || config.signature !== false) {
    // Single source of truth: parse the icon catalogue + IA-kit glyph straight from the lib.
    const ti = read(new URL('../projects/site-kit/src/lib/technologies/tech-icons.ts', import.meta.url));
    const techIcons = {};
    {
        const re = /(\w+):\s*\{\s*label:\s*'([^']*)',\s*url:\s*'([^']*)',\s*svg:\s*`([\s\S]*?)`/g;
        let m;
        while ((m = re.exec(ti))) techIcons[m[1]] = { label: m[2], url: m[3], svg: m[4] };
    }
    const techColors = {};
    {
        const cm = /TECH_COLORS[^{]*\{([\s\S]*?)\};/.exec(ti);
        if (cm) {
            const re = /(\w+):\s*'([^']+)'/g;
            let c;
            while ((c = re.exec(cm[1]))) techColors[c[1]] = c[2];
        }
    }
    const techFb = (/TECH_FALLBACK\s*=\s*`([\s\S]*?)`/.exec(ti) || [])[1] || '';
    const lg = read(new URL('../projects/site-kit/src/lib/brand/site-kit-logo.ts', import.meta.url));
    const ikGlyph = (/SITE_KIT_GLYPH\s*=\s*`([\s\S]*?)`/.exec(lg) || [])[1] || '';
    const ikName = (/SITE_KIT_NAME\s*=\s*'([^']+)'/.exec(lg) || [])[1] || 'IA kit';
    const ikAccent = (/SITE_KIT_ACCENT\s*=\s*'([^']+)'/.exec(lg) || [])[1] || '#9ca3af';
    const techBadge = (name, url, svg, accent, title) => {
        const ext = isExternal(url);
        return `<a class="ik-tech__b"${accent ? ` style="--tech:${esc(accent)}"` : ''} href="${esc(safeHref(url))}"${ext ? ' target="_blank" rel="noopener noreferrer"' : ''}${title ? ` title="${esc(title)}"` : ''}><span class="ik-tech__i">${svg}</span><span>${esc(name)}</span></a>`;
    };
    const techItems = techs.map((t) => {
        const meta = t.kind ? techIcons[t.kind] : null;
        const name = t.name ?? (meta && meta.label) ?? t.kind ?? 'Tech';
        const url = t.url ?? (meta && meta.url) ?? '#';
        const accent = t.color ?? (t.kind ? techColors[t.kind] : null) ?? '';
        const svg = t.icon
            ? /^\s*<svg/i.test(t.icon)
                ? t.icon
                : `<img src="${esc(safeImg(t.icon))}" alt="">`
            : (meta && meta.svg) || techFb;
        return techBadge(name, url, svg, accent, t.version ? `${name} v${t.version}` : null);
    });
    if (config.signature !== false)
        techItems.push(
            techBadge(
                ikName,
                'https://ilia.ae',
                ikGlyph,
                ikAccent,
                `${ikName} v${moduleVersion} · build ${skBuild}`,
            ),
        );
    const techSnippet = `<!-- @ilia-ae/site-kit · technologies · paste into your footer (self-contained) -->
<div class="ik-tech">${techItems.join('')}</div>
<style>
.ik-tech{display:inline-flex;flex-wrap:wrap;gap:6px;align-items:center;font-family:system-ui,-apple-system,'Segoe UI',sans-serif}
.ik-tech__b{display:inline-flex;align-items:center;gap:5px;padding:2px 8px 2px 6px;border:1px solid var(--border,#e5e5e9);border-radius:4px;color:var(--text-mute,#5c5c6d);font-size:11px;font-weight:600;letter-spacing:.2px;line-height:1.5;text-decoration:none;transition:color .15s,background .15s,border-color .15s}
.ik-tech__b:hover{color:var(--tech,var(--brand,#6366f1));border-color:color-mix(in oklab,var(--tech,var(--brand,#6366f1)) 45%,transparent);background:color-mix(in oklab,var(--tech,var(--brand,#6366f1)) 12%,transparent)}
.ik-tech__i{display:inline-flex;width:11px;height:11px;opacity:.7;flex-shrink:0}
.ik-tech__i svg,.ik-tech__i img{width:100%;height:100%;display:block}
.ik-tech__b:hover .ik-tech__i{opacity:1}
</style>`;
    writeFileSync(join(P.out, 'partials/technologies.html'), techSnippet);
}

// ── favicon assets + SEO files (dist root — preview/gallery + the source of truth) ──
const writeFavicons = (dir, subPath) => {
    if (!favSet) return;
    for (const [name, content] of favSet.assets) {
        const f = join(dir, String(subPath).replace(/^\/+/, ''), name);
        mkdirSync(dirname(f), { recursive: true });
        writeFileSync(f, content);
    }
};
writeFavicons(P.out, favBasePath);
// OG banner assets (og.svg + og.png) → same base path as favicons (og:image points there).
const writeOg = (dir, subPath) => {
    if (!ogSet) return;
    for (const [name, content] of ogSet) {
        const f = join(dir, String(subPath).replace(/^\/+/, ''), name);
        mkdirSync(dirname(f), { recursive: true });
        writeFileSync(f, content);
    }
};
writeOg(P.out, favBasePath);
// Only the real site pages (served per-language at /lang) belong in the multilingual
// sitemap. The QR page serves all languages from ONE URL (?lang=), so it's not listed
// with per-language variants here.
const seoPages = [{ path: '/', lastmod: skBuild }];
const sitemapXml = seoEnabled ? buildSitemap(config, seoPages) : '';
const robotsTxt = seoEnabled ? buildRobotsTxt(config) : '';
if (sitemapXml) writeFileSync(join(P.out, 'sitemap.xml'), sitemapXml);
if (robotsTxt) writeFileSync(join(P.out, 'robots.txt'), robotsTxt);
if (seoEnabled) {
    // A complete, paste-able <head> block (favicon + SEO) for the site's own pages.
    const seoHeadPartial =
        `<!-- @ilia-ae/site-kit · seo + favicon head · paste into your site's <head> (primary lang: ${primaryLang}) -->\n` +
        (config.favicon ? faviconTagsHtml(faviconTags(config.favicon, { theme: config.theme })) + '\n' : '') +
        seoTagsHtml(buildSeoTags(config, { lang: primaryLang, path: '/' }));
    writeFileSync(join(P.out, 'partials/seo-head.html'), seoHeadPartial);
}

// ── 4) local gallery index (preview + LIVE config editor + per-block context) ──
const card = (e) =>
    `<a class="gcard" href="./${esc(e.code)}.html"><span class="cg">${esc(e.glyph)}</span><span class="cc">${esc(String(e.code))}</span><span class="ct">${esc(e.title)}</span></a>`;
// CSS for the data-driven preview blocks, included in <head> so JS re-renders stay styled.
const GALLERY_PARTIAL_CSS = `
.ik-footer{border-top:1px solid var(--border);background:var(--bg-elev);color:var(--text-mute);font:var(--fs-sm)/1.6 var(--font-display,system-ui,sans-serif)}
.ik-footer .inner{max-width:var(--container);margin-inline:auto;padding:var(--sp-8) var(--gutter,1.5rem);display:flex;flex-wrap:wrap;align-items:center;gap:var(--sp-4) var(--sp-6)}
.ik-footer .name{font-weight:var(--fw-bold);color:var(--text);text-decoration:none}.ik-footer .tag{color:var(--text-dim)}
.ik-footer .legal{display:inline-flex;flex-wrap:wrap;gap:var(--sp-4)}.ik-footer .legal a{color:inherit;text-decoration:none}
.ik-footer .copyright{margin:0 0 0 auto;color:var(--text-dim)}
.ik-social{display:inline-flex;flex-wrap:wrap;gap:var(--sp-2);list-style:none;margin:0;padding:0}
.ik-social a{display:inline-flex;padding:var(--sp-2) var(--sp-3);border:1px solid var(--border);border-radius:var(--r-md);background:var(--bg-elev);color:var(--text-mute);text-decoration:none;font-size:var(--fs-sm)}
.ik-projects{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,16rem),1fr));gap:var(--sp-4)}
.ik-pcard{display:flex;flex-direction:column;gap:var(--sp-2);padding:var(--sp-5);text-decoration:none;color:var(--text);border:1px solid var(--border);border-radius:var(--r-lg);background:var(--bg-elev)}
.ik-pcard__top{display:flex;align-items:center;justify-content:space-between}
.ik-pcard__mono{display:grid;place-items:center;width:2.25rem;height:2.25rem;border-radius:var(--r-md);background:var(--grad-brand);color:#fff;font-weight:var(--fw-bold)}
.ik-pcard__logo{width:2.25rem;height:2.25rem;border-radius:var(--r-md);object-fit:cover}
.ik-pcard__badge{font-size:var(--fs-xs);padding:.15em .6em;border-radius:var(--r-full);border:1px solid var(--border);color:var(--text-mute)}
.ik-pcard__badge[data-status=live]{color:var(--success)}.ik-pcard__badge[data-status=wip]{color:var(--accent-3)}.ik-pcard__badge[data-status=archived]{color:var(--text-dim)}
.ik-pcard__name{font-weight:var(--fw-bold)}.ik-pcard__desc{font-size:var(--fs-sm);color:var(--text-mute)}
.ik-pcard__tags{display:flex;flex-wrap:wrap;gap:.35rem;list-style:none;margin:.25rem 0 0;padding:0}.ik-pcard__tags li{font-size:var(--fs-xs);color:var(--text-dim);background:var(--bg-mute);padding:.1em .5em;border-radius:var(--r-sm)}`;
// A block section with context: heading + description + the config slice that drives it.
const slice = (keys) => {
    const o = {};
    for (const k of keys) if (config[k] !== undefined) o[k] = config[k];
    return JSON.stringify(o, null, 2);
};
const ctx = (title, desc, keys, previewId) => `<section>
  <h2>${esc(title)}</h2><p class="desc">${esc(desc)}</p>
  <div class="stage"><div id="${previewId}"></div></div>
  <details class="cfg"><summary>config — данные этого блока (правьте выше → Apply)</summary><pre>${esc(slice(keys))}</pre></details>
</section>`;

// Favicon + SEO modules showcase (icon previews + the generated head block).
const faviconGallery = favSet
    ? `<section><h2>Favicon — один SVG → весь набор</h2>
  <p class="desc">Генерируется из 1 SVG (здесь — из brand.monogram на --brand) при <code>npm run build:static</code>: icon.svg · favicon.ico (32) · apple-touch (180, непрозрачный) · 192/512 · maskable (safe-zone) · manifest.webmanifest. Стандарт 2026 (evilmartians/RealFaviconGenerator), валидируется realfavicongenerator.net/favicon_checker.</p>
  <div class="stage" style="display:flex;gap:1.5rem;align-items:center;flex-wrap:wrap">
    <figure style="margin:0;text-align:center"><img src="./icon.svg" width="72" height="72" alt="icon.svg" style="border-radius:16px"><figcaption class="cc">icon.svg</figcaption></figure>
    <figure style="margin:0;text-align:center"><img src="./apple-touch-icon.png" width="72" height="72" alt="apple-touch" style="border-radius:16px"><figcaption class="cc">apple-touch 180</figcaption></figure>
    <figure style="margin:0;text-align:center"><img src="./icon-512.png" width="72" height="72" alt="icon-512" style="border-radius:16px"><figcaption class="cc">icon 512</figcaption></figure>
    <figure style="margin:0;text-align:center"><img src="./icon-mask.png" width="72" height="72" alt="maskable" style="border-radius:50%"><figcaption class="cc">maskable (circle mask)</figcaption></figure>
  </div>
  <details class="cfg"><summary>config.favicon → &lt;link&gt; tags</summary><pre>${esc(faviconTagsHtml(faviconTags(config.favicon, { theme: config.theme })))}</pre></details>
</section>`
    : '';
const seoGallery = seoEnabled
    ? `<section><h2>SEO — весь head сайта из конфига</h2>
  <p class="desc">title · description · canonical · robots · Open Graph · Twitter/X · hreflang · JSON-LD (${esc(config.seo.entity?.type ?? 'Organization')} + WebSite) + sitemap.xml/robots.txt. Один билдер питает Angular (Seo-сервис) и статику. Валидируется Rich Results Test / schema.org / Lighthouse SEO. Готовый блок — <code>partials/seo-head.html</code>.</p>
  <details class="cfg" open><summary>&lt;head&gt; (primary lang: ${esc(primaryLang)})</summary><pre>${esc(seoTagsHtml(buildSeoTags(config, { lang: primaryLang, path: '/' })))}</pre></details>
</section>`
    : '';

const gallery = `<!doctype html>
<html lang="${esc(primaryLang)}" dir="${isRtl(primaryLang) ? 'rtl' : 'ltr'}">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>@ilia-ae/site-kit — local index</title>
<style>${tokens}
${themeCss}
*,*::before,*::after{box-sizing:border-box}html,body{margin:0}
body{font-family:var(--font-display,system-ui,sans-serif);background:var(--bg);color:var(--text);line-height:var(--lh-base,1.6)}
.gh{position:sticky;top:0;z-index:500;display:flex;align-items:center;gap:var(--sp-3);flex-wrap:wrap;padding:var(--sp-3) var(--sp-6);background:var(--bg-overlay,rgba(255,255,255,.78));backdrop-filter:blur(8px);border-bottom:1px solid var(--border-strong,#aeb0bc)}
.gh .sp{flex:1}.gh .muted{color:var(--text-dim)}.gh .dash{color:var(--brand);text-decoration:none;font-weight:var(--fw-semi,600)}
.gh button{padding:var(--sp-2) var(--sp-4);border-radius:var(--r-full,999px);border:1px solid var(--border-strong,#aeb0bc);background:var(--bg-elev);color:var(--text);cursor:pointer;font:inherit}
.ed{border-bottom:1px solid var(--border)}
.ed .wrap{max-width:var(--container,72rem);margin-inline:auto;padding:var(--sp-4) var(--sp-6);display:flex;flex-direction:column;gap:var(--sp-2)}
.ed textarea{width:100%;min-height:10rem;padding:var(--sp-3);font-family:var(--font-mono,monospace);font-size:var(--fs-xs,.75rem);border:1px solid var(--border-strong);border-radius:var(--r-md);background:var(--bg-elev);color:var(--text);resize:vertical}
.ed .row{display:flex;align-items:center;gap:var(--sp-3)}.ed .hint{margin:0;color:var(--text-dim);font-size:var(--fs-sm)}.ed .hint code{font-family:var(--font-mono);background:var(--bg-mute);padding:.05em .35em;border-radius:4px}
.ed .apply{background:var(--brand);color:var(--text-on-brand,#fff);border-color:var(--brand);font-weight:var(--fw-semi)}
.ed .err{color:var(--danger,#dc2626);font-size:var(--fs-sm)}.ed .ok{color:var(--success,#16a34a);font-size:var(--fs-sm)}
main{max-width:var(--container,72rem);margin-inline:auto;padding:var(--sp-10,2.5rem) var(--sp-6)}
section{margin-bottom:var(--sp-12,3rem)}h2{font-size:var(--fs-xl,1.25rem);margin:0 0 var(--sp-2);padding-bottom:var(--sp-2);border-bottom:1px solid var(--border-soft)}
.desc{margin:0 0 var(--sp-4);color:var(--text-mute);font-size:var(--fs-sm)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(8.5rem,1fr));gap:var(--sp-4)}
.gcard{display:flex;flex-direction:column;align-items:center;gap:var(--sp-1);padding:var(--sp-5) var(--sp-3);text-decoration:none;color:var(--text);border:1px solid var(--border);border-radius:var(--r-lg,16px);background:var(--bg-elev);box-shadow:var(--shadow-sm)}
.gcard:hover{transform:translateY(-3px);border-color:var(--border-strong,#aeb0bc)}
.cg{font-size:var(--fs-3xl,1.875rem);font-weight:var(--fw-black,800);line-height:1;background:var(--grad-brand);-webkit-background-clip:text;background-clip:text;color:transparent}
.cc{font-size:var(--fs-xs,.75rem);color:var(--text-dim);letter-spacing:var(--ls-wide,.06em)}.ct{font-size:var(--fs-sm,.875rem);text-align:center;color:var(--text-mute)}
.stage{padding:var(--sp-6);border:1px solid var(--border);border-radius:var(--r-lg,16px);background:var(--bg-elev);box-shadow:var(--shadow-sm);min-height:3rem}
.cfg{margin-top:var(--sp-3)}.cfg summary{cursor:pointer;font-family:var(--font-mono);font-size:var(--fs-xs);color:var(--text-dim)}
.cfg pre{margin:var(--sp-2) 0 0;padding:var(--sp-3);overflow:auto;font-size:var(--fs-xs);font-family:var(--font-mono);border:1px solid var(--border-soft);border-radius:var(--r-md);background:var(--bg-sunk)}
.note{color:var(--text-mute)}.note code{font-family:var(--font-mono,monospace);background:var(--bg-mute);padding:.1em .4em;border-radius:var(--r-xs,4px)}
${GALLERY_PARTIAL_CSS}
</style></head>
<body>
<header class="gh"><strong>@ilia-ae/site-kit</strong><span class="muted">local index · ${esc(brand)} · ${esc(languages.join(' / '))}</span><span class="sp"></span><a class="dash" href="./dashboard.html">inventory →</a><button id="themeBtn" type="button">☾ / ☀ theme</button></header>

<div class="ed"><div class="wrap">
  <p class="hint">Редактор конфига — правьте JSON и <b>Apply</b>: блоки ниже (footer / projects / social) перерисуются из этих данных. Удалите <code>projects</code> → блок исчезнет (адаптивность). Статус-страницы и QR пересобираются через <code>npm run build:static</code>.</p>
  <textarea id="cfg" spellcheck="false">${esc(JSON.stringify(config, null, 2))}</textarea>
  <div class="row"><button class="apply" id="apply" type="button">Apply →</button><span id="msg" class="ok">✓ блоки берут данные отсюда</span></div>
</div></div>

<main>
  <section><h2>Status pages (${emitted.length}) — клик открывает полную мультиязычную страницу</h2><p class="desc">Один компонент + каталог кодов; показывает все языки сразу (RTL для ar/ur).</p><div class="grid">${emitted.map(card).join('')}</div></section>
  ${ctx('Projects', 'Грид «наши проекты» из config.projects. Ссылки локаль-зависимые, бейджи статуса. Пусто → блок скрыт.', ['projects'], 'pv-projects')}
  ${ctx('Footer', 'Авто-копирайт (год сам), бренд, юр-ссылки — из config.copyright/brand/legal.', ['brand', 'copyright', 'legal'], 'pv-footer')}
  ${ctx('Social', 'Каналы из config.social.', ['social'], 'pv-social')}
  ${qrSnippet ? `<section><h2>Contact QR</h2><p class="desc">QR генерится из config.contact.qr (сборкой). Полный интерактив (share-кнопки, 9 каналов) — в плейграунде.</p><div class="stage">${qrSnippet}</div><details class="cfg"><summary>config.contact</summary><pre>${esc(slice(['contact']))}</pre></details></section>` : ''}
  ${faviconGallery}
  ${seoGallery}
  <section><h2>Интерактивные блоки</h2><p class="note">nav, cookie-consent, lang-switcher, theme-toggle — интерактивные (Angular). Запустите <code>npm start</code>.</p></section>
</main>

<script>
var DEF=${defaultLang ? JSON.stringify(defaultLang) : '"en"'}, LANG=${primaryLang ? JSON.stringify(primaryLang) : '"en"'}, YEAR=${year};
var SK_VER=${JSON.stringify(skVersion)}, SK_BUILD=${JSON.stringify(skBuild)};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function safeHref(u){u=String(u==null?'':u);return /^(javascript|data|vbscript|file):/i.test(u.trim())?'#':u;}
function ext(u){return /^https?:\\/\\//i.test(String(u));}
function loc(url,lang,def){if(!url||lang===def)return url;if(/^(mailto:|tel:|#)/i.test(url))return url;var m=/^(https?:\\/\\/[^/]+)(\\/.*)?$/i.exec(url);var seg=function(p){return (p.split('/').filter(Boolean)[0]||'');};if(m){var o=m[1],pa=m[2]||'';if(seg(pa)===lang)return url;return o+'/'+lang+(pa===''||pa==='/'?'':pa);}var p=url.charAt(0)==='/'?url:'/'+url;if(seg(p)===lang)return url;return '/'+lang+(p==='/'?'':p);}
function lh(l,lang,def){return safeHref((l.urls&&l.urls[lang])||(l.localize?loc(l.url,lang,def):l.url));}
function lt(v,l,d){if(v==null)return '';if(typeof v==='string')return v;return v[l]||v[d]||Object.values(v)[0]||'';}
function renderFooter(c){var b=c.brand||{},cr=c.copyright||{},def=c.defaultLang||DEF;var r=cr.startYear&&cr.startYear<YEAR?cr.startYear+'–'+YEAR:''+YEAR;var tag=lt(b.tagline,LANG,def),sfx=lt(cr.suffix,LANG,def);var legal=(c.legal||[]).map(function(x){return '<a href="'+esc(safeHref(x.href))+'">'+esc(lt(x.label,LANG,def))+'</a>';}).join('');var sig='';return '<footer class="ik-footer"><div class="inner"><a class="name" href="'+esc(safeHref(loc(b.url||'/',LANG,def)))+'">'+esc(b.name||'')+'</a>'+(tag?'<span class="tag">'+esc(tag)+'</span>':'')+(legal?'<nav class="legal">'+legal+'</nav>':'')+sig+'<p class="copyright">© '+r+' '+esc(cr.holder||b.name||'')+'.'+(sfx?' '+esc(sfx):'')+'</p></div></footer>';}
function renderSocial(c){var s=c.social||[];if(!s.length)return '<span class="note">config.social пуст</span>';return '<ul class="ik-social">'+s.map(function(x){var e=ext(x.url);return '<li><a href="'+esc(safeHref(x.url))+'"'+(e?' target="_blank" rel="noopener noreferrer"':'')+'>'+esc((x.label&&typeof x.label==='object'?Object.values(x.label)[0]:x.label)||x.kind)+'</a></li>';}).join('')+'</ul>';}
function renderProjects(c){var p=c.projects||[],def=c.defaultLang||DEF,bd={live:'Live',wip:'WIP',archived:'Archived'};if(!p.length)return '<span class="note">config.projects пуст → блок скрыт</span>';return '<div class="ik-projects">'+p.map(function(x){var href=lh(x,LANG,def),e=ext(href),mono=(x.name||'?').trim().charAt(0).toUpperCase(),tags=(x.tags||[]).map(function(t){return '<li>'+esc(t)+'</li>';}).join('');return '<a class="ik-pcard" href="'+esc(href)+'"'+(e?' target="_blank" rel="noopener noreferrer"':'')+'><span class="ik-pcard__top">'+(x.logoUrl?'<img class="ik-pcard__logo" src="'+esc(x.logoUrl)+'" alt="'+esc(x.name)+'">':'<span class="ik-pcard__mono">'+esc(mono)+'</span>')+(x.status?'<span class="ik-pcard__badge" data-status="'+esc(x.status)+'">'+esc(bd[x.status]||x.status)+'</span>':'')+'</span><span class="ik-pcard__name">'+esc(x.name)+'</span>'+(x.description?'<span class="ik-pcard__desc">'+esc(x.description)+'</span>':'')+(tags?'<ul class="ik-pcard__tags">'+tags+'</ul>':'')+'</a>';}).join('')+'</div>';}
function paint(c){document.getElementById('pv-footer').innerHTML=renderFooter(c);document.getElementById('pv-social').innerHTML=renderSocial(c);document.getElementById('pv-projects').innerHTML=renderProjects(c);}
function apply(){var msg=document.getElementById('msg');try{var c=JSON.parse(document.getElementById('cfg').value);if(!c.brand||!c.brand.name)throw new Error('brand.name обязателен');paint(c);msg.className='ok';msg.textContent='✓ применено';}catch(e){msg.className='err';msg.textContent='⚠ '+e.message;}}
document.getElementById('apply').addEventListener('click',apply);
document.getElementById('themeBtn').addEventListener('click',function(){document.documentElement.classList.toggle('app-dark');});
paint(${JSON.stringify(config).replace(/</g, '\\u003c').replace(/>/g, '\\u003e')});
</script>
</body></html>`;
writeFileSync(join(P.out, 'index.html'), gallery);

// ── 5) deployable per-target bundle (git | cloudflare | wp) ──────────────────
// A self-describing public folder (default /kit): error pages + QR page + public
// config + manifest + tokens, laid out at the CONFIGURED routes. The manifest lets
// the inventory check a live site remotely.

// QR — a standalone branded MULTILINGUAL page (served at qrRoute). The primary
// language is rendered server-side (works with no JS + SEO); an inline script
// then picks the language from ?lang= → navigator → primary and swaps the QR
// TARGET + chrome, so ONE file serves every language for non-Angular sites (WP):
//   https://<site>/kit/qr.html?lang=en  ·  ?lang=ru  ·  (no param → auto-detect).
const qc = config.contact ?? {};
const qrLangs = languages; // the site's configured set
const qrPrimary = qrLangs.includes(primaryLang) ? primaryLang : qrLangs[0];

// Native names: mirror of IK_LANGUAGES (a .mjs can't import the .ts) — keep in sync with
// i18n/languages.ts. The QR / contact labels (QR_STRINGS) come from the shared JSON loaded above.
const LANG_NAMES = {
    en: 'English',
    ru: 'Русский',
    ar: 'العربية',
    kk: 'Қазақша',
    zh: '中文',
    hi: 'हिन्दी',
    ur: 'اردو',
};
const qrStr = (lang, key) => config.strings?.[lang]?.[key] ?? QR_STRINGS[lang]?.[key] ?? QR_STRINGS.en[key];
const BRAND_SHARE = {
    telegram: 'Telegram',
    whatsapp: 'WhatsApp',
    x: 'X',
    linkedin: 'LinkedIn',
    facebook: 'Facebook',
    vk: 'VK',
};
const LOCALIZABLE_SHARE = { native: 1, copy: 1, email: 1 };
const shareLabelFor = (k, lang) =>
    k === 'native'
        ? qrStr(lang, 'share')
        : k === 'copy'
          ? qrStr(lang, 'copy')
          : k === 'email'
            ? qrStr(lang, 'email')
            : (BRAND_SHARE[k] ?? k);

// Inline icons (library constants — same set as ik-contact-qr).
const ARROW_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>`;
const SHARE_ICONS = {
    native: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><path d="M16 6l-4-4-4 4"/><path d="M12 2v14"/></svg>`,
    copy: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
    telegram: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.94 4.34c-.31-.26-.78-.3-1.18-.13L2.77 11.7c-.46.19-.74.66-.7 1.16.05.5.41.91.9 1.02l4.51 1.04 1.74 5.38c.13.39.46.67.86.74.4.06.81-.1 1.05-.42l2.33-3.05 4.59 3.39c.21.16.46.24.71.24.16 0 .31-.03.46-.09.4-.16.69-.51.76-.94l2.32-13.74c.07-.42-.11-.84-.46-1.09zM9.74 14.45l-.65 3.55-1.13-3.5 7.7-5.7-5.92 5.65z"/></svg>`,
    whatsapp: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.5 14.4c-.3-.15-1.77-.87-2.04-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.17.2-.35.22-.65.07-1.77-.88-2.93-1.58-4.1-3.58-.31-.53.31-.5.88-1.65.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51l-.57-.01c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.06 2.88 1.21 3.07.15.2 2.09 3.2 5.07 4.49.71.3 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.08 1.77-.72 2.02-1.42.25-.7.25-1.3.17-1.42-.07-.13-.27-.2-.57-.35zM12 2C6.48 2 2 6.48 2 12c0 1.78.46 3.45 1.27 4.9L2 22l5.25-1.38A9.93 9.93 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm5.83 14.83A8 8 0 0 1 7.7 18.04l-.4-.24-3.07.81.82-2.99-.26-.41A8 8 0 1 1 17.83 16.83z"/></svg>`,
    x: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231 5.451-6.231zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77z"/></svg>`,
    linkedin: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.13 1.45-2.13 2.94v5.67H9.36V9h3.41v1.56h.05c.47-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.55C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.72V1.72C24 .77 23.2 0 22.22 0z"/></svg>`,
    facebook: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/></svg>`,
    vk: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93v6.13C2 20.67 3.33 22 8.93 22h6.13c5.6 0 6.93-1.33 6.93-6.93V8.93C22 3.33 20.67 2 15.07 2zm3.07 14.27h-1.45c-.55 0-.72-.44-1.71-1.43-.85-.83-1.23-.94-1.43-.94-.28 0-.36.08-.36.47v1.31c0 .33-.11.53-.96.53-1.43 0-3-.86-4.11-2.46C6.4 11.53 5.94 9.81 5.94 9.46c0-.2.08-.39.47-.39h1.45c.36 0 .49.16.62.55.69 2.02 1.86 3.79 2.34 3.79.18 0 .26-.08.26-.55v-2.13c-.06-.97-.58-1.06-.58-1.41 0-.16.14-.33.36-.33h2.28c.31 0 .42.16.42.53v2.86c0 .31.13.42.22.42.18 0 .33-.11.66-.44 1.04-1.16 1.78-2.95 1.78-2.95.09-.2.25-.39.61-.39h1.45c.44 0 .53.22.44.53-.18.85-1.96 3.36-1.96 3.36-.16.25-.22.36 0 .64.16.2.69.66 1.04 1.07.66.74 1.16 1.36 1.31 1.79.13.42-.09.64-.53.64z"/></svg>`,
    email: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 7l10 7 10-7"/></svg>`,
};

// per-language QR target (mirrors ContactQr.qrTarget / SiteKitLink resolution).
const qrBase = qc.qr?.data ?? config.brand?.url ?? brandUrl;
const qrTargetFor = (lang) =>
    qc.qr?.urls?.[lang] ?? (qc.qr?.localize ? localizeUrl(qrBase, lang, defaultLang) : qrBase);
// lede / caption may be a plain string (shared) OR a per-language { en, ru } map.
const pickLang = (v, lang) =>
    v && typeof v === 'object' && !Array.isArray(v)
        ? (v[lang] ?? v[defaultLang] ?? Object.values(v)[0] ?? '')
        : (v ?? '');

// Eyebrow pill — translates with the language (mirrors the Angular demo: CARD ↔ ВИЗИТКА).
const EYEBROW = { en: 'CARD', ru: 'ВИЗИТКА', ar: 'بطاقة', kk: 'КАРТА', zh: '名片', hi: 'कार्ड', ur: 'کارڈ' };
const eyebrowFor = (l) => EYEBROW[l] ?? EYEBROW[defaultLang] ?? 'CARD';

// baked per-language data the inline script swaps between (RAW strings → textContent).
const langData = {};
for (const l of qrLangs) {
    langData[l] = {
        dir: isRtl(l) ? 'rtl' : 'ltr',
        qr: genQrSvg(qrTargetFor(l)) || '',
        target: qrTargetFor(l),
        eyebrow: eyebrowFor(l),
        lede: pickLang(qc.qr?.lede, l),
        scan: pickLang(qc.qr?.caption, l) || qrStr(l, 'scan'),
        shareTitle: qrStr(l, 'shareTitle'),
        linksTitle: qrStr(l, 'linksTitle'),
        share: {
            native: qrStr(l, 'share'),
            copy: qrStr(l, 'copy'),
            copied: qrStr(l, 'copied'),
            email: qrStr(l, 'email'),
        },
        links: (qc.quickLinks ?? []).map((ln) => ({ href: linkHref(ln, l, defaultLang) })),
    };
}

// ── server-rendered fragments (primary language) ──
const langSwitcher =
    qrLangs.length > 1
        ? `<div class="langs" role="group" aria-label="Language">${qrLangs.map((l) => `<button type="button" class="lang${l === qrPrimary ? ' active' : ''}" data-lang="${esc(l)}"${l === qrPrimary ? ' aria-current="true"' : ''}>${esc(LANG_NAMES[l] ?? l)}</button>`).join('')}</div>`
        : '';
const brandGlyph = typeof config.brand?.glyph === 'string' ? config.brand.glyph : '';
const monoHtml = brandGlyph
    ? `<span class="mono mono--glyph">${brandGlyph}</span>`
    : config.brand?.logoUrl
      ? `<img class="mono mono--img" src="${esc(safeImg(config.brand.logoUrl))}" alt="${esc(brand)}">`
      : `<span class="mono">${esc(config.brand?.monogram ?? brand.charAt(0))}</span>`;
const personHtml =
    qc.person || qc.role || qc.location
        ? `<div class="person">${qc.person ? `<span class="person__name">${esc(qc.person)}</span>` : ''}${qc.role ? `<span class="person__role">${esc(qc.role)}</span>` : ''}${qc.location ? `<span class="person__loc">${esc(qc.location)}</span>` : ''}</div>`
        : '';
const ledeP = pickLang(qc.qr?.lede, qrPrimary);
const corners = qc.qr?.corners ?? 'none';
const cornersHtml =
    corners !== 'none'
        ? `<span class="corner corner--tl"></span><span class="corner corner--tr"></span><span class="corner corner--bl"></span><span class="corner corner--br"></span>`
        : '';
const badgeHtml = brandGlyph
    ? `<span class="badge"><span class="badge__glyph">${brandGlyph}</span></span>`
    : config.brand?.logoUrl
      ? `<span class="badge"><img class="badge__img" src="${esc(safeImg(config.brand.logoUrl))}" alt="${esc(brand)}"></span>`
      : `<span class="badge"><span class="badge__text">${esc(config.brand?.monogram ?? brand.charAt(0))}</span></span>`;
const prettyTg = (u) => {
    const h = String(u).replace(/^https?:\/\/(t\.me\/)?/i, '');
    return h && h !== u ? '@' + h : u;
};
const waHref = (v) => (/^https?:\/\//i.test(v) ? v : `https://wa.me/${String(v).replace(/[^\d]/g, '')}`);
const waLabel = (v) => {
    const d = String(v).replace(/[^\d]/g, '');
    return d ? formatPhone('+' + d) : 'WhatsApp';
};
// Phone display grouping — mirror of lib/i18n/phone-format.ts (display only; tel: uses raw digits).
const PHONE_GROUPS = {
    1: [3, 3, 4],
    7: [3, 3, 2, 2],
    20: [2, 4, 4],
    27: [2, 3, 4],
    30: [3, 3, 4],
    31: [1, 2, 2, 2, 2],
    32: [3, 2, 2, 2],
    33: [1, 2, 2, 2, 2],
    34: [3, 3, 3],
    36: [2, 3, 4],
    39: [3, 4, 4],
    40: [3, 3, 3],
    41: [2, 3, 2, 2],
    43: [3, 4, 4],
    44: [2, 4, 4],
    45: [2, 2, 2, 2],
    46: [2, 3, 2, 2],
    47: [3, 2, 3],
    48: [3, 3, 3],
    49: [3, 4, 5],
    51: [3, 3, 3],
    52: [2, 4, 4],
    54: [2, 4, 4],
    55: [2, 5, 4],
    56: [1, 4, 4],
    57: [3, 3, 4],
    58: [3, 3, 4],
    60: [2, 4, 4],
    61: [1, 4, 4],
    62: [3, 4, 4],
    63: [3, 3, 4],
    64: [1, 3, 4],
    65: [4, 4],
    66: [1, 4, 4],
    81: [2, 4, 4],
    82: [2, 4, 4],
    84: [2, 4, 3],
    86: [3, 4, 4],
    90: [3, 3, 2, 2],
    91: [5, 5],
    92: [3, 7],
    93: [2, 3, 4],
    94: [2, 3, 4],
    95: [2, 3, 4],
    98: [3, 3, 4],
    212: [4, 6],
    213: [3, 2, 2, 2],
    234: [3, 3, 4],
    351: [3, 3, 3],
    352: [2, 2, 2, 2, 2],
    353: [2, 3, 4],
    358: [2, 3, 2, 2],
    359: [2, 3, 3],
    370: [3, 3, 2],
    371: [2, 3, 3],
    372: [3, 4],
    373: [3, 2, 3],
    374: [2, 6],
    375: [2, 3, 2, 2],
    377: [2, 2, 2, 2],
    380: [2, 3, 2, 2],
    381: [2, 3, 4],
    385: [2, 3, 3],
    386: [2, 3, 3],
    420: [3, 3, 3],
    421: [3, 3, 3],
    852: [4, 4],
    880: [4, 6],
    886: [1, 3, 3, 3],
    961: [1, 3, 3],
    962: [1, 4, 4],
    963: [2, 3, 3],
    964: [3, 3, 4],
    965: [4, 4],
    966: [2, 3, 4],
    967: [3, 3, 3],
    968: [4, 4],
    970: [3, 3, 3],
    971: [2, 3, 4],
    972: [2, 3, 4],
    973: [4, 4],
    974: [4, 4],
    975: [2, 3, 3],
    976: [2, 2, 4],
    977: [2, 3, 5],
    992: [2, 3, 4],
    993: [2, 2, 2, 2],
    994: [2, 3, 2, 2],
    995: [3, 3, 3],
    996: [3, 3, 3],
    998: [2, 3, 2, 2],
};
const PHONE_CODES = Object.keys(PHONE_GROUPS).sort((a, b) => b.length - a.length);
const phGroupBy = (s, sizes) => {
    const parts = [];
    let i = 0;
    for (const g of sizes) {
        if (i >= s.length) break;
        parts.push(s.slice(i, i + g));
        i += g;
    }
    if (i < s.length) parts.push(s.slice(i));
    return parts.filter(Boolean).join(' ');
};
const phGeneric = (n) => {
    const sizes = [];
    let rem = n;
    while (rem > 4) {
        sizes.push(3);
        rem -= 3;
    }
    sizes.push(rem);
    if (sizes.length > 1 && sizes[sizes.length - 1] === 1) {
        sizes[sizes.length - 2] += 1;
        sizes.pop();
    }
    return sizes;
};
const formatPhone = (raw) => {
    const hasPlus = /^\s*\+/.test(raw);
    const digits = String(raw).replace(/\D/g, '');
    if (digits.length < 5) return raw;
    const code = hasPlus ? (PHONE_CODES.find((c) => digits.startsWith(c)) ?? '') : '';
    if (!code) return (hasPlus ? '+' : '') + phGroupBy(digits, phGeneric(digits.length));
    return ('+' + code + ' ' + phGroupBy(digits.slice(code.length), PHONE_GROUPS[code])).trim();
};
const CHANNEL_ICONS = {
    telegram: SHARE_ICONS.telegram,
    whatsapp: SHARE_ICONS.whatsapp,
    email: SHARE_ICONS.email,
    phone: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
    website: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 0 20 15.3 15.3 0 0 1 0-20z"/></svg>`,
    form: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z"/></svg>`,
};
const chans = [];
if (qc.telegram)
    chans.push({
        icon: CHANNEL_ICONS.telegram,
        label: prettyTg(qc.telegram),
        href: safeHref(qc.telegram),
        ext: true,
    });
if (qc.whatsapp)
    chans.push({
        icon: CHANNEL_ICONS.whatsapp,
        label: waLabel(qc.whatsapp),
        href: safeHref(waHref(qc.whatsapp)),
        ext: true,
    });
if (qc.email)
    chans.push({ icon: CHANNEL_ICONS.email, label: qc.email, href: `mailto:${qc.email}`, ext: false });
if (qc.phone)
    chans.push({
        icon: CHANNEL_ICONS.phone,
        label: formatPhone(qc.phone),
        href: `tel:${String(qc.phone).replace(/[^\d+]/g, '')}`,
        ext: false,
    });
if (qc.website)
    chans.push({
        icon: CHANNEL_ICONS.website,
        label: qrStr(qrPrimary, 'website'),
        href: safeHref(qc.website),
        ext: isExternal(qc.website),
    });
if (qc.contactForm)
    chans.push({
        icon: CHANNEL_ICONS.form,
        label: qrStr(qrPrimary, 'contactForm'),
        href: safeHref(qc.contactForm),
        ext: isExternal(qc.contactForm),
    });
const channelsHtml = chans.length
    ? `<ul class="links" role="list">${chans.map((c) => `<a class="link" href="${esc(c.href)}"${c.ext ? ' target="_blank" rel="noopener noreferrer"' : ''}><span class="link__icon">${c.icon}</span><span class="link__label">${esc(c.label)}</span><span class="link__arrow">${ARROW_ICON}</span></a>`).join('')}</ul>`
    : '';
const shareKinds = qc.share ?? ['native', 'copy', 'telegram', 'whatsapp', 'email'];
// presentation knobs (mirror ik-contact-qr inputs; config-driven for static parity)
// accent is set ONLY for an explicit override → chips otherwise inherit the theme --brand (one colour for all).
const shareAccent = (k) => qc.shareColors?.[k] ?? null;
const shareCls = `share${qc.shareLayout === 'inline' ? ' share--inline' : ''}${qc.shareTheme === 'color' ? ' share--color' : ''}`;
const shareHtml = shareKinds.length
    ? `<section class="sec"><h2 class="sec__title" id="shareTitle">${esc(qrStr(qrPrimary, 'shareTitle'))}</h2><div class="${shareCls}">${shareKinds.map((k) => `<button type="button" class="chip" data-share="${esc(k)}"${shareAccent(k) ? ` style="--chip-accent:${esc(shareAccent(k))}"` : ''} aria-label="${esc(shareLabelFor(k, qrPrimary))}"><span class="chip__icon">${SHARE_ICONS[k] ?? ''}</span><span class="chip__label"${LOCALIZABLE_SHARE[k] ? ` data-share-label="${esc(k)}"` : ''}>${esc(shareLabelFor(k, qrPrimary))}</span></button>`).join('')}</div></section>`
    : '';
const qlinks = qc.quickLinks ?? [];
const quickHtml = qlinks.length
    ? `<section class="sec"><h2 class="sec__title" id="linksTitle">${esc(qrStr(qrPrimary, 'linksTitle'))}</h2><ul class="links" role="list">${qlinks.map((l, i) => `<a class="link" data-ql="${i}" href="${esc(linkHref(l, qrPrimary, defaultLang))}"${isExternal(l.url) ? ' target="_blank" rel="noopener noreferrer"' : ''}><span class="link__label">${esc(lt(l.label, qrPrimary, defaultLang))}</span><span class="link__arrow">${ARROW_ICON}</span></a>`).join('')}</ul>`
    : '';
const frameInner = `<span class="qr" id="qr">${genQrSvg(qrTargetFor(qrPrimary)) || ''}</span>${badgeHtml}${cornersHtml}`;
const frameHtml = qc.qr?.href
    ? `<a class="frame frame--${corners}" href="${esc(safeHref(qc.qr.href))}" target="_blank" rel="noopener noreferrer">${frameInner}</a>`
    : `<span class="frame frame--${corners}">${frameInner}</span>`;

const LANGS_JSON = JSON.stringify(langData).replace(/</g, '\\u003c');
const qrCss = `*,*::before,*::after{box-sizing:border-box}html,body{margin:0;min-height:100%}
body{font-family:var(--font-display,system-ui,sans-serif);background:var(--bg);color:var(--text)}
.shell{position:relative;display:grid;place-items:center;min-height:100dvh;padding:var(--sp-6);isolation:isolate;overflow:hidden}
.bg{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:0}
.bg .glow{position:absolute;width:45vmax;height:45vmax;border-radius:50%;filter:blur(90px);opacity:.5}
.bg .glow--1{top:-12%;left:-8%;background:radial-gradient(circle,var(--brand,#6d28d9),transparent 70%)}
.bg .glow--2{bottom:-15%;right:-10%;background:radial-gradient(circle,var(--accent-2,#db2777),transparent 70%)}
.bg .grid{position:absolute;inset:0;background-image:linear-gradient(to right,var(--border,#e5e5e9) 1px,transparent 1px),linear-gradient(to bottom,var(--border,#e5e5e9) 1px,transparent 1px);background-size:48px 48px;opacity:.4;-webkit-mask-image:radial-gradient(ellipse 70% 60% at 50% 40%,#000 20%,transparent 75%);mask-image:radial-gradient(ellipse 70% 60% at 50% 40%,#000 20%,transparent 75%)}
.card{position:relative;z-index:1;width:100%;max-width:26rem;display:flex;flex-direction:column;gap:var(--sp-5,1.25rem);padding:var(--sp-8,2rem) var(--sp-6,1.5rem) var(--sp-6,1.5rem);background:color-mix(in oklab,var(--bg-elev,#fff) 88%,transparent);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border:1px solid var(--border,#e5e5e9);border-radius:var(--r-xl,24px);box-shadow:var(--shadow-lg,0 20px 48px rgba(9,9,15,.1))}
.head{display:flex;align-items:center;justify-content:space-between;gap:var(--sp-3,.75rem);flex-wrap:wrap}
.head__brand{display:inline-flex;align-items:center;gap:var(--sp-3,.75rem);min-width:0}
.head__text{display:flex;flex-direction:column;min-width:0}
.head__actions{display:inline-flex;align-items:center;gap:var(--sp-2,.5rem);flex-wrap:wrap}
.mono{display:grid;place-items:center;width:2.75rem;height:2.75rem;flex-shrink:0;border-radius:var(--r-md,12px);background:var(--grad-brand,linear-gradient(135deg,var(--brand,#6d28d9),var(--accent-2,#db2777)));color:var(--brand-text,#fff);font-weight:var(--fw-black,800);font-size:var(--fs-xl,1.25rem);box-shadow:0 6px 16px var(--brand-glow,rgba(109,40,217,.4))}
.mono--img{background:transparent;box-shadow:none;object-fit:contain}
.mono--glyph{color:#fff}.mono--glyph svg{display:block;width:55%;height:55%}
.brand-name{font-size:var(--fs-xl,1.25rem);font-weight:var(--fw-bold,700);letter-spacing:var(--ls-tight,-.025em);color:var(--text,#09090f)}
.brand-sub{font-size:var(--fs-sm,.875rem);color:var(--text-mute,#5c5c6d)}
.tbtn,.lang{padding:.3rem .6rem;border:1px solid var(--border,#e5e5e9);border-radius:var(--r-full,999px);background:var(--bg-elev,#fff);color:var(--text-mute,#5c5c6d);cursor:pointer;font:inherit;font-size:var(--fs-xs,.75rem);line-height:1}
.tbtn:hover,.lang:hover{border-color:var(--border-strong,#cdcdd4);color:var(--text,#09090f)}
.lang.active{background:var(--brand,#6d28d9);border-color:var(--brand,#6d28d9);color:var(--brand-text,#fff)}
.eyebrow{display:inline-flex;align-items:center;padding:.28em .65em;font-size:.58rem;font-weight:var(--fw-bold,700);letter-spacing:.18em;text-transform:uppercase;color:var(--brand-strong,var(--brand,#6d28d9));background:color-mix(in srgb,var(--brand,#6d28d9) 12%,transparent);border:1px solid color-mix(in srgb,var(--brand,#6d28d9) 24%,transparent);border-radius:var(--r-full,999px);white-space:nowrap}
.person{display:flex;flex-direction:column;gap:2px}
.person__name{font-size:var(--fs-lg,1.125rem);font-weight:var(--fw-semi,600);color:var(--text,#09090f)}
.person__role{font-size:var(--fs-sm,.875rem);color:var(--brand,#6d28d9);font-weight:var(--fw-medium,500)}
.person__loc{font-size:var(--fs-sm,.875rem);color:var(--text-dim,#8e8ea0)}
.lede{margin:0;font-size:var(--fs-sm,.875rem);line-height:1.5;color:var(--text-mute,#5c5c6d);text-align:center;text-wrap:balance;max-width:38ch;margin-inline:auto}
.lede[hidden]{display:none}
.qr-wrap{display:flex;flex-direction:column;align-items:center;gap:var(--sp-3,.75rem);margin:0}
.frame{position:relative;display:block;padding:var(--sp-4,1rem);background:#fff;border:1px solid var(--border,#e5e5e9);border-radius:var(--r-lg,16px);box-shadow:var(--shadow-md,0 8px 24px rgba(9,9,15,.08));line-height:0}
.qr{display:block;width:var(--ik-qr-size,13rem);height:var(--ik-qr-size,13rem)}
.qr svg{display:block;width:100%;height:100%}
.badge{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:grid;place-items:center;width:calc(var(--ik-qr-size,13rem)*.22);height:calc(var(--ik-qr-size,13rem)*.22);border-radius:var(--r-md,12px);background:var(--grad-brand,linear-gradient(135deg,var(--brand,#6d28d9),var(--accent-2,#db2777)));box-shadow:0 0 0 5px #fff,0 6px 16px color-mix(in srgb,var(--brand,#6d28d9) 38%,transparent);overflow:hidden;line-height:1}
.badge__text{font-size:calc(var(--ik-qr-size,13rem)*.115);font-weight:var(--fw-black,800);color:var(--brand-text,#fff)}
.badge__img{width:78%;height:78%;object-fit:contain}
.badge__glyph{display:inline-flex;align-items:center;justify-content:center;color:#fff}.badge__glyph svg{display:block;width:52%;height:52%}
.corner{position:absolute;width:1.05rem;height:1.05rem;pointer-events:none;border-color:var(--brand,#6d28d9)}
.frame--solid .corner{border-style:solid}.frame--dashed .corner{border-style:dashed}
.corner--tl{top:0;left:0;border-width:2px 0 0 2px;border-top-left-radius:var(--r-lg,16px)}
.corner--tr{top:0;right:0;border-width:2px 2px 0 0;border-top-right-radius:var(--r-lg,16px)}
.corner--bl{bottom:0;left:0;border-width:0 0 2px 2px;border-bottom-left-radius:var(--r-lg,16px)}
.corner--br{bottom:0;right:0;border-width:0 2px 2px 0;border-bottom-right-radius:var(--r-lg,16px)}
.frame--none .corner{display:none}
.scan{font-size:var(--fs-xs,.75rem);color:var(--text-dim,#8e8ea0);font-style:italic;line-height:1.5;text-align:center;text-wrap:balance;max-width:36ch;margin-inline:auto}
.sec{display:flex;flex-direction:column;gap:var(--sp-3,.75rem)}
.sec__title{margin:0;font-size:11px;font-weight:var(--fw-black,800);letter-spacing:.14em;text-transform:uppercase;color:var(--text-dim,#8e8ea0)}
.card--div-center .sec__title{display:flex;align-items:center;gap:.75rem;text-align:center;white-space:nowrap}
.card--div-center .sec__title::before,.card--div-center .sec__title::after{content:'';flex:1 1 0;min-width:0;border-top:1px solid var(--border,#e5e5e9)}
.card--div-dashed .sec__title::before,.card--div-dashed .sec__title::after{border-top-style:dashed}
.card--div-center .sec{gap:var(--sp-5,1.25rem)}
.links{display:flex;flex-direction:column;gap:var(--sp-1,.25rem);margin:0;padding:0;list-style:none}
.link{display:flex;align-items:center;justify-content:space-between;gap:var(--sp-3,.75rem);padding:.625rem .75rem;border-radius:var(--r-md,12px);border:1px solid transparent;color:var(--text,#09090f);font-size:var(--fs-sm,.875rem);font-weight:var(--fw-medium,500);text-decoration:none}
.link:hover{background:var(--bg-mute,#f0f0f2);border-color:var(--border,#e5e5e9)}
.link__icon{display:inline-flex;align-items:center;justify-content:center;width:1.1rem;height:1.1rem;flex-shrink:0;color:var(--brand,#6d28d9)}
.link__icon svg{width:100%;height:100%}
.link__label{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.link__arrow{display:inline-flex;width:1rem;height:1rem;flex-shrink:0;color:var(--text-dim,#8e8ea0)}
.link__arrow svg{width:100%;height:100%}
.link:hover .link__arrow{color:var(--brand,#6d28d9)}
.share{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--sp-2,.5rem)}
.chip{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-width:0;padding:.625rem .375rem;background:var(--bg-elev,#fff);border:1px solid var(--border,#e5e5e9);border-radius:var(--r-md,12px);color:var(--text,#09090f);font:inherit;font-size:var(--fs-xs,.75rem);font-weight:var(--fw-semi,600);cursor:pointer;overflow:hidden}
.chip:hover{background:var(--bg-mute,#f0f0f2);border-color:var(--border-strong,#cdcdd4)}
.chip__icon{display:inline-flex;align-items:center;justify-content:center;width:1.25rem;height:1.25rem;flex-shrink:0;color:var(--brand,#6d28d9)}
.chip__icon svg{width:100%;height:100%}
.chip__label{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.share--inline .chip{flex-direction:row;justify-content:flex-start;gap:.55rem;padding:.65rem .7rem;background:var(--bg-mute,#1c1c20);border-radius:.65rem;text-align:left}
.share--inline .chip__icon{width:18px;height:18px;color:var(--text,#09090f)}
.share--inline .chip:hover{color:var(--chip-accent,var(--brand,#6d28d9));border-color:color-mix(in oklab,var(--chip-accent,var(--brand,#6d28d9)) 45%,transparent);background:color-mix(in oklab,var(--chip-accent,var(--brand,#6d28d9)) 8%,var(--bg-elev,#fff))}
.share--inline .chip:hover .chip__icon{color:var(--chip-accent,var(--brand,#6d28d9))}
.share--color .chip__icon{color:var(--chip-accent,var(--brand,#6d28d9))}
.share--color .chip:hover{border-color:color-mix(in oklab,var(--chip-accent,var(--brand,#6d28d9)) 45%,transparent);background:color-mix(in oklab,var(--chip-accent,var(--brand,#6d28d9)) 10%,var(--bg-elev,#fff))}`;
const qrScript = `var LANGS=${LANGS_JSON};var AVAIL=${JSON.stringify(qrLangs)};var PRIMARY=${JSON.stringify(qrPrimary)};var BRAND=${JSON.stringify(brand)};var TAGLINE=${JSON.stringify(lt(config.brand?.tagline, qrPrimary, defaultLang) ?? '')};var BRANDURL=${JSON.stringify(brandUrl)};var CUR=PRIMARY;
function gid(id){return document.getElementById(id);}
function setText(id,t){var e=gid(id);if(e&&t!=null)e.textContent=t;}
function pick(){try{var q=new URLSearchParams(location.search).get('lang');if(q&&AVAIL.indexOf(q)>=0)return q;}catch(e){}var ns=(navigator.languages&&navigator.languages.length)?navigator.languages:[navigator.language||''];for(var i=0;i<ns.length;i++){var c=(ns[i]||'').slice(0,2).toLowerCase();if(AVAIL.indexOf(c)>=0)return c;}return PRIMARY;}
function apply(l,user){var d=LANGS[l];if(!d)return;CUR=l;var de=document.documentElement;de.lang=l;de.dir=d.dir;var qb=gid('qr');if(qb)qb.innerHTML=d.qr;var le=gid('lede');if(le){le.textContent=d.lede||'';le.hidden=!d.lede;}setText('eyebrow',d.eyebrow);setText('scan',d.scan);setText('shareTitle',d.shareTitle);setText('linksTitle',d.linksTitle);if(d.share){for(var k in d.share){if(k==='copied')continue;var n=document.querySelector('[data-share-label="'+k+'"]');if(n&&d.share[k])n.textContent=d.share[k];}}var qls=document.querySelectorAll('[data-ql]');for(var i=0;i<qls.length;i++){var ix=+qls[i].getAttribute('data-ql');if(d.links&&d.links[ix])qls[i].href=d.links[ix].href;}var bs=document.querySelectorAll('.lang');for(var j=0;j<bs.length;j++){var on=bs[j].getAttribute('data-lang')===l;bs[j].classList.toggle('active',on);bs[j].setAttribute('aria-current',on?'true':'false');}if(user){try{var u=new URL(location.href);u.searchParams.set('lang',l);history.replaceState(null,'',u);}catch(e){}}}
function shareUrl(){return (LANGS[CUR]&&LANGS[CUR].target)||BRANDURL;}
function shareText(){return TAGLINE?BRAND+' \\u2014 '+TAGLINE:BRAND;}
function openW(u){window.open(u,'_blank','noopener,noreferrer');}
function flashCopy(){var b=document.querySelector('[data-share="copy"]');if(!b)return;var lbl=b.querySelector('[data-share-label="copy"]');if(!lbl)return;var s=(LANGS[CUR]&&LANGS[CUR].share)||{};lbl.textContent=s.copied||'Copied';setTimeout(function(){lbl.textContent=s.copy||'Copy';},1600);}
function copyText(t){function fb(x){var ta=document.createElement('textarea');ta.value=x;ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');flashCopy();}catch(e){}document.body.removeChild(ta);}if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(flashCopy).catch(function(){fb(t);});}else{fb(t);}}
function doShare(kind){var url=shareUrl(),enc=encodeURIComponent(url),text=encodeURIComponent(shareText());if(kind==='native'){if(navigator.share){navigator.share({title:BRAND,url:url}).catch(function(){});}else{copyText(url);}return;}if(kind==='copy'){copyText(url);return;}if(kind==='telegram'){openW('https://t.me/share/url?url='+enc+'&text='+text);return;}if(kind==='whatsapp'){openW('https://wa.me/?text='+text);return;}if(kind==='x'){openW('https://twitter.com/intent/tweet?url='+enc+'&text='+text);return;}if(kind==='linkedin'){openW('https://www.linkedin.com/sharing/share-offsite/?url='+enc);return;}if(kind==='facebook'){openW('https://www.facebook.com/sharer/sharer.php?u='+enc);return;}if(kind==='vk'){openW('https://vk.com/share.php?url='+enc);return;}if(kind==='email'){openW('mailto:?subject='+encodeURIComponent(BRAND)+'&body='+text+'%0A%0A'+enc);return;}}
document.addEventListener('click',function(e){var t=e.target;if(!t||!t.closest)return;var s=t.closest('[data-share]');if(s){doShare(s.getAttribute('data-share'));return;}var lg=t.closest('.lang');if(lg){apply(lg.getAttribute('data-lang'),true);return;}if(t.closest('#theme')){document.documentElement.classList.toggle('app-dark');}});
apply(pick(),false);`;

// QR page is the indexable public card: full SEO head (canonical, OG, Twitter, JSON-LD)
// when a `seo` block exists, else the original minimal <title>. Favicon on either path.
const qrSeoHead = seoHead(qrPrimary, { path: qrRoute, ogType: 'profile', dropHreflang: true });
const qrHeadMeta = `${themeSyncScript}<meta name="site-kit-version" content="${esc(moduleVersion)}" data-schema="${schemaVersion}" data-brand="${esc(brand)}">${faviconHead}${qrSeoHead || `<title>${esc(brand)} — QR</title>`}`;
const qrHtml = `<!doctype html><html lang="${esc(qrPrimary)}" dir="${isRtl(qrPrimary) ? 'rtl' : 'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">${qrHeadMeta}<style>${inlineStyle}
${qrCss}</style></head><body><div class="shell"><div class="bg" aria-hidden="true"><span class="glow glow--1"></span><span class="glow glow--2"></span><span class="grid"></span></div>
<article class="card${qc.sectionDivider && qc.sectionDivider !== 'top' ? ' card--div-center' : ''}${qc.sectionDivider === 'center-dashed' ? ' card--div-dashed' : ''}">
<header class="head"><div class="head__brand">${monoHtml}<div class="head__text"><span class="brand-name">${esc(brand)}</span>${config.brand?.tagline ? `<span class="brand-sub">${esc(lt(config.brand.tagline, qrPrimary, defaultLang))}</span>` : ''}</div></div><div class="head__actions"><button type="button" class="tbtn" id="theme" aria-label="Theme">☾</button>${langSwitcher}<span class="eyebrow" id="eyebrow">${esc(eyebrowFor(qrPrimary))}</span></div></header>
${personHtml}
<p class="lede" id="lede"${ledeP ? '' : ' hidden'}>${esc(ledeP)}</p>
<figure class="qr-wrap">${frameHtml}<figcaption class="scan" id="scan">${esc(pickLang(qc.qr?.caption, qrPrimary) || qrStr(qrPrimary, 'scan'))}</figcaption></figure>
${channelsHtml}
${shareHtml}
${quickHtml}
</article></div>
<script>${qrScript}</script>
</body></html>`;

// ── verify.html — in-site authorship-validation page (vanilla port of ik-authorship-validator) ──
// WHAT (WebCrypto SHA-256 vs CITATION.cff) + WHEN (.ots/.tsr byte-parse) run natively; WHO loads
// openpgp lazily from a CDN (degrades to "unavailable" offline). Files never leave the browser.
const V = {
    en: {
        title: 'Verify authorship',
        sub: 'Verify a proof locally — files never leave your browser.',
        manifest: 'Manifest (CITATION.cff)',
        manifestHint: '.cff · .yaml · .yml',
        required: 'required',
        sources: 'Source files',
        sourcesHint: 'WHAT — content integrity',
        proofs: 'Timestamp proofs',
        proofsHint: '.ots · .tsr',
        pubkey: 'Public key',
        pubkeyHint: '.asc · .gpg · .pub',
        signature: 'Signature',
        signatureHint: '.asc',
        drop: 'Drop a file or click',
        verify: 'Verify',
        verifying: 'Verifying…',
        readiness: 'Readiness',
        need: 'Manifest is required; the rest unlock WHO/WHEN checks.',
        what: 'WHAT — Integrity',
        who: 'WHO — Signature',
        when: 'WHEN — Timestamp',
        passed: 'Passed',
        failed: 'Failed',
        skipped: 'Skipped',
        whatPass: 'All listed files match their manifest hashes.',
        whatFail: 'Some files do not match the manifest.',
        whatSkip: 'Add source files to check content integrity.',
        whoPass: 'Signature is valid for this key.',
        whoFail: 'Signature is invalid or does not match the key.',
        whoSkip: 'Add a public key + signature to verify WHO.',
        whoUnavail: 'GPG library unavailable (offline?).',
        whenPass: 'Timestamp proof is valid.',
        whenFail: 'Timestamp proof is invalid.',
        whenSkip: 'Add .ots/.tsr proofs to verify WHEN.',
        summaryOk: 'Authorship verified.',
        summaryPartial: 'Partially verified — see checks.',
        summaryFail: 'Verification failed.',
    },
    ru: {
        title: 'Проверка авторства',
        sub: 'Проверьте доказательство локально — файлы не покидают браузер.',
        manifest: 'Манифест (CITATION.cff)',
        manifestHint: '.cff · .yaml · .yml',
        required: 'обязательно',
        sources: 'Исходные файлы',
        sourcesHint: 'WHAT — целостность',
        proofs: 'Таймстемпы',
        proofsHint: '.ots · .tsr',
        pubkey: 'Публичный ключ',
        pubkeyHint: '.asc · .gpg · .pub',
        signature: 'Подпись',
        signatureHint: '.asc',
        drop: 'Перетащите файл или нажмите',
        verify: 'Проверить',
        verifying: 'Проверка…',
        readiness: 'Готовность',
        need: 'Манифест обязателен; остальное открывает проверки WHO/WHEN.',
        what: 'WHAT — Целостность',
        who: 'WHO — Подпись',
        when: 'WHEN — Время',
        passed: 'Пройдено',
        failed: 'Провалено',
        skipped: 'Пропущено',
        whatPass: 'Все перечисленные файлы совпадают с хэшами манифеста.',
        whatFail: 'Часть файлов не совпадает с манифестом.',
        whatSkip: 'Добавьте исходные файлы для проверки целостности.',
        whoPass: 'Подпись действительна для этого ключа.',
        whoFail: 'Подпись недействительна или не соответствует ключу.',
        whoSkip: 'Добавьте публичный ключ + подпись для проверки WHO.',
        whoUnavail: 'Библиотека GPG недоступна (офлайн?).',
        whenPass: 'Таймстемп действителен.',
        whenFail: 'Таймстемп недействителен.',
        whenSkip: 'Добавьте .ots/.tsr для проверки WHEN.',
        summaryOk: 'Авторство подтверждено.',
        summaryPartial: 'Подтверждено частично — см. проверки.',
        summaryFail: 'Проверка не пройдена.',
    },
    ar: {
        title: 'التحقق من التأليف',
        sub: 'تحقق من الإثبات محليًا — لا تغادر الملفات متصفحك.',
        manifest: 'البيان (CITATION.cff)',
        manifestHint: '.cff · .yaml · .yml',
        required: 'مطلوب',
        sources: 'الملفات المصدرية',
        sourcesHint: 'WHAT — سلامة المحتوى',
        proofs: 'إثباتات الطابع الزمني',
        proofsHint: '.ots · .tsr',
        pubkey: 'المفتاح العام',
        pubkeyHint: '.asc · .gpg · .pub',
        signature: 'التوقيع',
        signatureHint: '.asc',
        drop: 'أفلِت ملفًا أو انقر',
        verify: 'تحقّق',
        verifying: 'جارٍ التحقق…',
        readiness: 'الجاهزية',
        need: 'البيان مطلوب؛ والباقي يفتح فحوصات WHO/WHEN.',
        what: 'WHAT — السلامة',
        who: 'WHO — التوقيع',
        when: 'WHEN — الطابع الزمني',
        passed: 'ناجح',
        failed: 'فاشل',
        skipped: 'تم التخطي',
        whatPass: 'كل الملفات المدرجة تطابق تجزئات البيان.',
        whatFail: 'بعض الملفات لا تطابق البيان.',
        whatSkip: 'أضف ملفات مصدرية للتحقق من سلامة المحتوى.',
        whoPass: 'التوقيع صالح لهذا المفتاح.',
        whoFail: 'التوقيع غير صالح أو لا يطابق المفتاح.',
        whoSkip: 'أضف مفتاحًا عامًا + توقيعًا للتحقق من WHO.',
        whoUnavail: 'مكتبة GPG غير متاحة (غير متصل؟).',
        whenPass: 'إثبات الطابع الزمني صالح.',
        whenFail: 'إثبات الطابع الزمني غير صالح.',
        whenSkip: 'أضف إثباتات .ots/.tsr للتحقق من WHEN.',
        summaryOk: 'تم التحقق من التأليف.',
        summaryPartial: 'تحقق جزئي — راجع الفحوصات.',
        summaryFail: 'فشل التحقق.',
    },
    kk: {
        title: 'Авторлықты тексеру',
        sub: 'Дәлелді жергілікті тексеріңіз — файлдар браузерден шықпайды.',
        manifest: 'Манифест (CITATION.cff)',
        manifestHint: '.cff · .yaml · .yml',
        required: 'міндетті',
        sources: 'Бастапқы файлдар',
        sourcesHint: 'WHAT — тұтастық',
        proofs: 'Уақыт белгілері',
        proofsHint: '.ots · .tsr',
        pubkey: 'Ашық кілт',
        pubkeyHint: '.asc · .gpg · .pub',
        signature: 'Қолтаңба',
        signatureHint: '.asc',
        drop: 'Файлды тастаңыз немесе басыңыз',
        verify: 'Тексеру',
        verifying: 'Тексерілуде…',
        readiness: 'Дайындық',
        need: 'Манифест міндетті; қалғаны WHO/WHEN тексерулерін ашады.',
        what: 'WHAT — Тұтастық',
        who: 'WHO — Қолтаңба',
        when: 'WHEN — Уақыт',
        passed: 'Өтті',
        failed: 'Өтпеді',
        skipped: 'Өткізілді',
        whatPass: 'Барлық файлдар манифест хэштерімен сәйкес келеді.',
        whatFail: 'Кейбір файлдар манифестке сәйкес келмейді.',
        whatSkip: 'Тұтастықты тексеру үшін бастапқы файлдарды қосыңыз.',
        whoPass: 'Қолтаңба осы кілт үшін жарамды.',
        whoFail: 'Қолтаңба жарамсыз немесе кілтке сәйкес келмейді.',
        whoSkip: 'WHO тексеру үшін ашық кілт + қолтаңба қосыңыз.',
        whoUnavail: 'GPG кітапханасы қолжетімсіз (офлайн?).',
        whenPass: 'Уақыт белгісі жарамды.',
        whenFail: 'Уақыт белгісі жарамсыз.',
        whenSkip: 'WHEN тексеру үшін .ots/.tsr қосыңыз.',
        summaryOk: 'Авторлық расталды.',
        summaryPartial: 'Ішінара расталды — тексерулерді қараңыз.',
        summaryFail: 'Тексеруден өтпеді.',
    },
    zh: {
        title: '验证作者身份',
        sub: '在本地验证证明 — 文件绝不离开您的浏览器。',
        manifest: '清单 (CITATION.cff)',
        manifestHint: '.cff · .yaml · .yml',
        required: '必填',
        sources: '源文件',
        sourcesHint: 'WHAT — 内容完整性',
        proofs: '时间戳证明',
        proofsHint: '.ots · .tsr',
        pubkey: '公钥',
        pubkeyHint: '.asc · .gpg · .pub',
        signature: '签名',
        signatureHint: '.asc',
        drop: '拖入文件或点击',
        verify: '验证',
        verifying: '验证中…',
        readiness: '就绪情况',
        need: '清单为必填项；其余项可解锁 WHO/WHEN 检查。',
        what: 'WHAT — 完整性',
        who: 'WHO — 签名',
        when: 'WHEN — 时间戳',
        passed: '通过',
        failed: '失败',
        skipped: '已跳过',
        whatPass: '所有列出的文件均与清单哈希匹配。',
        whatFail: '部分文件与清单不匹配。',
        whatSkip: '添加源文件以检查内容完整性。',
        whoPass: '签名对此密钥有效。',
        whoFail: '签名无效或与密钥不匹配。',
        whoSkip: '添加公钥 + 签名以验证 WHO。',
        whoUnavail: 'GPG 库不可用（离线？）。',
        whenPass: '时间戳证明有效。',
        whenFail: '时间戳证明无效。',
        whenSkip: '添加 .ots/.tsr 证明以验证 WHEN。',
        summaryOk: '作者身份已验证。',
        summaryPartial: '部分验证 — 请查看检查项。',
        summaryFail: '验证失败。',
    },
    hi: {
        title: 'लेखकत्व सत्यापित करें',
        sub: 'प्रमाण को स्थानीय रूप से सत्यापित करें — फ़ाइलें आपका ब्राउज़र कभी नहीं छोड़तीं।',
        manifest: 'मैनिफ़ेस्ट (CITATION.cff)',
        manifestHint: '.cff · .yaml · .yml',
        required: 'आवश्यक',
        sources: 'स्रोत फ़ाइलें',
        sourcesHint: 'WHAT — सामग्री अखंडता',
        proofs: 'टाइमस्टैम्प प्रमाण',
        proofsHint: '.ots · .tsr',
        pubkey: 'सार्वजनिक कुंजी',
        pubkeyHint: '.asc · .gpg · .pub',
        signature: 'हस्ताक्षर',
        signatureHint: '.asc',
        drop: 'फ़ाइल छोड़ें या क्लिक करें',
        verify: 'सत्यापित करें',
        verifying: 'सत्यापित हो रहा है…',
        readiness: 'तैयारी',
        need: 'मैनिफ़ेस्ट आवश्यक है; बाकी WHO/WHEN जाँच खोलते हैं।',
        what: 'WHAT — अखंडता',
        who: 'WHO — हस्ताक्षर',
        when: 'WHEN — टाइमस्टैम्प',
        passed: 'पास',
        failed: 'विफल',
        skipped: 'छोड़ा गया',
        whatPass: 'सभी सूचीबद्ध फ़ाइलें मैनिफ़ेस्ट हैश से मेल खाती हैं।',
        whatFail: 'कुछ फ़ाइलें मैनिफ़ेस्ट से मेल नहीं खातीं।',
        whatSkip: 'सामग्री अखंडता जाँचने के लिए स्रोत फ़ाइलें जोड़ें।',
        whoPass: 'हस्ताक्षर इस कुंजी के लिए मान्य है।',
        whoFail: 'हस्ताक्षर अमान्य है या कुंजी से मेल नहीं खाता।',
        whoSkip: 'WHO सत्यापित करने के लिए सार्वजनिक कुंजी + हस्ताक्षर जोड़ें।',
        whoUnavail: 'GPG लाइब्रेरी अनुपलब्ध (ऑफ़लाइन?)।',
        whenPass: 'टाइमस्टैम्प प्रमाण मान्य है।',
        whenFail: 'टाइमस्टैम्प प्रमाण अमान्य है।',
        whenSkip: 'WHEN सत्यापित करने के लिए .ots/.tsr प्रमाण जोड़ें।',
        summaryOk: 'लेखकत्व सत्यापित।',
        summaryPartial: 'आंशिक रूप से सत्यापित — जाँच देखें।',
        summaryFail: 'सत्यापन विफल।',
    },
    ur: {
        title: 'تصنیف کی تصدیق',
        sub: 'ثبوت کی مقامی طور پر تصدیق کریں — فائلیں آپ کا براؤزر کبھی نہیں چھوڑتیں۔',
        manifest: 'مینی فیسٹ (CITATION.cff)',
        manifestHint: '.cff · .yaml · .yml',
        required: 'لازمی',
        sources: 'سورس فائلیں',
        sourcesHint: 'WHAT — مواد کی سالمیت',
        proofs: 'ٹائم اسٹیمپ ثبوت',
        proofsHint: '.ots · .tsr',
        pubkey: 'عوامی کلید',
        pubkeyHint: '.asc · .gpg · .pub',
        signature: 'دستخط',
        signatureHint: '.asc',
        drop: 'فائل چھوڑیں یا کلک کریں',
        verify: 'تصدیق کریں',
        verifying: 'تصدیق ہو رہی ہے…',
        readiness: 'تیاری',
        need: 'مینی فیسٹ لازمی ہے؛ باقی WHO/WHEN چیک کھولتے ہیں۔',
        what: 'WHAT — سالمیت',
        who: 'WHO — دستخط',
        when: 'WHEN — ٹائم اسٹیمپ',
        passed: 'کامیاب',
        failed: 'ناکام',
        skipped: 'چھوڑ دیا',
        whatPass: 'تمام درج فائلیں مینی فیسٹ ہیش سے مطابقت رکھتی ہیں۔',
        whatFail: 'کچھ فائلیں مینی فیسٹ سے مطابقت نہیں رکھتیں۔',
        whatSkip: 'مواد کی سالمیت جانچنے کے لیے سورس فائلیں شامل کریں۔',
        whoPass: 'دستخط اس کلید کے لیے درست ہے۔',
        whoFail: 'دستخط غلط ہے یا کلید سے مطابقت نہیں رکھتا۔',
        whoSkip: 'WHO کی تصدیق کے لیے عوامی کلید + دستخط شامل کریں۔',
        whoUnavail: 'GPG لائبریری دستیاب نہیں (آف لائن؟)۔',
        whenPass: 'ٹائم اسٹیمپ ثبوت درست ہے۔',
        whenFail: 'ٹائم اسٹیمپ ثبوت غلط ہے۔',
        whenSkip: 'WHEN کی تصدیق کے لیے .ots/.tsr ثبوت شامل کریں۔',
        summaryOk: 'تصنیف کی تصدیق ہو گئی۔',
        summaryPartial: 'جزوی تصدیق — چیکس دیکھیں۔',
        summaryFail: 'تصدیق ناکام۔',
    },
};
const vLang = V[qrPrimary] ? qrPrimary : 'en';
const vt = (k) => esc((V[vLang] && V[vLang][k]) ?? V.en[k] ?? k);
const vZone = (id, titleKey, hintKey, accept, multi, req) =>
    `<label class="vzone${req ? ' vzone--req' : ''}"><input type="file" id="f-${id}"${accept ? ` accept="${accept}"` : ''}${multi ? ' multiple' : ''} hidden>` +
    `<span class="vz-top"><span class="vz-t">${vt(titleKey)}${req ? ` <em class="vz-req">${vt('required')}</em>` : ''}</span><span class="vz-h">${vt(hintKey)}</span></span>` +
    `<span class="vz-file" id="n-${id}">${vt('drop')}</span></label>`;
const V_JSON = JSON.stringify(V[vLang] ?? V.en).replace(/</g, '\\u003c');
const verifyCss = `*,*::before,*::after{box-sizing:border-box}html,body{margin:0;min-height:100%}
body{font-family:var(--font-display,system-ui,sans-serif);background:var(--bg);color:var(--text)}
.vshell{max-width:64rem;margin-inline:auto;padding:var(--sp-10,2.5rem) var(--sp-6,1.5rem)}
.vh{display:flex;align-items:center;gap:var(--sp-3,.75rem);margin-bottom:var(--sp-8,2rem)}
.vh .mono{width:44px;height:44px}.vh .mono--glyph svg{width:55%;height:55%}
.vh h1{margin:0;font-family:var(--font-brand,system-ui);font-size:var(--fs-2xl,1.5rem);font-weight:var(--fw-bold,700);letter-spacing:-.02em}
.vh p{margin:.15rem 0 0;color:var(--text-mute);font-size:var(--fs-sm,.875rem)}
.vgrid{display:grid;grid-template-columns:1.4fr 1fr;gap:var(--sp-6,1.5rem);align-items:start}
.vzones{display:flex;flex-direction:column;gap:var(--sp-3,.75rem)}
.vzone{display:flex;flex-direction:column;gap:.25rem;padding:var(--sp-4,1rem) var(--sp-5,1.25rem);border:1px dashed var(--border-strong,#3f3f46);border-radius:var(--r-lg,16px);background:var(--bg-elev,#18181b);cursor:pointer;transition:border-color .15s,background .15s}
.vzone:hover{border-color:var(--brand,#6d28d9);background:color-mix(in oklch,var(--brand,#6d28d9) 5%,var(--bg-elev,#18181b))}
.vzone--req{border-style:solid;border-color:color-mix(in oklch,var(--brand,#6d28d9) 35%,var(--border,#27272a))}
.vzone.has{border-style:solid;border-color:color-mix(in oklch,var(--success,#16a34a) 45%,transparent);background:color-mix(in oklch,var(--success,#16a34a) 7%,var(--bg-elev,#18181b))}
.vz-top{display:flex;align-items:baseline;justify-content:space-between;gap:var(--sp-2,.5rem);flex-wrap:wrap}
.vz-t{font-weight:var(--fw-bold,700)}.vz-req{font-size:var(--fs-xs,.75rem);font-weight:600;font-style:normal;color:var(--brand-strong,var(--brand,#6d28d9));border:1px solid color-mix(in oklch,var(--brand,#6d28d9) 35%,transparent);border-radius:999px;padding:.05em .5em}
.vz-h{font-family:var(--font-mono,monospace);font-size:var(--fs-xs,.75rem);color:var(--text-dim,#8e8ea0)}
.vz-file{font-size:var(--fs-sm,.875rem);color:var(--text-mute,#a1a1aa)}
.vzone.has .vz-file{color:var(--text,#fafafa);font-weight:600}
.vside{display:flex;flex-direction:column;gap:var(--sp-4,1rem);position:sticky;top:var(--sp-6,1.5rem)}
.vready{padding:var(--sp-5,1.25rem);border:1px solid var(--border,#27272a);border-radius:var(--r-lg,16px);background:var(--bg-elev,#18181b)}
.vready-h{display:flex;align-items:center;justify-content:space-between}.vready-h h2{margin:0;font-size:var(--fs-lg,1.125rem)}
#vscore{font-family:var(--font-mono,monospace);color:var(--text-dim,#8e8ea0)}
#vhint{margin:var(--sp-2,.5rem) 0 var(--sp-4,1rem);font-family:var(--font-mono,monospace);font-size:var(--fs-xs,.75rem);color:var(--text-dim,#8e8ea0);line-height:1.5}
#vbtn{width:100%;padding:var(--sp-3,.75rem);border:0;border-radius:var(--r-md,12px);background:var(--brand,#6d28d9);color:var(--brand-text,#fff);font:inherit;font-weight:var(--fw-semi,600);cursor:pointer;transition:opacity .15s,filter .15s}
#vbtn:disabled{opacity:.45;cursor:not-allowed}#vbtn:not(:disabled):hover{filter:brightness(1.08)}
.vresults{display:flex;flex-direction:column;gap:var(--sp-2,.5rem)}
.vcheck{padding:var(--sp-3,.75rem) var(--sp-4,1rem);border:1px solid var(--border,#27272a);border-left-width:3px;border-radius:var(--r-md,12px);background:var(--bg-elev,#18181b)}
.vcheck.passed{border-left-color:var(--success,#16a34a)}.vcheck.failed{border-left-color:var(--danger,#dc2626)}.vcheck.skipped{border-left-color:var(--border-strong,#3f3f46)}
.vcheck .vc-h{display:flex;align-items:center;justify-content:space-between;gap:var(--sp-2,.5rem)}
.vc-name{font-weight:var(--fw-bold,700);font-size:var(--fs-sm,.875rem)}
.vc-badge{font-size:var(--fs-xs,.75rem);font-weight:700;text-transform:uppercase;letter-spacing:.06em}
.vcheck.passed .vc-badge{color:var(--success,#16a34a)}.vcheck.failed .vc-badge{color:var(--danger,#dc2626)}.vcheck.skipped .vc-badge{color:var(--text-dim,#8e8ea0)}
.vc-msg{margin:.3rem 0 0;font-size:var(--fs-xs,.75rem);color:var(--text-mute,#a1a1aa);line-height:1.5}
.vsummary{padding:var(--sp-3,.75rem) var(--sp-4,1rem);border-radius:var(--r-md,12px);font-weight:var(--fw-semi,600);text-align:center}
.vsummary.ok{background:color-mix(in oklch,var(--success,#16a34a) 14%,var(--bg-elev));color:var(--success,#16a34a)}
.vsummary.partial{background:color-mix(in oklch,var(--brand,#6d28d9) 14%,var(--bg-elev));color:var(--brand-strong,var(--brand,#6d28d9))}
.vsummary.fail{background:color-mix(in oklch,var(--danger,#dc2626) 14%,var(--bg-elev));color:var(--danger,#dc2626)}
@media(max-width:760px){.vgrid{grid-template-columns:1fr}.vside{position:static}}`;
const verifyScript = `var T=${V_JSON};
var files={manifest:null,sources:[],proofs:[],pubkey:null,signature:null};
function gid(id){return document.getElementById(id);}
async function sha256Buf(buf){var h=await crypto.subtle.digest('SHA-256',buf);return Array.from(new Uint8Array(h)).map(function(b){return b.toString(16).padStart(2,'0');}).join('');}
async function sha256Str(s){return sha256Buf(new TextEncoder().encode(s).buffer);}
async function sha256File(f){return sha256Buf(await f.arrayBuffer());}
function fpath(f){return f.webkitRelativePath||f.name;}
function parseHashes(text){
  var paths=Array.from(text.matchAll(/^ {2}- path:\\s*"?(.+?)"?\\s*$/gm)).map(function(m){return m[1];});
  var hashes=Array.from(text.matchAll(/^ {4}sha256:\\s*"?([0-9a-f]{64})"?\\s*$/gm)).map(function(m){return m[1];});
  var out=new Map();for(var i=0;i<Math.min(paths.length,hashes.length);i++)out.set(paths[i],hashes[i]);return out;
}
async function checkWhat(manifestText,sources){
  var exp=parseHashes(manifestText);
  if(!sources.length)return {status:'skipped',matched:0,total:exp.size,mismatch:[]};
  var matched=0,mismatch=[];
  for(var i=0;i<sources.length;i++){var f=sources[i],p=fpath(f),want=exp.get(p);if(!want)continue;var got=await sha256File(f);if(got===want)matched++;else mismatch.push(p);}
  return {status:mismatch.length?'failed':'passed',matched:matched,total:exp.size,mismatch:mismatch};
}
function parseOts(bytes,manifestHash,name){
  var M=31;if(bytes.length<M+2+32)return {name:name,status:'failed',code:'ots-short'};
  if(bytes[M+1]!==0x08)return {name:name,status:'failed',code:'ots-badop'};
  var digest=Array.from(bytes.slice(M+2,M+2+32)).map(function(b){return b.toString(16).padStart(2,'0');}).join('');
  if(digest!==manifestHash)return {name:name,status:'failed',code:'ots-mismatch'};
  return {name:name,status:'passed',code:'ots-ok'};
}
function parseTsr(bytes,name){if(bytes.length<10||bytes[0]!==0x30)return {name:name,status:'failed',code:'tsr-invalid'};return {name:name,status:'passed',code:'tsr-ok'};}
async function checkWhen(proofs,manifestText){
  if(!proofs.length)return [{status:'skipped'}];
  var manifestHash=await sha256Str(manifestText);var out=[];
  for(var i=0;i<proofs.length;i++){var p=proofs[i],bytes=new Uint8Array(await p.arrayBuffer());if(p.name.endsWith('.ots'))out.push(parseOts(bytes,manifestHash,p.name));else if(p.name.indexOf('.tsr')>=0)out.push(parseTsr(bytes,p.name));else out.push({name:p.name,status:'skipped'});}
  return out;
}
async function checkWho(manifestText,keyText,sigText){
  if(!keyText||!sigText)return {status:'skipped'};
  try{
    var openpgp=await import('https://esm.sh/openpgp@6');
    var key=await openpgp.readKey({armoredKey:keyText});
    if(typeof key.toPublic==='function' && typeof key.isDecrypted==='function')key=key.toPublic();
    var message=await openpgp.createMessage({text:manifestText});
    var signature=await openpgp.readSignature({armoredSignature:sigText});
    var result=await openpgp.verify({message:message,signature:signature,verificationKeys:key});
    var valid=false;try{await result.signatures[0].verified;valid=true;}catch(e){}
    return {status:valid?'passed':'failed',keyId:key.getKeyID().toHex().toUpperCase()};
  }catch(e){return {status:'unavail',error:String(e&&e.message||e)};}
}
async function readText(f){return f?await f.text():'';}
function setZone(id,label){var z=gid('f-'+id).closest('.vzone');gid('n-'+id).textContent=label||T.drop;z.classList.toggle('has',!!label);}
function refresh(){
  var n=0;if(files.manifest)n++;if(files.sources.length)n++;if(files.proofs.length)n++;if(files.pubkey)n++;if(files.signature)n++;
  gid('vscore').textContent=n+'/5';gid('vbtn').disabled=!files.manifest;
}
function wire(id,multi,key){gid('f-'+id).addEventListener('change',function(e){var fs=Array.from(e.target.files||[]);if(multi){files[key]=fs;setZone(id,fs.length?fs.length+' file(s)':'');}else{files[key]=fs[0]||null;setZone(id,fs[0]?fs[0].name:'');}refresh();});}
wire('manifest',false,'manifest');wire('sources',true,'sources');wire('proofs',true,'proofs');wire('pubkey',false,'pubkey');wire('signature',false,'signature');
function card(name,status,msg){return '<div class="vcheck '+status+'"><div class="vc-h"><span class="vc-name">'+name+'</span><span class="vc-badge">'+(status==='passed'?T.passed:status==='failed'?T.failed:T.skipped)+'</span></div><p class="vc-msg">'+msg+'</p></div>';}
gid('vbtn').addEventListener('click',async function(){
  var btn=gid('vbtn');btn.disabled=true;var old=btn.textContent;btn.textContent=T.verifying;var R=gid('vresults');R.innerHTML='';
  try{
    var manifestText=await readText(files.manifest);
    var what=await checkWhat(manifestText,files.sources);
    var keyText=await readText(files.pubkey),sigText=await readText(files.signature);
    var who=await checkWho(manifestText,keyText,sigText);
    var when=await checkWhen(files.proofs,manifestText);
    var whatMsg=what.status==='passed'?(T.whatPass+' ('+what.matched+'/'+what.total+')'):what.status==='failed'?(T.whatFail+' ['+what.mismatch.join(', ')+']'):T.whatSkip;
    var html=card(T.what,what.status,whatMsg);
    var whoStatus=who.status==='unavail'?'skipped':who.status;
    var whoMsg=who.status==='passed'?(T.whoPass+(who.keyId?' ('+who.keyId+')':'')):who.status==='failed'?T.whoFail:who.status==='unavail'?T.whoUnavail:T.whoSkip;
    html+=card(T.who,whoStatus,whoMsg);
    var whenStatus=when.length===1&&when[0].status==='skipped'?'skipped':(when.some(function(w){return w.status==='failed';})?'failed':'passed');
    var whenMsg=whenStatus==='passed'?T.whenPass:whenStatus==='failed'?T.whenFail:T.whenSkip;
    html+=card(T.when,whenStatus,whenMsg);
    var statuses=[what.status,whoStatus,whenStatus];
    var anyFail=statuses.indexOf('failed')>=0,anyPass=statuses.indexOf('passed')>=0;
    var sum=anyFail?'<div class="vsummary fail">'+T.summaryFail+'</div>':anyPass?(statuses.indexOf('skipped')>=0?'<div class="vsummary partial">'+T.summaryPartial+'</div>':'<div class="vsummary ok">'+T.summaryOk+'</div>'):'<div class="vsummary partial">'+T.summaryPartial+'</div>';
    R.innerHTML=sum+html;
  }catch(e){R.innerHTML='<div class="vsummary fail">'+String(e&&e.message||e)+'</div>';}
  btn.textContent=old;btn.disabled=false;
});`;
const verifyHtml = `<!doctype html><html lang="${esc(vLang)}" dir="${isRtl(vLang) ? 'rtl' : 'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">${themeSyncScript}<meta name="site-kit-version" content="${esc(moduleVersion)}" data-schema="${schemaVersion}" data-brand="${esc(brand)}">${faviconHead}<title>${esc(brand)} — ${vt('title')}</title><style>${inlineStyle}
${verifyCss}</style></head><body><div class="vshell">
<header class="vh">${monoHtml}<div><h1>${vt('title')}</h1><p>${vt('sub')}</p></div></header>
<div class="vgrid">
<div class="vzones">
${vZone('manifest', 'manifest', 'manifestHint', '.cff,.yaml,.yml', false, true)}
${vZone('sources', 'sources', 'sourcesHint', '', true, false)}
${vZone('proofs', 'proofs', 'proofsHint', '.ots,.tsr', true, false)}
${vZone('pubkey', 'pubkey', 'pubkeyHint', '.asc,.gpg,.pub', false, false)}
${vZone('signature', 'signature', 'signatureHint', '.asc,.sig', false, false)}
</div>
<aside class="vside">
<div class="vready"><div class="vready-h"><h2>${vt('readiness')}</h2><span id="vscore">0/5</span></div><p id="vhint">${vt('need')}</p><button id="vbtn" type="button" disabled>${vt('verify')}</button></div>
<div class="vresults" id="vresults"></div>
</aside>
</div></div>
<script>${verifyScript}</script>
</body></html>`;

// License page — the resolved license text (or a stub note linking to the canonical repo).
const licHtml = licName
    ? `<!doctype html><html lang="${esc(primaryLang)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">${themeSyncScript}<meta name="site-kit-version" content="${esc(moduleVersion)}" data-schema="${schemaVersion}" data-brand="${esc(brand)}">${faviconHead}<title>${esc(brand)} — ${esc(licName)}</title><style>${inlineStyle}
.lic-wrap{max-width:52rem;margin-inline:auto;padding:2rem 1.5rem}.lic-wrap h1{font-size:1.5rem;margin:0 0 1.25rem}.lic-text{margin:0;padding:1.25rem;border:1px solid var(--border,#e5e5e9);border-radius:12px;background:var(--bg-elev,#fff);font-family:var(--font-mono,ui-monospace,monospace);font-size:.875rem;line-height:1.6;white-space:pre-wrap;word-break:break-word;overflow-x:auto}.lic-note{color:var(--text-mute,#555)}.lic-note a{color:var(--brand,#6d28d9);word-break:break-all}</style></head><body><main class="lic-wrap"><h1>${esc(licName)}</h1>${licText ? `<pre class="lic-text">${esc(licText)}</pre>` : `<p class="lic-note">The full text is maintained in the project repository.${licEntry?.source ? ` <a href="${esc(safeHref(licEntry.source))}">${esc(licEntry.source)} ↗</a>` : ''}</p>`}</main></body></html>`
    : '';

// manifest — what a remote checker reads. Lists RESOLVED routes so it's self-locating.
const codeRoutes = Object.fromEntries(Object.keys(htmlByCode).map((c) => [c, statusRoute(c)]));
const manifest = {
    module: moduleVersion,
    schema: schemaVersion,
    license: config.license ?? null, // license TYPE (catalog key) — the dashboard reads it live
    licenseBuild,
    brand,
    target,
    path: basePath,
    languages: statusLangs,
    generatedAt: BUILD_TIME.toISOString(),
    routes: statusOnly
        ? { ...codeRoutes, manifest: manifestRoute }
        : {
              ...codeRoutes,
              qr: qrRoute,
              verify: verifyRoute,
              manifest: manifestRoute,
              config: configRoute,
              tokens: tokensRoute,
          },
};

// generated server snippets (from the REAL status list + resolved paths; no `internal` → public).
const numericCodes = Object.keys(htmlByCode)
    .map(Number)
    .filter(Number.isFinite)
    .sort((a, b) => a - b);
const nginxSnippet = `# @ilia-ae/site-kit — nginx error pages (generated; target=git)
# Paste inside the site's server { } block, then reload nginx. Files are PUBLIC
# under ${basePath}/ so the pages + manifest can be verified remotely.

${numericCodes.map((c) => `error_page ${c} ${statusRoute(c)};`).join('\n')}

location ^~ ${basePath}/ {
    # served from the webroot; intentionally NOT 'internal' (public for remote checks).
    # CORS: lets the inventory dashboard read the manifest from another origin.
    add_header Access-Control-Allow-Origin "*" always;
}
`;
const apacheSnippet = `# @ilia-ae/site-kit — Apache error pages (generated; target=${target})
# Append to the site's .htaccess. WordPress: place ABOVE "# BEGIN WordPress".

${numericCodes.map((c) => `ErrorDocument ${c} ${statusRoute(c)}`).join('\n')}

# CORS: lets the inventory dashboard read the manifest from another origin (needs mod_headers).
<IfModule mod_headers.c>
  <FilesMatch "\\.(json|webmanifest)$">
    Header set Access-Control-Allow-Origin "*"
  </FilesMatch>
</IfModule>
`;

// Cloudflare Worker for "Workers + Static Assets" (Git-connected Workers Builds).
// The PLATFORM serves the static files via the env.ASSETS binding — there is no separate
// origin. This Worker only layers correct HTTP status codes (real 404 for a missing file,
// branded 5xx, 503 maintenance) + security headers on top of that asset serving.
const intercept = [400, 401, 403, 404, 500, 502, 503, 504].filter((c) => htmlByCode[c] !== undefined);
const pagesForWorker = {};
for (const c of intercept) pagesForWorker[c] = htmlByCode[c];
const fallback4xx =
    htmlByCode[404] ?? Object.entries(htmlByCode).find(([k]) => +k >= 400 && +k < 500)?.[1] ?? '';
const fallback5xx =
    htmlByCode[503] ?? htmlByCode[500] ?? Object.entries(htmlByCode).find(([k]) => +k >= 500)?.[1] ?? '';
// Security headers the Worker re-applies to EVERY response. Under `run_worker_first = true` a
// `_headers` file does NOT apply to Worker-served responses, so to avoid regressing a site's CSP
// the Worker must own these. Provide the exact set (incl. Content-Security-Policy) via config
// `securityHeaders` (or `deploy.headers`); otherwise a safe default set is used. Header NAMES are
// lowercased so re-applying is an idempotent overwrite of whatever the asset layer returned.
const defaultSecurity = {
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'strict-origin-when-cross-origin',
    'x-frame-options': 'SAMEORIGIN',
};
const securityHeaders = Object.fromEntries(
    Object.entries(config.securityHeaders ?? deploy.headers ?? defaultSecurity).map(([k, v]) => [
        String(k).toLowerCase(),
        v,
    ]),
);
const workerJs = `// Generated by @ilia-ae/site-kit static generator — do not edit by hand.
// Cloudflare Worker for "Workers + Static Assets" (Git-connected Workers Builds). The platform
// serves files via env.ASSETS; this Worker adds correct status codes + 503 maintenance.
//
// wrangler.toml MUST set:
//   main = "<path to this file>"
//   [assets]
//   directory = "<your build output dir>"
//   binding = "ASSETS"                               # REQUIRED: without it env.ASSETS is undefined
//                                                    # and this Worker 500s on every request
//   not_found_handling = "single-page-application"   # unknown paths → index.html (the SPA)
//   run_worker_first = true                          # Worker sees EVERY request (needed for
//                                                    # maintenance + real-404; without it the
//                                                    # Worker is skipped whenever a file matches)
const PAGES = ${JSON.stringify(pagesForWorker)};
const FALLBACK_4XX = ${JSON.stringify(fallback4xx)};
const FALLBACK_5XX = ${JSON.stringify(fallback5xx)};
const MANIFEST_ROUTE = ${JSON.stringify(manifestRoute)};
const INTERCEPT = ${JSON.stringify(intercept)};

// Security headers re-applied to EVERY response. Under run_worker_first a _headers file does NOT
// apply to Worker-served responses, so the Worker owns these (incl. CSP) to avoid regressing them.
const SECURITY = ${JSON.stringify(securityHeaders)};
function errorPage(status, extra) {
  const body = PAGES[status] || (status >= 500 ? FALLBACK_5XX : FALLBACK_4XX);
  return new Response(body, { status, headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', ...SECURITY, ...(extra || {}) } });
}
// Pass an asset response through, re-applying the security headers (which _headers can't set under
// run_worker_first). Preserves the asset's own content-type / caching / etag — only overwrites SECURITY.
function withSecurity(res) {
  const headers = new Headers(res.headers);
  for (const k in SECURITY) headers.set(k, SECURITY[k]);
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers });
}
// An asset request = a path with a real file extension (not .html). A missing asset must 404 for
// crawlers/SEO; navigations (no extension) fall through to index.html so the SPA renders its page.
function isAsset(pathname) {
  return /\\.[a-z0-9]+$/i.test(pathname) && !/\\.html?$/i.test(pathname);
}
// Maintenance switch: env var MAINTENANCE=on (set in wrangler.toml / dashboard, needs a redeploy)
// OR a KV flag FLAGS:maintenance=on (toggle with NO redeploy, if a FLAGS KV namespace is bound).
async function inMaintenance(env) {
  if (env && (env.MAINTENANCE === 'on' || env.MAINTENANCE === '1' || env.MAINTENANCE === 'true')) return true;
  try { if (env && env.FLAGS && typeof env.FLAGS.get === 'function') return (await env.FLAGS.get('maintenance')) === 'on'; } catch (e) {}
  return false;
}

export default {
  async fetch(request, env) {
    const { pathname } = new URL(request.url);
    // Maintenance → branded 503 + Retry-After for everything except the kit manifest (so the
    // remote dashboard can still read version/license while the site is down).
    if (pathname !== MANIFEST_ROUTE && (await inMaintenance(env))) return errorPage(503, { 'retry-after': '3600' });
    // No assets binding wired up → say so loudly instead of a blank 500.
    if (!env || !env.ASSETS || typeof env.ASSETS.fetch !== 'function') return errorPage(500);
    // Hand off to the static assets (env.ASSETS respects not_found_handling).
    const res = await env.ASSETS.fetch(request);
    // Soft-404 fix: a path that LOOKS like a file but the SPA fallback handed back index.html
    // (200, text/html) → the file doesn't exist → emit a real branded 404.
    if (isAsset(pathname) && res.status === 200 && (res.headers.get('content-type') || '').includes('text/html')) {
      return errorPage(404);
    }
    // A real error status from the asset layer (e.g. not_found_handling="404-page") → brand it.
    if (INTERCEPT.includes(res.status)) return errorPage(res.status);
    // Normal asset / SPA-shell response → pass through with security headers re-applied.
    return withSecurity(res);
  },
};
`;
const slug =
    String(brand)
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '') || 'site';
const wranglerToml = `# Workers + Static Assets (Git-connected Workers Builds). If your site ALREADY has a root
# wrangler.toml, do NOT use this file as-is — just MERGE the \`main\` line and the [assets] keys
# below into it (especially main + binding + run_worker_first), then push: Workers Builds redeploys.
name = "${slug}"
main = "worker.js"
compatibility_date = "2024-11-01"

[assets]
directory = "."                                  # ← point at your build OUTPUT dir (e.g. dist/<app>/browser)
binding = "ASSETS"                               # REQUIRED with main: exposes env.ASSETS to worker.js
not_found_handling = "single-page-application"   # unknown paths → index.html (the SPA renders its own page)
run_worker_first = true                          # Worker runs on EVERY request → maintenance + real-404 work
`;

const routeList = Object.entries(manifest.routes)
    .map(([k, v]) => `- \`${k}\` → \`${v}\``)
    .join('\n');
const folderReadme = `# ${brand} — site-kit pages

Generated by \`@ilia-ae/site-kit\` (module v${moduleVersion}, schema v${schemaVersion}). Do not edit by hand — regenerate with \`npm run build:static\`.

**Target:** \`${target}\` · **Base:** \`${basePath}\`

## Files / routes
${routeList}

The folder is PUBLIC: \`https://<site>${manifestRoute}\` returns the manifest for remote checks.
`;
const cfReadme = `# ${brand} — Cloudflare Worker (Workers + Static Assets)

\`worker.js\` is for the **Workers + Static Assets** model deployed via **Git-connected Workers
Builds** — the same way this site already ships (push → Cloudflare rebuilds & redeploys, no CLI).
The platform serves files via the \`ASSETS\` binding; the Worker only adds correct HTTP status
codes (real 404 for a missing file, branded ${JSON.stringify(intercept)}) and a 503 maintenance mode.
Error pages are inlined (no extra public files).

## Wire it into your site (one-time)
Your repo's **root \`wrangler.toml\`** drives Workers Builds. Add/merge:
\`\`\`toml
main = "worker.js"            # path to this file from the repo root

[assets]
directory = "<build output>"               # e.g. frontend/dist/<app>/browser
not_found_handling = "single-page-application"
run_worker_first = true                    # Worker sees every request (maintenance + real-404)
\`\`\`
Commit \`worker.js\` + the \`wrangler.toml\` change and **push** — Workers Builds redeploys. No CLI.

## Maintenance (503)
- KV (no redeploy): bind a \`FLAGS\` KV namespace, then \`wrangler kv key put --binding=FLAGS maintenance on\` (off = \`delete\`).
- or env var: set \`MAINTENANCE = "on"\` under \`[vars]\` and push.

The kit manifest stays reachable during maintenance so the remote dashboard can still read the version.
`;
const coolifyNote = `# Coolify / Docker (target=git)

The \`${basePath}/\` folder is committed and shipped to disk by your git pipeline.
Wire the error pages once in your reverse proxy:

- **Nginx**: paste \`deploy/nginx.snippet.conf\` into the server block.
- **Traefik / Caddy**: point error middleware at \`${basePath}/<code>.html\`.
- **Coolify**: add the nginx snippet via the service's custom config, or serve
  \`${basePath}/\` as static and map \`error_page\` there.

Updates (pages AND config) ship on the next git deploy — no manual steps.
`;
const wpReadme = `# ${brand} — WordPress / manual upload (target=wp)

1. Upload the \`${basePath.replace(/^\//, '')}/\` folder to your webroot so pages live at \`https://<site>${basePath}/…\`.
2. Add the error directives:
   - **Apache:** copy \`.htaccess\` lines into your site's \`.htaccess\` ABOVE \`# BEGIN WordPress\`.
   - **nginx (aaPanel):** install \`static/deploy/wordpress/\` from the kit (in a consumer:
     \`node_modules/@ilia-ae/site-kit/static/deploy/wordpress/\`): the
     vhost snippet → nginx extension dir, the mu-plugin → \`wp-content/mu-plugins/\`, the php-error /
     db-error / maintenance drop-ins → \`wp-content/\`. WordPress then renders its own 404/500/503 from
     these pages while REST/AJAX keep their JSON errors. Never upload them into the \`${basePath}\` folder.
3. ${statusOnly ? 'Error pages only (`static.statusOnly`) — the site keeps its own favicon, sitemap and robots.' : `Config lives at \`${configRoute}\` (public) — edit it there to change content.`} Pages are static: regenerate with \`site-kit-static --config <your config> --out <dir>\` and re-upload (this repo: \`make prod-apply CONFIRM=panel\` — the Ansible role does both steps).
`;

// write the bundle for the declared target
const bundleDir = join(P.out, target);
try {
    rmSync(bundleDir, { recursive: true, force: true });
} catch {
    /* first run */
}
mkdirSync(bundleDir, { recursive: true });
const writeBundle = (route, content) => {
    const f = join(bundleDir, fileFor(route));
    mkdirSync(dirname(f), { recursive: true });
    writeFileSync(f, content);
};
const writeAt = (rel, content) => {
    const f = join(bundleDir, rel);
    mkdirSync(dirname(f), { recursive: true });
    writeFileSync(f, content);
};

if (target === 'cloudflare') {
    // CF static-assets sites serve files directly (they don't deploy the interceptor worker),
    // so always emit a readable static manifest for the dashboard. `static.manifestOnly` emits
    // ONLY that — for sites that handle errors in-app and just want version/license tracking.
    if (!config.static?.manifestOnly) {
        writeAt('worker.js', workerJs);
        writeAt('wrangler.toml', wranglerToml);
        writeAt('README.md', cfReadme);
    }
    writeBundle(manifestRoute, JSON.stringify(manifest, null, 2));
} else {
    for (const code of Object.keys(htmlByCode)) writeBundle(statusRoute(code), htmlByCode[code]);
    writeBundle(manifestRoute, JSON.stringify(manifest, null, 2));
    if (!statusOnly) {
        writeBundle(qrRoute, qrHtml);
        writeBundle(verifyRoute, verifyHtml);
        if (licHtml) writeBundle(licRoute, licHtml);
        writeBundle(configRoute, JSON.stringify(config, null, 2));
        writeBundle(tokensRoute, tokens);
        writeBundle(`${basePath}/README.md`, folderReadme);
    }
    if (target === 'git') {
        writeAt('deploy/nginx.snippet.conf', nginxSnippet);
        writeAt('deploy/apache.htaccess', apacheSnippet);
        writeAt('deploy/COOLIFY.md', coolifyNote);
    } else {
        // wp
        writeAt('.htaccess', apacheSnippet);
        writeAt('UPLOAD.md', wpReadme);
    }
}

// favicon assets + sitemap.xml + robots.txt — site-root files, shipped in every bundle
// (incl. cloudflare, where they sit alongside worker.js for Workers static assets / upload).
// A statusOnly site keeps its own (the CMS owns them), so they stay out of its bundle.
if (!statusOnly) {
    if (favSet)
        for (const [name, content] of favSet.assets)
            writeAt(join(favBasePath.replace(/^\/+/, ''), name), content);
    if (ogSet)
        for (const [name, content] of ogSet) writeAt(join(favBasePath.replace(/^\/+/, ''), name), content);
    if (sitemapXml) writeAt('sitemap.xml', sitemapXml);
    if (robotsTxt) writeAt('robots.txt', robotsTxt);
}

console.log(`✓ site-kit static: ${emitted.length} status pages + partials + gallery → ${P.out}`);
console.log(`  languages: ${statusLangs.join(', ')} (primary ${primaryLang})`);
console.log(`  deploy bundle: target=${target} · base=${basePath} → ${bundleDir}`);
console.log(
    `  manifest route: ${manifestRoute}${target === 'cloudflare' ? ' (served as a static asset; worker only sets status codes)' : ''}`,
);
console.log(`  open the local index:  open ${join(P.out, 'index.html')}`);
