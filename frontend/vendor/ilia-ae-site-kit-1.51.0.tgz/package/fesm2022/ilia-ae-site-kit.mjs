import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable, makeEnvironmentProviders, ENVIRONMENT_INITIALIZER, DestroyRef, signal, computed, input, ChangeDetectionStrategy, Component, isDevMode, effect, ElementRef, output, viewChild, afterNextRender, untracked } from '@angular/core';
import { DOCUMENT, NgTemplateOutlet } from '@angular/common';
import { Title, DomSanitizer } from '@angular/platform-browser';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { SwUpdate, provideServiceWorker } from '@angular/service-worker';

const IK_LANGUAGES = [
    { code: 'en', name: 'English', nativeName: 'English', direction: 'ltr', flag: '🇬🇧', flagCode: 'gb' },
    { code: 'ru', name: 'Russian', nativeName: 'Русский', direction: 'ltr', flag: '🇷🇺', flagCode: 'ru' },
    { code: 'es', name: 'Spanish', nativeName: 'Español', direction: 'ltr', flag: '🇪🇸', flagCode: 'es' },
    { code: 'pt', name: 'Portuguese', nativeName: 'Português', direction: 'ltr', flag: '🇧🇷', flagCode: 'br' },
    { code: 'ar', name: 'Arabic', nativeName: 'العربية', direction: 'rtl', flag: '🇦🇪', flagCode: 'ae' },
    { code: 'kk', name: 'Kazakh', nativeName: 'Қазақша', direction: 'ltr', flag: '🇰🇿', flagCode: 'kz' },
    { code: 'zh', name: 'Chinese', nativeName: '中文', direction: 'ltr', flag: '🇨🇳', flagCode: 'cn' },
    { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', direction: 'ltr', flag: '🇮🇳', flagCode: 'in' },
    { code: 'ur', name: 'Urdu', nativeName: 'اردو', direction: 'rtl', flag: '🇵🇰', flagCode: 'pk' },
];
/** Built on first lookup, not at load (a top-level `new Map` would pin IK_LANGUAGES in every app). */
let byCode$1;
const BY_CODE = () => (byCode$1 ??= new Map(IK_LANGUAGES.map((l) => [l.code, l])));
/** Look up a language descriptor by code. */
function ikLanguage(code) {
    return BY_CODE().get(code);
}
/** Convenience: is this language right-to-left (Arabic, Urdu)? */
function isRtl(code) {
    return ikLanguage(code)?.direction === 'rtl';
}
/** Resolve a subset of IK_LANGUAGES from codes (unknown codes dropped), preserving order. */
function ikLanguages(codes) {
    if (!codes?.length)
        return [...IK_LANGUAGES];
    return codes.map((c) => BY_CODE().get(c)).filter((l) => !!l);
}
/**
 * Locale-aware URL: for the default language returns `url` unchanged; for any
 * other language inserts the code as a path prefix after the origin.
 *   localizeUrl('https://ilia.ae', 'en', {defaultLang:'ru'})  → 'https://ilia.ae/en'
 *   localizeUrl('https://ilia.ae/blog', 'en', …)              → 'https://ilia.ae/en/blog'
 *   localizeUrl('/about', 'en', …)                            → '/en/about'
 * Hash-only / mailto: / tel: links pass through untouched. Already-prefixed
 * URLs are left as-is so it's idempotent.
 */
/**
 * Resolve a `LocalizedString` (plain string OR `{ en, ru }` map) for the active
 * language — falls back to the default language, then the first value, so one
 * config holds every translation. Returns `undefined` only for nullish input.
 */
function localizeText(value, lang, defaultLang = 'en') {
    if (value == null)
        return undefined;
    if (typeof value === 'string')
        return value;
    return value[lang ?? defaultLang] ?? value[defaultLang] ?? Object.values(value)[0];
}
function localizeUrl(url, lang, opts) {
    const def = opts?.defaultLang ?? 'en';
    if (!url || lang === def)
        return url;
    if (/^(mailto:|tel:|#)/i.test(url))
        return url;
    const abs = /^(https?:\/\/[^/]+)(\/.*)?$/i.exec(url);
    if (abs) {
        const origin = abs[1];
        const path = abs[2] ?? '';
        if (firstSegment(path) === lang)
            return url;
        return origin + '/' + lang + (path === '/' || path === '' ? '' : path);
    }
    const path = url.startsWith('/') ? url : '/' + url;
    if (firstSegment(path) === lang)
        return url;
    return '/' + lang + (path === '/' ? '' : path);
}
function firstSegment(path) {
    return path.split('/').filter(Boolean)[0] ?? '';
}
/** Origin (scheme://host) of an absolute URL, else '' for relative paths. */
function originOf(url) {
    return /^(https?:\/\/[^/]+)/i.exec(url)?.[1] ?? '';
}
/**
 * Resolve a link's href for the active language. Precedence:
 *   1. `urls[lang]`       — explicit full per-language URL
 *   2. `pathByLang[lang]` — `domain(url) + modifier`; languages absent → bare `url`
 *   3. `localize`         — auto `/<lang>` for non-default languages
 *   4. `url`              — the base
 */
function resolveLinkHref(link, lang, defaultLang = 'en') {
    if (link.urls?.[lang])
        return link.urls[lang];
    if (link.pathByLang) {
        const mod = link.pathByLang[lang];
        if (mod === undefined)
            return link.url; // this language has no modifier → base
        const origin = originOf(link.url);
        if (!origin)
            return mod || link.url; // relative base — use the modifier as the path
        return mod ? origin + (mod.startsWith('/') ? mod : '/' + mod) : origin;
    }
    if (link.localize)
        return localizeUrl(link.url, lang, { defaultLang });
    return link.url;
}

// ─── Status pages ─────────────────────────────────────────────
/** Default auto-redirect countdown (seconds) when `status.redirect` is not configured. */
const DEFAULT_REDIRECT_SECONDS = 15;
/**
 * Schema version of the config CONTRACT. Bump when the shape gains/changes fields.
 * Each site's data file should declare the `schemaVersion` it was written for; the
 * inventory dashboard (tools/inventory.mjs) compares it to this to flag stale data.
 *   1 = initial config (status/footer/contact/social/legal)
 *   2 = + nav, projects, languages/defaultLang, locale links, rich contact
 *   3 = + theme design layer, status redirect/back, strings overrides
 *   4 = + deploy layer: target git/cloudflare/wp, configurable /kit path
 *   5 = + technologies tech-stack block / footer badges
 *   6 = + favicon icon-set + seo head/OG/Twitter/hreflang/JSON-LD/sitemap
 *   7 = + pwa installable-app module — Angular-only: manifest/ngsw/install/splash
 *   8 = + seo.ogImage — auto-generated OG banner from brand/theme
 *   9 = + cookie consent module (Angular-only) — config.cookie
 *  10 = + cookie.policyBody — in-app localized "learn more" policy panel
 *  11 = cookie "learn more" = FULL in-app localized policy; removed cookie.policyHref
 *  12 = status auto-redirect ON by default (DEFAULT_REDIRECT_SECONDS); { delaySeconds: 0 } disables
 *  13 = cookie.policyHref — optional locale-aware link to the official full policy
 *  14 = config.license — license type key (text pulled from the license bank)
 *  15 = brand.nameHidden / footer.compact — minimal chrome + compact footer mode
 *  16 = verify — live build-integrity status on the brand/footer surfaces
 *  17 = footer.projects — built-in "our projects" family row (real-logo chips)
 *  18 = seo.entity.type 'SoftwareApplication'/'Product' — product rich-results (offers, category)
 */
const SITE_KIT_SCHEMA_VERSION = 18;
/** Module version (kept in sync with package.json; stamped into a <meta> for the live dashboard check). */
const SITE_KIT_VERSION = '1.51.0';
/** DI token holding the resolved, defaults-applied configuration. */
const SITE_KIT_CONFIG = new InjectionToken('SITE_KIT_CONFIG');
/**
 * Applies derived defaults so consumers can pass a minimal config. Pure, no side effects.
 * NOTE: `static/generate.mjs` mirrors this logic inline (a .mjs can't import this .ts) —
 * keep the two in sync when changing defaults.
 */
function resolveSiteKitConfig(config) {
    const languages = config.languages?.length ? config.languages : IK_LANGUAGES.map((l) => l.code);
    // safe: `languages` is guaranteed non-empty above (falls back to every IK_LANGUAGES code), so languages[0] is always defined.
    const defaultLang = config.defaultLang ?? languages[0];
    return {
        ...config,
        copyright: {
            holder: config.copyright?.holder ?? config.brand.name,
            startYear: config.copyright?.startYear,
            suffix: config.copyright?.suffix,
        },
        social: config.social ?? [],
        legal: config.legal ?? [],
        nav: config.nav ?? [],
        projects: config.projects ?? [],
        technologies: config.technologies ?? [],
        languages,
        defaultLang,
        status: {
            homeHref: config.status?.homeHref ?? config.brand.url ?? '/',
            homeLabel: config.status?.homeLabel, // left undefined → status page localizes via ikString
            languages: config.status?.languages ?? languages,
            supportLine: config.status?.supportLine,
            redirect: config.status?.redirect,
            showBack: config.status?.showBack ?? true,
        },
        deploy: {
            target: config.deploy?.target ?? 'git',
            path: config.deploy?.path ?? '/kit',
            routes: config.deploy?.routes,
            zone: config.deploy?.zone,
        },
    };
}

/** Join a public base path + filename into one clean URL path. */
function joinPath(base, file) {
    const b = String(base ?? '/').replace(/\/+$/, '');
    const f = String(file).replace(/^\/+/, '');
    return `${b}/${f}`.replace(/\/{2,}/g, '/');
}
/** Resolve the browser-UI theme-color into `{ light?, dark? }`. */
function resolveThemeColor(favicon, theme) {
    const tc = favicon?.themeColor;
    if (tc && typeof tc === 'object')
        return { light: tc.light, dark: tc.dark };
    const single = tc ?? theme?.['--brand'] ?? '#ffffff';
    return { light: single };
}
/**
 * Canonical favicon head tags from config — the single source shared by the Angular
 * runtime and the static generator. Order matters: SVG-capable browsers prefer
 * `icon.svg`, legacy falls back to `favicon.ico`.
 */
function faviconTags(favicon, opts = {}) {
    if (!favicon)
        return [];
    const base = favicon.path ?? opts.basePath ?? '/';
    const withManifest = favicon.manifest !== false;
    const tags = [
        { tag: 'link', rel: 'icon', href: joinPath(base, 'favicon.ico'), sizes: '32x32' },
        { tag: 'link', rel: 'icon', href: joinPath(base, 'icon.svg'), type: 'image/svg+xml' },
        { tag: 'link', rel: 'apple-touch-icon', href: joinPath(base, 'apple-touch-icon.png') },
    ];
    if (withManifest)
        tags.push({ tag: 'link', rel: 'manifest', href: joinPath(base, 'manifest.webmanifest') });
    const tc = resolveThemeColor(favicon, opts.theme);
    if (tc.light && tc.dark) {
        tags.push({
            tag: 'meta',
            name: 'theme-color',
            content: tc.light,
            media: '(prefers-color-scheme: light)',
        });
        tags.push({
            tag: 'meta',
            name: 'theme-color',
            content: tc.dark,
            media: '(prefers-color-scheme: dark)',
        });
    }
    else if (tc.light) {
        tags.push({ tag: 'meta', name: 'theme-color', content: tc.light });
    }
    return tags;
}
const escXml$1 = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const innerSvg$1 = (svg) => String(svg)
    .replace(/<\?xml[\s\S]*?\?>/i, '')
    .trim();
/**
 * Browser-safe derivation of the SQUARE source SVG (no file IO) — the icon shown in
 * previews and the basis for the rasterized set. Resolution: inline `favicon.src`
 * `<svg…>` / `data:image/svg+xml` → `brand.glyph` (tinted on a `--brand` tile) →
 * `brand.monogram`/initial letter tile. The build-time tools/lib/favicon.mjs mirror
 * adds the file-path case on top of this same logic.
 */
function faviconSourceSvg(favicon, brand, theme) {
    const fav = favicon ?? {};
    const bg = fav.background ?? theme?.['--brand'] ?? '#6366f1';
    const fg = fav.color ?? '#ffffff';
    if (fav.src) {
        const s = String(fav.src).trim();
        if (/^<svg/i.test(s))
            return s;
        if (/^data:image\/svg\+xml/i.test(s)) {
            const m = /^data:image\/svg\+xml(;base64)?,(.*)$/is.exec(s);
            if (m)
                return m[1] ? atob(m[2]) : decodeURIComponent(m[2]); // safe: group 2 (.*) is always present after a successful match
        }
    }
    if (typeof brand?.glyph === 'string' && /<svg/i.test(brand.glyph)) {
        const pad = 512 * 0.2, inner = 512 - pad * 2;
        return (`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">` +
            `<rect width="512" height="512" rx="96" fill="${escXml$1(bg)}"/>` +
            `<svg x="${pad}" y="${pad}" width="${inner}" height="${inner}" overflow="visible" style="color:${escXml$1(fg)}">${innerSvg$1(brand.glyph)}</svg></svg>`);
    }
    const letter = escXml$1((brand?.monogram ?? brand?.name ?? '?').trim().charAt(0).toUpperCase());
    return (`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">` +
        `<rect width="512" height="512" rx="96" fill="${escXml$1(bg)}"/>` +
        `<text x="256" y="360" text-anchor="middle" ` +
        `font-family="system-ui,-apple-system,Segoe UI,Roboto,sans-serif" font-weight="800" font-size="300" fill="${escXml$1(fg)}">${letter}</text></svg>`);
}
/**
 * Apply favicon tags to a document `<head>`, idempotently. Kit-managed nodes carry
 * `data-ik-favicon` so a re-apply (e.g. multi-domain host swap) replaces cleanly and
 * never collides with the app's own tags. SSR/no-DOM safe (caller wraps in try/catch).
 */
function applyFaviconTags(doc, tags) {
    const head = doc.head;
    if (!head)
        return;
    head.querySelectorAll('[data-ik-favicon]').forEach((n) => n.remove());
    for (const t of tags) {
        const el = doc.createElement(t.tag);
        el.setAttribute('data-ik-favicon', '');
        if (t.tag === 'link') {
            el.setAttribute('rel', t.rel);
            el.setAttribute('href', t.href);
            if (t.type)
                el.setAttribute('type', t.type);
            if (t.sizes)
                el.setAttribute('sizes', t.sizes);
        }
        else {
            el.setAttribute('name', t.name);
            el.setAttribute('content', t.content);
            if (t.media)
                el.setAttribute('media', t.media);
        }
        head.appendChild(el);
    }
}

/** Default `og:locale` territory per language code (underscore form). */
const OG_LOCALE = {
    en: 'en_US',
    ru: 'ru_RU',
    ar: 'ar_AE',
    kk: 'kk_KZ',
    zh: 'zh_CN',
    hi: 'hi_IN',
    ur: 'ur_PK',
};
const stripSlash = (u) => u.replace(/\/+$/, '');
const loc = (v, lang, def) => localizeText(v, lang, def);
/** Resolve a possibly-relative URL to an absolute one against `siteUrl`. */
function absUrl(siteUrl, maybe) {
    if (!maybe)
        return undefined;
    if (/^https?:\/\//i.test(maybe))
        return maybe;
    if (!siteUrl)
        return maybe;
    return `${stripSlash(siteUrl)}/${String(maybe).replace(/^\/+/, '')}`;
}
/** Per-language canonical URL for a path (default lang un-prefixed; others get `/lang`). */
function canonicalFor(siteUrl, path, lang, def) {
    const base = stripSlash(siteUrl);
    const p = !path || path === '/' ? '/' : path.startsWith('/') ? path : `/${path}`;
    return localizeUrl(base + p, lang, { defaultLang: def });
}
/**
 * Build the full SEO head for one page+language from a site config.
 * Returns `[]` when there's nothing meaningful to emit (no brand/seo signal).
 *
 * @remarks Low-level builder (advanced API): the high-level `Seo` directive applies these tags at
 * runtime. Exported for the static generator and SSR/custom-rendering consumers — most apps should
 * use `Seo` instead.
 */
function buildSeoTags(config, ctx = {}) {
    const seo = config.seo ?? {};
    const brand = config.brand;
    const languages = config.languages?.length ? config.languages : [];
    const def = config.defaultLang ?? languages[0] ?? 'en';
    const lang = ctx.lang ?? def;
    const siteUrl = seo.siteUrl ? stripSlash(seo.siteUrl) : brand?.url ? stripSlash(brand.url) : undefined;
    const tags = [];
    // ── title ──
    const brandName = brand?.name ?? '';
    let title;
    if (ctx.title) {
        title = seo.titleTemplate
            ? seo.titleTemplate.replace('%s', ctx.title)
            : `${ctx.title} — ${brandName}`;
    }
    else {
        const baseTitle = loc(seo.title, lang, def);
        const tagline = loc(brand?.tagline, lang, def);
        title = baseTitle ?? (tagline ? `${brandName} — ${tagline}` : brandName);
    }
    if (title)
        tags.push({ tag: 'title', text: title });
    // ── description ──
    const description = ctx.description ?? loc(seo.description, lang, def) ?? loc(brand?.tagline, lang, def);
    if (description)
        tags.push({ tag: 'meta', name: 'description', content: description });
    // ── robots ──
    const robots = ctx.robots ??
        seo.robots ??
        'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    tags.push({ tag: 'meta', name: 'robots', content: robots });
    if (seo.author)
        tags.push({ tag: 'meta', name: 'author', content: seo.author });
    if (seo.referrer)
        tags.push({ tag: 'meta', name: 'referrer', content: seo.referrer });
    // ── canonical + hreflang ──
    const path = ctx.path ?? '/';
    let canonical;
    if (siteUrl) {
        canonical = canonicalFor(siteUrl, path, lang, def);
        tags.push({ tag: 'link', rel: 'canonical', href: canonical });
        const wantHreflang = seo.hreflang !== false && languages.length > 1;
        if (wantHreflang) {
            for (const l of languages)
                tags.push({
                    tag: 'link',
                    rel: 'alternate',
                    hreflang: l,
                    href: canonicalFor(siteUrl, path, l, def),
                });
            tags.push({
                tag: 'link',
                rel: 'alternate',
                hreflang: 'x-default',
                href: canonicalFor(siteUrl, path, def, def),
            });
        }
    }
    // ── Open Graph (property=) ──
    // Auto OG banner (seo.ogImage) → <favicon.path>/og.png, unless an explicit image is set.
    const favPath = config.favicon?.path ?? '/';
    const ogPath = seo.ogImage ? `${favPath}/og.png`.replace(/\/{2,}/g, '/') : undefined;
    const image = absUrl(siteUrl, ctx.image ?? seo.image ?? ogPath);
    const ogType = ctx.ogType ?? seo.ogType ?? 'website';
    const og = (property, content) => {
        if (content)
            tags.push({ tag: 'meta', property, content });
    };
    og('og:type', ogType);
    og('og:title', title);
    og('og:description', description);
    og('og:url', canonical);
    og('og:site_name', brandName);
    if (image) {
        og('og:image', image);
        if (/^https:\/\//i.test(image))
            og('og:image:secure_url', image);
        og('og:image:width', '1200');
        og('og:image:height', '630');
        og('og:image:alt', loc(seo.imageAlt, lang, def) ?? title);
    }
    if (languages.length) {
        const localeOf = (l) => seo.locales?.[l] ?? OG_LOCALE[l] ?? l;
        og('og:locale', localeOf(lang));
        for (const l of languages)
            if (l !== lang)
                tags.push({ tag: 'meta', property: 'og:locale:alternate', content: localeOf(l) });
    }
    // ── Twitter / X (name=) ──
    const tw = (name, content) => {
        if (content)
            tags.push({ tag: 'meta', name, content });
    };
    tw('twitter:card', seo.twitterCard ?? (image ? 'summary_large_image' : 'summary'));
    tw('twitter:site', seo.twitterSite);
    tw('twitter:creator', seo.twitterCreator);
    tw('twitter:title', title);
    tw('twitter:description', description);
    if (image) {
        tw('twitter:image', image);
        tw('twitter:image:alt', loc(seo.imageAlt, lang, def) ?? title);
    }
    // ── JSON-LD @graph (entity + WebSite) ──
    if (seo.entity && siteUrl) {
        const e = seo.entity;
        const type = e.type ?? 'Organization';
        const isApp = type === 'SoftwareApplication' || type === 'Product';
        const entityId = `${siteUrl}/#${isApp
            ? type === 'Product'
                ? 'product'
                : 'software'
            : type === 'Person'
                ? 'person'
                : 'organization'}`;
        let entityNode;
        if (isApp) {
            // SoftwareApplication / Product — product rich-results (offers, category, …).
            entityNode = { '@type': type, '@id': entityId, name: e.name ?? brandName, url: `${siteUrl}/` };
            if (e.applicationCategory)
                entityNode['applicationCategory'] = e.applicationCategory;
            if (e.applicationSubCategory)
                entityNode['applicationSubCategory'] = e.applicationSubCategory;
            const os = e.operatingSystem ?? (type === 'SoftwareApplication' ? 'Any' : undefined);
            if (os)
                entityNode['operatingSystem'] = os;
            const inLang = e.inLanguage ?? languages;
            if (inLang.length)
                entityNode['inLanguage'] = inLang;
            // Site-wide description for the active lang — NOT the page-level `description`
            // (which folds in ctx.description), so this stable-@id node stays consistent across pages.
            const entityDesc = loc(seo.description, lang, def) ?? loc(brand?.tagline, lang, def);
            if (entityDesc)
                entityNode['description'] = entityDesc;
            const img = absUrl(siteUrl, e.image ?? brand?.logoUrl);
            if (img)
                entityNode['image'] = img;
            if (e.offers) {
                const offer = {
                    '@type': 'Offer',
                    price: e.offers.price,
                    priceCurrency: e.offers.priceCurrency,
                };
                if (e.offers.availability)
                    offer['availability'] = e.offers.availability;
                if (e.offers.url)
                    offer['url'] = e.offers.url;
                entityNode['offers'] = offer;
            }
        }
        else {
            const sameAs = e.sameAs ?? (config.social ?? []).map((s) => s.url).filter((u) => /^https?:\/\//i.test(u));
            entityNode = { '@type': type, '@id': entityId, name: e.name ?? brandName, url: `${siteUrl}/` };
            if (e.email ?? config.contact?.email)
                entityNode['email'] = e.email ?? config.contact?.email;
            if (sameAs.length)
                entityNode['sameAs'] = sameAs;
            const logo = absUrl(siteUrl, e.image ?? brand?.logoUrl);
            if (type === 'Person') {
                const jt = loc(e.jobTitle, lang, def);
                if (jt)
                    entityNode['jobTitle'] = jt;
                if (logo)
                    entityNode['image'] = logo;
            }
            else if (logo) {
                entityNode['logo'] = { '@type': 'ImageObject', url: logo };
            }
        }
        const webSite = {
            '@type': 'WebSite',
            '@id': `${siteUrl}/#website`,
            url: `${siteUrl}/`,
            name: brandName,
        };
        // The app node carries no publisher/author link (no Organization node present).
        if (!isApp)
            webSite[type === 'Person' ? 'author' : 'publisher'] = { '@id': entityId };
        if (languages.length)
            webSite['inLanguage'] = languages;
        tags.push({
            tag: 'jsonld',
            json: { '@context': 'https://schema.org', '@graph': [entityNode, webSite] },
        });
    }
    return tags;
}

/**
 * Live SEO head manager for kit-driven Angular apps.
 *
 * Applies the `buildSeoTags()` output (title · meta · canonical/hreflang · JSON-LD)
 * to the document `<head>` from `config.seo`, and lets routes refine it per page:
 *
 * ```ts
 * private readonly seo = inject(Seo);
 * ngOnInit() { this.seo.update({ lang: 'ru', path: '/about', title: 'Обо мне' }); }
 * ```
 *
 * Site-wide defaults are applied at boot by `provideSiteKit` (when `config.seo` is
 * present). Kit-managed nodes carry `data-ik-seo`, so every `update()` replaces the
 * previous set cleanly and never clobbers the app's own tags. SSR/no-DOM safe.
 */
class Seo {
    doc = inject(DOCUMENT);
    title = inject(Title);
    config = inject(SITE_KIT_CONFIG);
    /** Recompute and apply the head for a page/language (merges over `config.seo`). */
    update(ctx = {}) {
        this.applyTags(buildSeoTags(this.config, ctx));
    }
    /** Apply a pre-built descriptor list (e.g. from a shared computation). */
    applyTags(tags) {
        const head = this.doc.head;
        if (!head)
            return;
        try {
            head.querySelectorAll('[data-ik-seo]').forEach((n) => n.remove());
            for (const t of tags) {
                if (t.tag === 'title') {
                    this.title.setTitle(t.text);
                    continue;
                }
                const el = this.doc.createElement(t.tag === 'jsonld' ? 'script' : t.tag);
                el.setAttribute('data-ik-seo', '');
                if (t.tag === 'meta') {
                    if (t.name)
                        el.setAttribute('name', t.name);
                    if (t.property)
                        el.setAttribute('property', t.property);
                    el.setAttribute('content', t.content);
                    if (t.media)
                        el.setAttribute('media', t.media);
                }
                else if (t.tag === 'link') {
                    el.setAttribute('rel', t.rel);
                    el.setAttribute('href', t.href);
                    if (t.hreflang)
                        el.setAttribute('hreflang', t.hreflang);
                }
                else {
                    el.setAttribute('type', 'application/ld+json');
                    el.textContent = JSON.stringify(t.json);
                }
                head.appendChild(el);
            }
        }
        catch {
            /* SSR / no DOM — skip */
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Seo, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Seo, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Seo, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/** Builds the DI providers for a resolved config + stamps a discovery <meta> tag. */
function kitProviders(resolved) {
    return makeEnvironmentProviders([
        { provide: SITE_KIT_CONFIG, useValue: resolved },
        {
            // Stamps <meta name="site-kit-version" content="1.1.0" data-schema="2" data-brand="…">
            // so the inventory dashboard's HTTP check can read the deployed version.
            provide: ENVIRONMENT_INITIALIZER,
            multi: true,
            useValue: () => {
                const doc = inject(DOCUMENT);
                try {
                    // Apply the DESIGN layer — config.theme → CSS custom properties on <html>.
                    if (resolved.theme) {
                        const root = doc.documentElement;
                        for (const [k, v] of Object.entries(resolved.theme)) {
                            if (k.startsWith('--'))
                                root.style.setProperty(k, v);
                        }
                    }
                    // Favicon head tags (icon set + theme-color) — opt-in via config.favicon.
                    if (resolved.favicon) {
                        applyFaviconTags(doc, faviconTags(resolved.favicon, { theme: resolved.theme }));
                    }
                    // SEO head (title · meta · OG · Twitter · hreflang · JSON-LD) — opt-in
                    // via config.seo; routes refine per-page with inject(Seo).update(…).
                    if (resolved.seo) {
                        inject(Seo).update({ lang: resolved.defaultLang });
                    }
                    const head = doc.head;
                    if (!head || head.querySelector('meta[name="site-kit-version"]'))
                        return;
                    const m = doc.createElement('meta');
                    m.setAttribute('name', 'site-kit-version');
                    m.setAttribute('content', SITE_KIT_VERSION);
                    m.setAttribute('data-schema', String(resolved.schemaVersion ?? SITE_KIT_SCHEMA_VERSION));
                    m.setAttribute('data-brand', resolved.brand.name);
                    head.appendChild(m);
                }
                catch {
                    /* SSR / no DOM — skip */
                }
            },
        },
    ]);
}
/**
 * Registers the site-kit configuration for the application.
 *
 * ```ts
 * // app.config.ts
 * providers: [
 *   provideSiteKit({
 *     brand:   { name: 'ilia.ae', url: 'https://ilia.ae', tagline: 'Fractional CTO' },
 *     schemaVersion: 2,
 *     languages: ['ru', 'en', 'ar'],
 *     defaultLang: 'ru',
 *     nav:     [{ label: 'Blog', url: 'https://ilia.ae/blog', localize: true }],
 *     projects:[{ name: 'Mayday', url: 'https://mayday.software', status: 'live' }],
 *     contact: { qr: { data: 'https://t.me/ilia_ae' }, email: 'hi@ilia.ae' },
 *   }),
 * ]
 * ```
 */
function provideSiteKit(config) {
    return kitProviders(resolveSiteKitConfig(config));
}
/**
 * Multi-domain variant — automatically picks the config whose key matches the
 * current hostname. One built artifact serves every site:
 *
 * ```ts
 * provideSiteKitForHost({
 *   'ilia.ae':          iliaConfig,
 *   'mayday.software':  maydayConfig,
 *   'monolith.plus':    monolithConfig,
 *   'aliro':            aliroConfig,
 * }, { fallback: 'ilia.ae' });
 * ```
 *
 * Matching order: exact hostname → `www.` stripped → longest key that is a
 * suffix of (or contained in) the hostname → `fallback` → first entry.
 */
function provideSiteKitForHost(configs, opts) {
    const host = (opts?.hostname ?? hostFromLocation()).toLowerCase();
    const key = pickHostKey(host, configs, opts?.fallback);
    // safe: pickHostKey only ever returns a key that exists in `configs` (matched key, fallback, or keys[0]).
    return kitProviders(resolveSiteKitConfig(configs[key]));
}
/* istanbul ignore next -- SSR guard: `location` is undefined server-side, so this branch
   cannot execute under the (browser) Karma test runner; callers pass `hostname` for SSR. */
const hostFromLocation = () => (typeof location !== 'undefined' ? location.hostname : '');
/**
 * Resolves which config key best matches a hostname.
 * @internal Exported for testing and `provideSiteKitForHost`; not part of the committed public API.
 */
function pickHostKey(hostname, configs, fallback) {
    const keys = Object.keys(configs);
    if (!keys.length)
        throw new Error('provideSiteKitForHost: empty config map');
    const host = hostname.replace(/^www\./, '');
    if (configs[host] !== undefined)
        return host;
    if (configs[hostname] !== undefined)
        return hostname;
    const matches = keys
        .filter((k) => host === k || host.endsWith('.' + k) || host.includes(k))
        .sort((a, b) => b.length - a.length);
    if (matches.length)
        return matches[0]; // safe: matches.length > 0 guarded above
    if (fallback && configs[fallback] !== undefined)
        return fallback;
    return keys[0]; // safe: keys.length > 0 (empty-map check threw above)
}

/**
 * OG-banner SVG builder (1200×630), browser-safe — the share image generated FROM
 * CONFIG (theme gradient + brand mark + name + tagline). The PNG (`og.png`) is
 * rasterized at build time by tools/lib/og.mjs (sharp); this pure SVG is the same
 * markup, used for live previews. Mirror of tools/lib/og.mjs `buildOgSvg`.
 */
const escXml = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const cssVal = (v) => String(v).replace(/["<>]/g, '');
const innerSvg = (svg) => String(svg)
    .replace(/^\s*<svg[^>]*>/i, '')
    .replace(/<\/svg>\s*$/i, '');
/**
 * Convert an `oklch(L C H)` colour to an sRGB hex. Hex/rgb/named colours pass
 * through unchanged. The OG banner needs hex because: (a) `currentColor` doesn't
 * reliably resolve `oklch()` for the inline mark glyph, and (b) the build-time
 * rasterizer (sharp/librsvg) can't parse `oklch()` at all.
 */
function toHex(v) {
    const m = /^oklch\(\s*([\d.]+)(%?)\s+([\d.]+)(%?)\s+([\d.]+)(?:deg)?\s*\)$/i.exec(String(v).trim());
    if (!m)
        return String(v);
    const L = m[2] ? parseFloat(m[1]) / 100 : parseFloat(m[1]); // safe: regex matched
    const C = m[4] ? (parseFloat(m[3]) / 100) * 0.4 : parseFloat(m[3]); // safe: regex matched
    const h = (parseFloat(m[5]) * Math.PI) / 180; // safe: regex matched
    const a = C * Math.cos(h), b = C * Math.sin(h);
    const l_ = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3;
    const m_ = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3;
    const s_ = (L - 0.0894841775 * a - 1.291485548 * b) ** 3;
    const lin = [
        4.0767416621 * l_ - 3.3077115913 * m_ + 0.2309699292 * s_,
        -1.2684380046 * l_ + 2.6097574011 * m_ - 0.3413193965 * s_,
        -0.0041960863 * l_ - 0.7034186147 * m_ + 1.707614701 * s_,
    ];
    const enc = (c) => {
        const g = c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
        return Math.max(0, Math.min(255, Math.round(g * 255)))
            .toString(16)
            .padStart(2, '0');
    };
    return `#${enc(lin[0])}${enc(lin[1])}${enc(lin[2])}`; // safe: lin is a fixed 3-element array literal
}
const W = 1200, H = 630;
/**
 * Build the OG banner SVG (1200×630) for a site config + language.
 *
 * @remarks Low-level builder (advanced API): exported for the static generator (which rasterizes it
 * to PNG) and SSR/custom-rendering consumers.
 */
function buildOgSvg(config, opts = {}) {
    const brand = config.brand;
    const theme = config.theme ?? {};
    const def = config.defaultLang ?? config.languages?.[0] ?? 'en';
    const lang = opts.lang ?? def;
    const c1 = toHex(cssVal(theme['--brand'] ?? '#6d28d9'));
    const c2 = toHex(cssVal(theme['--accent-2'] ?? theme['--accent'] ?? '#db2777'));
    const seoTitle = config.seo?.title;
    const name = brand?.name ??
        (typeof seoTitle === 'string' ? seoTitle : undefined) ??
        config.favicon?.name ??
        'Site';
    // Subtitle = the brand SLOGAN (brand.tagline), NOT seo.description — the description
    // already shows in og:description / the card body, so reusing it just duplicates.
    const slogan = localizeText(brand?.tagline, lang, def) ?? '';
    const markFav = { ...(config.favicon ?? {}), background: '#ffffff', color: c1 };
    const mark = innerSvg(faviconSourceSvg(markFav, brand, theme));
    // Editorial left-aligned hero: logo chip + big name + slogan, vertically centred,
    // over a mesh-gradient background. (No domain footer — the brand carries it.)
    const headline = name.length > 18 ? `${name.slice(0, 17).trimEnd()}…` : name;
    const titleSize = name.length > 13 ? 130 : 196;
    const sub = slogan.length > 50 ? `${slogan.slice(0, 49).trimEnd()}…` : slogan;
    // Grouped block (logo + name + slogan), vertically centred. Big logo + name fill the
    // canvas → small top/bottom margins, while the logo→name gap stays tight.
    const P = 84, logoSize = 208, FONT = 'Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif';
    const nameCap = Math.round(titleSize * 0.74);
    const gapLN = 40, gapNS = 36, subCap = 34;
    const blockH = logoSize + gapLN + nameCap + (sub ? gapNS + subCap : 0);
    const logoY = Math.round((H - blockH) / 2);
    const nameY = logoY + logoSize + gapLN + nameCap; // baseline
    const subY = nameY + gapNS + subCap;
    return (`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${escXml(name)}">` +
        `<defs>` +
        `<linearGradient id="ogbg" x1="0" y1="0.05" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient>` +
        // mesh blobs → an organic, rich background (not flat) even for a monochrome theme.
        `<radialGradient id="ogb1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.26"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>` +
        `<radialGradient id="ogb2"><stop offset="0" stop-color="#000000" stop-opacity="0.34"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></radialGradient>` +
        `<radialGradient id="ogb3"><stop offset="0" stop-color="${c1}" stop-opacity="0.5"/><stop offset="1" stop-color="${c1}" stop-opacity="0"/></radialGradient>` +
        `<pattern id="ogdots" width="44" height="44" patternUnits="userSpaceOnUse"><circle cx="2.5" cy="2.5" r="2.2" fill="#ffffff" fill-opacity="0.07"/></pattern>` +
        `<filter id="ogcard" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="0" dy="10" stdDeviation="22" flood-color="#000000" flood-opacity="0.3"/></filter>` +
        `</defs>` +
        `<rect width="${W}" height="${H}" fill="url(#ogbg)"/>` +
        `<ellipse cx="990" cy="70" rx="560" ry="470" fill="url(#ogb1)"/>` +
        `<ellipse cx="1080" cy="560" rx="520" ry="420" fill="url(#ogb3)"/>` +
        `<ellipse cx="120" cy="650" rx="540" ry="430" fill="url(#ogb2)"/>` +
        `<rect width="${W}" height="${H}" fill="url(#ogdots)"/>` +
        `<g filter="url(#ogcard)" transform="translate(${P} ${logoY}) scale(${(logoSize / 512).toFixed(4)})">${mark}</g>` +
        `<text x="${P}" y="${nameY}" font-family="${FONT}" font-size="${titleSize}" font-weight="800" letter-spacing="-2.5" fill="#fff">${escXml(headline)}</text>` +
        (sub
            ? `<text x="${P}" y="${subY}" font-family="${FONT}" font-size="44" font-weight="500" fill="#fff" fill-opacity="0.88">${escXml(sub)}</text>`
            : '') +
        `</svg>`);
}

/**
 * Apple splash-screen device matrix (physical px + DPR). CSS size = px / ratio; the
 * media query matches `device-width`/`device-height` in CSS px at that pixel ratio.
 * A focused set covering current iPhone/iPad classes (portrait).
 */
const PWA_SPLASH_DEVICES = [
    { id: 'iphone-se', w: 640, h: 1136, ratio: 2 },
    { id: 'iphone-8', w: 750, h: 1334, ratio: 2 },
    { id: 'iphone-11', w: 828, h: 1792, ratio: 2 },
    { id: 'iphone-x', w: 1125, h: 2436, ratio: 3 },
    { id: 'iphone-14', w: 1170, h: 2532, ratio: 3 },
    { id: 'iphone-15-pro', w: 1179, h: 2556, ratio: 3 },
    { id: 'iphone-plus', w: 1242, h: 2208, ratio: 3 },
    { id: 'iphone-11-pro-max', w: 1242, h: 2688, ratio: 3 },
    { id: 'iphone-14-plus', w: 1284, h: 2778, ratio: 3 },
    { id: 'iphone-15-pro-max', w: 1290, h: 2796, ratio: 3 },
    { id: 'ipad-9-7', w: 1536, h: 2048, ratio: 2 },
    { id: 'ipad-10-2', w: 1620, h: 2160, ratio: 2 },
    { id: 'ipad-air', w: 1640, h: 2360, ratio: 2 },
    { id: 'ipad-pro-11', w: 1668, h: 2388, ratio: 2 },
    { id: 'ipad-pro-12-9', w: 2048, h: 2732, ratio: 2 },
];
/** Portrait media query for an apple-touch-startup-image link (CSS px). */
function splashMedia(d) {
    return (`(device-width: ${d.w / d.ratio}px) and (device-height: ${d.h / d.ratio}px) ` +
        `and (-webkit-device-pixel-ratio: ${d.ratio}) and (orientation: portrait)`);
}
/**
 * Build the ENRICHED web manifest (icons from `config.favicon` + PWA fields from
 * `config.pwa`). The single source for the demo inspector, the build tooling
 * (tools/lib/pwa.mjs mirror) and tests. Returns `null` when `config.pwa` is absent.
 *
 * @remarks Low-level builder (advanced API): `provideSiteKitPwa()` / the `Pwa` component wire PWA
 * up for apps. Exported for the static generator and build tooling — most apps don't call it directly.
 */
function buildManifest(config) {
    if (!config.pwa)
        return null;
    const pwa = config.pwa;
    const fav = config.favicon ?? {};
    const base = fav.path ?? '/';
    const def = config.defaultLang ?? config.languages?.[0] ?? 'en';
    const name = pwa.name ?? fav.name ?? config.brand?.name ?? 'App';
    const description = localizeText(pwa.description, def, def) ??
        localizeText(config.seo?.description, def, def) ??
        localizeText(config.brand?.tagline, def, def);
    const icon = (file, sizes, purpose, type = 'image/png') => ({
        src: joinPath(base, file),
        type,
        sizes,
        purpose,
    });
    const m = {
        id: pwa.scope ?? pwa.startUrl ?? '/',
        name,
        short_name: pwa.shortName ?? name,
        start_url: pwa.startUrl ?? '/',
        scope: pwa.scope ?? '/',
        display: pwa.display ?? 'standalone',
        orientation: pwa.orientation ?? 'any',
        background_color: pwa.backgroundColor ?? fav.background ?? '#ffffff',
        theme_color: resolveThemeColor(fav, config.theme).light ?? '#ffffff',
        lang: def,
        dir: isRtl(def) ? 'rtl' : 'ltr',
        prefer_related_applications: false,
        launch_handler: { client_mode: 'auto' },
        icons: [
            icon('icon.svg', 'any', 'any', 'image/svg+xml'),
            icon('apple-touch-icon.png', '180x180', 'any'),
            icon('icon-192.png', '192x192', 'any'),
            icon('icon-512.png', '512x512', 'any'),
            icon('icon-mask.png', '512x512', 'maskable'),
        ],
    };
    if (description)
        m['description'] = description;
    if (pwa.displayOverride?.length)
        m['display_override'] = pwa.displayOverride;
    if (pwa.categories?.length)
        m['categories'] = pwa.categories;
    if (pwa.shortcuts?.length) {
        m['shortcuts'] = pwa.shortcuts.map((s) => ({
            name: s.name,
            ...(s.shortName ? { short_name: s.shortName } : {}),
            ...(s.description ? { description: s.description } : {}),
            url: s.url,
            icons: [{ src: joinPath(base, 'icon-192.png'), sizes: '192x192' }],
        }));
    }
    return m;
}
/** iOS/chrome `<meta>` tags from `config.pwa` (the app-shell chrome a manifest can't set). */
function pwaMetaTags(config) {
    if (!config.pwa)
        return [];
    const name = config.pwa.name ?? config.favicon?.name ?? config.brand?.name ?? 'App';
    return [
        { name: 'application-name', content: name },
        { name: 'apple-mobile-web-app-title', content: config.pwa.shortName ?? name },
        { name: 'apple-mobile-web-app-capable', content: 'yes' },
        { name: 'mobile-web-app-capable', content: 'yes' },
        {
            name: 'apple-mobile-web-app-status-bar-style',
            content: config.pwa.appleStatusBarStyle ?? 'black-translucent',
        },
        { name: 'color-scheme', content: 'light dark' },
        { name: 'format-detection', content: 'telephone=no' },
    ];
}
/** `apple-touch-startup-image` splash `<link>`s (empty when `pwa.splash === false`). */
function pwaSplashLinks(config, basePath) {
    if (!config.pwa || config.pwa.splash === false)
        return [];
    const base = basePath ?? config.favicon?.path ?? '/';
    return PWA_SPLASH_DEVICES.map((d) => ({
        rel: 'apple-touch-startup-image',
        href: joinPath(base, `splash/${d.id}.png`),
        media: splashMedia(d),
    }));
}
/** Is the app running as an installed/standalone PWA? (display-mode + iOS navigator.standalone) */
function isStandalone(win) {
    try {
        if (win.matchMedia?.('(display-mode: standalone)').matches)
            return true;
        if (win.matchMedia?.('(display-mode: window-controls-overlay)').matches)
            return true;
    }
    catch {
        /* no matchMedia */
    }
    return win.navigator.standalone === true;
}
/** iOS Safari (no `beforeinstallprompt` → needs the manual "Add to Home Screen" hint). */
function isIos(nav) {
    const ua = nav.userAgent || '';
    const iDevice = /iphone|ipad|ipod/i.test(ua) ||
        (nav.platform === 'MacIntel' && nav.maxTouchPoints > 1); // iPadOS 13+
    return iDevice && /safari/i.test(ua) && !/crios|fxios|edgios/i.test(ua);
}
/** Apply PWA meta + splash links to a document `<head>`, idempotently (`data-ik-pwa`). */
function applyPwaTags(doc, metas, links) {
    const head = doc.head;
    if (!head)
        return;
    head.querySelectorAll('[data-ik-pwa]').forEach((n) => n.remove());
    for (const m of metas) {
        const el = doc.createElement('meta');
        el.setAttribute('data-ik-pwa', '');
        el.setAttribute('name', m.name);
        el.setAttribute('content', m.content);
        head.appendChild(el);
    }
    for (const l of links) {
        const el = doc.createElement('link');
        el.setAttribute('data-ik-pwa', '');
        el.setAttribute('rel', l.rel);
        el.setAttribute('href', l.href);
        if (l.media)
            el.setAttribute('media', l.media);
        head.appendChild(el);
    }
}

/**
 * Installable-app service (Angular-only). Captures the `beforeinstallprompt` event,
 * exposes `canInstall`/`install()`, detects standalone/installed + iOS (which has no
 * prompt → needs the manual "Add to Home Screen" hint), and surfaces ngsw update
 * availability. Registered + head-applied by `provideSiteKitPwa()`.
 */
class Pwa {
    doc = inject(DOCUMENT);
    config = inject(SITE_KIT_CONFIG);
    destroyRef = inject(DestroyRef);
    swUpdate = inject(SwUpdate, { optional: true });
    promptEvent = signal(null, ...(ngDevMode ? [{ debugName: "promptEvent" }] : /* istanbul ignore next */ []));
    /** True once the app is installed / running standalone. */
    installed = signal(false, ...(ngDevMode ? [{ debugName: "installed" }] : /* istanbul ignore next */ []));
    /** A new service-worker version is ready (offer a "reload to update"). */
    updateAvailable = signal(false, ...(ngDevMode ? [{ debugName: "updateAvailable" }] : /* istanbul ignore next */ []));
    /** iOS Safari — no `beforeinstallprompt`, so show the manual hint instead. */
    isIosSafari = signal(false, ...(ngDevMode ? [{ debugName: "isIosSafari" }] : /* istanbul ignore next */ []));
    /** Show the install button (a prompt is queued and we're not installed). */
    canInstall = computed(() => !!this.promptEvent() && !this.installed(), ...(ngDevMode ? [{ debugName: "canInstall" }] : /* istanbul ignore next */ []));
    /** Show the iOS "Add to Home Screen" hint. */
    needsIosHint = computed(() => this.isIosSafari() && !this.installed(), ...(ngDevMode ? [{ debugName: "needsIosHint" }] : /* istanbul ignore next */ []));
    constructor() {
        const win = this.doc.defaultView;
        if (!win)
            return; // SSR / no DOM
        this.installed.set(isStandalone(win));
        this.isIosSafari.set(isIos(win.navigator));
        const onPrompt = (e) => {
            e.preventDefault();
            this.promptEvent.set(e);
        };
        const onInstalled = () => {
            this.promptEvent.set(null);
            this.installed.set(true);
        };
        win.addEventListener('beforeinstallprompt', onPrompt);
        win.addEventListener('appinstalled', onInstalled);
        this.destroyRef.onDestroy(() => {
            win.removeEventListener('beforeinstallprompt', onPrompt);
            win.removeEventListener('appinstalled', onInstalled);
        });
        if (this.swUpdate?.isEnabled) {
            this.swUpdate.versionUpdates.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((e) => {
                if (e.type === 'VERSION_READY')
                    this.updateAvailable.set(true);
            });
        }
    }
    /** Show the native install prompt. Returns the outcome (`'unavailable'` if no prompt queued). */
    async install() {
        const evt = this.promptEvent();
        if (!evt)
            return 'unavailable';
        await evt.prompt();
        const { outcome } = await evt.userChoice;
        this.promptEvent.set(null); // a prompt event is single-use
        return outcome;
    }
    /** Activate a ready ngsw update and reload to it. */
    async applyUpdate() {
        if (!this.swUpdate?.isEnabled)
            return;
        await this.swUpdate.activateUpdate();
        this.doc.defaultView?.location.reload();
    }
    /** Apply the iOS/chrome PWA `<meta>` + splash `<link>`s to `<head>` (called at boot). */
    applyHead() {
        try {
            applyPwaTags(this.doc, pwaMetaTags(this.config), pwaSplashLinks(this.config));
        }
        catch {
            /* SSR / no DOM — skip */
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Pwa, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Pwa, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Pwa, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/** Install-button labels per language (falls back to English). */
const INSTALL_STRINGS = {
    en: {
        label: 'Install app',
        ios: 'To install: Share → Add to Home Screen',
        update: 'Update available — reload',
    },
    ru: {
        label: 'Установить приложение',
        ios: 'Чтобы установить: Поделиться → На экран «Домой»',
        update: 'Доступно обновление — обновить',
    },
    es: {
        label: 'Instalar app',
        ios: 'Para instalar: Compartir → Añadir a pantalla de inicio',
        update: 'Actualización disponible — recargar',
    },
    pt: {
        label: 'Instalar app',
        ios: 'Para instalar: Compartilhar → Adicionar à Tela de Início',
        update: 'Atualização disponível — recarregar',
    },
    ar: {
        label: 'تثبيت التطبيق',
        ios: 'للتثبيت: مشاركة ← إضافة إلى الشاشة الرئيسية',
        update: 'يتوفر تحديث — إعادة التحميل',
    },
    kk: {
        label: 'Қолданбаны орнату',
        ios: 'Орнату: «Бөлісу» → «Негізгі экранға қосу»',
        update: 'Жаңарту бар — қайта жүктеу',
    },
    zh: { label: '安装应用', ios: '安装：分享 → 添加到主屏幕', update: '有可用更新 — 重新加载' },
    hi: {
        label: 'ऐप इंस्टॉल करें',
        ios: 'इंस्टॉल करें: शेयर → होम स्क्रीन में जोड़ें',
        update: 'अपडेट उपलब्ध — पुनः लोड करें',
    },
    ur: {
        label: 'ایپ انسٹال کریں',
        ios: 'انسٹال: شیئر ← ہوم اسکرین میں شامل کریں',
        update: 'اپ ڈیٹ دستیاب — دوبارہ لوڈ کریں',
    },
};
/**
 * `<ik-install>` — install affordance for the PWA module (Angular-only).
 *   • installable (Chrome/Edge/Android): an "Install app" button → native prompt.
 *   • iOS Safari (no prompt): the manual "Add to Home Screen" hint.
 *   • already installed/standalone: renders nothing.
 * When a new service-worker version is ready it offers a reload-to-update button.
 */
class Install {
    pwa = inject(Pwa);
    /** Active language for the button label / iOS hint. */
    lang = input('en', ...(ngDevMode ? [{ debugName: "lang" }] : /* istanbul ignore next */ []));
    t = computed(() => INSTALL_STRINGS[this.lang()] ?? INSTALL_STRINGS['en'], ...(ngDevMode ? [{ debugName: "t" }] : /* istanbul ignore next */ [])); // safe: 'en' is a fixed key of INSTALL_STRINGS
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Install, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: Install, isStandalone: true, selector: "ik-install", inputs: { lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
        @if (pwa.updateAvailable()) {
            <button type="button" class="ik-install__btn ik-install__btn--update" (click)="pwa.applyUpdate()">
                {{ t().update }}
            </button>
        } @else if (pwa.canInstall()) {
            <button
                type="button"
                class="ik-install__btn"
                (click)="pwa.install()"
                [attr.aria-label]="t().label"
            >
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    aria-hidden="true"
                >
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="7 10 12 15 17 10" />
                    <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
                <span>{{ t().label }}</span>
            </button>
        } @else if (pwa.needsIosHint()) {
            <p class="ik-install__ios">{{ t().ios }}</p>
        }
    `, isInline: true, styles: [":host{display:contents}.ik-install__btn{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);padding:var(--sp-2, .5rem) var(--sp-4, 1rem);border:1px solid var(--brand, #6d28d9);border-radius:var(--r-full, 999px);background:var(--brand, #6d28d9);color:var(--text-on-brand, #fff);font:inherit;font-weight:var(--fw-semi, 600);cursor:pointer;transition:filter .15s}.ik-install__btn:hover{filter:brightness(1.08)}.ik-install__btn svg{width:1.1em;height:1.1em}.ik-install__btn--update{background:var(--accent-3, #ea580c);border-color:var(--accent-3, #ea580c)}.ik-install__ios{margin:0;font-size:var(--fs-sm, .875rem);color:var(--text-mute, #5c5c6d)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Install, decorators: [{
            type: Component,
            args: [{ selector: 'ik-install', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        @if (pwa.updateAvailable()) {
            <button type="button" class="ik-install__btn ik-install__btn--update" (click)="pwa.applyUpdate()">
                {{ t().update }}
            </button>
        } @else if (pwa.canInstall()) {
            <button
                type="button"
                class="ik-install__btn"
                (click)="pwa.install()"
                [attr.aria-label]="t().label"
            >
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    aria-hidden="true"
                >
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="7 10 12 15 17 10" />
                    <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
                <span>{{ t().label }}</span>
            </button>
        } @else if (pwa.needsIosHint()) {
            <p class="ik-install__ios">{{ t().ios }}</p>
        }
    `, styles: [":host{display:contents}.ik-install__btn{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);padding:var(--sp-2, .5rem) var(--sp-4, 1rem);border:1px solid var(--brand, #6d28d9);border-radius:var(--r-full, 999px);background:var(--brand, #6d28d9);color:var(--text-on-brand, #fff);font:inherit;font-weight:var(--fw-semi, 600);cursor:pointer;transition:filter .15s}.ik-install__btn:hover{filter:brightness(1.08)}.ik-install__btn svg{width:1.1em;height:1.1em}.ik-install__btn--update{background:var(--accent-3, #ea580c);border-color:var(--accent-3, #ea580c)}.ik-install__ios{margin:0;font-size:var(--fs-sm, .875rem);color:var(--text-mute, #5c5c6d)}\n"] }]
        }], propDecorators: { lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }] } });

/**
 * Enables the installable-app (PWA) module for a kit-driven **Angular** app:
 * registers the ngsw service worker and applies the iOS/chrome PWA `<meta>` + splash
 * `<link>`s from `config.pwa` (icons come from `config.favicon`).
 *
 * ```ts
 * // app.config.ts
 * providers: [ provideSiteKit(cfg), provideSiteKitPwa() ]
 * ```
 * Also set `"serviceWorker": "ngsw-config.json"` in angular.json (a reference config
 * ships at `@ilia-ae/site-kit/ngsw-config.json`) and generate the manifest/splash
 * assets with the kit's build tooling. Not available for the static (WP) target.
 */
function provideSiteKitPwa(opts) {
    return makeEnvironmentProviders([
        provideServiceWorker('ngsw-worker.js', {
            enabled: opts?.enabled ?? !isDevMode(),
            // Register once the app is stable so we don't compete with first render.
            registrationStrategy: opts?.registrationStrategy ?? 'registerWhenStable:30000',
        }),
        {
            provide: ENVIRONMENT_INITIALIZER,
            multi: true,
            useValue: () => {
                inject(Pwa).applyHead();
            },
        },
    ]);
}

// AUTO-GENERATED by tools/stamp-version.mjs — do not edit.
/** Build date (UTC, YYYY-MM-DD) stamped at build time. */
const SITE_KIT_BUILD_DATE = "2026-11-07";

/**
 * Pretty-print a phone number for DISPLAY only — groups the national digits per the
 * country's calling-code convention (so it reads "+971 50 000 0000", not one blob).
 * Never changes the digits; build the `tel:` href separately from the raw digits.
 *
 * Pattern = national-number group sizes after the `+<code>`. Unknown codes fall back to
 * generic groups of three (last group up to four). A JS mirror lives in static/generate.mjs.
 */
const PHONE_GROUPS = {
    '1': [3, 3, 4],
    '7': [3, 3, 2, 2],
    '20': [2, 4, 4],
    '27': [2, 3, 4],
    '30': [3, 3, 4],
    '31': [1, 2, 2, 2, 2],
    '32': [3, 2, 2, 2],
    '33': [1, 2, 2, 2, 2],
    '34': [3, 3, 3],
    '36': [2, 3, 4],
    '39': [3, 4, 4],
    '40': [3, 3, 3],
    '41': [2, 3, 2, 2],
    '43': [3, 4, 4],
    '44': [2, 4, 4],
    '45': [2, 2, 2, 2],
    '46': [2, 3, 2, 2],
    '47': [3, 2, 3],
    '48': [3, 3, 3],
    '49': [3, 4, 5],
    '51': [3, 3, 3],
    '52': [2, 4, 4],
    '54': [2, 4, 4],
    '55': [2, 5, 4],
    '56': [1, 4, 4],
    '57': [3, 3, 4],
    '58': [3, 3, 4],
    '60': [2, 4, 4],
    '61': [1, 4, 4],
    '62': [3, 4, 4],
    '63': [3, 3, 4],
    '64': [1, 3, 4],
    '65': [4, 4],
    '66': [1, 4, 4],
    '81': [2, 4, 4],
    '82': [2, 4, 4],
    '84': [2, 4, 3],
    '86': [3, 4, 4],
    '90': [3, 3, 2, 2],
    '91': [5, 5],
    '92': [3, 7],
    '93': [2, 3, 4],
    '94': [2, 3, 4],
    '95': [2, 3, 4],
    '98': [3, 3, 4],
    '212': [4, 6],
    '213': [3, 2, 2, 2],
    '234': [3, 3, 4],
    '351': [3, 3, 3],
    '352': [2, 2, 2, 2, 2],
    '353': [2, 3, 4],
    '358': [2, 3, 2, 2],
    '359': [2, 3, 3],
    '370': [3, 3, 2],
    '371': [2, 3, 3],
    '372': [3, 4],
    '373': [3, 2, 3],
    '374': [2, 6],
    '375': [2, 3, 2, 2],
    '377': [2, 2, 2, 2],
    '380': [2, 3, 2, 2],
    '381': [2, 3, 4],
    '385': [2, 3, 3],
    '386': [2, 3, 3],
    '420': [3, 3, 3],
    '421': [3, 3, 3],
    '852': [4, 4],
    '880': [4, 6],
    '886': [1, 3, 3, 3],
    '961': [1, 3, 3],
    '962': [1, 4, 4],
    '963': [2, 3, 3],
    '964': [3, 3, 4],
    '965': [4, 4],
    '966': [2, 3, 4],
    '967': [3, 3, 3],
    '968': [4, 4],
    '970': [3, 3, 3],
    '971': [2, 3, 4],
    '972': [2, 3, 4],
    '973': [4, 4],
    '974': [4, 4],
    '975': [2, 3, 3],
    '976': [2, 2, 4],
    '977': [2, 3, 5],
    '992': [2, 3, 4],
    '993': [2, 2, 2, 2],
    '994': [2, 3, 2, 2],
    '995': [3, 3, 3],
    '996': [3, 3, 3],
    '998': [2, 3, 2, 2],
};
/** Country codes, longest first (computed on first use, not at load: tools/bundle-size.mjs). */
let phoneCodes;
const PHONE_CODES = () => (phoneCodes ??= Object.keys(PHONE_GROUPS).sort((a, b) => b.length - a.length));
function groupBy(s, sizes) {
    const parts = [];
    let i = 0;
    for (const g of sizes) {
        if (i >= s.length)
            break;
        parts.push(s.slice(i, i + g));
        i += g;
    }
    if (i < s.length)
        parts.push(s.slice(i)); // leftover beyond the pattern
    return parts.filter(Boolean).join(' ');
}
/** Generic grouping: threes, with the last group up to four (never a lone trailing digit). */
function genericSizes(n) {
    const sizes = [];
    let rem = n;
    while (rem > 4) {
        sizes.push(3);
        rem -= 3;
    }
    sizes.push(rem);
    /* istanbul ignore next -- defensive: rem after the loop is always 2..4, never a lone 1 */
    if (sizes.length > 1 && sizes[sizes.length - 1] === 1) {
        sizes[sizes.length - 2] += 1; // safe: sizes.length > 1 guarded above
        sizes.pop();
    }
    return sizes;
}
/** Group a phone number for display. Returns the input unchanged for too-short / empty values. */
function formatPhone(raw) {
    const hasPlus = /^\s*\+/.test(raw);
    const digits = String(raw).replace(/\D/g, '');
    if (digits.length < 5)
        return raw;
    const code = hasPlus ? (PHONE_CODES().find((c) => digits.startsWith(c)) ?? '') : '';
    if (!code)
        return (hasPlus ? '+' : '') + groupBy(digits, genericSizes(digits.length));
    const nat = digits.slice(code.length);
    return `+${code} ${groupBy(nat, PHONE_GROUPS[code] ?? genericSizes(nat.length))}`.trim();
}

/**
 * "IA kit" — the library's brand mark. A 2×2 cluster of distinct primitives:
 *   ◣ triangle (top-left) · ▢ square (top-right) · ▢ square (bottom-left) · ● circle (bottom-right)
 * The diagonal triangle↔circle gives it identity; the two squares read as "modular blocks".
 * Trusted library constant (rendered via innerHTML); `currentColor` so it adapts to its mark.
 */
// Pure-math 2×2 grid in a 24 box: shapes inset to [3,10] & [14,21] (cluster centre 12 =
// viewBox centre); the 1px outline grows the footprint back out to ~[2.25,21.75]. Outline-only.
const SITE_KIT_GLYPH = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" stroke-linecap="round" xmlns="http://www.w3.org/2000/svg"><path d="M6.5 3 10 10 3 10Z"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><circle cx="17.5" cy="17.5" r="3.5"/></svg>`;
/** The library's signature accent — warm sand (the IA kit brand colour); tints the badge hover. */
const SITE_KIT_ACCENT = '#ad7729';
/** Display name of the library's signature badge. */
const SITE_KIT_NAME = 'IA kit';

var en = {
	scan: "Scan to connect",
	shareTitle: "Share this site",
	linksTitle: "Quick links",
	share: "Share",
	copy: "Copy",
	copied: "Copied",
	email: "Email",
	website: "Website",
	contactForm: "Contact form"
};
var ru = {
	scan: "Сканируйте, чтобы связаться",
	shareTitle: "Поделиться сайтом",
	linksTitle: "Быстрые ссылки",
	share: "Поделиться",
	copy: "Скопировать",
	copied: "Скопировано",
	email: "Email",
	website: "Сайт",
	contactForm: "Форма связи"
};
var es = {
	scan: "Escanea para conectar",
	shareTitle: "Comparte este sitio",
	linksTitle: "Enlaces rápidos",
	share: "Compartir",
	copy: "Copiar",
	copied: "Copiado",
	email: "Correo",
	website: "Sitio web",
	contactForm: "Formulario de contacto"
};
var pt = {
	scan: "Escaneie para conectar",
	shareTitle: "Compartilhe este site",
	linksTitle: "Links rápidos",
	share: "Compartilhar",
	copy: "Copiar",
	copied: "Copiado",
	email: "E-mail",
	website: "Site",
	contactForm: "Formulário de contato"
};
var ar = {
	scan: "امسح للتواصل",
	shareTitle: "شارك هذا الموقع",
	linksTitle: "روابط سريعة",
	share: "مشاركة",
	copy: "نسخ",
	copied: "تم النسخ",
	email: "البريد",
	website: "الموقع",
	contactForm: "نموذج الاتصال"
};
var kk = {
	scan: "Байланысу үшін сканерлеңіз",
	shareTitle: "Сайтпен бөлісу",
	linksTitle: "Жылдам сілтемелер",
	share: "Бөлісу",
	copy: "Көшіру",
	copied: "Көшірілді",
	email: "Email",
	website: "Сайт",
	contactForm: "Байланыс формасы"
};
var zh = {
	scan: "扫码联系",
	shareTitle: "分享此网站",
	linksTitle: "快速链接",
	share: "分享",
	copy: "复制",
	copied: "已复制",
	email: "邮箱",
	website: "网站",
	contactForm: "联系表单"
};
var hi = {
	scan: "जुड़ने के लिए स्कैन करें",
	shareTitle: "इस साइट को साझा करें",
	linksTitle: "त्वरित लिंक",
	share: "साझा करें",
	copy: "कॉपी करें",
	copied: "कॉपी हो गया",
	email: "ईमेल",
	website: "वेबसाइट",
	contactForm: "संपर्क फ़ॉर्म"
};
var ur = {
	scan: "رابطے کے لیے اسکین کریں",
	shareTitle: "اس سائٹ کو شیئر کریں",
	linksTitle: "فوری لنکس",
	share: "شیئر",
	copy: "کاپی",
	copied: "کاپی ہو گیا",
	email: "ای میل",
	website: "ویب سائٹ",
	contactForm: "رابطہ فارم"
};
var QR_STRINGS = {
	en: en,
	ru: ru,
	es: es,
	pt: pt,
	ar: ar,
	kk: kk,
	zh: zh,
	hi: hi,
	ur: ur
};

/**
 * Built-in UI strings for the toolkit's own chrome (not page content) — so
 * blocks are multilingual out of the box across the Integra language set.
 * Apps can override any string via `config.strings` (deep-merged per language).
 * `redirect` is a template: the `{n}` placeholder is replaced with the live countdown.
 */
// Shared QR / contact labels — single JSON source of truth mirrored by static/generate.mjs.
/** Languages the kit's OWN chrome is fully maintained in (LATAM go-to-market set). */
const IK_CHROME_LANGS = ['en', 'ru', 'es', 'pt'];
// The strings live in groups, each its own top-level object, and every component looks up only its
// group (chromeString / cookieString / qrString), so a bundler keeps only what an app renders: a
// 404 page doesn't carry the cookie policy in nine languages (tools/bundle-size.mjs). The languages
// a lookup never reaches (ikString resolves anything outside IK_CHROME_LANGS to English) sit in the
// *_MORE tables, read only by the public IK_STRINGS.
const CHROME = {
    en: {
        home: 'Home',
        back: 'Back',
        redirect: 'Redirecting to home in {n}s',
        menu: 'Menu',
        language: 'Language',
        tags: 'Tags',
        close: 'Close',
    },
    ru: {
        home: 'На главную',
        back: 'Назад',
        redirect: 'Вы будете перенаправлены на главную через {n} с',
        menu: 'Меню',
        language: 'Язык',
        tags: 'Теги',
        close: 'Закрыть',
    },
    es: {
        home: 'Inicio',
        back: 'Atrás',
        redirect: 'Redirigiendo al inicio en {n} s',
        menu: 'Menú',
        language: 'Idioma',
        tags: 'Etiquetas',
        close: 'Cerrar',
    },
    pt: {
        home: 'Início',
        back: 'Voltar',
        redirect: 'Redirecionando para o início em {n} s',
        menu: 'Menu',
        language: 'Idioma',
        tags: 'Tags',
        close: 'Fechar',
    },
};
const CHROME_MORE = {
    ar: {
        home: 'الرئيسية',
        back: 'رجوع',
        redirect: 'ستتم إعادة توجيهك إلى الرئيسية خلال {n} ثانية',
        menu: 'القائمة',
        language: 'اللغة',
        tags: 'الوسوم',
        close: 'إغلاق',
    },
    kk: {
        home: 'Басты бет',
        back: 'Артқа',
        redirect: '{n} секундтан кейін басты бетке бағытталасыз',
        menu: 'Мәзір',
        language: 'Тіл',
        tags: 'Тегтер',
        close: 'Жабу',
    },
    zh: {
        home: '首页',
        back: '返回',
        redirect: '{n} 秒后将跳转到首页',
        menu: '菜单',
        language: '语言',
        tags: '标签',
        close: '关闭',
    },
    hi: {
        home: 'होम',
        back: 'वापस',
        redirect: '{n} सेकंड में होम पर भेजा जा रहा है',
        menu: 'मेन्यू',
        language: 'भाषा',
        tags: 'टैग',
        close: 'बंद करें',
    },
    ur: {
        home: 'ہوم',
        back: 'واپس',
        redirect: '{n} سیکنڈ میں ہوم پر بھیجا جا رہا ہے',
        menu: 'مینو',
        language: 'زبان',
        tags: 'ٹیگز',
        close: 'بند کریں',
    },
};
const COOKIE = {
    en: {
        cookieText: 'We use cookies to keep the site working and to understand how it’s used.',
        cookieAccept: 'Accept all',
        cookieReject: 'Reject all',
        cookieMore: 'Learn more',
        cookieLabel: 'Cookie consent',
        cookiePolicyTitle: 'About cookies on this site',
        cookieFullPolicy: 'Read the full policy',
        cookiePolicyBody: 'Cookies are small text files a site stores in your browser. This site uses the minimum needed, never shares them with advertisers and never sells your data.\n\nEssential cookies are always on. They remember your language, theme and consent choice and keep the site secure — the site can’t work without them, so they can’t be disabled.\n\nAnalytics cookies are optional and load only after you press “Accept all”. They measure anonymous, aggregate usage (which pages are opened, how the site performs) so we can improve it. “Reject all” and the × keep only the essential cookies.\n\nYou can change your decision at any time by reopening the cookie settings. Your choice is stored locally in your browser for up to 12 months; clearing your browser data resets it and the banner asks again.\n\nWe process this data to run and improve the site based on your consent (essential cookies rely on legitimate interest). For any questions about your data, contact the site owner listed in the footer.',
    },
    ru: {
        cookieText: 'Мы используем cookie, чтобы сайт работал и чтобы понимать, как им пользуются.',
        cookieAccept: 'Принять все',
        cookieReject: 'Отклонить все',
        cookieMore: 'Подробнее',
        cookieLabel: 'Согласие на cookie',
        cookiePolicyTitle: 'Использование cookie',
        cookieFullPolicy: 'Полная политика',
        cookiePolicyBody: 'Cookie — это небольшие текстовые файлы, которые сайт сохраняет в вашем браузере. Мы используем необходимый минимум, никогда не передаём их рекламодателям и не продаём ваши данные.\n\nНеобходимые cookie включены всегда. Они запоминают язык, тему и ваш выбор согласия и обеспечивают безопасность — без них сайт не работает, поэтому отключить их нельзя.\n\nАналитические cookie необязательны и загружаются только после нажатия «Принять все». Они измеряют анонимную обобщённую статистику (какие страницы открывают, как работает сайт), чтобы мы могли его улучшать. «Отклонить все» и крестик × оставляют только необходимые.\n\nИзменить решение можно в любой момент, снова открыв настройки cookie. Ваш выбор хранится локально в браузере до 12 месяцев; очистка данных браузера сбрасывает его, и баннер появится снова.\n\nМы обрабатываем эти данные, чтобы сайт работал и улучшался, на основании вашего согласия (необходимые cookie — на основании законного интереса). По вопросам о ваших данных свяжитесь с владельцем сайта, указанным в футере.',
    },
    es: {
        cookieText: 'Usamos cookies para que el sitio funcione y para entender cómo se usa.',
        cookieAccept: 'Aceptar todas',
        cookieReject: 'Rechazar todas',
        cookieMore: 'Más información',
        cookieLabel: 'Consentimiento de cookies',
        cookiePolicyTitle: 'Sobre las cookies en este sitio',
        cookieFullPolicy: 'Leer la política completa',
        cookiePolicyBody: 'Las cookies son pequeños archivos de texto que un sitio guarda en tu navegador. Este sitio usa el mínimo necesario, nunca las comparte con anunciantes y nunca vende tus datos.\n\nLas cookies esenciales están siempre activas. Recuerdan tu idioma, tema y decisión de consentimiento y mantienen el sitio seguro: el sitio no puede funcionar sin ellas, por eso no se pueden desactivar.\n\nLas cookies de analítica son opcionales y solo se cargan después de pulsar «Aceptar todas». Miden el uso de forma anónima y agregada (qué páginas se abren, cómo funciona el sitio) para poder mejorarlo. «Rechazar todas» y la × conservan solo las esenciales.\n\nPuedes cambiar tu decisión en cualquier momento reabriendo la configuración de cookies. Tu elección se guarda localmente en tu navegador hasta 12 meses; borrar los datos del navegador la restablece y el aviso vuelve a preguntar.\n\nTratamos estos datos para operar y mejorar el sitio según tu consentimiento (las cookies esenciales se basan en el interés legítimo). Para cualquier pregunta sobre tus datos, contacta con el propietario del sitio indicado en el pie de página.',
    },
    pt: {
        cookieText: 'Usamos cookies para o site funcionar e para entender como ele é usado.',
        cookieAccept: 'Aceitar todos',
        cookieReject: 'Recusar todos',
        cookieMore: 'Saiba mais',
        cookieLabel: 'Consentimento de cookies',
        cookiePolicyTitle: 'Sobre os cookies neste site',
        cookieFullPolicy: 'Ler a política completa',
        cookiePolicyBody: 'Cookies são pequenos arquivos de texto que um site guarda no seu navegador. Este site usa o mínimo necessário, nunca os compartilha com anunciantes e nunca vende seus dados.\n\nOs cookies essenciais ficam sempre ativos. Eles lembram seu idioma, tema e escolha de consentimento e mantêm o site seguro — o site não funciona sem eles, por isso não podem ser desativados.\n\nOs cookies de análise são opcionais e só carregam depois que você clica em «Aceitar todos». Eles medem o uso de forma anônima e agregada (quais páginas são abertas, como o site se comporta) para que possamos melhorá-lo. «Recusar todos» e o × mantêm apenas os essenciais.\n\nVocê pode mudar sua decisão a qualquer momento reabrindo as configurações de cookies. Sua escolha fica salva localmente no navegador por até 12 meses; limpar os dados do navegador a redefine e o aviso pergunta novamente.\n\nTratamos esses dados para operar e melhorar o site com base no seu consentimento (os cookies essenciais se baseiam no legítimo interesse). Para qualquer dúvida sobre seus dados, entre em contato com o proprietário do site indicado no rodapé.',
    },
};
const COOKIE_MORE = {
    ar: {
        cookieText: 'نستخدم ملفات تعريف الارتباط لتشغيل الموقع وفهم كيفية استخدامه.',
        cookieAccept: 'قبول الكل',
        cookieReject: 'رفض الكل',
        cookieMore: 'اعرف المزيد',
        cookieLabel: 'موافقة ملفات تعريف الارتباط',
        cookiePolicyTitle: 'حول ملفات تعريف الارتباط في هذا الموقع',
        cookieFullPolicy: 'اقرأ السياسة الكاملة',
        cookiePolicyBody: 'ملفات تعريف الارتباط هي ملفات نصية صغيرة يخزّنها الموقع في متصفحك. نستخدم الحد الأدنى اللازم ولا نشاركها مع المعلنين ولا نبيع بياناتك.\n\nملفات تعريف الارتباط الضرورية مفعّلة دائمًا. تحفظ لغتك ومظهرك واختيار موافقتك وتحافظ على أمان الموقع — لا يعمل الموقع بدونها، لذلك لا يمكن تعطيلها.\n\nملفات تحليلات الاستخدام اختيارية ولا تُحمَّل إلا بعد الضغط على «قبول الكل». تقيس استخدامًا مجهّلاً ومجمّعًا (الصفحات التي تُفتح وأداء الموقع) حتى نتمكن من تحسينه. «رفض الكل» والزر × يُبقيان الضرورية فقط.\n\nيمكنك تغيير قرارك في أي وقت بإعادة فتح إعدادات ملفات تعريف الارتباط. يُحفظ اختيارك محليًا في متصفحك حتى 12 شهرًا؛ ومسح بيانات المتصفح يعيد ضبطه فيظهر الإشعار من جديد.\n\nنعالج هذه البيانات لتشغيل الموقع وتحسينه بناءً على موافقتك (الضرورية بموجب المصلحة المشروعة). لأي أسئلة حول بياناتك، تواصل مع مالك الموقع المذكور في التذييل.',
    },
    kk: {
        cookieText: 'Сайт жұмыс істеуі және оны қалай қолданатынын түсіну үшін cookie пайдаланамыз.',
        cookieAccept: 'Барлығын қабылдау',
        cookieReject: 'Барлығын қабылдамау',
        cookieMore: 'Толығырақ',
        cookieLabel: 'Cookie келісімі',
        cookiePolicyTitle: 'Осы сайттағы cookie туралы',
        cookieFullPolicy: 'Толық саясатты оқу',
        cookiePolicyBody: 'Cookie — сайт браузеріңізде сақтайтын шағын мәтіндік файлдар. Біз қажетті ең азын ғана пайдаланамыз, оларды жарнама берушілерге бермейміз және деректеріңізді сатпаймыз.\n\nҚажетті cookie әрқашан қосулы. Олар тіліңізді, тақырыпты және келісіміңізді есте сақтайды әрі қауіпсіздікті қамтамасыз етеді — онсыз сайт жұмыс істемейді, сондықтан оларды өшіруге болмайды.\n\nАналитикалық cookie міндетті емес және тек «Барлығын қабылдау» басылғаннан кейін жүктеледі. Олар сайтты жақсарту үшін анонимді жиынтық пайдалануды (қандай беттер ашылады, сайт қалай жұмыс істейді) өлшейді. «Барлығын қабылдамау» және × батырмасы тек қажеттілерін қалдырады.\n\nШешімді кез келген уақытта cookie параметрлерін қайта ашып өзгертуге болады. Таңдауыңыз браузерде 12 айға дейін сақталады; браузер деректерін тазалау оны қайта орнатады және баннер қайта сұрайды.\n\nБұл деректерді сайтты жұмыс істету және жақсарту үшін келісіміңіз негізінде өңдейміз (қажетті cookie — заңды мүдде негізінде). Деректеріңіз туралы сұрақтар бойынша төменгі деректемеде көрсетілген сайт иесіне хабарласыңыз.',
    },
    zh: {
        cookieText: '我们使用 Cookie 以保证网站运行并了解其使用情况。',
        cookieAccept: '全部接受',
        cookieReject: '全部拒绝',
        cookieMore: '了解更多',
        cookieLabel: 'Cookie 同意',
        cookiePolicyTitle: '关于本网站的 Cookie',
        cookieFullPolicy: '阅读完整政策',
        cookiePolicyBody: 'Cookie 是网站存储在您浏览器中的小型文本文件。本网站仅使用必要的最少量，绝不与广告商共享，也不出售您的数据。\n\n必要 Cookie 始终开启。它们记住您的语言、主题和同意选择并保障网站安全——没有它们网站无法运行，因此无法关闭。\n\n分析 Cookie 为可选项，仅在您点击“全部接受”后加载。它们测量匿名的汇总使用情况（打开了哪些页面、网站性能如何）以便我们改进。“全部拒绝”和 × 按钮仅保留必要 Cookie。\n\n您可以随时重新打开 Cookie 设置更改决定。您的选择在浏览器本地保存至多 12 个月；清除浏览器数据会将其重置，横幅将再次询问。\n\n我们基于您的同意处理这些数据以运行和改进网站（必要 Cookie 基于合法利益）。如对您的数据有疑问，请联系页脚中列出的网站所有者。',
    },
    hi: {
        cookieText: 'हम साइट को चलाने और उसके उपयोग को समझने के लिए कुकीज़ का उपयोग करते हैं।',
        cookieAccept: 'सभी स्वीकारें',
        cookieReject: 'सभी अस्वीकारें',
        cookieMore: 'और जानें',
        cookieLabel: 'कुकी सहमति',
        cookiePolicyTitle: 'इस साइट पर कुकीज़ के बारे में',
        cookieFullPolicy: 'पूरी नीति पढ़ें',
        cookiePolicyBody: 'कुकीज़ छोटी टेक्स्ट फ़ाइलें हैं जिन्हें साइट आपके ब्राउज़र में सहेजती है। यह साइट ज़रूरी न्यूनतम का ही उपयोग करती है, इन्हें कभी विज्ञापनदाताओं के साथ साझा नहीं करती और न ही आपका डेटा बेचती है।\n\nआवश्यक कुकीज़ हमेशा चालू रहती हैं। ये आपकी भाषा, थीम और सहमति का विकल्प याद रखती हैं और साइट को सुरक्षित रखती हैं — इनके बिना साइट काम नहीं करती, इसलिए इन्हें बंद नहीं किया जा सकता।\n\nएनालिटिक्स कुकीज़ वैकल्पिक हैं और केवल “सभी स्वीकारें” दबाने के बाद लोड होती हैं। ये गुमनाम, समग्र उपयोग मापती हैं (कौन-से पेज खुलते हैं, साइट कैसा प्रदर्शन करती है) ताकि हम इसे बेहतर बना सकें। “सभी अस्वीकारें” और × बटन केवल आवश्यक कुकीज़ रखते हैं।\n\nआप कभी भी कुकी सेटिंग्स फिर से खोलकर अपना निर्णय बदल सकते हैं। आपका विकल्प ब्राउज़र में 12 महीनों तक स्थानीय रूप से सहेजा जाता है; ब्राउज़र डेटा साफ़ करने पर यह रीसेट हो जाता है और बैनर फिर पूछता है।\n\nहम इस डेटा को आपकी सहमति के आधार पर साइट चलाने और सुधारने के लिए संसाधित करते हैं (आवश्यक कुकीज़ वैध हित के आधार पर)। अपने डेटा से जुड़े सवालों के लिए, फ़ुटर में दिए गए साइट स्वामी से संपर्क करें।',
    },
    ur: {
        cookieText: 'ہم سائٹ کو چلانے اور اس کے استعمال کو سمجھنے کے لیے کوکیز استعمال کرتے ہیں۔',
        cookieAccept: 'سب قبول کریں',
        cookieReject: 'سب مسترد کریں',
        cookieMore: 'مزید جانیں',
        cookieLabel: 'کوکی رضامندی',
        cookiePolicyTitle: 'اس سائٹ پر کوکیز کے بارے میں',
        cookieFullPolicy: 'مکمل پالیسی پڑھیں',
        cookiePolicyBody: 'کوکیز چھوٹی ٹیکسٹ فائلیں ہیں جو سائٹ آپ کے براؤزر میں محفوظ کرتی ہے۔ یہ سائٹ صرف ضروری کم سے کم استعمال کرتی ہے، انہیں کبھی مشتہرین کے ساتھ شیئر نہیں کرتی اور نہ آپ کا ڈیٹا بیچتی ہے۔\n\nضروری کوکیز ہمیشہ آن رہتی ہیں۔ یہ آپ کی زبان، تھیم اور رضامندی کا انتخاب یاد رکھتی ہیں اور سائٹ کو محفوظ رکھتی ہیں — ان کے بغیر سائٹ کام نہیں کرتی، اس لیے انہیں بند نہیں کیا جا سکتا۔\n\nاینالیٹکس کوکیز اختیاری ہیں اور صرف «سب قبول کریں» دبانے کے بعد لوڈ ہوتی ہیں۔ یہ گمنام، مجموعی استعمال ناپتی ہیں (کون سے صفحات کھلتے ہیں، سائٹ کی کارکردگی کیسی ہے) تاکہ ہم اسے بہتر بنا سکیں۔ «سب مسترد کریں» اور × بٹن صرف ضروری کوکیز رکھتے ہیں۔\n\nآپ کسی بھی وقت کوکی سیٹنگز دوبارہ کھول کر اپنا فیصلہ بدل سکتے ہیں۔ آپ کا انتخاب براؤزر میں 12 ماہ تک مقامی طور پر محفوظ رہتا ہے؛ براؤزر ڈیٹا صاف کرنے پر یہ ری سیٹ ہو جاتا ہے اور بینر دوبارہ پوچھتا ہے۔\n\nہم یہ ڈیٹا آپ کی رضامندی کی بنیاد پر سائٹ چلانے اور بہتر بنانے کے لیے پراسیس کرتے ہیں (ضروری کوکیز جائز مفاد کی بنیاد پر)۔ اپنے ڈیٹا کے بارے میں سوالات کے لیے، فوٹر میں درج سائٹ مالک سے رابطہ کریں۔',
    },
};
/** The shared QR strings of a language (qr-strings.json); English when it has none. */
// safe: qr-strings.json always carries `en`.
const qr = (lang) => QR_STRINGS[lang] ?? QR_STRINGS.en;
/**
 * Every built-in string, per language (en, ru, es, pt, ar, kk, zh, hi, ur). Built inside a pure
 * IIFE, so it costs nothing unless an app imports it.
 */
const IK_STRINGS = /* @__PURE__ */ (() => {
    const all = {};
    for (const l of ['en', 'ru', 'es', 'pt', 'ar', 'kk', 'zh', 'hi', 'ur']) {
        // safe: every language listed here has a row in CHROME or CHROME_MORE and in COOKIE or COOKIE_MORE
        all[l] = { ...(CHROME[l] ?? CHROME_MORE[l]), ...qr(l), ...(COOKIE[l] ?? COOKIE_MORE[l]) };
    }
    return all;
})();
/** The chrome language a lookup resolves to: one of IK_CHROME_LANGS, else English. */
const chromeLang = (lang) => lang && IK_CHROME_LANGS.includes(lang) ? lang : 'en';
/** A shared chrome string (status page, nav, footer, switchers). */
function chromeString(lang, key, overrides) {
    const l = chromeLang(lang);
    // safe: `l` is one of IK_CHROME_LANGS, all rows of CHROME
    return overrides?.[l]?.[key] ?? CHROME[l][key];
}
/** A cookie banner / policy string. */
function cookieString(lang, key, overrides) {
    const l = chromeLang(lang);
    // safe: `l` is one of IK_CHROME_LANGS, all rows of COOKIE
    return overrides?.[l]?.[key] ?? COOKIE[l][key];
}
/** A QR card / share string. */
function qrString(lang, key, overrides) {
    const l = chromeLang(lang);
    return overrides?.[l]?.[key] ?? qr(l)[key];
}
const isChrome = (k) => k === 'home' ||
    k === 'back' ||
    k === 'redirect' ||
    k === 'menu' ||
    k === 'language' ||
    k === 'tags' ||
    k === 'close';
/**
 * Resolve a built-in UI (chrome) string. The kit's OWN chrome is maintained in four
 * languages — English, Russian, Spanish and Portuguese; every other language resolves to
 * English. (Per-MODULE content — status copy, config-provided localized fields — stays
 * multilingual via `localizeText`/catalogs; this only governs the shared kit labels.)
 * Apps may still override any chrome string via `config.strings`.
 *
 * Inside the kit, components call the group lookup instead (chromeString / cookieString /
 * qrString), which keeps the other groups out of an app's bundle; this one reaches them all.
 */
function ikString(lang, key, overrides) {
    if (isChrome(key))
        return chromeString(lang, key, overrides);
    if (key.startsWith('cookie'))
        return cookieString(lang, key, overrides);
    return qrString(lang, key, overrides);
}

/**
 * Shared "draining countdown" fill — ONE definition for every timed control in the kit
 * (cookie auto-close on the reject button, status auto-redirect on the home button, …).
 * A full-bleed overlay that shrinks `scaleX(1 → 0)` over `durationMs`; drop it inside a
 * `position: relative; overflow: hidden` button and keep the label above it (`z-index: 1`).
 * Colour comes from `--ik-countdown-fill` (defaults to a tint of the button's text colour).
 *
 * ```html
 * <button style="position:relative; overflow:hidden; --ik-countdown-fill: …">
 *   @if (active()) { <ik-countdown [durationMs]="ms" [loop]="preview()" /> }
 *   <span style="position:relative; z-index:1">Label</span>
 * </button>
 * ```
 */
class IkCountdown {
    /** Total drain time in milliseconds. */
    durationMs = input.required(...(ngDevMode ? [{ debugName: "durationMs" }] : /* istanbul ignore next */ []));
    /** Loop forever (e.g. a demo/preview) instead of draining once. */
    loop = input(false, ...(ngDevMode ? [{ debugName: "loop" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: IkCountdown, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.15", type: IkCountdown, isStandalone: true, selector: "ik-countdown", inputs: { durationMs: { classPropertyName: "durationMs", publicName: "durationMs", isSignal: true, isRequired: true, transformFunction: null }, loop: { classPropertyName: "loop", publicName: "loop", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "aria-hidden": "true" }, properties: { "style.animation-duration.ms": "durationMs()", "style.animation-iteration-count": "loop() ? 'infinite' : '1'" }, classAttribute: "ik-countdown" }, ngImport: i0, template: '', isInline: true, styles: [":host{position:absolute;inset:0;z-index:0;pointer-events:none;background:var(--ik-countdown-fill, color-mix(in srgb, currentColor 24%, transparent));transform-origin:left center;animation:ik-countdown-drain linear forwards}@keyframes ik-countdown-drain{0%{transform:scaleX(1)}to{transform:scaleX(0)}}@media(prefers-reduced-motion:reduce){:host{display:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: IkCountdown, decorators: [{
            type: Component,
            args: [{ selector: 'ik-countdown', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: '', host: {
                        class: 'ik-countdown',
                        'aria-hidden': 'true',
                        '[style.animation-duration.ms]': 'durationMs()',
                        '[style.animation-iteration-count]': "loop() ? 'infinite' : '1'",
                    }, styles: [":host{position:absolute;inset:0;z-index:0;pointer-events:none;background:var(--ik-countdown-fill, color-mix(in srgb, currentColor 24%, transparent));transform-origin:left center;animation:ik-countdown-drain linear forwards}@keyframes ik-countdown-drain{0%{transform:scaleX(1)}to{transform:scaleX(0)}}@media(prefers-reduced-motion:reduce){:host{display:none}}\n"] }]
        }], propDecorators: { durationMs: [{ type: i0.Input, args: [{ isSignal: true, alias: "durationMs", required: true }] }], loop: [{ type: i0.Input, args: [{ isSignal: true, alias: "loop", required: false }] }] } });

/**
 * Decorative animated "techno" background — floating brand glows, a faint grid
 * masked toward the centre, and a subtle noise layer. Mirrors the look of the
 * apps' QR page background. Purely cosmetic (`aria-hidden`), token-driven, and
 * it honours `prefers-reduced-motion`.
 *
 * Drop it as the first child of a positioned container:
 * ```html
 * <div style="position:relative">
 *   <ik-techno-bg />
 *   …content…
 * </div>
 * ```
 */
class TechnoBg {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: TechnoBg, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.15", type: TechnoBg, isStandalone: true, selector: "ik-techno-bg", host: { attributes: { "aria-hidden": "true" }, classAttribute: "ik-techno-bg" }, ngImport: i0, template: `
        <div class="glow glow--1"></div>
        <div class="glow glow--2"></div>
        <div class="glow glow--3"></div>
        <div class="grid"></div>
        <div class="noise"></div>
    `, isInline: true, styles: [":host{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:0}.glow{position:absolute;width:45vmax;height:45vmax;border-radius:50%;filter:blur(90px);opacity:.5;will-change:transform}.glow--1{top:-10%;left:-5%;background:radial-gradient(circle,var(--brand, #6d28d9),transparent 70%);animation:ik-float 20s var(--ease-in-out, ease-in-out) infinite}.glow--2{bottom:-15%;right:-10%;background:radial-gradient(circle,var(--accent-2, #db2777),transparent 70%);animation:ik-float 24s var(--ease-in-out, ease-in-out) infinite reverse}.glow--3{top:30%;right:20%;width:30vmax;height:30vmax;background:radial-gradient(circle,var(--accent-3, #ea580c),transparent 70%);opacity:.35;animation:ik-float 18s var(--ease-in-out, ease-in-out) infinite}.grid{position:absolute;inset:0;background-image:linear-gradient(to right,var(--border, #e5e5e9) 1px,transparent 1px),linear-gradient(to bottom,var(--border, #e5e5e9) 1px,transparent 1px);background-size:48px 48px;opacity:.4;-webkit-mask-image:radial-gradient(ellipse 70% 60% at 50% 40%,#000 20%,transparent 75%);mask-image:radial-gradient(ellipse 70% 60% at 50% 40%,#000 20%,transparent 75%)}.noise{position:absolute;inset:0;opacity:.025;background-image:url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>\")}@keyframes ik-float{0%,to{transform:translate(0) scale(1)}33%{transform:translate(6%,8%) scale(1.08)}66%{transform:translate(-5%,4%) scale(.95)}}@media(prefers-reduced-motion:reduce){.glow{animation:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: TechnoBg, decorators: [{
            type: Component,
            args: [{ selector: 'ik-techno-bg', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <div class="glow glow--1"></div>
        <div class="glow glow--2"></div>
        <div class="glow glow--3"></div>
        <div class="grid"></div>
        <div class="noise"></div>
    `, host: { class: 'ik-techno-bg', 'aria-hidden': 'true' }, styles: [":host{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:0}.glow{position:absolute;width:45vmax;height:45vmax;border-radius:50%;filter:blur(90px);opacity:.5;will-change:transform}.glow--1{top:-10%;left:-5%;background:radial-gradient(circle,var(--brand, #6d28d9),transparent 70%);animation:ik-float 20s var(--ease-in-out, ease-in-out) infinite}.glow--2{bottom:-15%;right:-10%;background:radial-gradient(circle,var(--accent-2, #db2777),transparent 70%);animation:ik-float 24s var(--ease-in-out, ease-in-out) infinite reverse}.glow--3{top:30%;right:20%;width:30vmax;height:30vmax;background:radial-gradient(circle,var(--accent-3, #ea580c),transparent 70%);opacity:.35;animation:ik-float 18s var(--ease-in-out, ease-in-out) infinite}.grid{position:absolute;inset:0;background-image:linear-gradient(to right,var(--border, #e5e5e9) 1px,transparent 1px),linear-gradient(to bottom,var(--border, #e5e5e9) 1px,transparent 1px);background-size:48px 48px;opacity:.4;-webkit-mask-image:radial-gradient(ellipse 70% 60% at 50% 40%,#000 20%,transparent 75%);mask-image:radial-gradient(ellipse 70% 60% at 50% 40%,#000 20%,transparent 75%)}.noise{position:absolute;inset:0;opacity:.025;background-image:url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>\")}@keyframes ik-float{0%,to{transform:translate(0) scale(1)}33%{transform:translate(6%,8%) scale(1.08)}66%{transform:translate(-5%,4%) scale(.95)}}@media(prefers-reduced-motion:reduce){.glow{animation:none}}\n"] }]
        }] });

/** Title + message of each status in "en". */
const STATUS_COPY = {
    "400": {
        "title": "Bad request",
        "message": "The server couldn't process this request — check the address and try again."
    },
    "401": {
        "title": "Authorization required",
        "message": "You need to sign in to view this page."
    },
    "403": {
        "title": "Access denied",
        "message": "You don't have permission to view this page."
    },
    "404": {
        "title": "Page not found",
        "message": "The link may be outdated or the address was mistyped."
    },
    "405": {
        "title": "Method not allowed",
        "message": "This kind of request isn't available here."
    },
    "408": {
        "title": "Request timeout",
        "message": "The request took too long. Please try again."
    },
    "410": {
        "title": "Gone",
        "message": "This content is no longer available."
    },
    "429": {
        "title": "Too many requests",
        "message": "You're sending requests too often. Please wait a moment."
    },
    "500": {
        "title": "Internal server error",
        "message": "Something went wrong on our side. We're already looking into it."
    },
    "502": {
        "title": "Bad gateway",
        "message": "The service is temporarily unavailable. Try again in a minute."
    },
    "503": {
        "title": "Service unavailable",
        "message": "Maintenance in progress. We'll be back shortly."
    },
    "504": {
        "title": "Gateway timeout",
        "message": "The server took too long to respond. Try refreshing."
    },
    "maintenance": {
        "title": "Under maintenance",
        "message": "We're briefly offline for an update. Check back soon."
    },
    "offline": {
        "title": "You're offline",
        "message": "Looks like the connection dropped. Check your network and refresh."
    }
};

// GENERATED by tools/gen-status-copy.mjs from status-catalog.json — do not edit.
/** The big decorative glyph of each status (the code, or an emoji for a pseudo-state). */
const STATUS_GLYPHS = {
    "400": "400",
    "401": "401",
    "403": "403",
    "404": "404",
    "405": "405",
    "408": "408",
    "410": "410",
    "429": "429",
    "500": "500",
    "502": "502",
    "503": "503",
    "504": "504",
    "maintenance": "🛠",
    "offline": "⚡"
};

/** Every catalog language but English (imported with the page), each as a chunk of its own. */
const STATUS_COPY_LOADERS = {
    ru: () => import('./ilia-ae-site-kit-ru.generated-pCP6pXoC.mjs').then((m) => m.STATUS_COPY),
    ar: () => import('./ilia-ae-site-kit-ar.generated-BDParcmD.mjs').then((m) => m.STATUS_COPY),
    kk: () => import('./ilia-ae-site-kit-kk.generated-CAgwh7gY.mjs').then((m) => m.STATUS_COPY),
    zh: () => import('./ilia-ae-site-kit-zh.generated-K5ZuSKZJ.mjs').then((m) => m.STATUS_COPY),
    hi: () => import('./ilia-ae-site-kit-hi.generated-CP5LX4hw.mjs').then((m) => m.STATUS_COPY),
    ur: () => import('./ilia-ae-site-kit-ur.generated-CqOApv-z.mjs').then((m) => m.STATUS_COPY),
};

/**
 * Status copy for <ik-status-page>, a language at a time (tools/gen-status-copy.mjs): English comes
 * with the page, every other catalog language is a chunk of its own, fetched when a page shows it.
 * The full catalog (status-codes.ts: STATUS_ENTRIES, statusEntry, statusCopy) stays for the apps
 * and tools that want all of it; the page itself no longer carries it.
 */
const loaded$1 = { en: STATUS_COPY };
const pending$1 = {};
/** The copy every lookup ends at: the catalog's generic error. */
const GENERIC_STATUS_COPY = { title: 'Error', message: 'An unexpected error occurred.' };
/** Whether the catalog has copy in this language at all. */
function hasStatusCopy(lang) {
    return Object.hasOwn(loaded$1, lang) || Object.hasOwn(STATUS_COPY_LOADERS, lang);
}
/** A language's copy once it has loaded (English always has); undefined before, or with none. */
function statusCopyIfLoaded(lang) {
    return Object.hasOwn(loaded$1, lang) ? loaded$1[lang] : undefined;
}
/** Loads a language's copy (once); resolves to undefined for a language the catalog lacks. */
function loadStatusCopy(lang) {
    const have = statusCopyIfLoaded(lang);
    if (have)
        return Promise.resolve(have);
    const load = Object.hasOwn(STATUS_COPY_LOADERS, lang) ? STATUS_COPY_LOADERS[lang] : undefined;
    if (!load)
        return Promise.resolve(undefined);
    return (pending$1[lang] ??= load().then((c) => (loaded$1[lang] = c)));
}
/** The big glyph of a status: the code, or an emoji for a pseudo-state. */
function statusGlyph(code) {
    const k = String(code);
    return (Object.hasOwn(STATUS_GLYPHS, k) && STATUS_GLYPHS[k]) || k;
}

/**
 * Resolved, deduped language list. Precedence: explicit `languages` input →
 * configured `status.languages` → a single-entry list from the active language
 * (or the configured default). Order is preserved; duplicates are dropped.
 */
function resolveLangList(languagesInput, configLanguages, activeLang, defaultLang) {
    const list = languagesInput?.length ? languagesInput : configLanguages;
    const resolved = list?.length ? list : [activeLang ?? defaultLang];
    return Array.from(new Set(resolved));
}
/** Primary language: the active lang if present in the list, else the first entry. */
function resolvePrimaryLang(list, activeLang, defaultLang) {
    if (activeLang && list.includes(activeLang))
        return activeLang;
    /* istanbul ignore next -- callers pass a list with ≥1 entry, so the `?? defaultLang` fallback is unreachable. */
    return list[0] ?? defaultLang;
}
/**
 * Universal, multilingual status / error page — one component drives 404, 403,
 * 500, 503, maintenance, offline and every other code in the catalog, and it
 * renders the copy in EVERY configured language at once: the primary language
 * large up top, the rest stacked below smaller and dimmed (each with its own
 * `dir`, so Arabic / Urdu read correctly).
 *
 * ```html
 * <ik-status-page [code]="404" />
 * <ik-status-page [code]="503" title="Скоро вернёмся" [lang]="'ru'" />
 * <ik-status-page code="maintenance" [languages]="['en','ar']" [showHome]="false" />
 * ```
 *
 * A floating "techno" background sits behind a centred glass panel. Theming is
 * inherited from the host app's CSS custom properties (`--brand`, `--bg`,
 * `--text`, `--border`, `--grad-brand` …); fallbacks keep it readable with no
 * theme present. Honours `prefers-reduced-motion`.
 *
 * Driven by `config.status`:
 *   • `redirect: { delaySeconds, href? }` → live countdown then auto-navigate
 *     home; any page interaction (click / focus / key) cancels the countdown.
 *   • `showBack` (default true) → a secondary "← Back" button (history.back()).
 * When `lang` is not supplied it is auto-detected from `navigator.language`.
 */
class StatusPage {
    cfg = inject(SITE_KIT_CONFIG);
    doc = inject(DOCUMENT);
    /** HTTP code (404, 500 …) or pseudo-state ('maintenance' | 'offline'). */
    code = input.required(...(ngDevMode ? [{ debugName: "code" }] : /* istanbul ignore next */ []));
    /** Override the PRIMARY language title for this instance. */
    title = input(...(ngDevMode ? [undefined, { debugName: "title" }] : /* istanbul ignore next */ []));
    /** Override the PRIMARY language message for this instance. */
    message = input(...(ngDevMode ? [undefined, { debugName: "message" }] : /* istanbul ignore next */ []));
    /** Languages to render simultaneously; defaults to `config.status.languages`. */
    languages = input(...(ngDevMode ? [undefined, { debugName: "languages" }] : /* istanbul ignore next */ []));
    /** Active / primary language. Defaults to auto-detect, then `config.defaultLang`. */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Show the "go home" button. */
    showHome = input(true, ...(ngDevMode ? [{ debugName: "showHome" }] : /* istanbul ignore next */ []));
    /**
     * Preview/demo mode: the redirect countdown still renders, but it does NOT
     * actually navigate away when it elapses. Lets a playground show error pages
     * (and the redirect copy) without the page being whisked off to home.
     */
    preview = input(false, ...(ngDevMode ? [{ debugName: "preview" }] : /* istanbul ignore next */ []));
    glyph = computed(() => statusGlyph(this.code()), ...(ngDevMode ? [{ debugName: "glyph" }] : /* istanbul ignore next */ []));
    /** Home-button label: explicit config, else localized to the primary language. */
    homeLabel = computed(() => localizeText(this.cfg.status.homeLabel, this.primaryLang(), this.cfg.defaultLang) ??
        chromeString(this.primaryLang(), 'home', this.cfg.strings), ...(ngDevMode ? [{ debugName: "homeLabel" }] : /* istanbul ignore next */ []));
    /** Support line, localized to the primary language. */
    supportLine = computed(() => localizeText(this.cfg.status.supportLine, this.primaryLang(), this.cfg.defaultLang), ...(ngDevMode ? [{ debugName: "supportLine" }] : /* istanbul ignore next */ []));
    /** "Back" button label, localized to the primary language. */
    backLabel = computed(() => chromeString(this.primaryLang(), 'back', this.cfg.strings), ...(ngDevMode ? [{ debugName: "backLabel" }] : /* istanbul ignore next */ []));
    /** Render the Back button unless explicitly disabled in config. */
    showBack = computed(() => this.cfg.status.showBack !== false, ...(ngDevMode ? [{ debugName: "showBack" }] : /* istanbul ignore next */ []));
    /** Resolved, deduped language list — falls back to the configured default. */
    langList = computed(() => resolveLangList(this.languages(), this.cfg.status.languages, this.resolvedLang(), this.cfg.defaultLang), ...(ngDevMode ? [{ debugName: "langList" }] : /* istanbul ignore next */ []));
    /**
     * The effective active language: the explicit `lang` input when given,
     * otherwise auto-detected from the browser (first 2 chars of
     * `navigator.language`) IF that language is configured for this site.
     * SSR-safe — `navigator` is guarded.
     */
    resolvedLang = computed(() => {
        const explicit = this.lang();
        if (explicit)
            return explicit;
        const nav = this.doc.defaultView?.navigator;
        const detected = nav?.language?.slice(0, 2).toLowerCase();
        if (detected && this.cfg.languages.includes(detected))
            return detected;
        return undefined;
    }, ...(ngDevMode ? [{ debugName: "resolvedLang" }] : /* istanbul ignore next */ []));
    /** Primary language: the resolved active lang if present in the list, else the first entry. */
    primaryLang = computed(() => resolvePrimaryLang(this.langList(), this.resolvedLang(), this.cfg.defaultLang), ...(ngDevMode ? [{ debugName: "primaryLang" }] : /* istanbul ignore next */ []));
    /** Primary row — `title`/`message` inputs override the catalog copy here only. Null while the
     *  language's copy is still loading (status-copy.ts), so no other language flashes first. */
    primary = computed(() => {
        const lang = this.primaryLang();
        const own = this.title() !== undefined && this.message() !== undefined;
        const copy = own ? GENERIC_STATUS_COPY : this.copyFor(lang);
        if (!copy)
            return null;
        return {
            lang,
            rtl: isRtl(lang),
            title: this.title() ?? copy.title,
            message: this.message() ?? copy.message,
        };
    }, ...(ngDevMode ? [{ debugName: "primary" }] : /* istanbul ignore next */ []));
    /** Every other configured language, in order, with un-overridden catalog copy. */
    secondary = computed(() => {
        const primary = this.primaryLang();
        return this.langList()
            .filter((lang) => lang !== primary)
            .flatMap((lang) => {
            const copy = this.copyFor(lang);
            return copy ? [{ lang, rtl: isRtl(lang), title: copy.title, message: copy.message }] : [];
        });
    }, ...(ngDevMode ? [{ debugName: "secondary" }] : /* istanbul ignore next */ []));
    // ─── Auto-redirect countdown ──────────────────────────────────
    /** Seconds left in the live countdown (0 = elapsed/inactive). */
    remaining = signal(0, ...(ngDevMode ? [{ debugName: "remaining" }] : /* istanbul ignore next */ []));
    timerId;
    /** True while a redirect countdown is running and has time left. */
    countdownActive = computed(() => this.remaining() > 0, ...(ngDevMode ? [{ debugName: "countdownActive" }] : /* istanbul ignore next */ []));
    /** Total redirect delay (s) — drives the home-button fill animation duration. */
    redirectSeconds = signal(0, ...(ngDevMode ? [{ debugName: "redirectSeconds" }] : /* istanbul ignore next */ []));
    /** Localized "You'll be redirected to home in N s" — replaces the support line. */
    redirectText = computed(() => chromeString(this.primaryLang(), 'redirect', this.cfg.strings).replace('{n}', String(this.remaining())), ...(ngDevMode ? [{ debugName: "redirectText" }] : /* istanbul ignore next */ []));
    constructor() {
        // Start the countdown once, when a positive delay is configured and we
        // have a browser window. Guarded so it never fires twice and is SSR-safe.
        effect(() => {
            const delay = this.cfg.status.redirect?.delaySeconds ?? DEFAULT_REDIRECT_SECONDS; // ON by default; { delaySeconds: 0 } disables
            const view = this.doc.defaultView;
            if (delay > 0 && view && this.timerId === undefined) {
                this.redirectSeconds.set(Math.floor(delay));
                this.remaining.set(Math.floor(delay));
                this.timerId = setInterval(() => this.tick(), 1000);
            }
        });
    }
    /** One countdown tick: step down, or (at zero) hand off to navigateHome. */
    tick() {
        const next = this.remaining() - 1;
        if (next > 0) {
            this.remaining.set(next);
            return;
        }
        this.remaining.set(0);
        this.clearTimer();
        this.navigateHome();
    }
    /** Cancel the auto-redirect (inline button, or a focus/click on the page). */
    cancelRedirect() {
        this.clearTimer();
        this.remaining.set(0);
    }
    /** Pause/cancel the countdown when the user interacts with the page. In preview the
     *  countdown is a looping demo, so interaction must NOT cancel it. */
    onUserIntent() {
        if (this.preview())
            return;
        if (this.countdownActive())
            this.cancelRedirect();
    }
    /** Go to the previous page in browser history. SSR-safe. */
    goBack() {
        this.doc.defaultView?.history.back();
    }
    /* istanbul ignore next -- preview re-arm (looping demo) and real navigation both leave the
       coverable path: location.assign would whisk the karma runner away, so this method's body
       runs only in the browser. Its OUTCOMES are asserted by the redirect loop/navigate tests. */
    navigateHome() {
        if (this.preview()) {
            // demo/preview: never leave — restart the countdown so it loops for the showcase.
            this.remaining.set(this.redirectSeconds());
            this.timerId = setInterval(() => this.tick(), 1000);
            return;
        }
        const target = this.cfg.status.redirect?.href ?? this.cfg.status.homeHref;
        const view = this.doc.defaultView;
        // Reject scheme-based redirects (location.assign isn't URL-sanitized like [href]).
        if (target && view && !/^(javascript|data|vbscript|file):/i.test(target.trim())) {
            view.location.assign(target);
        }
    }
    clearTimer() {
        if (this.timerId !== undefined) {
            clearInterval(this.timerId);
            this.timerId = undefined;
        }
    }
    ngOnDestroy() {
        this.clearTimer();
    }
    /** Bumped as each language's copy arrives, so the rows recompute. */
    copyArrived = signal(0, ...(ngDevMode ? [{ debugName: "copyArrived" }] : /* istanbul ignore next */ []));
    /** Fetch the copy of every language the page shows (and the default, its fallback). */
    loadCopy = effect(() => {
        for (const lang of new Set([...this.langList(), this.cfg.defaultLang])) {
            if (hasStatusCopy(lang) && !statusCopyIfLoaded(lang)) {
                void loadStatusCopy(lang).then(() => this.copyArrived.update((n) => n + 1));
            }
        }
    }, ...(ngDevMode ? [{ debugName: "loadCopy" }] : /* istanbul ignore next */ []));
    /**
     * The copy of this code in a language: that language, else the site's default, else English,
     * else the generic error (as statusCopy() falls back). Null while a language it should use is
     * still loading.
     */
    copyFor(lang) {
        this.copyArrived();
        const code = String(this.code());
        for (const l of [lang, this.cfg.defaultLang, 'en']) {
            if (!hasStatusCopy(l))
                continue;
            const copies = statusCopyIfLoaded(l);
            if (!copies)
                return null;
            if (Object.hasOwn(copies, code))
                return copies[code];
        }
        return GENERIC_STATUS_COPY;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: StatusPage, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: StatusPage, isStandalone: true, selector: "ik-status-page", inputs: { code: { classPropertyName: "code", publicName: "code", isSignal: true, isRequired: true, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, languages: { classPropertyName: "languages", publicName: "languages", isSignal: true, isRequired: false, transformFunction: null }, lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, showHome: { classPropertyName: "showHome", publicName: "showHome", isSignal: true, isRequired: false, transformFunction: null }, preview: { classPropertyName: "preview", publicName: "preview", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "pointerdown": "onUserIntent()", "focusin": "onUserIntent()", "keydown": "onUserIntent()" }, classAttribute: "ik-status-page" }, ngImport: i0, template: `
        <ik-techno-bg />

        <div class="panel" role="alert" aria-live="polite">
            <div class="glyph" aria-hidden="true">{{ glyph() }}</div>

            @if (primary(); as p) {
                <div class="primary" [attr.dir]="p.rtl ? 'rtl' : 'ltr'" [attr.lang]="p.lang">
                    <h1 class="title">{{ p.title }}</h1>
                    <p class="message">{{ p.message }}</p>
                </div>
            }

            @if (secondary().length) {
                <div class="others">
                    @for (row of secondary(); track row.lang) {
                        <div class="other" [attr.dir]="row.rtl ? 'rtl' : 'ltr'" [attr.lang]="row.lang">
                            <span class="other-title">{{ row.title }}</span>
                            <span class="other-message">{{ row.message }}</span>
                        </div>
                    }
                </div>
            }

            @if (supportLine(); as sl) {
                <p class="support">{{ sl }}</p>
            }

            <div class="actions">
                @if (showHome()) {
                    <a class="btn home" [href]="cfg.status.homeHref">
                        @if (countdownActive()) {
                            <ik-countdown [durationMs]="redirectSeconds() * 1000" [loop]="preview()" />
                        }
                        <span class="home-label">{{ homeLabel() }}</span>
                    </a>
                }
                @if (showBack()) {
                    <button type="button" class="btn back" (click)="goBack()">
                        <span aria-hidden="true">←</span> {{ backLabel() }}
                    </button>
                }
            </div>

            @if (countdownActive()) {
                <p class="redirect" aria-live="polite">{{ redirectText() }}</p>
            }

            <ng-content />
        </div>
    `, isInline: true, styles: [":host{position:relative;display:grid;place-items:center;min-height:100dvh;padding:var(--sp-8, 2rem);overflow:hidden;background:var(--bg, #fafafa);color:var(--text, #09090f);font-family:var(--font-display, system-ui, -apple-system, sans-serif)}.panel{position:relative;z-index:var(--z-raised, 10);display:flex;flex-direction:column;align-items:center;text-align:center;gap:var(--sp-5, 1.25rem);width:100%;max-width:var(--container-narrow, 42rem);padding:clamp(var(--sp-8, 2rem),6vw,var(--sp-16, 4rem)) var(--sp-8, 2rem);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-2xl, 32px);background:var(--bg-overlay, rgba(255, 255, 255, .7));box-shadow:var(--shadow-xl, 0 32px 64px rgba(9, 9, 15, .14));-webkit-backdrop-filter:blur(20px) saturate(1.4);backdrop-filter:blur(20px) saturate(1.4);animation:ik-panel-in var(--dur-slow, .5s) var(--ease-out, cubic-bezier(.16, 1, .3, 1)) both}.glyph{font-size:clamp(5rem,18vw,9rem);font-weight:var(--fw-black, 800);line-height:1;letter-spacing:var(--ls-tight, -.025em);background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );background-size:200% 200%;-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent;filter:drop-shadow(0 8px 28px var(--brand-glow, rgba(109, 40, 217, .4)));animation:ik-glyph-shimmer 6s var(--ease-in-out, ease-in-out) infinite}.primary{display:flex;flex-direction:column;gap:var(--sp-3, .75rem);align-items:center}.title{margin:0;font-size:var(--fs-3xl, 1.875rem);font-weight:var(--fw-bold, 700);line-height:var(--lh-tight, 1.1);letter-spacing:var(--ls-snug, -.01em)}.message{margin:0;font-size:var(--fs-lg, 1.125rem);color:var(--text-mute, #5c5c6d);line-height:var(--lh-base, 1.6);max-width:42ch}.others{display:flex;flex-direction:column;gap:var(--sp-2, .5rem);width:100%;max-width:44ch;margin-top:var(--sp-1, .25rem);padding-top:var(--sp-4, 1rem);border-top:1px solid var(--border-soft, #f0f0f2)}.other{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:center;gap:var(--sp-1, .25rem) var(--sp-2, .5rem);font-size:var(--fs-sm, .875rem);line-height:var(--lh-snug, 1.25);opacity:.7}.other-title{font-weight:var(--fw-semi, 600);color:var(--text-mute, #5c5c6d)}.other-message{color:var(--text-dim, #8e8ea0)}.support{margin:0;font-size:var(--fs-sm, .875rem);color:var(--text-dim, #8e8ea0)}.actions{margin-top:var(--sp-2, .5rem);display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:var(--sp-3, .75rem)}.btn{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);text-decoration:none;padding:var(--sp-3, .75rem) var(--sp-6, 1.5rem);border-radius:var(--r-full, 999px);font-family:inherit;font-size:var(--fs-base, 1rem);font-weight:var(--fw-semi, 600);cursor:pointer;transition:transform var(--dur-fast, .15s) var(--ease-out, ease),box-shadow var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease)}.home{position:relative;overflow:hidden;border:1px solid transparent;background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );color:var(--text-on-brand, #fff);box-shadow:var(--shadow-md, 0 8px 24px rgba(9, 9, 15, .08));--ik-countdown-fill: rgba(9, 9, 15, .26)}.home:hover{transform:translateY(-2px);box-shadow:var(--shadow-lg, 0 20px 48px rgba(9, 9, 15, .1))}.home-label{position:relative;z-index:1}.back{border:1px solid var(--border, #e5e5e9);background:var(--bg-elev, transparent);color:var(--text-mute, #5c5c6d)}.back:hover{transform:translateY(-2px);color:var(--text, #09090f);border-color:var(--border-strong, #aeb0bc)}.btn:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.redirect{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@keyframes ik-glyph-shimmer{0%,to{background-position:0% 50%}50%{background-position:100% 50%}}@keyframes ik-panel-in{0%{opacity:0;transform:translateY(16px) scale(.985)}to{opacity:1;transform:none}}@media(max-width:40rem){:host{padding:var(--sp-4, 1rem)}.panel{padding:var(--sp-8, 2rem) var(--sp-5, 1.25rem);border-radius:var(--r-xl, 24px)}}@media(prefers-reduced-motion:reduce){.glyph,.panel{animation:none}.btn{transition:none}.home:hover,.back:hover{transform:none}}\n"], dependencies: [{ kind: "component", type: TechnoBg, selector: "ik-techno-bg" }, { kind: "component", type: IkCountdown, selector: "ik-countdown", inputs: ["durationMs", "loop"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: StatusPage, decorators: [{
            type: Component,
            args: [{ selector: 'ik-status-page', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [TechnoBg, IkCountdown], template: `
        <ik-techno-bg />

        <div class="panel" role="alert" aria-live="polite">
            <div class="glyph" aria-hidden="true">{{ glyph() }}</div>

            @if (primary(); as p) {
                <div class="primary" [attr.dir]="p.rtl ? 'rtl' : 'ltr'" [attr.lang]="p.lang">
                    <h1 class="title">{{ p.title }}</h1>
                    <p class="message">{{ p.message }}</p>
                </div>
            }

            @if (secondary().length) {
                <div class="others">
                    @for (row of secondary(); track row.lang) {
                        <div class="other" [attr.dir]="row.rtl ? 'rtl' : 'ltr'" [attr.lang]="row.lang">
                            <span class="other-title">{{ row.title }}</span>
                            <span class="other-message">{{ row.message }}</span>
                        </div>
                    }
                </div>
            }

            @if (supportLine(); as sl) {
                <p class="support">{{ sl }}</p>
            }

            <div class="actions">
                @if (showHome()) {
                    <a class="btn home" [href]="cfg.status.homeHref">
                        @if (countdownActive()) {
                            <ik-countdown [durationMs]="redirectSeconds() * 1000" [loop]="preview()" />
                        }
                        <span class="home-label">{{ homeLabel() }}</span>
                    </a>
                }
                @if (showBack()) {
                    <button type="button" class="btn back" (click)="goBack()">
                        <span aria-hidden="true">←</span> {{ backLabel() }}
                    </button>
                }
            </div>

            @if (countdownActive()) {
                <p class="redirect" aria-live="polite">{{ redirectText() }}</p>
            }

            <ng-content />
        </div>
    `, host: {
                        class: 'ik-status-page',
                        // Any deliberate interaction cancels the auto-redirect (no-op once inactive).
                        '(pointerdown)': 'onUserIntent()',
                        '(focusin)': 'onUserIntent()',
                        '(keydown)': 'onUserIntent()',
                    }, styles: [":host{position:relative;display:grid;place-items:center;min-height:100dvh;padding:var(--sp-8, 2rem);overflow:hidden;background:var(--bg, #fafafa);color:var(--text, #09090f);font-family:var(--font-display, system-ui, -apple-system, sans-serif)}.panel{position:relative;z-index:var(--z-raised, 10);display:flex;flex-direction:column;align-items:center;text-align:center;gap:var(--sp-5, 1.25rem);width:100%;max-width:var(--container-narrow, 42rem);padding:clamp(var(--sp-8, 2rem),6vw,var(--sp-16, 4rem)) var(--sp-8, 2rem);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-2xl, 32px);background:var(--bg-overlay, rgba(255, 255, 255, .7));box-shadow:var(--shadow-xl, 0 32px 64px rgba(9, 9, 15, .14));-webkit-backdrop-filter:blur(20px) saturate(1.4);backdrop-filter:blur(20px) saturate(1.4);animation:ik-panel-in var(--dur-slow, .5s) var(--ease-out, cubic-bezier(.16, 1, .3, 1)) both}.glyph{font-size:clamp(5rem,18vw,9rem);font-weight:var(--fw-black, 800);line-height:1;letter-spacing:var(--ls-tight, -.025em);background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );background-size:200% 200%;-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent;filter:drop-shadow(0 8px 28px var(--brand-glow, rgba(109, 40, 217, .4)));animation:ik-glyph-shimmer 6s var(--ease-in-out, ease-in-out) infinite}.primary{display:flex;flex-direction:column;gap:var(--sp-3, .75rem);align-items:center}.title{margin:0;font-size:var(--fs-3xl, 1.875rem);font-weight:var(--fw-bold, 700);line-height:var(--lh-tight, 1.1);letter-spacing:var(--ls-snug, -.01em)}.message{margin:0;font-size:var(--fs-lg, 1.125rem);color:var(--text-mute, #5c5c6d);line-height:var(--lh-base, 1.6);max-width:42ch}.others{display:flex;flex-direction:column;gap:var(--sp-2, .5rem);width:100%;max-width:44ch;margin-top:var(--sp-1, .25rem);padding-top:var(--sp-4, 1rem);border-top:1px solid var(--border-soft, #f0f0f2)}.other{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:center;gap:var(--sp-1, .25rem) var(--sp-2, .5rem);font-size:var(--fs-sm, .875rem);line-height:var(--lh-snug, 1.25);opacity:.7}.other-title{font-weight:var(--fw-semi, 600);color:var(--text-mute, #5c5c6d)}.other-message{color:var(--text-dim, #8e8ea0)}.support{margin:0;font-size:var(--fs-sm, .875rem);color:var(--text-dim, #8e8ea0)}.actions{margin-top:var(--sp-2, .5rem);display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:var(--sp-3, .75rem)}.btn{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);text-decoration:none;padding:var(--sp-3, .75rem) var(--sp-6, 1.5rem);border-radius:var(--r-full, 999px);font-family:inherit;font-size:var(--fs-base, 1rem);font-weight:var(--fw-semi, 600);cursor:pointer;transition:transform var(--dur-fast, .15s) var(--ease-out, ease),box-shadow var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease)}.home{position:relative;overflow:hidden;border:1px solid transparent;background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );color:var(--text-on-brand, #fff);box-shadow:var(--shadow-md, 0 8px 24px rgba(9, 9, 15, .08));--ik-countdown-fill: rgba(9, 9, 15, .26)}.home:hover{transform:translateY(-2px);box-shadow:var(--shadow-lg, 0 20px 48px rgba(9, 9, 15, .1))}.home-label{position:relative;z-index:1}.back{border:1px solid var(--border, #e5e5e9);background:var(--bg-elev, transparent);color:var(--text-mute, #5c5c6d)}.back:hover{transform:translateY(-2px);color:var(--text, #09090f);border-color:var(--border-strong, #aeb0bc)}.btn:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.redirect{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@keyframes ik-glyph-shimmer{0%,to{background-position:0% 50%}50%{background-position:100% 50%}}@keyframes ik-panel-in{0%{opacity:0;transform:translateY(16px) scale(.985)}to{opacity:1;transform:none}}@media(max-width:40rem){:host{padding:var(--sp-4, 1rem)}.panel{padding:var(--sp-8, 2rem) var(--sp-5, 1.25rem);border-radius:var(--r-xl, 24px)}}@media(prefers-reduced-motion:reduce){.glyph,.panel{animation:none}.btn{transition:none}.home:hover,.back:hover{transform:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { code: [{ type: i0.Input, args: [{ isSignal: true, alias: "code", required: true }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], languages: [{ type: i0.Input, args: [{ isSignal: true, alias: "languages", required: false }] }], lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], showHome: [{ type: i0.Input, args: [{ isSignal: true, alias: "showHome", required: false }] }], preview: [{ type: i0.Input, args: [{ isSignal: true, alias: "preview", required: false }] }] } });

var $comment = "Single source of truth for ALL status/error pages — consumed by Angular <ik-status-page> AND static/generate.mjs. Languages match the Integra (UAE STARS) set: en, ru, ar, kk, zh, hi, ur. A static page can show several at once; pick which via config.static.languages.";
var languages = [
	"en",
	"ru",
	"ar",
	"kk",
	"zh",
	"hi",
	"ur"
];
var entries = [
	{
		code: 400,
		glyph: "400",
		i18n: {
			en: {
				title: "Bad request",
				message: "The server couldn't process this request — check the address and try again."
			},
			ru: {
				title: "Некорректный запрос",
				message: "Сервер не смог обработать запрос — проверьте адрес и повторите."
			},
			ar: {
				title: "طلب غير صالح",
				message: "تعذّر على الخادم معالجة الطلب — تحقّق من العنوان وحاول مجددًا."
			},
			kk: {
				title: "Қате сұрау",
				message: "Сервер сұрауды өңдей алмады — мекенжайды тексеріп, қайталаңыз."
			},
			zh: {
				title: "请求无效",
				message: "服务器无法处理此请求——请检查地址后重试。"
			},
			hi: {
				title: "गलत अनुरोध",
				message: "सर्वर इस अनुरोध को संसाधित नहीं कर सका — पता जाँचें और पुनः प्रयास करें।"
			},
			ur: {
				title: "غلط درخواست",
				message: "سرور یہ درخواست پروسیس نہ کر سکا — پتہ چیک کریں اور دوبارہ کوشش کریں۔"
			}
		}
	},
	{
		code: 401,
		glyph: "401",
		i18n: {
			en: {
				title: "Authorization required",
				message: "You need to sign in to view this page."
			},
			ru: {
				title: "Требуется авторизация",
				message: "Чтобы открыть эту страницу, нужно войти в систему."
			},
			ar: {
				title: "يلزم تسجيل الدخول",
				message: "يجب تسجيل الدخول لعرض هذه الصفحة."
			},
			kk: {
				title: "Авторизация қажет",
				message: "Бұл бетті көру үшін жүйеге кіру қажет."
			},
			zh: {
				title: "需要登录",
				message: "查看此页面需要先登录。"
			},
			hi: {
				title: "प्राधिकरण आवश्यक",
				message: "इस पेज को देखने के लिए साइन इन करें।"
			},
			ur: {
				title: "اجازت درکار",
				message: "یہ صفحہ دیکھنے کے لیے سائن اِن کریں۔"
			}
		}
	},
	{
		code: 403,
		glyph: "403",
		i18n: {
			en: {
				title: "Access denied",
				message: "You don't have permission to view this page."
			},
			ru: {
				title: "Доступ запрещён",
				message: "У вас нет прав на просмотр этой страницы."
			},
			ar: {
				title: "الوصول مرفوض",
				message: "ليست لديك صلاحية لعرض هذه الصفحة."
			},
			kk: {
				title: "Қол жеткізу тыйым салынған",
				message: "Бұл бетті көруге рұқсатыңыз жоқ."
			},
			zh: {
				title: "禁止访问",
				message: "您没有权限查看此页面。"
			},
			hi: {
				title: "पहुँच अस्वीकृत",
				message: "इस पेज को देखने की अनुमति आपके पास नहीं है।"
			},
			ur: {
				title: "رسائی ممنوع",
				message: "آپ کو یہ صفحہ دیکھنے کی اجازت نہیں ہے۔"
			}
		}
	},
	{
		code: 404,
		glyph: "404",
		i18n: {
			en: {
				title: "Page not found",
				message: "The link may be outdated or the address was mistyped."
			},
			ru: {
				title: "Страница не найдена",
				message: "Возможно, ссылка устарела или адрес введён с ошибкой."
			},
			ar: {
				title: "الصفحة غير موجودة",
				message: "قد يكون الرابط قديمًا أو العنوان مكتوبًا بشكل خاطئ."
			},
			kk: {
				title: "Бет табылмады",
				message: "Сілтеме ескірген немесе мекенжай қате терілген болуы мүмкін."
			},
			zh: {
				title: "页面未找到",
				message: "链接可能已失效，或地址输入有误。"
			},
			hi: {
				title: "पेज नहीं मिला",
				message: "हो सकता है लिंक पुराना हो या पता गलत टाइप हुआ हो।"
			},
			ur: {
				title: "صفحہ نہیں ملا",
				message: "ممکن ہے لنک پرانا ہو یا پتہ غلط ٹائپ ہوا ہو۔"
			}
		}
	},
	{
		code: 405,
		glyph: "405",
		i18n: {
			en: {
				title: "Method not allowed",
				message: "This kind of request isn't available here."
			},
			ru: {
				title: "Метод не поддерживается",
				message: "Этот тип запроса здесь недоступен."
			},
			ar: {
				title: "الطريقة غير مسموحة",
				message: "هذا النوع من الطلبات غير متاح هنا."
			},
			kk: {
				title: "Әдіс қолдауы жоқ",
				message: "Сұраудың бұл түрі мұнда қолжетімсіз."
			},
			zh: {
				title: "方法不被允许",
				message: "此类请求在这里不可用。"
			},
			hi: {
				title: "विधि अनुमत नहीं",
				message: "इस प्रकार का अनुरोध यहाँ उपलब्ध नहीं है।"
			},
			ur: {
				title: "طریقہ کار مجاز نہیں",
				message: "اس قسم کی درخواست یہاں دستیاب نہیں۔"
			}
		}
	},
	{
		code: 408,
		glyph: "408",
		i18n: {
			en: {
				title: "Request timeout",
				message: "The request took too long. Please try again."
			},
			ru: {
				title: "Время ожидания истекло",
				message: "Запрос занял слишком много времени. Попробуйте ещё раз."
			},
			ar: {
				title: "انتهت مهلة الطلب",
				message: "استغرق الطلب وقتًا طويلًا. حاول مرة أخرى."
			},
			kk: {
				title: "Күту уақыты бітті",
				message: "Сұрау тым ұзаққа созылды. Қайталап көріңіз."
			},
			zh: {
				title: "请求超时",
				message: "请求耗时过长。请重试。"
			},
			hi: {
				title: "अनुरोध समय समाप्त",
				message: "अनुरोध में बहुत समय लगा। कृपया पुनः प्रयास करें।"
			},
			ur: {
				title: "درخواست کا وقت ختم",
				message: "درخواست میں بہت وقت لگا۔ دوبارہ کوشش کریں۔"
			}
		}
	},
	{
		code: 410,
		glyph: "410",
		i18n: {
			en: {
				title: "Gone",
				message: "This content is no longer available."
			},
			ru: {
				title: "Страница удалена",
				message: "Этот материал больше не доступен."
			},
			ar: {
				title: "تمت الإزالة",
				message: "لم يَعُد هذا المحتوى متاحًا."
			},
			kk: {
				title: "Жойылған",
				message: "Бұл мазмұн енді қолжетімсіз."
			},
			zh: {
				title: "已删除",
				message: "此内容已不再可用。"
			},
			hi: {
				title: "हटा दिया गया",
				message: "यह सामग्री अब उपलब्ध नहीं है।"
			},
			ur: {
				title: "ہٹا دیا گیا",
				message: "یہ مواد اب دستیاب نہیں۔"
			}
		}
	},
	{
		code: 429,
		glyph: "429",
		i18n: {
			en: {
				title: "Too many requests",
				message: "You're sending requests too often. Please wait a moment."
			},
			ru: {
				title: "Слишком много запросов",
				message: "Вы отправляете запросы слишком часто. Подождите немного."
			},
			ar: {
				title: "طلبات كثيرة جدًا",
				message: "أنت ترسل طلبات بمعدّل مرتفع. انتظر قليلًا."
			},
			kk: {
				title: "Сұраулар тым көп",
				message: "Сіз сұрауларды тым жиі жібересіз. Сәл күтіңіз."
			},
			zh: {
				title: "请求过于频繁",
				message: "您发送请求过于频繁。请稍候。"
			},
			hi: {
				title: "बहुत अधिक अनुरोध",
				message: "आप बहुत बार अनुरोध भेज रहे हैं। कृपया थोड़ा रुकें।"
			},
			ur: {
				title: "بہت زیادہ درخواستیں",
				message: "آپ بہت کثرت سے درخواستیں بھیج رہے ہیں۔ ذرا انتظار کریں۔"
			}
		}
	},
	{
		code: 500,
		glyph: "500",
		i18n: {
			en: {
				title: "Internal server error",
				message: "Something went wrong on our side. We're already looking into it."
			},
			ru: {
				title: "Внутренняя ошибка сервера",
				message: "Что-то пошло не так на нашей стороне. Мы уже разбираемся."
			},
			ar: {
				title: "خطأ داخلي في الخادم",
				message: "حدث خطأ من جانبنا. نحن نعمل على حلّه بالفعل."
			},
			kk: {
				title: "Сервердің ішкі қатесі",
				message: "Біздің жағымызда қателік кетті. Біз қазірдің өзінде қарап жатырмыз."
			},
			zh: {
				title: "服务器内部错误",
				message: "我们这边出了点问题，我们正在处理。"
			},
			hi: {
				title: "आंतरिक सर्वर त्रुटि",
				message: "हमारी ओर से कुछ गलत हुआ। हम इसे पहले से देख रहे हैं।"
			},
			ur: {
				title: "اندرونی سرور کی خرابی",
				message: "ہماری طرف سے کچھ خرابی ہوئی۔ ہم پہلے ہی دیکھ رہے ہیں۔"
			}
		}
	},
	{
		code: 502,
		glyph: "502",
		i18n: {
			en: {
				title: "Bad gateway",
				message: "The service is temporarily unavailable. Try again in a minute."
			},
			ru: {
				title: "Ошибка шлюза",
				message: "Сервис временно недоступен. Повторите попытку через минуту."
			},
			ar: {
				title: "بوابة غير صالحة",
				message: "الخدمة غير متاحة مؤقتًا. حاول بعد دقيقة."
			},
			kk: {
				title: "Шлюз қатесі",
				message: "Қызмет уақытша қолжетімсіз. Бір минуттан кейін қайталаңыз."
			},
			zh: {
				title: "网关错误",
				message: "服务暂时不可用。请一分钟后重试。"
			},
			hi: {
				title: "खराब गेटवे",
				message: "सेवा अस्थायी रूप से अनुपलब्ध है। एक मिनट बाद पुनः प्रयास करें।"
			},
			ur: {
				title: "خراب گیٹ وے",
				message: "سروس عارضی طور پر دستیاب نہیں۔ ایک منٹ بعد کوشش کریں۔"
			}
		}
	},
	{
		code: 503,
		glyph: "503",
		i18n: {
			en: {
				title: "Service unavailable",
				message: "Maintenance in progress. We'll be back shortly."
			},
			ru: {
				title: "Сервис недоступен",
				message: "Идут технические работы. Скоро всё вернётся в строй."
			},
			ar: {
				title: "الخدمة غير متاحة",
				message: "تجري أعمال صيانة. سنعود قريبًا."
			},
			kk: {
				title: "Қызмет қолжетімсіз",
				message: "Техникалық жұмыстар жүріп жатыр. Жақын арада қайта оралады."
			},
			zh: {
				title: "服务不可用",
				message: "正在进行维护。我们很快回来。"
			},
			hi: {
				title: "सेवा अनुपलब्ध",
				message: "रखरखाव जारी है। हम जल्द लौटेंगे।"
			},
			ur: {
				title: "سروس دستیاب نہیں",
				message: "دیکھ بھال جاری ہے۔ ہم جلد واپس آئیں گے۔"
			}
		}
	},
	{
		code: 504,
		glyph: "504",
		i18n: {
			en: {
				title: "Gateway timeout",
				message: "The server took too long to respond. Try refreshing."
			},
			ru: {
				title: "Шлюз не отвечает",
				message: "Сервер слишком долго отвечает. Попробуйте обновить страницу."
			},
			ar: {
				title: "انتهت مهلة البوابة",
				message: "استغرق الخادم وقتًا طويلًا للرد. حاول تحديث الصفحة."
			},
			kk: {
				title: "Шлюз жауап бермейді",
				message: "Сервер тым ұзақ жауап береді. Бетті жаңартып көріңіз."
			},
			zh: {
				title: "网关超时",
				message: "服务器响应时间过长。请尝试刷新。"
			},
			hi: {
				title: "गेटवे समय समाप्त",
				message: "सर्वर ने जवाब देने में बहुत समय लिया। ताज़ा करके देखें।"
			},
			ur: {
				title: "گیٹ وے کا وقت ختم",
				message: "سرور کے جواب میں بہت وقت لگا۔ صفحہ ریفریش کریں۔"
			}
		}
	},
	{
		code: "maintenance",
		glyph: "🛠",
		i18n: {
			en: {
				title: "Under maintenance",
				message: "We're briefly offline for an update. Check back soon."
			},
			ru: {
				title: "Технические работы",
				message: "Мы ненадолго отключились для обновления. Загляните чуть позже."
			},
			ar: {
				title: "تحت الصيانة",
				message: "نحن متوقفون مؤقتًا للتحديث. عُد قريبًا."
			},
			kk: {
				title: "Техникалық жұмыстар",
				message: "Жаңарту үшін қысқа уақытқа өшірілдік. Сәл кейінірек кіріңіз."
			},
			zh: {
				title: "正在维护",
				message: "我们正在短暂更新。请稍后再来。"
			},
			hi: {
				title: "रखरखाव जारी",
				message: "हम अपडेट के लिए कुछ देर ऑफ़लाइन हैं। थोड़ी देर बाद आएँ।"
			},
			ur: {
				title: "دیکھ بھال جاری",
				message: "ہم اپ ڈیٹ کے لیے کچھ دیر آف لائن ہیں۔ تھوڑی دیر بعد آئیں۔"
			}
		}
	},
	{
		code: "offline",
		glyph: "⚡",
		i18n: {
			en: {
				title: "You're offline",
				message: "Looks like the connection dropped. Check your network and refresh."
			},
			ru: {
				title: "Нет соединения",
				message: "Похоже, пропал интернет. Проверьте подключение и обновите страницу."
			},
			ar: {
				title: "أنت غير متصل",
				message: "يبدو أن الاتصال انقطع. تحقّق من الشبكة وحدّث الصفحة."
			},
			kk: {
				title: "Байланыс жоқ",
				message: "Интернет үзілген сияқты. Желіні тексеріп, бетті жаңартыңыз."
			},
			zh: {
				title: "您已离线",
				message: "连接似乎已断开。请检查网络后刷新。"
			},
			hi: {
				title: "आप ऑफ़लाइन हैं",
				message: "लगता है कनेक्शन टूट गया। नेटवर्क जाँचें और ताज़ा करें।"
			},
			ur: {
				title: "آپ آف لائن ہیں",
				message: "لگتا ہے کنکشن منقطع ہو گیا۔ نیٹ ورک چیک کر کے ریفریش کریں۔"
			}
		}
	}
];
var catalog = {
	$comment: $comment,
	languages: languages,
	entries: entries
};

// Nothing here runs when the module loads (no property reads, no Map): a bundler keeps a
// top-level expression it can't prove side-effect free, and with it the whole catalog, in every
// app that imports anything from the kit (tools/bundle-size.mjs). The PURE annotation on the calls
// below lets it drop the value when unused.
/** Languages the catalog ships copy for, in display order. */
const STATUS_LANGUAGES = /* @__PURE__ */ (() => catalog.languages)();
/** All known status entries, in catalog order. */
const STATUS_ENTRIES = /* @__PURE__ */ (() => catalog.entries)();
let byCode;
/** Returns the entry for a code, falling back to a generic error entry. */
function statusEntry(code) {
    return ((byCode ??= new Map(STATUS_ENTRIES.map((e) => [e.code, e]))).get(code) ?? {
        code,
        glyph: String(code),
        i18n: { en: { title: 'Error', message: 'An unexpected error occurred.' } },
    });
}
/** Resolves copy for a language, falling back to `fallback`, then to the first available. */
function statusCopy(entry, lang, fallback = 'en') {
    return (entry.i18n[lang] ??
        entry.i18n[fallback] ??
        Object.values(entry.i18n)[0] ?? { title: 'Error', message: 'An unexpected error occurred.' });
}

/**
 * Internal full-screen mobile overlay for {@link Nav} — the burger-triggered sheet
 * with numbered links, hover-in arrows and expandable accordion sections. Kept as a
 * private child so the overlay markup + its CSS travel together (Angular's emulated
 * encapsulation then renders byte-for-byte identical to the inline version). NOT
 * exported from the public API; only `<ik-nav>` instantiates it.
 */
class NavMobile {
    host = inject((ElementRef));
    cfg = inject(SITE_KIT_CONFIG);
    /** Whether the overlay is shown — driven by the parent burger. */
    open = input(false, ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    /** Resolved nav items (locale-aware) supplied by the parent. */
    items = input([], ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    /** Active language code — mirrors the parent's `lang`. */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Emitted whenever the overlay should close (backdrop, close button or a link). */
    closed = output();
    /** Keys of the expanded mobile accordion sections (multiple may be open). */
    openGroups = signal(new Set(), ...(ngDevMode ? [{ debugName: "openGroups" }] : /* istanbul ignore next */ []));
    /** Keys of nav items that have children (accordion groups). */
    groupKeys = computed(() => this.items()
        .filter((i) => i.children.length)
        .map((i) => i.key), ...(ngDevMode ? [{ debugName: "groupKeys" }] : /* istanbul ignore next */ []));
    activeLang = computed(() => this.lang() ?? this.cfg.defaultLang, ...(ngDevMode ? [{ debugName: "activeLang" }] : /* istanbul ignore next */ []));
    constructor() {
        // Match the original timing: when the overlay opens, measure + auto-expand
        // (the burger's toggle() used to call scheduleAutoExpand() on open).
        let wasOpen = false;
        effect(() => {
            const isOpen = this.open();
            if (isOpen && !wasOpen)
                this.scheduleAutoExpand();
            wasOpen = isOpen;
        });
    }
    pad(n) {
        return n < 10 ? `0${n}` : String(n);
    }
    /** Localized UI string for the active language (with per-app overrides). */
    t(key) {
        return chromeString(this.activeLang(), key, this.cfg.strings);
    }
    toggleGroup(key) {
        this.openGroups.update((cur) => {
            const next = new Set(cur);
            if (next.has(key))
                next.delete(key);
            else
                next.add(key);
            return next;
        });
    }
    /**
     * On open, expand ALL accordion groups by default IF the fully-expanded menu fits
     * the viewport height; otherwise leave them collapsed (accordion on small screens).
     * Measures after layout (children are in the DOM, just clipped, so their full height
     * is readable via scrollHeight). SSR/no-DOM safe.
     */
    scheduleAutoExpand() {
        const win = this.host.nativeElement.ownerDocument?.defaultView;
        if (!win?.requestAnimationFrame)
            return;
        win.requestAnimationFrame(() => {
            const root = this.host.nativeElement;
            const sheet = root.querySelector('.sheet');
            const nav = root.querySelector('.mob-nav');
            if (!sheet || !nav)
                return;
            const inners = Array.from(root.querySelectorAll('.acc-inner'));
            const expandedExtra = inners.reduce((sum, el) => sum + el.scrollHeight, 0);
            const cs = win.getComputedStyle(sheet);
            const available = sheet.clientHeight - parseFloat(cs.paddingTop || '0') - parseFloat(cs.paddingBottom || '0');
            if (nav.scrollHeight + expandedExtra <= available) {
                this.openGroups.set(new Set(this.groupKeys()));
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: NavMobile, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: NavMobile, isStandalone: true, selector: "ik-nav-mobile", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closed: "closed" }, ngImport: i0, template: `
        <!-- Mobile overlay. Closed via the top-bar menu toggle (which is itself an ✕ while open),
             a backdrop click, or Esc (document:keydown.escape host listener) — so the overlay
             carries NO separate close chip of its own. -->
        <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
        <div class="overlay" [class.is-open]="open()" (click)="closed.emit()">
            <div class="sheet">
                <!-- Non-interactive wrapper: stops sheet clicks from bubbling to the backdrop. -->
                <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
                <div class="mob-nav" (click)="$event.stopPropagation()">
                    @for (it of items(); track it.key; let i = $index) {
                        @if (it.children.length) {
                            <div class="acc" [class.is-open]="openGroups().has(it.key)">
                                <button
                                    type="button"
                                    class="mob-link acc-head"
                                    [class.is-cta]="it.item.cta"
                                    (click)="toggleGroup(it.key)"
                                    [attr.aria-expanded]="openGroups().has(it.key)"
                                >
                                    <span class="mob-num">{{ pad(i + 1) }}</span>
                                    <span class="mob-text">{{ it.label }}</span>
                                    <svg
                                        class="acc-chev"
                                        width="18"
                                        height="18"
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor"
                                        stroke-width="2.5"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        aria-hidden="true"
                                    >
                                        <path d="M6 9l6 6 6-6" />
                                    </svg>
                                </button>
                                <div class="acc-body">
                                    <div class="acc-inner">
                                        @for (ch of it.children; track ch.key) {
                                            <a
                                                class="acc-link"
                                                [href]="ch.href"
                                                [attr.target]="ch.external ? '_blank' : null"
                                                [attr.rel]="ch.external ? 'noopener noreferrer' : null"
                                                (click)="closed.emit()"
                                            >
                                                <span class="acc-dot" aria-hidden="true"></span>
                                                <span class="acc-text">{{ ch.label }}</span>
                                            </a>
                                        }
                                    </div>
                                </div>
                            </div>
                        } @else {
                            <a
                                class="mob-link"
                                [class.is-cta]="it.item.cta"
                                [href]="it.href"
                                [attr.target]="it.external ? '_blank' : null"
                                [attr.rel]="it.external ? 'noopener noreferrer' : null"
                                (click)="closed.emit()"
                            >
                                <span class="mob-num">{{ pad(i + 1) }}</span>
                                <span class="mob-text">{{ it.label }}</span>
                                <span class="mob-arrow" aria-hidden="true">&rarr;</span>
                            </a>
                        }
                    }
                </div>
            </div>
        </div>
    `, isInline: true, styles: [":host{display:contents}.overlay{position:fixed;inset:0;z-index:calc(var(--z-sticky, 500) - 1);padding-top:56px;background:var(--bg-overlay, rgba(255, 255, 255, .85));backdrop-filter:blur(24px) saturate(180%);-webkit-backdrop-filter:blur(24px) saturate(180%);opacity:0;visibility:hidden;transition:opacity var(--dur-base, .25s) var(--ease-out, ease),visibility 0s var(--dur-base, .25s);display:none}.overlay.is-open{opacity:1;visibility:visible;transition:opacity var(--dur-base, .25s) var(--ease-out, ease),visibility 0s}.sheet{display:flex;flex-direction:column;justify-content:space-between;height:100%;padding:var(--sp-6, 1.5rem) var(--sp-4, 1rem);overflow-y:auto}.mob-nav{display:flex;flex-direction:column;gap:var(--sp-2, .5rem)}.mob-link{display:flex;align-items:center;gap:var(--sp-4, 1rem);width:100%;padding:var(--sp-4, 1rem) var(--sp-5, 1.25rem);text-align:start;text-decoration:none;background:transparent;border:1px solid transparent;border-radius:var(--r-lg, 16px);cursor:pointer;transition:background var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease)}.mob-link:hover,.mob-link:active{background:var(--brand-soft, #ede9fe);border-color:var(--brand, #6d28d9)}.mob-link:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.mob-num{display:grid;place-items:center;width:36px;height:36px;border-radius:var(--r-full, 999px);background:var(--bg-mute, #f0f0f2);border:1px solid var(--border, #e5e5e9);font-family:var(--font-mono, \"JetBrains Mono\", monospace);font-size:var(--fs-xs, .75rem);font-weight:var(--fw-semi, 600);color:var(--text-dim, #8e8ea0);flex-shrink:0;transition:background var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease)}.mob-link:hover .mob-num,.mob-link:active .mob-num{background:var(--brand, #6d28d9);color:var(--brand-text, #fff);border-color:var(--brand, #6d28d9)}.mob-text{flex:1;font-family:var(--font-brand, \"Space Grotesk\", system-ui, sans-serif);font-size:var(--fs-xl, 1.25rem);font-weight:var(--fw-semi, 600);color:var(--text, #09090f);letter-spacing:var(--ls-snug, -.01em)}.mob-link:hover .mob-text,.mob-link:active .mob-text{color:var(--brand-strong, #5b21b6)}.mob-link.is-cta .mob-num{background:var(--brand-soft, #ede9fe);color:var(--brand, #6d28d9);border-color:var(--brand, #6d28d9)}.mob-link.is-cta .mob-text{color:var(--brand, #6d28d9)}.mob-arrow{font-size:var(--fs-xl, 1.25rem);color:var(--text-dim, #8e8ea0);opacity:0;transform:translate(-8px);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease)}.mob-link:hover .mob-arrow,.mob-link:active .mob-arrow{opacity:1;transform:translate(0);color:var(--brand, #6d28d9)}.acc-head{gap:var(--sp-4, 1rem)}.acc-chev{color:var(--text-dim, #8e8ea0);flex-shrink:0;transition:transform var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease)}.acc.is-open .acc-chev{transform:rotate(180deg);color:var(--brand, #6d28d9)}.acc-body{display:grid;grid-template-rows:0fr;transition:grid-template-rows var(--dur-base, .25s) var(--ease-out, ease)}.acc.is-open .acc-body{grid-template-rows:1fr}.acc-inner{min-height:0;overflow:hidden}.acc-link{display:flex;align-items:center;gap:var(--sp-3, .75rem);padding:var(--sp-3, .75rem) var(--sp-5, 1.25rem);margin-left:calc(36px + var(--sp-4, 1rem));text-decoration:none;border-radius:var(--r-md, 12px);transition:background var(--dur-fast, .15s) var(--ease-out, ease)}.acc-link:hover{background:var(--bg-mute, #f0f0f2)}.acc-link:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.acc-dot{width:6px;height:6px;border-radius:var(--r-full, 999px);background:var(--text-dim, #8e8ea0);flex-shrink:0;transition:background var(--dur-fast, .15s) var(--ease-out, ease)}.acc-link:hover .acc-dot{background:var(--brand, #6d28d9)}.acc-text{font-family:var(--font-display, system-ui, sans-serif);font-size:var(--fs-base, 1rem);font-weight:var(--fw-medium, 500);color:var(--text-mute, #5c5c6d)}.acc-link:hover .acc-text{color:var(--text, #09090f)}.sheet-bottom{display:flex;align-items:center;justify-content:center;gap:var(--sp-3, .75rem);padding:var(--sp-6, 1.5rem) 0 var(--sp-2, .5rem);margin-top:var(--sp-4, 1rem);border-top:1px solid var(--border, #e5e5e9)}@media(max-width:720px){.overlay{display:block}}@media(prefers-reduced-motion:reduce){.acc-chev,.acc-body,.mob-arrow,.overlay{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: NavMobile, decorators: [{
            type: Component,
            args: [{ selector: 'ik-nav-mobile', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <!-- Mobile overlay. Closed via the top-bar menu toggle (which is itself an ✕ while open),
             a backdrop click, or Esc (document:keydown.escape host listener) — so the overlay
             carries NO separate close chip of its own. -->
        <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
        <div class="overlay" [class.is-open]="open()" (click)="closed.emit()">
            <div class="sheet">
                <!-- Non-interactive wrapper: stops sheet clicks from bubbling to the backdrop. -->
                <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
                <div class="mob-nav" (click)="$event.stopPropagation()">
                    @for (it of items(); track it.key; let i = $index) {
                        @if (it.children.length) {
                            <div class="acc" [class.is-open]="openGroups().has(it.key)">
                                <button
                                    type="button"
                                    class="mob-link acc-head"
                                    [class.is-cta]="it.item.cta"
                                    (click)="toggleGroup(it.key)"
                                    [attr.aria-expanded]="openGroups().has(it.key)"
                                >
                                    <span class="mob-num">{{ pad(i + 1) }}</span>
                                    <span class="mob-text">{{ it.label }}</span>
                                    <svg
                                        class="acc-chev"
                                        width="18"
                                        height="18"
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor"
                                        stroke-width="2.5"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        aria-hidden="true"
                                    >
                                        <path d="M6 9l6 6 6-6" />
                                    </svg>
                                </button>
                                <div class="acc-body">
                                    <div class="acc-inner">
                                        @for (ch of it.children; track ch.key) {
                                            <a
                                                class="acc-link"
                                                [href]="ch.href"
                                                [attr.target]="ch.external ? '_blank' : null"
                                                [attr.rel]="ch.external ? 'noopener noreferrer' : null"
                                                (click)="closed.emit()"
                                            >
                                                <span class="acc-dot" aria-hidden="true"></span>
                                                <span class="acc-text">{{ ch.label }}</span>
                                            </a>
                                        }
                                    </div>
                                </div>
                            </div>
                        } @else {
                            <a
                                class="mob-link"
                                [class.is-cta]="it.item.cta"
                                [href]="it.href"
                                [attr.target]="it.external ? '_blank' : null"
                                [attr.rel]="it.external ? 'noopener noreferrer' : null"
                                (click)="closed.emit()"
                            >
                                <span class="mob-num">{{ pad(i + 1) }}</span>
                                <span class="mob-text">{{ it.label }}</span>
                                <span class="mob-arrow" aria-hidden="true">&rarr;</span>
                            </a>
                        }
                    }
                </div>
            </div>
        </div>
    `, styles: [":host{display:contents}.overlay{position:fixed;inset:0;z-index:calc(var(--z-sticky, 500) - 1);padding-top:56px;background:var(--bg-overlay, rgba(255, 255, 255, .85));backdrop-filter:blur(24px) saturate(180%);-webkit-backdrop-filter:blur(24px) saturate(180%);opacity:0;visibility:hidden;transition:opacity var(--dur-base, .25s) var(--ease-out, ease),visibility 0s var(--dur-base, .25s);display:none}.overlay.is-open{opacity:1;visibility:visible;transition:opacity var(--dur-base, .25s) var(--ease-out, ease),visibility 0s}.sheet{display:flex;flex-direction:column;justify-content:space-between;height:100%;padding:var(--sp-6, 1.5rem) var(--sp-4, 1rem);overflow-y:auto}.mob-nav{display:flex;flex-direction:column;gap:var(--sp-2, .5rem)}.mob-link{display:flex;align-items:center;gap:var(--sp-4, 1rem);width:100%;padding:var(--sp-4, 1rem) var(--sp-5, 1.25rem);text-align:start;text-decoration:none;background:transparent;border:1px solid transparent;border-radius:var(--r-lg, 16px);cursor:pointer;transition:background var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease)}.mob-link:hover,.mob-link:active{background:var(--brand-soft, #ede9fe);border-color:var(--brand, #6d28d9)}.mob-link:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.mob-num{display:grid;place-items:center;width:36px;height:36px;border-radius:var(--r-full, 999px);background:var(--bg-mute, #f0f0f2);border:1px solid var(--border, #e5e5e9);font-family:var(--font-mono, \"JetBrains Mono\", monospace);font-size:var(--fs-xs, .75rem);font-weight:var(--fw-semi, 600);color:var(--text-dim, #8e8ea0);flex-shrink:0;transition:background var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease)}.mob-link:hover .mob-num,.mob-link:active .mob-num{background:var(--brand, #6d28d9);color:var(--brand-text, #fff);border-color:var(--brand, #6d28d9)}.mob-text{flex:1;font-family:var(--font-brand, \"Space Grotesk\", system-ui, sans-serif);font-size:var(--fs-xl, 1.25rem);font-weight:var(--fw-semi, 600);color:var(--text, #09090f);letter-spacing:var(--ls-snug, -.01em)}.mob-link:hover .mob-text,.mob-link:active .mob-text{color:var(--brand-strong, #5b21b6)}.mob-link.is-cta .mob-num{background:var(--brand-soft, #ede9fe);color:var(--brand, #6d28d9);border-color:var(--brand, #6d28d9)}.mob-link.is-cta .mob-text{color:var(--brand, #6d28d9)}.mob-arrow{font-size:var(--fs-xl, 1.25rem);color:var(--text-dim, #8e8ea0);opacity:0;transform:translate(-8px);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease)}.mob-link:hover .mob-arrow,.mob-link:active .mob-arrow{opacity:1;transform:translate(0);color:var(--brand, #6d28d9)}.acc-head{gap:var(--sp-4, 1rem)}.acc-chev{color:var(--text-dim, #8e8ea0);flex-shrink:0;transition:transform var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease)}.acc.is-open .acc-chev{transform:rotate(180deg);color:var(--brand, #6d28d9)}.acc-body{display:grid;grid-template-rows:0fr;transition:grid-template-rows var(--dur-base, .25s) var(--ease-out, ease)}.acc.is-open .acc-body{grid-template-rows:1fr}.acc-inner{min-height:0;overflow:hidden}.acc-link{display:flex;align-items:center;gap:var(--sp-3, .75rem);padding:var(--sp-3, .75rem) var(--sp-5, 1.25rem);margin-left:calc(36px + var(--sp-4, 1rem));text-decoration:none;border-radius:var(--r-md, 12px);transition:background var(--dur-fast, .15s) var(--ease-out, ease)}.acc-link:hover{background:var(--bg-mute, #f0f0f2)}.acc-link:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.acc-dot{width:6px;height:6px;border-radius:var(--r-full, 999px);background:var(--text-dim, #8e8ea0);flex-shrink:0;transition:background var(--dur-fast, .15s) var(--ease-out, ease)}.acc-link:hover .acc-dot{background:var(--brand, #6d28d9)}.acc-text{font-family:var(--font-display, system-ui, sans-serif);font-size:var(--fs-base, 1rem);font-weight:var(--fw-medium, 500);color:var(--text-mute, #5c5c6d)}.acc-link:hover .acc-text{color:var(--text, #09090f)}.sheet-bottom{display:flex;align-items:center;justify-content:center;gap:var(--sp-3, .75rem);padding:var(--sp-6, 1.5rem) 0 var(--sp-2, .5rem);margin-top:var(--sp-4, 1rem);border-top:1px solid var(--border, #e5e5e9)}@media(max-width:720px){.overlay{display:block}}@media(prefers-reduced-motion:reduce){.acc-chev,.acc-body,.mob-arrow,.overlay{transition:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { open: [{ type: i0.Input, args: [{ isSignal: true, alias: "open", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], closed: [{ type: i0.Output, args: ["closed"] }] } });

/**
 * Resolve a single config nav item (and its children, recursively) into a
 * {@link ResolvedNavItem}: locale-aware href, externality and label baked in.
 * Pure — no DI, so it can be reused by `<ik-nav>` and shared helpers alike.
 */
function resolveNavItem(item, lang, key, defaultLang = 'en') {
    const href = resolveLinkHref(item, lang, defaultLang);
    const external = item.external ?? /^https?:\/\//i.test(href);
    const children = (item.children ?? []).map((ch, j) => resolveNavItem(ch, lang, `${key}.${j}`, defaultLang));
    const label = localizeText(item.label, lang, defaultLang) ?? '';
    return { item, label, href, external, children, key };
}

/**
 * Shared site navigation — fixed glass topbar with brand, a desktop link row
 * (CTA highlight + hover/focus dropdowns) and a full-screen mobile overlay with
 * numbered links, hover-in arrows and expandable accordion sections.
 *
 * Items come from `config.nav`; hrefs are resolved locale-aware against `lang`.
 * Right-side controls are projected so the host drops in its own switchers:
 *
 * ```html
 * <ik-nav [lang]="translate.currentLang">
 *   <ik-lang-switcher slot="actions" />
 *   <ik-theme-toggle slot="actions" />
 * </ik-nav>
 * ```
 */
class Nav {
    host = inject((ElementRef));
    cfg = inject(SITE_KIT_CONFIG);
    sanitizer = inject(DomSanitizer);
    /** Trusted inline brand glyph (rendered in an inverted mark, like the reference topbar). */
    brandGlyph = computed(() => {
        const g = this.cfg.brand.glyph;
        return g ? this.sanitizer.bypassSecurityTrustHtml(g) : null;
    }, ...(ngDevMode ? [{ debugName: "brandGlyph" }] : /* istanbul ignore next */ []));
    /** Active language code; host binds `[lang]="translate.currentLang"`. */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Pin the bar to the top of the viewport. */
    sticky = input(true, ...(ngDevMode ? [{ debugName: "sticky" }] : /* istanbul ignore next */ []));
    /**
     * Use a consumer-projected brand instead of the config brand mark — project the
     * element via `<… slot="brand">`. For apps whose logo is bespoke or stateful
     * (e.g. an SVG tinted by a live status) that the config brand can't express.
     */
    customBrand = input(false, ...(ngDevMode ? [{ debugName: "customBrand" }] : /* istanbul ignore next */ []));
    menuOpen = signal(false, ...(ngDevMode ? [{ debugName: "menuOpen" }] : /* istanbul ignore next */ []));
    activeLang = computed(() => this.lang() ?? this.cfg.defaultLang, ...(ngDevMode ? [{ debugName: "activeLang" }] : /* istanbul ignore next */ []));
    monogram = computed(() => this.cfg.brand.monogram ?? this.cfg.brand.name.charAt(0), ...(ngDevMode ? [{ debugName: "monogram" }] : /* istanbul ignore next */ []));
    items = computed(() => {
        const lang = this.activeLang();
        return this.cfg.nav.map((item, i) => resolveNavItem(item, lang, String(i), this.cfg.defaultLang));
    }, ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    /** Localized UI string for the active language (with per-app overrides). */
    t(key) {
        return chromeString(this.activeLang(), key, this.cfg.strings);
    }
    toggle(event) {
        event.stopPropagation();
        this.menuOpen.set(!this.menuOpen());
    }
    onDocClick(event) {
        const target = event.target;
        if (this.menuOpen() && target instanceof Node && !this.host.nativeElement.contains(target)) {
            this.menuOpen.set(false);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Nav, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: Nav, isStandalone: true, selector: "ik-nav", inputs: { lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, sticky: { classPropertyName: "sticky", publicName: "sticky", isSignal: true, isRequired: false, transformFunction: null }, customBrand: { classPropertyName: "customBrand", publicName: "customBrand", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "document:click": "onDocClick($event)", "document:keydown.escape": "menuOpen.set(false)" }, classAttribute: "ik-nav" }, ngImport: i0, template: `
        <nav class="bar" [class.is-sticky]="sticky()" aria-label="Primary">
            <div class="inner">
                <!-- Brand: a consumer-projected element ([customBrand]) for bespoke/stateful
                     logos, else the config-driven brand mark. -->
                @if (customBrand()) {
                    <ng-content select="[slot=brand]" />
                } @else {
                    <a class="brand" [href]="cfg.brand.url || '/'" aria-label="{{ cfg.brand.name }}">
                        @if (brandGlyph(); as g) {
                            <span
                                class="brand-mono brand-mono--glyph"
                                aria-hidden="true"
                                [innerHTML]="g"
                            ></span>
                            @if (!cfg.brand.nameHidden) {
                                <span class="brand-name">{{ cfg.brand.name }}</span>
                            }
                        } @else if (cfg.brand.logoUrl; as logo) {
                            <img class="brand-logo" [src]="logo" [alt]="cfg.brand.name" height="28" />
                            @if (!cfg.brand.nameHidden) {
                                <span class="brand-name">{{ cfg.brand.name }}</span>
                            }
                        } @else {
                            <span class="brand-mono" aria-hidden="true">{{ monogram() }}</span>
                            @if (!cfg.brand.nameHidden) {
                                <span class="brand-name">{{ cfg.brand.name }}</span>
                            }
                        }
                    </a>
                }

                <!-- Desktop nav -->
                @if (items().length) {
                    <div class="nav-desktop">
                        @for (it of items(); track it.key) {
                            @if (it.children.length) {
                                <div class="has-dd">
                                    <button
                                        type="button"
                                        class="nav-link nav-trigger"
                                        [class.is-cta]="it.item.cta"
                                        aria-haspopup="true"
                                        [attr.aria-expanded]="false"
                                    >
                                        {{ it.label }}
                                        <svg
                                            class="chev"
                                            width="12"
                                            height="12"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2.5"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            aria-hidden="true"
                                        >
                                            <path d="M6 9l6 6 6-6" />
                                        </svg>
                                    </button>
                                    <div class="dd" role="menu">
                                        @for (ch of it.children; track ch.key) {
                                            <a
                                                class="dd-link"
                                                role="menuitem"
                                                [href]="ch.href"
                                                [attr.target]="ch.external ? '_blank' : null"
                                                [attr.rel]="ch.external ? 'noopener noreferrer' : null"
                                                >{{ ch.label }}</a
                                            >
                                        }
                                    </div>
                                </div>
                            } @else {
                                <a
                                    class="nav-link"
                                    [class.is-cta]="it.item.cta"
                                    [href]="it.href"
                                    [attr.target]="it.external ? '_blank' : null"
                                    [attr.rel]="it.external ? 'noopener noreferrer' : null"
                                    >{{ it.label }}</a
                                >
                            }
                        }
                    </div>
                }

                <!-- Right controls -->
                <div class="ctrls">
                    <span class="actions"><ng-content select="[slot=actions]" /></span>
                    @if (items().length) {
                        <button
                            type="button"
                            class="burger"
                            (click)="toggle($event)"
                            [attr.aria-expanded]="menuOpen()"
                            [attr.aria-label]="t('menu')"
                        >
                            @if (menuOpen()) {
                                <svg
                                    width="18"
                                    height="18"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    aria-hidden="true"
                                >
                                    <path d="M6 6l12 12M18 6L6 18" />
                                </svg>
                            } @else {
                                <svg
                                    width="18"
                                    height="18"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    aria-hidden="true"
                                >
                                    <path d="M4 7h16M4 12h16M4 17h16" />
                                </svg>
                            }
                        </button>
                    }
                </div>
            </div>
        </nav>

        <ik-nav-mobile [open]="menuOpen()" [items]="items()" [lang]="lang()" (closed)="menuOpen.set(false)" />
    `, isInline: true, styles: [":host{display:block}.bar{top:0;left:0;right:0;z-index:var(--z-sticky, 500);height:56px;background:var(--bg-overlay, rgba(255, 255, 255, .7));backdrop-filter:blur(12px) saturate(160%);-webkit-backdrop-filter:blur(12px) saturate(160%);border-bottom:1px solid var(--border, #e5e5e9)}.bar.is-sticky{position:fixed}.inner{display:flex;align-items:center;gap:var(--sp-6, 1.5rem);max-width:var(--container-wide, 84rem);margin-inline:auto;padding:0 var(--sp-6, 1.5rem);height:56px}.brand{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);color:var(--text, #09090f);text-decoration:none;flex-shrink:0}.brand-logo{display:block;height:28px;width:auto}.brand-mono{display:grid;place-items:center;width:28px;height:28px;border-radius:var(--r-sm, 8px);background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );color:var(--brand-text, #fff);font-family:var(--font-brand, \"Space Grotesk\", system-ui, sans-serif);font-size:14px;font-weight:var(--fw-bold, 700);line-height:1}.brand-mono--glyph{background:var(--text, #09090f);color:var(--bg, #fff)}.brand-mono--glyph ::ng-deep svg{display:block;width:60%;height:60%}.brand-name{font-family:var(--font-brand, \"Space Grotesk\", system-ui, sans-serif);font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-bold, 700);letter-spacing:var(--ls-tight, -.025em);line-height:1}.nav-desktop{display:flex;align-items:center;gap:var(--sp-1, .25rem);flex:1}.has-dd{position:relative}.nav-link{display:inline-flex;align-items:center;gap:var(--sp-1, .25rem);padding:var(--sp-2, .5rem) var(--sp-3, .75rem);font-family:var(--font-display, system-ui, sans-serif);font-size:var(--fs-sm, .875rem);font-weight:var(--fw-medium, 500);color:var(--text-mute, #5c5c6d);text-decoration:none;border-radius:var(--r-sm, 8px);letter-spacing:var(--ls-snug, -.01em);background:transparent;border:0;cursor:pointer;transition:color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease)}.nav-link:hover,.nav-trigger:focus-visible{color:var(--text, #09090f);background:var(--bg-mute, #f0f0f2)}.nav-link:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.nav-link.is-cta{color:var(--brand, #6d28d9);font-weight:var(--fw-bold, 700)}.nav-link.is-cta:hover{color:var(--brand-strong, #5b21b6);background:var(--brand-soft, #ede9fe)}.chev{transition:transform var(--dur-fast, .15s) var(--ease-out, ease)}.has-dd:hover .chev,.has-dd:focus-within .chev{transform:rotate(180deg)}.dd{position:absolute;top:calc(100% + var(--sp-2, .5rem));left:0;min-width:13rem;padding:var(--sp-2, .5rem);display:flex;flex-direction:column;gap:2px;background:var(--bg-elev, #fff);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);box-shadow:var(--shadow-md, 0 8px 24px rgba(9, 9, 15, .08));opacity:0;visibility:hidden;transform:translateY(-6px);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),visibility 0s var(--dur-fast, .15s);z-index:var(--z-dropdown, 100)}.has-dd:hover .dd,.has-dd:focus-within .dd{opacity:1;visibility:visible;transform:translateY(0);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),visibility 0s}.dd-link{padding:var(--sp-2, .5rem) var(--sp-3, .75rem);font-family:var(--font-display, system-ui, sans-serif);font-size:var(--fs-sm, .875rem);font-weight:var(--fw-medium, 500);color:var(--text-mute, #5c5c6d);text-decoration:none;border-radius:var(--r-sm, 8px);transition:color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease)}.dd-link:hover{color:var(--brand, #6d28d9);background:var(--bg-mute, #f0f0f2)}.dd-link:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.ctrls{display:flex;align-items:center;gap:var(--sp-2, .5rem);margin-left:auto}.actions{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem)}.burger{display:none;align-items:center;justify-content:center;width:32px;height:32px;color:var(--text-mute, #5c5c6d);background:transparent;border:0;border-radius:var(--r-xs, 6px);cursor:pointer;transition:background var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease)}.burger:hover{background:var(--bg-mute, #f0f0f2);color:var(--text, #09090f)}.burger:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}@media(max-width:720px){.inner{gap:var(--sp-3, .75rem);padding:0 var(--sp-4, 1rem)}.nav-desktop{display:none}.burger{display:inline-flex}}@media(prefers-reduced-motion:reduce){.chev,.dd{transition:none}}\n"], dependencies: [{ kind: "component", type: NavMobile, selector: "ik-nav-mobile", inputs: ["open", "items", "lang"], outputs: ["closed"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Nav, decorators: [{
            type: Component,
            args: [{ selector: 'ik-nav', standalone: true, imports: [NavMobile], changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <nav class="bar" [class.is-sticky]="sticky()" aria-label="Primary">
            <div class="inner">
                <!-- Brand: a consumer-projected element ([customBrand]) for bespoke/stateful
                     logos, else the config-driven brand mark. -->
                @if (customBrand()) {
                    <ng-content select="[slot=brand]" />
                } @else {
                    <a class="brand" [href]="cfg.brand.url || '/'" aria-label="{{ cfg.brand.name }}">
                        @if (brandGlyph(); as g) {
                            <span
                                class="brand-mono brand-mono--glyph"
                                aria-hidden="true"
                                [innerHTML]="g"
                            ></span>
                            @if (!cfg.brand.nameHidden) {
                                <span class="brand-name">{{ cfg.brand.name }}</span>
                            }
                        } @else if (cfg.brand.logoUrl; as logo) {
                            <img class="brand-logo" [src]="logo" [alt]="cfg.brand.name" height="28" />
                            @if (!cfg.brand.nameHidden) {
                                <span class="brand-name">{{ cfg.brand.name }}</span>
                            }
                        } @else {
                            <span class="brand-mono" aria-hidden="true">{{ monogram() }}</span>
                            @if (!cfg.brand.nameHidden) {
                                <span class="brand-name">{{ cfg.brand.name }}</span>
                            }
                        }
                    </a>
                }

                <!-- Desktop nav -->
                @if (items().length) {
                    <div class="nav-desktop">
                        @for (it of items(); track it.key) {
                            @if (it.children.length) {
                                <div class="has-dd">
                                    <button
                                        type="button"
                                        class="nav-link nav-trigger"
                                        [class.is-cta]="it.item.cta"
                                        aria-haspopup="true"
                                        [attr.aria-expanded]="false"
                                    >
                                        {{ it.label }}
                                        <svg
                                            class="chev"
                                            width="12"
                                            height="12"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2.5"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            aria-hidden="true"
                                        >
                                            <path d="M6 9l6 6 6-6" />
                                        </svg>
                                    </button>
                                    <div class="dd" role="menu">
                                        @for (ch of it.children; track ch.key) {
                                            <a
                                                class="dd-link"
                                                role="menuitem"
                                                [href]="ch.href"
                                                [attr.target]="ch.external ? '_blank' : null"
                                                [attr.rel]="ch.external ? 'noopener noreferrer' : null"
                                                >{{ ch.label }}</a
                                            >
                                        }
                                    </div>
                                </div>
                            } @else {
                                <a
                                    class="nav-link"
                                    [class.is-cta]="it.item.cta"
                                    [href]="it.href"
                                    [attr.target]="it.external ? '_blank' : null"
                                    [attr.rel]="it.external ? 'noopener noreferrer' : null"
                                    >{{ it.label }}</a
                                >
                            }
                        }
                    </div>
                }

                <!-- Right controls -->
                <div class="ctrls">
                    <span class="actions"><ng-content select="[slot=actions]" /></span>
                    @if (items().length) {
                        <button
                            type="button"
                            class="burger"
                            (click)="toggle($event)"
                            [attr.aria-expanded]="menuOpen()"
                            [attr.aria-label]="t('menu')"
                        >
                            @if (menuOpen()) {
                                <svg
                                    width="18"
                                    height="18"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    aria-hidden="true"
                                >
                                    <path d="M6 6l12 12M18 6L6 18" />
                                </svg>
                            } @else {
                                <svg
                                    width="18"
                                    height="18"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    aria-hidden="true"
                                >
                                    <path d="M4 7h16M4 12h16M4 17h16" />
                                </svg>
                            }
                        </button>
                    }
                </div>
            </div>
        </nav>

        <ik-nav-mobile [open]="menuOpen()" [items]="items()" [lang]="lang()" (closed)="menuOpen.set(false)" />
    `, host: {
                        class: 'ik-nav',
                        '(document:click)': 'onDocClick($event)',
                        '(document:keydown.escape)': 'menuOpen.set(false)',
                    }, styles: [":host{display:block}.bar{top:0;left:0;right:0;z-index:var(--z-sticky, 500);height:56px;background:var(--bg-overlay, rgba(255, 255, 255, .7));backdrop-filter:blur(12px) saturate(160%);-webkit-backdrop-filter:blur(12px) saturate(160%);border-bottom:1px solid var(--border, #e5e5e9)}.bar.is-sticky{position:fixed}.inner{display:flex;align-items:center;gap:var(--sp-6, 1.5rem);max-width:var(--container-wide, 84rem);margin-inline:auto;padding:0 var(--sp-6, 1.5rem);height:56px}.brand{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);color:var(--text, #09090f);text-decoration:none;flex-shrink:0}.brand-logo{display:block;height:28px;width:auto}.brand-mono{display:grid;place-items:center;width:28px;height:28px;border-radius:var(--r-sm, 8px);background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );color:var(--brand-text, #fff);font-family:var(--font-brand, \"Space Grotesk\", system-ui, sans-serif);font-size:14px;font-weight:var(--fw-bold, 700);line-height:1}.brand-mono--glyph{background:var(--text, #09090f);color:var(--bg, #fff)}.brand-mono--glyph ::ng-deep svg{display:block;width:60%;height:60%}.brand-name{font-family:var(--font-brand, \"Space Grotesk\", system-ui, sans-serif);font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-bold, 700);letter-spacing:var(--ls-tight, -.025em);line-height:1}.nav-desktop{display:flex;align-items:center;gap:var(--sp-1, .25rem);flex:1}.has-dd{position:relative}.nav-link{display:inline-flex;align-items:center;gap:var(--sp-1, .25rem);padding:var(--sp-2, .5rem) var(--sp-3, .75rem);font-family:var(--font-display, system-ui, sans-serif);font-size:var(--fs-sm, .875rem);font-weight:var(--fw-medium, 500);color:var(--text-mute, #5c5c6d);text-decoration:none;border-radius:var(--r-sm, 8px);letter-spacing:var(--ls-snug, -.01em);background:transparent;border:0;cursor:pointer;transition:color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease)}.nav-link:hover,.nav-trigger:focus-visible{color:var(--text, #09090f);background:var(--bg-mute, #f0f0f2)}.nav-link:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.nav-link.is-cta{color:var(--brand, #6d28d9);font-weight:var(--fw-bold, 700)}.nav-link.is-cta:hover{color:var(--brand-strong, #5b21b6);background:var(--brand-soft, #ede9fe)}.chev{transition:transform var(--dur-fast, .15s) var(--ease-out, ease)}.has-dd:hover .chev,.has-dd:focus-within .chev{transform:rotate(180deg)}.dd{position:absolute;top:calc(100% + var(--sp-2, .5rem));left:0;min-width:13rem;padding:var(--sp-2, .5rem);display:flex;flex-direction:column;gap:2px;background:var(--bg-elev, #fff);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);box-shadow:var(--shadow-md, 0 8px 24px rgba(9, 9, 15, .08));opacity:0;visibility:hidden;transform:translateY(-6px);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),visibility 0s var(--dur-fast, .15s);z-index:var(--z-dropdown, 100)}.has-dd:hover .dd,.has-dd:focus-within .dd{opacity:1;visibility:visible;transform:translateY(0);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),visibility 0s}.dd-link{padding:var(--sp-2, .5rem) var(--sp-3, .75rem);font-family:var(--font-display, system-ui, sans-serif);font-size:var(--fs-sm, .875rem);font-weight:var(--fw-medium, 500);color:var(--text-mute, #5c5c6d);text-decoration:none;border-radius:var(--r-sm, 8px);transition:color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease)}.dd-link:hover{color:var(--brand, #6d28d9);background:var(--bg-mute, #f0f0f2)}.dd-link:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.ctrls{display:flex;align-items:center;gap:var(--sp-2, .5rem);margin-left:auto}.actions{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem)}.burger{display:none;align-items:center;justify-content:center;width:32px;height:32px;color:var(--text-mute, #5c5c6d);background:transparent;border:0;border-radius:var(--r-xs, 6px);cursor:pointer;transition:background var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease)}.burger:hover{background:var(--bg-mute, #f0f0f2);color:var(--text, #09090f)}.burger:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}@media(max-width:720px){.inner{gap:var(--sp-3, .75rem);padding:0 var(--sp-4, 1rem)}.nav-desktop{display:none}.burger{display:inline-flex}}@media(prefers-reduced-motion:reduce){.chev,.dd{transition:none}}\n"] }]
        }], propDecorators: { lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], sticky: [{ type: i0.Input, args: [{ isSignal: true, alias: "sticky", required: false }] }], customBrand: [{ type: i0.Input, args: [{ isSignal: true, alias: "customBrand", required: false }] }] } });

/** Single-letter monogram from a project name — first non-blank char, uppercased, '·' when empty. */
function monogramOf(name) {
    return (name.trim()[0] ?? '·').toUpperCase();
}
/** Short, single-word status label for a project ('' when no status). */
const STATUS_LABELS = {
    live: 'Live',
    wip: 'WIP',
    archived: 'Archived',
};
function statusLabelOf(status) {
    return status ? STATUS_LABELS[status] : '';
}
/**
 * "Our projects" directory — a responsive grid of project cards driven by
 * `config.projects` (`SiteKitProject[]`).
 *
 * Each card is a locale-aware link (urls?.[lang] → localize → url). Cards show a
 * logo or a brand-gradient monogram, the name, a 2-line-clamped description,
 * tag chips, and a colour-coded status badge (live / wip / archived). Renders
 * nothing when there are no projects.
 *
 * ```html
 * <ik-projects [lang]="translate.currentLang" heading="What we build" />
 * <ik-projects [columns]="3" />
 * ```
 */
class Projects {
    cfg = inject(SITE_KIT_CONFIG);
    /** Active language for locale-aware links. Defaults to the config default. */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Optional section title rendered above the grid. */
    heading = input(...(ngDevMode ? [undefined, { debugName: "heading" }] : /* istanbul ignore next */ []));
    /** Fixed column count; omit for responsive auto-fill. */
    columns = input(...(ngDevMode ? [undefined, { debugName: "columns" }] : /* istanbul ignore next */ []));
    activeLang = computed(() => this.lang() ?? this.cfg.defaultLang, ...(ngDevMode ? [{ debugName: "activeLang" }] : /* istanbul ignore next */ []));
    /** Localized aria-label for the per-project tag list. */
    tagsLabel = computed(() => chromeString(this.activeLang(), 'tags', this.cfg.strings), ...(ngDevMode ? [{ debugName: "tagsLabel" }] : /* istanbul ignore next */ []));
    projects = computed(() => {
        const lang = this.activeLang();
        const defaultLang = this.cfg.defaultLang;
        return this.cfg.projects.map((project) => {
            const href = project.urls?.[lang] ??
                (project.localize ? localizeUrl(project.url, lang, { defaultLang }) : project.url);
            return {
                project,
                href,
                external: /^https?:\/\//i.test(href),
                monogram: monogramOf(project.name),
                statusLabel: statusLabelOf(project.status),
            };
        });
    }, ...(ngDevMode ? [{ debugName: "projects" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Projects, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: Projects, isStandalone: true, selector: "ik-projects", inputs: { lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, heading: { classPropertyName: "heading", publicName: "heading", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ik-projects" }, ngImport: i0, template: `
        @if (projects().length) {
            <section class="wrap">
                @if (heading()) {
                    <h2 class="heading">{{ heading() }}</h2>
                }

                <ul
                    class="grid"
                    [style.grid-template-columns]="
                        columns() ? 'repeat(' + columns() + ', minmax(0, 1fr))' : null
                    "
                >
                    @for (item of projects(); track item.project.url) {
                        <li>
                            <a
                                class="card"
                                [href]="item.href"
                                [attr.target]="item.external ? '_blank' : null"
                                [attr.rel]="item.external ? 'noopener noreferrer' : null"
                            >
                                <div class="top">
                                    <span class="logo">
                                        @if (item.project.logoUrl; as logo) {
                                            <img [src]="logo" [alt]="item.project.name" loading="lazy" />
                                        } @else {
                                            <span class="monogram" aria-hidden="true">{{
                                                item.monogram
                                            }}</span>
                                        }
                                    </span>

                                    @if (item.statusLabel) {
                                        <span class="badge" [attr.data-status]="item.project.status">{{
                                            item.statusLabel
                                        }}</span>
                                    }
                                </div>

                                <h3 class="name">{{ item.project.name }}</h3>

                                @if (item.project.description; as desc) {
                                    <p class="desc">{{ desc }}</p>
                                }

                                @if (item.project.tags?.length) {
                                    <ul class="tags" [attr.aria-label]="tagsLabel()">
                                        @for (tag of item.project.tags; track tag) {
                                            <li class="chip">{{ tag }}</li>
                                        }
                                    </ul>
                                }
                            </a>
                        </li>
                    }
                </ul>
            </section>
        }
    `, isInline: true, styles: [":host{display:block}.wrap{max-width:var(--container, 72rem);margin-inline:auto;padding:var(--sp-8, 2rem) var(--gutter, 1.5rem);font-family:var(--font-display, system-ui, sans-serif)}.heading{margin:0 0 var(--sp-6, 1.5rem);font-family:var(--font-brand, var(--font-display, system-ui, sans-serif));font-size:var(--fs-2xl, 1.5rem);font-weight:var(--fw-bold, 700);letter-spacing:var(--ls-tight, -.025em);color:var(--text, #09090f)}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,16rem),1fr));gap:var(--sp-4, 1rem);margin:0;padding:0;list-style:none}.card{display:flex;flex-direction:column;gap:var(--sp-3, .75rem);height:100%;box-sizing:border-box;padding:var(--sp-5, 1.25rem);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);background:var(--bg-elev, #fff);color:var(--text, #09090f);text-decoration:none;transition:transform var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),box-shadow var(--dur-fast, .15s) var(--ease-out, ease)}.card:hover{transform:translateY(-3px);border-color:var(--border-strong, #cdcdd4);box-shadow:var(--shadow-md, 0 8px 24px rgba(9, 9, 15, .08))}.card:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.top{display:flex;align-items:center;justify-content:space-between;gap:var(--sp-2, .5rem)}.logo{display:inline-grid;place-items:center;width:2.75rem;height:2.75rem;flex:none;border-radius:var(--r-md, 12px);overflow:hidden}.logo img{display:block;width:100%;height:100%;object-fit:contain}.monogram{display:grid;place-items:center;width:100%;height:100%;border-radius:var(--r-md, 12px);background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );color:var(--text-on-brand, #fff);font-family:var(--font-brand, var(--font-display, system-ui, sans-serif));font-size:var(--fs-xl, 1.25rem);font-weight:var(--fw-bold, 700);line-height:1;text-transform:uppercase}.badge{flex:none;padding:.125rem var(--sp-2, .5rem);border-radius:var(--r-full, 999px);font-size:var(--fs-xs, .75rem);font-weight:var(--fw-semi, 600);letter-spacing:var(--ls-wide, .06em);text-transform:uppercase;line-height:1.5;color:var(--text-dim, #8e8ea0);background:var(--bg-sunk, #f3f3f5)}.badge[data-status=live]{color:var(--success, #16a34a);background:color-mix(in srgb,var(--success, #16a34a) 12%,transparent)}.badge[data-status=wip]{color:var(--accent-3, #ea580c);background:color-mix(in srgb,var(--accent-3, #ea580c) 12%,transparent)}.badge[data-status=archived]{color:var(--text-dim, #8e8ea0);background:var(--bg-sunk, #f3f3f5)}.name{margin:0;font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-semi, 600);letter-spacing:var(--ls-snug, -.01em);color:var(--text, #09090f)}.desc{margin:0;font-size:var(--fs-sm, .875rem);line-height:var(--lh-snug, 1.25);color:var(--text-mute, #5c5c6d);display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-clamp:2;overflow:hidden}.tags{display:flex;flex-wrap:wrap;gap:var(--sp-2, .5rem);margin:auto 0 0;padding:0;list-style:none}.chip{padding:.125rem var(--sp-2, .5rem);border-radius:var(--r-sm, 8px);border:1px solid var(--border-soft, #f0f0f2);background:var(--bg-sunk, #f3f3f5);font-size:var(--fs-xs, .75rem);color:var(--text-mute, #5c5c6d)}@media(prefers-reduced-motion:reduce){.card{transition:none}.card:hover{transform:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Projects, decorators: [{
            type: Component,
            args: [{ selector: 'ik-projects', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        @if (projects().length) {
            <section class="wrap">
                @if (heading()) {
                    <h2 class="heading">{{ heading() }}</h2>
                }

                <ul
                    class="grid"
                    [style.grid-template-columns]="
                        columns() ? 'repeat(' + columns() + ', minmax(0, 1fr))' : null
                    "
                >
                    @for (item of projects(); track item.project.url) {
                        <li>
                            <a
                                class="card"
                                [href]="item.href"
                                [attr.target]="item.external ? '_blank' : null"
                                [attr.rel]="item.external ? 'noopener noreferrer' : null"
                            >
                                <div class="top">
                                    <span class="logo">
                                        @if (item.project.logoUrl; as logo) {
                                            <img [src]="logo" [alt]="item.project.name" loading="lazy" />
                                        } @else {
                                            <span class="monogram" aria-hidden="true">{{
                                                item.monogram
                                            }}</span>
                                        }
                                    </span>

                                    @if (item.statusLabel) {
                                        <span class="badge" [attr.data-status]="item.project.status">{{
                                            item.statusLabel
                                        }}</span>
                                    }
                                </div>

                                <h3 class="name">{{ item.project.name }}</h3>

                                @if (item.project.description; as desc) {
                                    <p class="desc">{{ desc }}</p>
                                }

                                @if (item.project.tags?.length) {
                                    <ul class="tags" [attr.aria-label]="tagsLabel()">
                                        @for (tag of item.project.tags; track tag) {
                                            <li class="chip">{{ tag }}</li>
                                        }
                                    </ul>
                                }
                            </a>
                        </li>
                    }
                </ul>
            </section>
        }
    `, host: { class: 'ik-projects' }, styles: [":host{display:block}.wrap{max-width:var(--container, 72rem);margin-inline:auto;padding:var(--sp-8, 2rem) var(--gutter, 1.5rem);font-family:var(--font-display, system-ui, sans-serif)}.heading{margin:0 0 var(--sp-6, 1.5rem);font-family:var(--font-brand, var(--font-display, system-ui, sans-serif));font-size:var(--fs-2xl, 1.5rem);font-weight:var(--fw-bold, 700);letter-spacing:var(--ls-tight, -.025em);color:var(--text, #09090f)}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,16rem),1fr));gap:var(--sp-4, 1rem);margin:0;padding:0;list-style:none}.card{display:flex;flex-direction:column;gap:var(--sp-3, .75rem);height:100%;box-sizing:border-box;padding:var(--sp-5, 1.25rem);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);background:var(--bg-elev, #fff);color:var(--text, #09090f);text-decoration:none;transition:transform var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),box-shadow var(--dur-fast, .15s) var(--ease-out, ease)}.card:hover{transform:translateY(-3px);border-color:var(--border-strong, #cdcdd4);box-shadow:var(--shadow-md, 0 8px 24px rgba(9, 9, 15, .08))}.card:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.top{display:flex;align-items:center;justify-content:space-between;gap:var(--sp-2, .5rem)}.logo{display:inline-grid;place-items:center;width:2.75rem;height:2.75rem;flex:none;border-radius:var(--r-md, 12px);overflow:hidden}.logo img{display:block;width:100%;height:100%;object-fit:contain}.monogram{display:grid;place-items:center;width:100%;height:100%;border-radius:var(--r-md, 12px);background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );color:var(--text-on-brand, #fff);font-family:var(--font-brand, var(--font-display, system-ui, sans-serif));font-size:var(--fs-xl, 1.25rem);font-weight:var(--fw-bold, 700);line-height:1;text-transform:uppercase}.badge{flex:none;padding:.125rem var(--sp-2, .5rem);border-radius:var(--r-full, 999px);font-size:var(--fs-xs, .75rem);font-weight:var(--fw-semi, 600);letter-spacing:var(--ls-wide, .06em);text-transform:uppercase;line-height:1.5;color:var(--text-dim, #8e8ea0);background:var(--bg-sunk, #f3f3f5)}.badge[data-status=live]{color:var(--success, #16a34a);background:color-mix(in srgb,var(--success, #16a34a) 12%,transparent)}.badge[data-status=wip]{color:var(--accent-3, #ea580c);background:color-mix(in srgb,var(--accent-3, #ea580c) 12%,transparent)}.badge[data-status=archived]{color:var(--text-dim, #8e8ea0);background:var(--bg-sunk, #f3f3f5)}.name{margin:0;font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-semi, 600);letter-spacing:var(--ls-snug, -.01em);color:var(--text, #09090f)}.desc{margin:0;font-size:var(--fs-sm, .875rem);line-height:var(--lh-snug, 1.25);color:var(--text-mute, #5c5c6d);display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-clamp:2;overflow:hidden}.tags{display:flex;flex-wrap:wrap;gap:var(--sp-2, .5rem);margin:auto 0 0;padding:0;list-style:none}.chip{padding:.125rem var(--sp-2, .5rem);border-radius:var(--r-sm, 8px);border:1px solid var(--border-soft, #f0f0f2);background:var(--bg-sunk, #f3f3f5);font-size:var(--fs-xs, .75rem);color:var(--text-mute, #5c5c6d)}@media(prefers-reduced-motion:reduce){.card{transition:none}.card:hover{transform:none}}\n"] }]
        }], propDecorators: { lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], heading: [{ type: i0.Input, args: [{ isSignal: true, alias: "heading", required: false }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }] } });

/**
 * Compact "our projects" list (icon/logo + name + status dot), driven by
 * `config.projects` — the same data as the `ik-projects` grid, rendered as a small
 * linked list for reuse in footers, sidebars, etc. Locale-aware links. Renders
 * nothing when there are no projects.
 *
 * ```html
 * <ik-projects-list [lang]="lang" heading="Проекты" />
 * ```
 */
class ProjectsList {
    cfg = inject(SITE_KIT_CONFIG);
    /** Active language for locale-aware links. Defaults to the config default. */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Optional heading above the list. */
    heading = input(...(ngDevMode ? [undefined, { debugName: "heading" }] : /* istanbul ignore next */ []));
    activeLang = computed(() => this.lang() ?? this.cfg.defaultLang, ...(ngDevMode ? [{ debugName: "activeLang" }] : /* istanbul ignore next */ []));
    items = computed(() => {
        const lang = this.activeLang();
        const defaultLang = this.cfg.defaultLang;
        return this.cfg.projects.map((project) => {
            const href = project.urls?.[lang] ??
                (project.localize ? localizeUrl(project.url, lang, { defaultLang }) : project.url);
            return {
                project,
                href,
                external: /^https?:\/\//i.test(href),
                monogram: (project.name.trim()[0] ?? '·').toUpperCase(),
            };
        });
    }, ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ProjectsList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: ProjectsList, isStandalone: true, selector: "ik-projects-list", inputs: { lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, heading: { classPropertyName: "heading", publicName: "heading", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ik-projects-list" }, ngImport: i0, template: `
        @if (items().length) {
            @if (heading()) {
                <h3 class="ik-pl-title">{{ heading() }}</h3>
            }
            <ul class="ik-pl" role="list">
                @for (it of items(); track it.project.name) {
                    <li>
                        <a
                            class="row"
                            [href]="it.href"
                            [attr.target]="it.external ? '_blank' : null"
                            [attr.rel]="it.external ? 'noopener noreferrer' : null"
                        >
                            <span class="logo">
                                @if (it.project.logoUrl) {
                                    <img [src]="it.project.logoUrl" [alt]="it.project.name" loading="lazy" />
                                } @else {
                                    <span class="mono" aria-hidden="true">{{ it.monogram }}</span>
                                }
                            </span>
                            <span class="name">{{ it.project.name }}</span>
                            @if (it.project.status) {
                                <span
                                    class="dot"
                                    [attr.data-status]="it.project.status"
                                    [attr.title]="it.project.status"
                                ></span>
                            }
                        </a>
                    </li>
                }
            </ul>
        }
    `, isInline: true, styles: [":host{display:block}.ik-pl-title{margin:0 0 var(--sp-2, .5rem);font-size:var(--fs-sm, .875rem);font-weight:var(--fw-semi, 600);color:var(--text, #09090f)}.ik-pl{display:flex;flex-direction:column;gap:var(--sp-1, .25rem);list-style:none;margin:0;padding:0}.row{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);text-decoration:none;color:var(--text-mute, #5c5c6d);font-size:var(--fs-sm, .875rem);line-height:1;transition:color var(--dur-fast, .15s) var(--ease-out, ease)}.row:hover{color:var(--brand, #6d28d9)}.row:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3));border-radius:var(--r-sm, 8px)}.logo{display:inline-grid;place-items:center;width:1.5rem;height:1.5rem;border-radius:var(--r-sm, 8px);overflow:hidden;flex:0 0 auto}.logo img{width:100%;height:100%;object-fit:contain}.mono{display:grid;place-items:center;width:100%;height:100%;background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );color:#fff;font-weight:var(--fw-bold, 700);font-size:.7rem}.dot{width:.5rem;height:.5rem;border-radius:50%;flex:0 0 auto;background:var(--text-dim, #8e8ea0)}.dot[data-status=live]{background:var(--success, #16a34a)}.dot[data-status=wip]{background:var(--accent-3, #ea580c)}.dot[data-status=archived]{background:var(--text-dim, #8e8ea0)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ProjectsList, decorators: [{
            type: Component,
            args: [{ selector: 'ik-projects-list', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        @if (items().length) {
            @if (heading()) {
                <h3 class="ik-pl-title">{{ heading() }}</h3>
            }
            <ul class="ik-pl" role="list">
                @for (it of items(); track it.project.name) {
                    <li>
                        <a
                            class="row"
                            [href]="it.href"
                            [attr.target]="it.external ? '_blank' : null"
                            [attr.rel]="it.external ? 'noopener noreferrer' : null"
                        >
                            <span class="logo">
                                @if (it.project.logoUrl) {
                                    <img [src]="it.project.logoUrl" [alt]="it.project.name" loading="lazy" />
                                } @else {
                                    <span class="mono" aria-hidden="true">{{ it.monogram }}</span>
                                }
                            </span>
                            <span class="name">{{ it.project.name }}</span>
                            @if (it.project.status) {
                                <span
                                    class="dot"
                                    [attr.data-status]="it.project.status"
                                    [attr.title]="it.project.status"
                                ></span>
                            }
                        </a>
                    </li>
                }
            </ul>
        }
    `, host: { class: 'ik-projects-list' }, styles: [":host{display:block}.ik-pl-title{margin:0 0 var(--sp-2, .5rem);font-size:var(--fs-sm, .875rem);font-weight:var(--fw-semi, 600);color:var(--text, #09090f)}.ik-pl{display:flex;flex-direction:column;gap:var(--sp-1, .25rem);list-style:none;margin:0;padding:0}.row{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);text-decoration:none;color:var(--text-mute, #5c5c6d);font-size:var(--fs-sm, .875rem);line-height:1;transition:color var(--dur-fast, .15s) var(--ease-out, ease)}.row:hover{color:var(--brand, #6d28d9)}.row:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3));border-radius:var(--r-sm, 8px)}.logo{display:inline-grid;place-items:center;width:1.5rem;height:1.5rem;border-radius:var(--r-sm, 8px);overflow:hidden;flex:0 0 auto}.logo img{width:100%;height:100%;object-fit:contain}.mono{display:grid;place-items:center;width:100%;height:100%;background:var( --grad-brand, linear-gradient(135deg, var(--brand, #6d28d9), var(--accent-2, #db2777)) );color:#fff;font-weight:var(--fw-bold, 700);font-size:.7rem}.dot{width:.5rem;height:.5rem;border-radius:50%;flex:0 0 auto;background:var(--text-dim, #8e8ea0)}.dot[data-status=live]{background:var(--success, #16a34a)}.dot[data-status=wip]{background:var(--accent-3, #ea580c)}.dot[data-status=archived]{background:var(--text-dim, #8e8ea0)}\n"] }]
        }], propDecorators: { lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], heading: [{ type: i0.Input, args: [{ isSignal: true, alias: "heading", required: false }] }] } });

const TECH_ICONS = {
    angular: {
        label: 'Angular',
        url: 'https://angular.dev',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9.931 12.645h4.138l-2.07-4.908m0-7.737L.68 3.982l1.726 14.771L12 24l9.596-5.247L23.32 3.982 11.999 0zm7.064 18.31h-2.638l-1.422-3.503H8.996l-1.422 3.504h-2.64L12 2.65z"/></svg>`,
    },
    typescript: {
        label: 'TypeScript',
        url: 'https://www.typescriptlang.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M1.125 0C.502 0 0 .502 0 1.125v21.75C0 23.498.502 24 1.125 24h21.75c.623 0 1.125-.502 1.125-1.125V1.125C24 .502 23.498 0 22.875 0zm17.363 9.75c.612 0 1.154.037 1.627.111a6.38 6.38 0 0 1 1.306.34v2.458a3.95 3.95 0 0 0-.643-.361 5.093 5.093 0 0 0-.717-.26 5.453 5.453 0 0 0-1.426-.2c-.3 0-.573.028-.819.086a2.1 2.1 0 0 0-.623.242c-.17.104-.3.229-.393.374a.888.888 0 0 0-.14.49c0 .196.053.373.156.529.104.156.252.304.443.444s.423.276.696.41c.273.135.582.274.926.416.47.197.892.407 1.266.628.374.222.695.473.963.753.268.279.472.598.614.957.142.359.214.776.214 1.253 0 .657-.125 1.21-.373 1.656a3.033 3.033 0 0 1-1.012 1.085 4.38 4.38 0 0 1-1.487.596c-.566.12-1.163.18-1.79.18a9.916 9.916 0 0 1-1.84-.164 5.544 5.544 0 0 1-1.512-.493v-2.63a5.033 5.033 0 0 0 3.237 1.2c.333 0 .624-.03.872-.09.249-.06.456-.144.623-.25.166-.108.29-.234.373-.38a1.023 1.023 0 0 0-.074-1.089 2.12 2.12 0 0 0-.537-.5 5.597 5.597 0 0 0-.807-.444 27.72 27.72 0 0 0-1.007-.436c-.918-.383-1.602-.852-2.053-1.405-.45-.553-.676-1.222-.676-2.005 0-.614.123-1.141.369-1.582.246-.441.58-.804 1.004-1.089a4.494 4.494 0 0 1 1.47-.629 7.536 7.536 0 0 1 1.77-.201zm-15.113.188h9.563v2.166H9.506v9.646H6.789v-9.646H3.375z"/></svg>`,
    },
    javascript: {
        label: 'JavaScript',
        url: 'https://developer.mozilla.org/docs/Web/JavaScript',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
    },
    node: {
        label: 'Node.js',
        url: 'https://nodejs.org',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 2 21 7v10l-9 5-9-5V7l9-5Z"/></svg>`,
    },
    cloudflare: {
        label: 'Cloudflare',
        url: 'https://www.cloudflare.com',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 17.5H7.2a4 4 0 1 1 1-7.87A6 6 0 0 1 19.8 11.6 3.45 3.45 0 0 1 19 17.5Z"/></svg>`,
    },
    wordpress: {
        label: 'WordPress',
        url: 'https://wordpress.org',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m5.5 8 3 8.5L11 9l2.5 7.5 3-8.5"/></svg>`,
    },
    bitcoin: {
        label: 'Bitcoin',
        url: 'https://bitcoin.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.638 14.904c-1.602 6.43-8.113 10.34-14.542 8.736C2.67 22.05-1.244 15.525.362 9.105 1.962 2.67 8.475-1.243 14.9.358c6.43 1.605 10.342 8.115 8.738 14.546zm-6.35-4.613c.24-1.59-.974-2.45-2.64-3.03l.54-2.153-1.315-.33-.525 2.107c-.345-.087-.7-.17-1.053-.252l.53-2.12-1.313-.33-.54 2.152c-.286-.065-.567-.13-.84-.2l.001-.007-1.812-.452-.35 1.407s.975.224.955.238c.535.136.63.494.614.778l-.614 2.456c.037.01.083.024.135.046l-.137-.035-.86 3.456c-.065.16-.23.4-.6.308.013.02-.956-.239-.956-.239l-.652 1.514 1.71.427.937.24-.546 2.19 1.313.328.54-2.157c.36.1.708.19 1.05.273l-.538 2.155 1.315.33.546-2.183c2.245.424 3.93.253 4.64-1.774.57-1.637-.03-2.58-1.217-3.196.867-.2 1.52-.77 1.694-1.94z"/></svg>`,
    },
    ethereum: {
        label: 'Ethereum',
        url: 'https://ethereum.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 6 12l6 3.5L18 12 12 2Zm-6 11.3L12 22l6-8.7-6 3.5-6-3.5Z"/></svg>`,
    },
    ton: {
        label: 'TON',
        url: 'https://ton.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 7h16L12 21 4 7Zm3.2 1.6L12 17l4.8-8.4H7.2Z"/></svg>`,
    },
    postgres: {
        label: 'PostgreSQL',
        url: 'https://www.postgresql.org',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.66 3.58 3 8 3s8-1.34 8-3V5"/><path d="M4 12c0 1.66 3.58 3 8 3s8-1.34 8-3"/></svg>`,
    },
    redis: {
        label: 'Redis',
        url: 'https://redis.io',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="6" rx="9" ry="3"/><path d="M3 6v12c0 1.66 4.03 3 9 3s9-1.34 9-3V6"/><path d="M3 12c0 1.66 4.03 3 9 3s9-1.34 9-3"/></svg>`,
    },
    go: {
        label: 'Go',
        url: 'https://go.dev',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M1.811 10.231c-.047 0-.058-.023-.035-.059l.246-.315c.023-.035.081-.058.128-.058h4.172c.046 0 .058.035.035.07l-.199.303c-.023.036-.082.07-.117.07zM.047 11.306c-.047 0-.059-.023-.035-.058l.245-.316c.023-.035.082-.058.129-.058h5.328c.047 0 .07.035.058.07l-.093.28c-.012.047-.058.07-.105.07zm2.828 1.075c-.047 0-.059-.035-.035-.07l.163-.292c.023-.035.07-.07.117-.07h2.337c.047 0 .07.035.07.082l-.023.28c0 .047-.047.082-.082.082zm12.129-2.36c-.736.187-1.239.327-1.963.514-.176.046-.187.058-.34-.117-.174-.199-.303-.327-.548-.444-.737-.362-1.45-.257-2.115.175-.795.514-1.204 1.274-1.192 2.22.011.935.654 1.706 1.577 1.835.795.105 1.46-.175 1.987-.77.105-.13.198-.27.315-.434H10.47c-.245 0-.304-.152-.222-.35.152-.362.432-.97.596-1.274a.315.315 0 01.292-.187h4.253c-.023.316-.023.631-.07.947a4.983 4.983 0 01-.958 2.29c-.841 1.11-1.94 1.8-3.33 1.986-1.145.152-2.209-.07-3.143-.77-.865-.655-1.356-1.52-1.484-2.595-.152-1.274.222-2.419.993-3.424.83-1.086 1.928-1.776 3.272-2.02 1.098-.2 2.15-.07 3.096.571.62.41 1.063.97 1.356 1.648.07.105.023.164-.117.2m3.868 6.461c-1.064-.024-2.034-.328-2.852-1.029a3.665 3.665 0 01-1.262-2.255c-.21-1.32.152-2.489.947-3.529.853-1.122 1.881-1.706 3.272-1.95 1.192-.21 2.314-.095 3.33.595.923.63 1.496 1.484 1.648 2.605.198 1.578-.257 2.863-1.344 3.962-.771.783-1.718 1.273-2.805 1.495-.315.06-.63.07-.934.106zm2.78-4.72c-.011-.153-.011-.27-.034-.387-.21-1.157-1.274-1.81-2.384-1.554-1.087.245-1.788.935-2.045 2.033-.21.912.234 1.835 1.075 2.21.643.28 1.285.244 1.905-.07.923-.48 1.425-1.228 1.484-2.233z"/></svg>`,
    },
    docker: {
        label: 'Docker',
        url: 'https://www.docker.com',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="11" width="3" height="3" rx=".4"/><rect x="6.6" y="11" width="3" height="3" rx=".4"/><rect x="10.2" y="11" width="3" height="3" rx=".4"/><rect x="10.2" y="7.4" width="3" height="3" rx=".4"/><rect x="13.8" y="11" width="3" height="3" rx=".4"/><path d="M17.5 12.5c.9-.6 1.6-.2 1.9.1.3-.7 1.1-.6 1.4-.3-.2 1.6-1.6 2.7-3.6 2.7-3 .2-5.6-1-6.9-3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>`,
    },
    rust: {
        label: 'Rust',
        url: 'https://www.rust-lang.org',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="9.2"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4" stroke-linecap="round"/></svg>`,
    },
    tailwind: {
        label: 'Tailwind',
        url: 'https://tailwindcss.com',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12.001,4.8c-3.2,0-5.2,1.6-6,4.8c1.2-1.6,2.6-2.2,4.2-1.8c.913,.228,1.565,.89,2.288,1.624C13.666,10.618,15.027,12,18.001,12c3.2,0,5.2-1.6,6-4.8-1.2,1.6-2.6,2.2-4.2,1.8-.913-.228-1.565-.89-2.288-1.624C16.337,6.182,14.976,4.8,12.001,4.8ZM6.001,12c-3.2,0-5.2,1.6-6,4.8,1.2-1.6,2.6-2.2,4.2-1.8,.913,.228,1.565,.89,2.288,1.624,1.177,1.194,2.538,2.576,5.512,2.576,3.2,0,5.2-1.6,6-4.8-1.2,1.6-2.6,2.2-4.2,1.8-.913-.228-1.565-.89-2.288-1.624C10.337,13.382,8.976,12,6.001,12Z"/></svg>`,
    },
    // Tabler's own mark (icon "brand-tabler" from @tabler/icons, MIT).
    tabler: {
        label: 'Tabler',
        url: 'https://tabler.io',
        svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 9l3 3l-3 3"/><path d="M13 15h3"/><path d="M4 8a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v8a4 4 0 0 1-4 4h-8a4 4 0 0 1-4-4z"/></svg>`,
    },
    selectel: {
        label: 'Selectel',
        url: 'https://selectel.ru',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M2 5h20v3H2zm0 5.5h20v3H2zM2 16h20v3H2zM4 6.5h2v1H4zm4 0h8v1H8zM4 12h2v1H4zm4 0h8v1H8zM4 17.5h2v1H4zm4 0h8v1H8z"/></svg>`,
    },
    // Common site/footer marks (not strictly "tech", but frequently badged next to the stack).
    brandbook: {
        label: 'Brandbook',
        url: '',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 2h11a3 3 0 0 1 3 3v15a2 2 0 0 1-2 2H7a3 3 0 0 1-3-3V5a3 3 0 0 1 2-2.83V2zm0 2.17C5.4 4.39 5 4.94 5 5.5V18a2 2 0 0 1 2-2h11V5a2 2 0 0 0-2-2H6v1.17zM7 17a1 1 0 0 0 0 2h11v-2H7z"/></svg>`,
    },
    onion: {
        label: '.onion',
        url: 'https://www.torproject.org',
        svg: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 4a8 8 0 1 1 0 16 8 8 0 0 1 0-16zm0 3a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 3a2 2 0 1 1 0 4 2 2 0 0 1 0-4z"/></svg>`,
    },
};
/** Generic tag glyph for technologies without a built-in icon. */
const TECH_FALLBACK = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 13.4 11 3.8a2 2 0 0 0-1.4-.6H4a1 1 0 0 0-1 1v5.6a2 2 0 0 0 .6 1.4l9.6 9.6a2 2 0 0 0 2.8 0l4.6-4.6a2 2 0 0 0 0-2.8Z"/><circle cx="7.5" cy="7.5" r="1.3" fill="currentColor"/></svg>`;
/** Brand accent per known kind — used to tint a badge on hover (like the reference footer). */
const TECH_COLORS = {
    angular: '#dd0031',
    typescript: '#3178c6',
    javascript: '#f7df1e',
    node: '#5fa04e',
    cloudflare: '#f38020',
    wordpress: '#21759b',
    bitcoin: '#f7931a',
    ethereum: '#627eea',
    ton: '#0098ea',
    postgres: '#336791',
    redis: '#dc382d',
    go: '#00add8',
    docker: '#2496ed',
    rust: '#ce422b',
    tailwind: '#38bdf8',
    tabler: '#066fd1',
    onion: '#7d4698',
};

/** Minimal currentColor device glyphs for the PageSpeed chips. */
const PS_ICON_MOBILE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></svg>';
const PS_ICON_DESKTOP = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="13" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>';
/**
 * Tech-stack badges, driven by `config.technologies`. Each is a link (icon + name)
 * to the technology's site. `kind` selects a built-in icon + canonical URL; `name`,
 * `url`, `icon` override. Renders nothing when there are no technologies.
 *
 * The footer auto-includes this, so a project only needs to list its stack in config.
 *
 * ```html
 * <ik-technologies />
 * <ik-technologies size="sm" />
 * ```
 */
class Technologies {
    cfg = inject(SITE_KIT_CONFIG);
    sanitizer = inject(DomSanitizer);
    /** Visual size hint, reflected to a host attribute for CSS. */
    size = input('md', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Center the (wrapping) badge rows — for the standalone section vs the footer. */
    center = input(false, ...(ngDevMode ? [{ debugName: "center" }] : /* istanbul ignore next */ []));
    /** Append the library's own "site-kit" badge as the LAST technology (the footer does this). */
    appendSiteKit = input(false, ...(ngDevMode ? [{ debugName: "appendSiteKit" }] : /* istanbul ignore next */ []));
    /** Render PageSpeed score chips (from `config.pageSpeed`) JUST BEFORE the IA-kit badge. Footer-only. */
    showPageSpeed = input(false, ...(ngDevMode ? [{ debugName: "showPageSpeed" }] : /* istanbul ignore next */ []));
    /** Active language — localizes the PageSpeed chip tooltip ("re-test" / "перепроверить"). */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    items = computed(() => {
        const out = this.cfg.technologies.map((t) => {
            const meta = t.kind ? TECH_ICONS[t.kind] : undefined;
            const name = t.name ?? meta?.label ?? t.kind ?? 'Tech';
            const url = t.url ?? meta?.url ?? '#';
            const external = /^https?:\/\//i.test(url);
            const accent = t.color ?? (t.kind ? TECH_COLORS[t.kind] : undefined) ?? null;
            const title = t.version ? `${name} v${t.version}` : undefined;
            if (t.icon) {
                // inline SVG vs image URL
                return /^\s*<svg/i.test(t.icon)
                    ? {
                        name,
                        url,
                        external,
                        accent,
                        title,
                        svg: this.sanitizer.bypassSecurityTrustHtml(t.icon),
                        imgUrl: null,
                    }
                    : { name, url, external, accent, title, svg: null, imgUrl: t.icon };
            }
            return {
                name,
                url,
                external,
                accent,
                title,
                svg: this.sanitizer.bypassSecurityTrustHtml(meta?.svg ?? TECH_FALLBACK),
                imgUrl: null,
            };
        });
        return out;
    }, ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    /** The library's own "site-kit" signature badge — rendered LAST (after any PageSpeed chips).
     *  Null unless `appendSiteKit` is set and `config.signature` isn't `false`. */
    siteKitBadge = computed(() => {
        const sig = this.cfg.signature;
        if (!this.appendSiteKit() || sig === false)
            return null;
        const href = typeof sig === 'object' && sig.href ? sig.href : 'https://ilia.ae';
        return {
            name: SITE_KIT_NAME,
            url: href,
            external: true,
            accent: SITE_KIT_ACCENT,
            svg: this.sanitizer.bypassSecurityTrustHtml(SITE_KIT_GLYPH),
            imgUrl: null,
            title: `${SITE_KIT_NAME} v${SITE_KIT_VERSION} · schema ${SITE_KIT_SCHEMA_VERSION} · build ${SITE_KIT_BUILD_DATE}`,
        };
    }, ...(ngDevMode ? [{ debugName: "siteKitBadge" }] : /* istanbul ignore next */ []));
    /** PageSpeed score badge from `config.pageSpeed` (only when `showPageSpeed`) — ONE chip holding
     *  the mobile + desktop scores, linking to PSI to RE-TEST the live URL (defaults to `seo.siteUrl`
     *  → `brand.url`). Numbers are author-supplied; each gets a Lighthouse colour-band dot. */
    pageSpeed = computed(() => {
        if (!this.showPageSpeed())
            return null;
        const ps = this.cfg.pageSpeed;
        if (!ps)
            return null;
        const url = ps.url ?? this.cfg.seo?.siteUrl ?? this.cfg.brand.url;
        if (!url)
            return null;
        const ru = (this.lang() ?? this.cfg.defaultLang) === 'ru';
        const chips = [];
        const parts = [];
        const add = (factor, score, name, icon) => {
            if (typeof score !== 'number')
                return;
            const band = score >= 90 ? '#0cce6b' : score >= 50 ? '#ffa400' : '#ff4e42';
            chips.push({ factor, score, band, icon: this.sanitizer.bypassSecurityTrustHtml(icon) });
            parts.push(`${name} ${score}`);
        };
        add('mobile', ps.mobile, ru ? 'Мобайл' : 'Mobile', PS_ICON_MOBILE);
        add('desktop', ps.desktop, ru ? 'Десктоп' : 'Desktop', PS_ICON_DESKTOP);
        const first = chips[0];
        if (!first)
            return null;
        const label = ps.label ?? 'PageSpeed';
        return {
            href: `https://pagespeed.web.dev/report?url=${encodeURIComponent(url)}`,
            title: `${label} — ${parts.join(' · ')} · ${ru ? 'перепроверить' : 're-test'}`,
            accent: first.band,
            chips,
        };
    }, ...(ngDevMode ? [{ debugName: "pageSpeed" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Technologies, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: Technologies, isStandalone: true, selector: "ik-technologies", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, center: { classPropertyName: "center", publicName: "center", isSignal: true, isRequired: false, transformFunction: null }, appendSiteKit: { classPropertyName: "appendSiteKit", publicName: "appendSiteKit", isSignal: true, isRequired: false, transformFunction: null }, showPageSpeed: { classPropertyName: "showPageSpeed", publicName: "showPageSpeed", isSignal: true, isRequired: false, transformFunction: null }, lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.size": "size()", "class.is-center": "center()" }, classAttribute: "ik-technologies" }, ngImport: i0, template: `
        @if (items().length || pageSpeed() || siteKitBadge()) {
            <ul class="ik-tech" role="list">
                @for (t of items(); track $index) {
                    <li>
                        <a
                            class="b"
                            [href]="t.url"
                            [style.--tech-accent]="t.accent"
                            [attr.target]="t.external ? '_blank' : null"
                            [attr.rel]="t.external ? 'noopener noreferrer' : null"
                            [attr.title]="t.title ?? t.name"
                        >
                            @if (t.svg) {
                                <span class="ico" [innerHTML]="t.svg"></span>
                            } @else if (t.imgUrl) {
                                <img class="ico" [src]="t.imgUrl" [alt]="t.name" />
                            }
                            <span class="lbl">{{ t.name }}</span>
                        </a>
                    </li>
                }
                <!-- PageSpeed: ONE badge (mobile · desktop) sitting JUST BEFORE the IA-kit one.
                     Muted at rest; on hover the numbers + device glyphs light up in the score band. -->
                @if (pageSpeed(); as p) {
                    <li>
                        <a
                            class="b b--ps"
                            [href]="p.href"
                            target="_blank"
                            rel="noopener noreferrer"
                            [style.--tech-accent]="p.accent"
                            [attr.title]="p.title"
                            [attr.aria-label]="p.title"
                            data-ik-part="footer.pagespeed"
                        >
                            @for (c of p.chips; track c.factor; let i = $index) {
                                @if (i > 0) {
                                    <span class="ps-sep" aria-hidden="true"></span>
                                }
                                <span
                                    class="ps-seg"
                                    [style.--ps-band]="c.band"
                                    [attr.data-ik-part]="'footer.pagespeed.' + c.factor"
                                >
                                    <span class="ico" [innerHTML]="c.icon"></span>
                                    <span class="lbl">{{ c.score }}</span>
                                </span>
                            }
                        </a>
                    </li>
                }
                @if (siteKitBadge(); as s) {
                    <li>
                        <a
                            class="b"
                            [href]="s.url"
                            [style.--tech-accent]="s.accent"
                            target="_blank"
                            rel="noopener noreferrer"
                            [attr.title]="s.title ?? s.name"
                        >
                            @if (s.svg) {
                                <span class="ico" [innerHTML]="s.svg"></span>
                            }
                            <span class="lbl">{{ s.name }}</span>
                        </a>
                    </li>
                }
            </ul>
        }
    `, isInline: true, styles: [":host{display:block}.ik-tech{display:inline-flex;flex-wrap:wrap;gap:var(--sp-2, .5rem);list-style:none;margin:0;padding:0}:host(.is-center) .ik-tech{display:flex;justify-content:center}.b{display:inline-flex;align-items:center;gap:.45em;padding:.42em .8em;border:1px solid var(--border, #e5e5e9);border-radius:var(--r-full, 999px);background:var(--bg-elev, #fff);color:var(--text-mute, #5c5c6d);font-size:var(--fs-xs, .75rem);line-height:1.2;text-decoration:none;transition:color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.b:hover{color:var(--tech-accent, var(--brand, #6d28d9));border-color:color-mix(in oklch,var(--tech-accent, var(--brand, #6d28d9)) 45%,transparent);background:color-mix(in oklch,var(--tech-accent, var(--brand, #6d28d9)) 14%,var(--bg-elev, #fff));transform:translateY(-1px)}.b:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.ico{display:inline-flex;width:1.05em;height:1.05em}.ico ::ng-deep svg,.ico img{display:block;width:100%;height:100%}.lbl{line-height:1}.b--ps{gap:6px}.ps-seg{display:inline-flex;align-items:center;gap:4px}.b--ps .lbl{font-weight:var(--fw-bold, 700);font-variant-numeric:tabular-nums}.ps-sep{width:1px;align-self:stretch;margin-block:1px;background:var(--border, #e5e5e9)}.b--ps:hover .ps-seg{color:var(--ps-band, var(--brand, #6d28d9))}:host([size=\"sm\"]) .b--ps:hover .ico{opacity:1}:host([size=\"sm\"]) .b{gap:4px;padding:5px 7px 5px 5px;border-radius:4px;font-size:10px;font-weight:var(--fw-semi, 600);letter-spacing:.2px;line-height:1.4}:host([size=\"sm\"]) .b:hover{transform:none}:host([size=\"sm\"]) .ico{width:10px;height:10px;opacity:.65}:host([size=\"sm\"]) .b:hover .ico{opacity:1}@media(prefers-reduced-motion:reduce){.b,.b:hover{transform:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Technologies, decorators: [{
            type: Component,
            args: [{ selector: 'ik-technologies', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        @if (items().length || pageSpeed() || siteKitBadge()) {
            <ul class="ik-tech" role="list">
                @for (t of items(); track $index) {
                    <li>
                        <a
                            class="b"
                            [href]="t.url"
                            [style.--tech-accent]="t.accent"
                            [attr.target]="t.external ? '_blank' : null"
                            [attr.rel]="t.external ? 'noopener noreferrer' : null"
                            [attr.title]="t.title ?? t.name"
                        >
                            @if (t.svg) {
                                <span class="ico" [innerHTML]="t.svg"></span>
                            } @else if (t.imgUrl) {
                                <img class="ico" [src]="t.imgUrl" [alt]="t.name" />
                            }
                            <span class="lbl">{{ t.name }}</span>
                        </a>
                    </li>
                }
                <!-- PageSpeed: ONE badge (mobile · desktop) sitting JUST BEFORE the IA-kit one.
                     Muted at rest; on hover the numbers + device glyphs light up in the score band. -->
                @if (pageSpeed(); as p) {
                    <li>
                        <a
                            class="b b--ps"
                            [href]="p.href"
                            target="_blank"
                            rel="noopener noreferrer"
                            [style.--tech-accent]="p.accent"
                            [attr.title]="p.title"
                            [attr.aria-label]="p.title"
                            data-ik-part="footer.pagespeed"
                        >
                            @for (c of p.chips; track c.factor; let i = $index) {
                                @if (i > 0) {
                                    <span class="ps-sep" aria-hidden="true"></span>
                                }
                                <span
                                    class="ps-seg"
                                    [style.--ps-band]="c.band"
                                    [attr.data-ik-part]="'footer.pagespeed.' + c.factor"
                                >
                                    <span class="ico" [innerHTML]="c.icon"></span>
                                    <span class="lbl">{{ c.score }}</span>
                                </span>
                            }
                        </a>
                    </li>
                }
                @if (siteKitBadge(); as s) {
                    <li>
                        <a
                            class="b"
                            [href]="s.url"
                            [style.--tech-accent]="s.accent"
                            target="_blank"
                            rel="noopener noreferrer"
                            [attr.title]="s.title ?? s.name"
                        >
                            @if (s.svg) {
                                <span class="ico" [innerHTML]="s.svg"></span>
                            }
                            <span class="lbl">{{ s.name }}</span>
                        </a>
                    </li>
                }
            </ul>
        }
    `, host: { class: 'ik-technologies', '[attr.size]': 'size()', '[class.is-center]': 'center()' }, styles: [":host{display:block}.ik-tech{display:inline-flex;flex-wrap:wrap;gap:var(--sp-2, .5rem);list-style:none;margin:0;padding:0}:host(.is-center) .ik-tech{display:flex;justify-content:center}.b{display:inline-flex;align-items:center;gap:.45em;padding:.42em .8em;border:1px solid var(--border, #e5e5e9);border-radius:var(--r-full, 999px);background:var(--bg-elev, #fff);color:var(--text-mute, #5c5c6d);font-size:var(--fs-xs, .75rem);line-height:1.2;text-decoration:none;transition:color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.b:hover{color:var(--tech-accent, var(--brand, #6d28d9));border-color:color-mix(in oklch,var(--tech-accent, var(--brand, #6d28d9)) 45%,transparent);background:color-mix(in oklch,var(--tech-accent, var(--brand, #6d28d9)) 14%,var(--bg-elev, #fff));transform:translateY(-1px)}.b:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.ico{display:inline-flex;width:1.05em;height:1.05em}.ico ::ng-deep svg,.ico img{display:block;width:100%;height:100%}.lbl{line-height:1}.b--ps{gap:6px}.ps-seg{display:inline-flex;align-items:center;gap:4px}.b--ps .lbl{font-weight:var(--fw-bold, 700);font-variant-numeric:tabular-nums}.ps-sep{width:1px;align-self:stretch;margin-block:1px;background:var(--border, #e5e5e9)}.b--ps:hover .ps-seg{color:var(--ps-band, var(--brand, #6d28d9))}:host([size=\"sm\"]) .b--ps:hover .ico{opacity:1}:host([size=\"sm\"]) .b{gap:4px;padding:5px 7px 5px 5px;border-radius:4px;font-size:10px;font-weight:var(--fw-semi, 600);letter-spacing:.2px;line-height:1.4}:host([size=\"sm\"]) .b:hover{transform:none}:host([size=\"sm\"]) .ico{width:10px;height:10px;opacity:.65}:host([size=\"sm\"]) .b:hover .ico{opacity:1}@media(prefers-reduced-motion:reduce){.b,.b:hover{transform:none}}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], center: [{ type: i0.Input, args: [{ isSignal: true, alias: "center", required: false }] }], appendSiteKit: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendSiteKit", required: false }] }], showPageSpeed: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPageSpeed", required: false }] }], lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }] } });

/** The ILIA family, keyed by stable slug (NOT host — avoids monogram/host collisions). */
const IK_FAMILY = {
    ilia: {
        name: 'ilia.ae',
        url: 'https://ilia.ae',
        urls: { ru: 'https://ilia.ae', en: 'https://ilia.ae/en/' },
        accent: '#6366f1',
        icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAOzklEQVR4nO2d+Y9UxRbHQYP6D8DPaBBZXBB6UQkgaBA1LoBLmBgxooBRwN0g0YgSxbglbEZINPoIaCDuECAsURaNmXmsLmjECGrIgHsEZrvn5ZR15lX39HT3zD3dfavm+0kqwzBQde/05557bm23V68SENHpRNTb+X4AEc2Ioug/RNRARMeIqIkAiEeTdanBujWDXXO8680ulvK1mMjtFURRdCYRTSGiT4jopD2AKOYJANAZ4tZJ6xy7d0ahAFuuzKdxsX8eT0QHnIa4tNjSBrGBIpF1SvwS35j97GK+n2XJ7ETlZdJQFEWtXCAwqCKFvFvGbrqulpSZiPpGUbTTVtBiKwSgZlgHOWozO9jRolI7MveLomiv/Y/NiMggQUTWSbKO9isotSTZRHQWEW23/1muBgCShri53Uk/eheKzkvsPzRXAQAJRhxdlBOlpWuOiK7mnyJfBr7guDrBdZn/0IeI6u0PudsEAB8QV9ndPm7KUcd/i+gMfMNxts4VemveDwHwAsfZrSLzUGcuBoazgW+Is+zwEBZ6pvlbRGfgKY6703mIe6X9Bv3OwFeMu+xyLzsFlEHvBvC+t6OXnYPKIH8GviLuNrLQp2p8MABocYqFBiAYIDQICggNggJCg6CA0CAoIDQICggNggJCg6CA0CAoIDQICggNggJCg6CA0CAoIDQICggNggJCg6CA0CAoIDQICggNggJCg6CA0CAoIDQICggNggJCg6CA0CAoIDQICggNggJCg6CA0CAoIDQICggNggJCg6CA0CAoEit0FEUVK6GdT9LOtZYkVujQqOWF1JNIpNBtbW104sQJ9fLPP/9QU5O8Y7S6cLvcfiXOq1hpa+tZLzdLlNASTY4cOULXXXcdXXPNNXTttdeqFK7v8ssvp+eff960Ua0PWs5p7ty5NG7cOHMcWudU6nyvuOIK2rVrV1XPt9YkSmj5pR86dIguvvhiuuCCC+jCCy9UKVzfOeecQ48++mhOW9WQ+ZdffqFLLrmEhg4dShdddJHaOZU63/79+9OCBQvMMbS29ozXuCdS6B9++MEIkEqlKJ1OqxSub/DgwTRv3ryctiqJSPTuu+/SoEGDzDFonU+pkslkzMVz4403UnNzc4/JpxMrdDabpREjRhipNQrXx1I9/vjjOW1V43zuv/9+czGxZFrnU05Jp9NG6t27d1ftnGsNhK4QEg0bGxtpzJgxJgVgwaopdDabpYEDB9LixYt7TNoBoSuEyLNu3TpzZ2C5qilzKpUyd4Tzzz+f6urq2i+w0NMOCF0h5PbOD6G1EjrlpB4HDx7MOa5QgdAVQKLg77//brrOhg0bVvV0I5WXdrz55ps9Iu2A0BVApNm0aRMNGTKk6g+Dqby0g49hxowZ5piQclSRUHo5pG7uIkxCujF8+HAaOXKk6Q8PXWpEaGVElj///JOuuuoq021Wq3QjlXcxf/DBB8GnHRBaGZFl27ZtZmSwlulGKk/oRx55JPgHQwitjMgyf/58Ou+882qabqSctIMfTK+88kr6448/gk47ILQiIgnPquMJQhrphgxlx5U6k8mYOwbfOUJOOyB0BaIzz3DjAQ0NmWWiUdy6stmsuWM888wz5hghdBXwvZdDJFm4cKHp+42Tbsg8jJtuusn0ZbPUGhfH9ddfTydPngw27UCEVkLk4In8PMON5YkTVTlF4Ij66aef0lNPPUXnnntu7Hw8bS+ShoaGYB8OIbQSIgfLEldm6Tu+9NJLTT6+Zs2a2BE/5YwaLlq0KNi0A0IrIXK88sorseWT0b0777zT1PnNN9+opF8ZZ7JSqEBoxXSDozTnvLzSJk7/s0TSV1991dTLOe/EiRNNvVqDNN999137MYcEhFZApNi7d6/KRCTJdevr69vbePLJJ1X6tbOBT1aC0AqIFEuWLFHr3eAFwrxqW6L/hx9+aHpp4o48Zmw6c/fddwfZ0wGhFdONKVOmmBw1brrBkZhXiTMtLS3m6+HDh82axLi5dNqZrMSr691zCAEIrZRufPnll0YUrf7y999/v0NKwA9zcS+YlNMGL97Nb8N3IHRMRIbXXntNpWuNIzBHYh5ckgtG2njhhRfUuu8GDRpEDz30UHsboQChY+Deqm+//fbYs+ukW+22227LaUOE3rp1q8qCgbSdrMQjkL/99luHc/EZCB0DiWzcBcaSxM1vOxv4ENmOHTumtoI8Yx8O+SJx2/IdCB0DkYC7wDRSAYnQn332WU79rtTTp09XidJZ+/DJ01zz2/IZCB0Dkeyuu+6KLVmpOcsiHA+2aFw8aTtZiffAO3XqVIf2fAVCx0w3fvzxx/butLiTkXh3Jd5lya0/v70vvvgi9lyRVJ7UXGehNn0EQncTiZhvv/22Ws8DpwCrV6/OqV+Q6Pn333/T+PHjVUYks7ZNnn9SqE0fgdDdRKLZPffco7pvXbE5FvJ3DzzwgMpq8ozN2W+99dYOD6C+AqG7gYj1888/mxE3HlCJm27wxKObb765ve5CYol0K1euVF2vOGLECPrqq69yzs1XIHQ3ELHWrl2rEimlu+65557LqT8fke3AgQMqo5Ipp+3XX3+9aNu+AKG7gYg1a9YslXRD+oS3bNlSVCp3VcwNN9yg8nCYsW1zT43bhq9A6C4iH/jRo0dp9OjRsQc5+P9yHfy6DB44cdsohMj+xBNPqKQdaWd1zE8//eR92gGhu4gI9dFHH6k9mHGU54fLcmSS9nnyktY2Y1nb2xHCZCUI3UVEON6FSDN/fuONN8qSyX0PjdbK+KydrNRZH7hPQOguIKnAr7/+qrpNLqcc+/fvL0smNx3RmH+dctKesWPHlpX2JBkI3c1tcjUeBmWkjh/wujL8LMfBr6jTGNRJOQ+HGzduzGnDNyB0F5APmbfJ1Vrfx/XwA570XnAbpYq8PFTrwko5x8JrF31OOyB0mUjk/Ouvv8w2uRrpRnencLrTSTlN0JhOmrZrGXlPPt4LxG3HJyB0mYhsvJOR9q789957r1lDyO9jeeyxx7pUZH60xnGk02kzYvn55597G6UhdBeFfvrpp9W3yeW0gXNhrrerRWvEMOX0uLz88ss55+wTELpG2+Tmpx4sU3eK1jGknDklt9xyi7evgYPQZSC33p07d6ruXpTUMnz4cLOK3T13X4DQZSC33meffTYxu/JXqmRt2rF8+fKcc/cFCF0CueXy/nJaE4KSXDJ2p/877rgj5/x9AUKXoBJLn5Jc0nb1ev7eIL4AoUsgt9yXXnpJbVQu6SVrB1neeeednN+BD0DoIsjtlveX09gm15eSsTMAZ8+ebc4fETqQd6xob5PrS0nbyUo8aHP8+PGcizvpIEIXQW61S5cu7THpRiovSvs2WQlCV3Gapo959Lx587xKOyB0J8gH+PXXX6sOL7vCaJe0Ykokk5UmTJhgJmT5knZA6E6QW+yKFSsqkm5w9BswYIB5XZtG4bqGKef5sm/Hjh07vInSELoK2+QWin58oaxbt47ee+89sz4wTuE61q9fbzaM0eyJkVFDXkjgSx4NoQsgkejbb79Vv43z4AxPcNJ8m6uItnjxYtW7iUxWmjx5MjU3N6sdbyWB0EUE4YWrmnM3WBDuOnzwwQdN/SxJOStUyl3Bsn37dvW7SVfXPNYaCF0AiULTpk1TFURu4W+99ZbqLVyOt7GxUWWvEJ8nK0HoIoM7GtvkFuo52L17d05bmkydOlX1IpTJSlwvg5TDs5FCiUCrVq1STTdEZt4Kt9CG5nGR437xxRfVe2X4c2CxfZishAidh0g2c+ZM1bWDMvLG6wcrIYUIvXnzZtXtfcvZuzpJQOgCMvMebxrb5FYzF5UL5MiRI3TZZZepHnv+xZjktANCO4hkvMeb1r5xbsrBXWDyQiDtCF3Jofq0nazED5y8SWV+e0kCQjuIZHPmzFG9bbtbbVVy9lqrvSAXLFignkdLlObBILetpAGhq9D1Va0Xxrfm7YxaiTxa3kGe1AdDCJ0nw8cff6yebnT2Qk1t2qxk33//vZFZs5dIeml41yh+cVFS0w4InSfDww8/rC609OVu27atokJHVjCun4ertbdckPPg7RwqeR5xgNB52+SOGzdONd2QHfJHjRpVlQeqNnthau3wX+hOs3DhQtMGhC7zw5BROhFCo3B9/FBTaMK6fDAbNmwwua7MLdYoXBf3OPCsvWrQas9lzZo15k7D5611LhyhOe2YNGlSYicrJTJC8+70PLeXReDZaXzrjFu4vrPPPttsiOi25f6ZJw3179/f/FuNNqVdrrPUG660f4cHDx5UOwe38OfBF0p9fX2H32MSSJTQAm/+za8u4xlemmXPnj10+PDhTiMLS7Bv376KtMvpTGftVoKWlhbz7kHt8+HPheeiJHXxbCKFBiAoofmq51tZJUqxiFKpNku1WynaAjsfb4UGoLtAaBAUEBoEBYQGQQGhQVBAaBAUEBoEBYQGQQGhQVBAaBAUEBoEBYQGQQGhQVBAaBAUEBoEBYQGQQGhQVBAaBAUEBoEBYQGQQGhQVBAaBAUEBoEBYQGQQGhQVBAaBAUEBoEBYQGQQGhQVBAaBAUEBoEBYQGQQGhQXBCN9X6IABQoomF/vftL0TJfMcAAKURd4+z0P+13yTr/VwAlI+429AriqKV9puWLlQAQJIw7rLLHKGn22+S9+JmAMrAcXc6R+jBzoMh8mjgG+LsKXa5F0NEW81PEKWBZzjObjEyW6Hr8n4IgBc4zta5Qvchon/fRo7eDuBf7wa720dkPt1+vZp/gigNfMFxdYLrMv/hNPt1if0HzTU8TgDKQRxd4josQve2X8+Komin/YfolwZJRdzcwc66DrtSS5TuF0XRXucqQFceSAqRRGbraL8O0bkTqfu6kRp5Nag11kEZEWQ3+xaVOV/qKIrOJKJl/68varWVImKDalHIu2XsZlkyu1I70Xo8Ee2TBmxpsYW7TSA40CKyTolf4htZB8fn+1k2nGQ7XXpnENEUItqOYXJQBUTiJuscu3eGdfH0Dg+AXRQ7pwIiGkJE99lZeg1EdAyLBADFh+VllxqsW/exa4UCbDFf/wdPNCKBosFaVwAAAABJRU5ErkJggg==',
    },
    mayday: {
        name: 'mayday',
        url: 'https://mayday.software',
        accent: '#6d28d9',
        icon: 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2032%2032%22%3E%20%3Cdefs%3E%20%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%25%22%20y1%3D%220%25%22%20x2%3D%22100%25%22%20y2%3D%22100%25%22%3E%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%236d28d9%22%2F%3E%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23db2777%22%2F%3E%20%3C%2FlinearGradient%3E%20%3C%2Fdefs%3E%20%3Crect%20width%3D%2232%22%20height%3D%2232%22%20rx%3D%228%22%20fill%3D%22url(%23g)%22%2F%3E%20%3Ctext%20x%3D%2216%22%20y%3D%2223%22%20font-family%3D%22system-ui%2Csans-serif%22%20font-size%3D%2218%22%20font-weight%3D%22800%22%20fill%3D%22%23fff%22%20text-anchor%3D%22middle%22%3EM%3C%2Ftext%3E%20%3C%2Fsvg%3E',
    },
    deposit: {
        name: 'deposit',
        url: 'https://deposit.mayday.software',
        accent: '#e8a33d',
        icon: 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2264%22%20height%3D%2264%22%20viewBox%3D%220%200%2064%2064%22%20role%3D%22img%22%20aria-label%3D%22deposit%22%3E%20%3Crect%20width%3D%2264%22%20height%3D%2264%22%20rx%3D%2214%22%20fill%3D%22%23ffffff%22%2F%3E%20%3Cpath%20d%3D%22M22%2022%20L32%2032%20L42%2022%22%20fill%3D%22none%22%20stroke%3D%22%231a1208%22%20stroke-width%3D%224.5%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%2F%3E%20%3Cpath%20d%3D%22M32%2014%20L32%2030%22%20stroke%3D%22%231a1208%22%20stroke-width%3D%224.5%22%20stroke-linecap%3D%22round%22%2F%3E%20%3Cline%20x1%3D%2216%22%20y1%3D%2246%22%20x2%3D%2248%22%20y2%3D%2246%22%20stroke%3D%22%231a1208%22%20stroke-width%3D%224.5%22%20stroke-linecap%3D%22round%22%2F%3E%20%3C%2Fsvg%3E',
    },
    aliro: {
        name: 'aliro',
        url: 'https://aliro.mayday.software',
        accent: '#00723a',
        icon: 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2064%2064%22%3E%20%3Crect%20width%3D%2264%22%20height%3D%2264%22%20rx%3D%2214%22%20fill%3D%22%2300723a%22%2F%3E%20%3Cpath%20d%3D%22M18%2048%20L32%2016%20L46%2048%20M23.5%2038%20L40.5%2038%22%20fill%3D%22none%22%20stroke%3D%22%23ffffff%22%20stroke-width%3D%225%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%2F%3E%20%3C%2Fsvg%3E',
    },
    mirador: {
        name: 'MIRADOR',
        url: 'https://mirador.mayday.software',
        accent: '#d21f2b',
        icon: 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2032%2032%22%20role%3D%22img%22%20aria-label%3D%22MIRADOR%22%3E%20%3Crect%20width%3D%2232%22%20height%3D%2232%22%20rx%3D%227%22%20fill%3D%22%23d21f2b%22%2F%3E%20%3Cg%20fill%3D%22none%22%20stroke%3D%22%23ffffff%22%20stroke-width%3D%222.4%22%20stroke-linecap%3D%22round%22%3E%20%3Ccircle%20cx%3D%2216%22%20cy%3D%2216%22%20r%3D%227.6%22%2F%3E%20%3Cpath%20d%3D%22M16%202.6%20V6.4%20M16%2025.6%20V29.4%20M2.6%2016%20H6.4%20M25.6%2016%20H29.4%22%2F%3E%20%3C%2Fg%3E%20%3Ccircle%20cx%3D%2216%22%20cy%3D%2216%22%20r%3D%222.3%22%20fill%3D%22%23ffffff%22%2F%3E%20%3C%2Fsvg%3E',
    },
    monolith: {
        name: 'monolith',
        url: 'https://monolith.plus',
        accent: '#5b43ad',
        icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAADS1JREFUeNrs3T2MXNUVwPEZCwqCFDm2UBoXS+ECCuyAItOxbqHAFo4rEHYBUuzCRqKP6JEwBSDZBUZxBUZZCrv10hkRwtoFKVywBQ2JcKxIgYIm78y+xd5hd3a+3rx73/39pckkfDi7d+b+37n3nHtPv9cyZ09eW6reDtevQ9Vrb/Va7gHdY7V63atet6rXWrze+/iF9TZ/oH4LE35zgr9Yvy/5XqBg1msxfBbvlRDudVIA1cQ/Vk/6Uz5zYEcuhwwqEaxkL4D6aR8T/pwnPTBxZPBuCKHJqKDf4MQ/X0/8vT5LYGru1SK40IQI+g1M/njiv2PiA3MXwRuVBC4nKYB6N//Dnh18oElWq9fpeWUP9sxp8ke4/7XJDzROzLGv6znXbgRQr/XjqX/M5wIsnJU6Gri3cAFUk/9wPfkP+xyA1lirJbC2MAHUk/9Gz0YfkAIRARydRgJ7ppj8x0x+ICliLt6o52ZzEUCd4vvQeAPJcnySKsL+BJNf2A90bDnQN/mBciXQH2Py760nv91+IB/WagmMTBGOswko1Qfkx2aavje1AOpqI0U+QJ4c261isD9i8i/1Nsp7rfuBvPcD/rDT2YE9u4T+Jj+QN3tHLQX27PD0P9VzsAfoCsv1nN59CVDv+n/r6Q90binw+HBWYLsI4LzJD3RyKXB+ZATg6Q+UFQUMRwCnTH6g01HAqVFLgHPGCOg057YVQH2UcMn4AJ1m6cFjww9GAC8aG6AIfpnr/frpH2uD/xgXoBh+F5uBmxHAsvEAimIw5x9adPi//7FHekeWDyQxAnf/9VPv5uff+SoUzlN//H3vwNJvW/0Zrn9yp41lwMpDi44A9j32m97zJw4m8+H/+OPPvdtffm8WFEo8kF7581O9Rx59uDQBDOb8nvrU31KpX4D48ONLgDJ5+cyh1id/S0Q2YCn2AIq+7CM+/NfefMZMKJDn/3Swd/DJfSUPweHiBRDE+i++DCjsMz9R/Gc+EMAhX4fe4Mtw8Mn9BqKU0L9a+qF3KASg9r/m9TefLnU9WBQvvfpk67v+ibA3BLBsHO7vB7ziydBpIso7+vySgdhgeY8x2ErkhH1BOiz4MwT/IAQgRCyGiO72SfkSwHj7Ac/YD+hYZBcvEMBYxJPixKtPGIgOsFntBwKYiCPPHeg9+9wBA5E5BVf7EcDs+wFPKBXOmNjQLbzajwBmQalwvqj2I4C5fZEiM4DMQv8ETvkRQIdCSbvI+RBnO6RyCWCuvOKJkgVR7Sf0J4BG9gNetx+Q/Gek2o8AGny67HN0OGGidkO1HwE0u748YX2ZIrFHc0TdBgEsAqXCCYb+qv0IYFHsU16aFDZoCaCVkNPR4faRoiUA+wGFEmXaUn4E0OraU8VZe7xmL4YA2iYiAEeHW4i+VPsRQCpE+sk6dLHSFfoTQFLoMrS4ZZeKTAJI8ovp6PACQv/qya/ajwDSDU2VCjeG1CsBZPGE0mWomQhL8RUBZIEuQ/NHtR8BZPW0slE1P56VZSGA3Iijw9arsxOZlZfUWRBAjugyNDuu9SaAzPcDlKtOS2RUXOtNAFmjy9B0qPYjgM6gy9BkbB6yAgF0aD/gCfsB44b+jlkTgKdamUQRlewJAXR2XavL0GhJutabADqNK6x2Jqr9HPQhgCK+6FKDWwkpEiMBFBPqKhW+z363LBNAaegydB/VfgRQJI4Ob+yJqPYjgHL3A86Uux8gK0IAxVNylyF1EQSAXplXXbnWmwAwtB9QyoSIfQ8HfQgAD1BKlyHVfgSAHSihy1D8fqr9CAA70OUuQ/F7HXEsmgAwmi52GXKtNwFggsnStS5DqV2NduebuwRQ8i//3fp/k98P6EqpcGrVfj/97+fexbe/IoCSf/nbf/++d+P6etI/YxdKhVO82++vH9weSIAACuf61TvJRwK5dxlKLbUZ0r/95ffWmQSwEQpeSfxpkPPR4dSq/UL2IX0QQFZfihy7DKUY+l8R+hNArmFhTl2GUoxaPv3om+SXewTQIjlsDOXSZSie/ClV+0XKL/UNXwJIYD/g4tv/SPpnzKHLUGonGwf7PO/f8gUngHGeFD8kvx+QcpehFKv9IrL74d8/+XITwHhc/yT91GCqXYZSu+34i8+/k/IjgMm59PZXyacGU7tNJ7V+B3erp/7Vj/7py0wAkxMhY4SOKZPSfXpxcCm1lN/FxCVOAIkToWOEkCmTylM3tWu9c6jwJIAMiBDybuIbSG2vu6PaL6WDPpHyi30cEMDM5HBqrM2im9Sq/aT8CGDuRCgZVWQp00aXoRQ3IqX8CKARooos9QskFn10OLVbjGPPRsqPABojh13lRXUZCtGkVO13N4OsDQF0Yj8g/VLhpivxNvYcnk4r9H/fKT8CWABRKpz6oZKma/FTq/aLlF98LiCAhZDDsdKm1uchl5Sq/QZ3OUj5EcCiyeEWoXlfxbU/sSamMf6XXOxJAG09eT5NvM583l2GUqv2i/GX8iOA1riZwUmzeXUZSu1a7xj3m4mXaRNAAUTqKYdS4Vm6DKV06CiQ8iOApNahOZQKz9JlKLlqPyk/AkhtPyD1W4Sm7TKU2kWkGxWZUn4EkBiRiupaqXBq1X45nMkggIKJU2jp3yo8Xpehwd1+Z9JK+V2x7ieAlMnhFqFxjw7HxmFK13q74IMAsiDSU6mXCu/WZSi1ar8cxpQAkNXTaqfNvdSu9Y7QX8qPALIil/Xqdl2GUus8FKcvpfwIIDty2LEe7jKUWrWflB8BZE0ODUc3uwyldreflB8BdIIcGo5Gl6GXEzrjL+VHAJ3aD0j9FqGY+ClV+0n5EUCnyKHhaDpjpY03AXSQHBqOphEtueCDADrKJb3qRpLDfgkBYGqiVPhT3Wq3JYeMCQFgZuIWmy/cZLOFHI5TEwDmRg4NRxfJFaE/AZSEza775HDFOgGgkbC39Eo3KT8CKJocGo6KgggADXKx0NSglB8BoFfmefcvMuinQABYGCXdeBPZj6tqIQgAWyllN/yiakgCwPZ0PR/ulB8BYAQ5NBydlsh2aONNANiFmx3cIBtc8PH+LR8uAWAccmg4Ounvo403AWCCJ2Y0wOwCUn4EgKnWzPnfIiTlRwCYgRwajo4M/bXxJgDMRg4NR7eV19U77vQnAMxKDg1Hhxlc8CHlRwCYDzmVCke0cskpPwLA/EPqHKroopBJyo8A0MCTNfVuORGp3HTfIQGgubV1qrcI3c1wrwIEkB2pXp8t5UcAWNRkS+zUoJQfAWDB+wGpNByV8iMAtEAKpcLaeBMA2gy9W2446oIPAkDLtNVwtKR7DAkAydJGw9ESbzImACTLohuOxgaklB8BICEW1XB0o5uRlB8BICkW0WpLP0MCQMI0OUGl/AgAGdBUw1EpPwJAJsy7+4423gSAzPYD5pWm08abAJAh8yrU0cabAJApszYcTfXoMQgAYzJtw9HBKb+rTvkRALJm2ol8RehPAOgGk4bysy4dQABIjHEbjkr5EQA6yDgNR6X8CAAdZrdbhKT8yuMhQ1AWcYtQTPJHHn34V09/KT8CQAFY48MSAAABAAQAgAAAEAAAAgBAAAAIAAABACAAAAQAgAAAEAAAAgBAAAAIAAABACAAAAQAgAAAEAAAAgBAAAAIAAABACAAAAQAgAAAEAAAAgBAAAAIAAABACAAAAQAgAAAEAAAAgBAAAABACAAAAQAgAAAEAAAAgBAAAC6JYBVwwAUyWoI4J5xAIrkXgjglnEAiuRWCGDNOABFskYAQMkCeO/jF9ar/7JuLICiWI+5v5kGXDUeQFEM5nw//uPsyWvHqre/GROgGI5XEcCKCAAoOAIYCKAyQdQCXDYmQBFcruf8llLgz4wLUAS/zPX+g3/17Mlr31ZvS8YH6Cyx+//45v8YPgz0rvEBOs2WOT4sgNgHcDYA6Ca/2uvbIoB6Y0AUAHT06b+5+bdTBBBcEAUAnXz6Xxj+i78SQG2IN4wX0CneGH76B/2d/umzJ6/dqN6WjRuQPavV5D+63d8YdSXYaUsBoBOh/+md/uaOAqhPCb5l/ICseauey9vS3+3frpYCcUjomHEEsmOlmvzHR/0D49wKHOGDS0OAvFgbFfqPHQHUUcDh6i02BfcaVyCLdf/R6um/NhcBkADQvck/7hJgQP0Hnja+QNKcHnfyTySAWgIr1dvxnvQgkOKT/3g9R8emP83/k+UAkG/YP3UEMLQciMoi2QGgXdamnfxTRwAPRAIRAXzYUycAtMFKveafeknen8dPUYngfPX2F0sCYGEhf1T4XZj1D+rP6yeqJLBURwPLPh+gMVbrp/76PP6w/rx/ukoEp6q3d0QDwNyf+nGk9/I8/9B+Ez9pvTcQy4JzRADMPPHjlq4Ls6z1FyqAIRGcqkWw5LMExma9nviXm5j4CxHAkAwiU/BiLQQA2xMh/meTFvQkL4ChqGC5lsGyyACe9IONvWjWsdrk0z4JAWwjhBDA4fp1qN4zWPa9QAdZrdf0t3obBTxr89rNn5b/CzAAdjtvo00ZwmQAAAAASUVORK5CYII=',
    },
    netcheck: {
        name: 'Netcheck',
        url: 'https://tg.ilia.ae',
        accent: '#0088cc',
        icon: 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2264%22%20height%3D%2264%22%20viewBox%3D%220%200%2064%2064%22%20role%3D%22img%22%20aria-label%3D%22tg.ilia.ae%22%3E%20%3Ccircle%20cx%3D%2232%22%20cy%3D%2232%22%20r%3D%228%22%20fill%3D%22%23111%22%2F%3E%20%3Cpath%20d%3D%22M12%2032c0%200%208-14%2020-14s20%2014%2020%2014-8%2014-20%2014S12%2032%2012%2032z%22%20fill%3D%22none%22%20stroke%3D%22%23111%22%20stroke-width%3D%222.5%22%20stroke-linecap%3D%22round%22%2F%3E%20%3Ccircle%20cx%3D%2232%22%20cy%3D%2232%22%20r%3D%2218%22%20fill%3D%22none%22%20stroke%3D%22%23111%22%20stroke-width%3D%221%22%20stroke-dasharray%3D%224%204%22%20opacity%3D%220.3%22%2F%3E%20%3C%2Fsvg%3E',
    },
    integra: {
        name: 'Integra',
        url: 'https://integra.supply',
        accent: '#6366f1',
        icon: 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2032%2032%22%3E%20%3Cdefs%3E%20%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%25%22%20y1%3D%220%25%22%20x2%3D%22100%25%22%20y2%3D%22100%25%22%3E%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23818CF8%22%2F%3E%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%236366F1%22%2F%3E%20%3C%2FlinearGradient%3E%20%3C%2Fdefs%3E%20%3Ccircle%20cx%3D%2216%22%20cy%3D%2216%22%20r%3D%2215%22%20fill%3D%22url(%23g)%22%2F%3E%20%3Cpath%20d%3D%22M16%205L5%2011v10l11%206%2011-6V11L16%205z%22%20stroke%3D%22%23fff%22%20stroke-width%3D%222.5%22%20stroke-linejoin%3D%22round%22%20fill%3D%22none%22%2F%3E%20%3Cpath%20d%3D%22M5%2011l11%205.5%2011-5.5%22%20stroke%3D%22%23fff%22%20stroke-width%3D%222.5%22%20stroke-linejoin%3D%22round%22%20fill%3D%22none%22%2F%3E%20%3Cpath%20d%3D%22M16%2016.5V27%22%20stroke%3D%22%23fff%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%2F%3E%20%3C%2Fsvg%3E',
    },
};
/** Canonical order for the footer "our projects" row. */
const IK_FAMILY_ORDER = [
    'ilia',
    'mayday',
    'deposit',
    'aliro',
    'mirador',
    'monolith',
    'netcheck',
    'integra',
];

/**
 * "Our projects" row — the ILIA family of sites as real-logo chips, from the built-in
 * `IK_FAMILY` catalogue (same marks the panel shows), with per-active-language URLs. No host
 * markup or per-project config: the footer auto-embeds this when `footer.projects` is set.
 *
 * ```html
 * <ik-family-links />
 * <ik-family-links size="sm" [keys]="['mayday','deposit']" />
 * ```
 */
class FamilyLinks {
    cfg = inject(SITE_KIT_CONFIG);
    /** Visual size hint, reflected to a host attribute for CSS. */
    size = input('md', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Active language for per-language URLs. */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Which family keys to render, in order. Defaults to the whole family (`IK_FAMILY_ORDER`). */
    keys = input(...(ngDevMode ? [undefined, { debugName: "keys" }] : /* istanbul ignore next */ []));
    activeLang = computed(() => this.lang() ?? this.cfg.defaultLang, ...(ngDevMode ? [{ debugName: "activeLang" }] : /* istanbul ignore next */ []));
    items = computed(() => {
        const lang = this.activeLang();
        const keys = this.keys() ?? IK_FAMILY_ORDER;
        return keys
            .map((k) => IK_FAMILY[k])
            .filter((m) => !!m)
            .map((m) => ({
            name: m.name,
            url: resolveLinkHref({ url: m.url, urls: m.urls }, lang, this.cfg.defaultLang),
            icon: m.icon,
            accent: m.accent,
        }));
    }, ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: FamilyLinks, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: FamilyLinks, isStandalone: true, selector: "ik-family-links", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, keys: { classPropertyName: "keys", publicName: "keys", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.size": "size()" }, classAttribute: "ik-family-links" }, ngImport: i0, template: `
        @if (items().length) {
            <ul class="row" role="list">
                @for (p of items(); track p.url) {
                    <li>
                        <a
                            class="chip"
                            [href]="p.url"
                            [style.--fam-accent]="p.accent"
                            [attr.title]="p.name"
                            [attr.aria-label]="p.name"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <img class="ico" [src]="p.icon" [alt]="p.name" loading="lazy" />
                        </a>
                    </li>
                }
            </ul>
        }
    `, isInline: true, styles: [":host{display:block}.row{display:inline-flex;flex-wrap:wrap;gap:var(--sp-2, .5rem);list-style:none;margin:0;padding:0}.chip{display:inline-flex;width:var(--ik-family-size, 2.25rem);height:var(--ik-family-size, 2.25rem);border-radius:var(--r-md, 12px);border:1px solid var(--border, #e5e5e9);background:#fff;overflow:hidden;transition:border-color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),box-shadow var(--dur-fast, .15s) var(--ease-out, ease)}.chip:hover{border-color:color-mix(in oklch,var(--fam-accent, var(--brand, #6d28d9)) 55%,transparent);box-shadow:0 0 0 3px color-mix(in oklch,var(--fam-accent, var(--brand, #6d28d9)) 18%,transparent);transform:translateY(-1px)}.chip:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .35))}.ico{display:block;width:100%;height:100%;object-fit:cover}:host([size=\"sm\"]) .chip{width:var(--ik-family-size, 1.5rem);height:var(--ik-family-size, 1.5rem);border-radius:5px}:host([size=\"sm\"]) .chip:hover{transform:none}@media(prefers-reduced-motion:reduce){.chip,.chip:hover{transform:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: FamilyLinks, decorators: [{
            type: Component,
            args: [{ selector: 'ik-family-links', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        @if (items().length) {
            <ul class="row" role="list">
                @for (p of items(); track p.url) {
                    <li>
                        <a
                            class="chip"
                            [href]="p.url"
                            [style.--fam-accent]="p.accent"
                            [attr.title]="p.name"
                            [attr.aria-label]="p.name"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <img class="ico" [src]="p.icon" [alt]="p.name" loading="lazy" />
                        </a>
                    </li>
                }
            </ul>
        }
    `, host: { class: 'ik-family-links', '[attr.size]': 'size()' }, styles: [":host{display:block}.row{display:inline-flex;flex-wrap:wrap;gap:var(--sp-2, .5rem);list-style:none;margin:0;padding:0}.chip{display:inline-flex;width:var(--ik-family-size, 2.25rem);height:var(--ik-family-size, 2.25rem);border-radius:var(--r-md, 12px);border:1px solid var(--border, #e5e5e9);background:#fff;overflow:hidden;transition:border-color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),box-shadow var(--dur-fast, .15s) var(--ease-out, ease)}.chip:hover{border-color:color-mix(in oklch,var(--fam-accent, var(--brand, #6d28d9)) 55%,transparent);box-shadow:0 0 0 3px color-mix(in oklch,var(--fam-accent, var(--brand, #6d28d9)) 18%,transparent);transform:translateY(-1px)}.chip:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .35))}.ico{display:block;width:100%;height:100%;object-fit:cover}:host([size=\"sm\"]) .chip{width:var(--ik-family-size, 1.5rem);height:var(--ik-family-size, 1.5rem);border-radius:5px}:host([size=\"sm\"]) .chip:hover{transform:none}@media(prefers-reduced-motion:reduce){.chip,.chip:hover{transform:none}}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], keys: [{ type: i0.Input, args: [{ isSignal: true, alias: "keys", required: false }] }] } });

// AUTO-GENERATED by `npm run gen:licenses` with license-catalog.generated.ts — DO NOT EDIT BY HAND.
// The display name of each licence in the catalog, without its text (see tools/licenses.mjs).
const LICENSE_NAMES = {
    "mit": "MIT License",
    "proprietary": "Proprietary License",
    "polyform-nc": "PolyForm Noncommercial 1.0.0",
    "nda-confidential": "INTEGRA NDA Confidential",
    "source-available-commercial": "Source-Available Commercial v1"
};

/** Localized DISPLAY names for licenses whose label has a meaningful translation. Keys (and
 *  languages) not listed fall back to the catalog's English name — the right default for SPDX /
 *  proper names (e.g. "PolyForm Noncommercial 1.0.0"). The license TEXT is unaffected. */
const LICENSE_NAME_I18N = {
    proprietary: { ru: 'Лицензия' },
    'source-available-commercial': { ru: 'Исходный код доступен (коммерческая) v1' },
    'nda-confidential': { ru: 'INTEGRA NDA (конфиденциально)' },
    mit: { ru: 'Лицензия MIT' },
};
/** `config.license` → its key and localized display name, without the licence text: what the footer
 *  links. Its own module, apart from license.ts and the catalog's 25 kB of texts, which an app then
 *  carries only when it renders a licence (ik-license, resolveLicense). */
function licenseName(cfg, lang) {
    const key = cfg?.license;
    if (!key)
        return undefined;
    const name = (lang && LICENSE_NAME_I18N[key]?.[lang]) || LICENSE_NAMES[key] || key;
    return { key, name };
}

/**
 * Language switcher — DEPENDENCY-FREE on i18n engines. It renders the language
 * list (flag + native name) and emits the chosen code; the host wires it to
 * its translator.
 *
 * Defaults: shows the site's configured languages (from `provideSiteKit`'s
 * `languages`), or the full Integra set (en/ru/ar/kk/zh/hi/ur) when standalone.
 *
 * ```html
 * <ik-lang-switcher [current]="translate.currentLang" (langChange)="translate.use($event)" />
 * ```
 */
class LangSwitcher {
    cfg = inject(SITE_KIT_CONFIG, { optional: true });
    host = inject((ElementRef));
    /** Languages to offer. Defaults to the site's configured set, else all of IK_LANGUAGES. */
    languages = input(this.cfg?.languages?.length ? ikLanguages(this.cfg.languages) : [...IK_LANGUAGES], ...(ngDevMode ? [{ debugName: "languages" }] : /* istanbul ignore next */ []));
    /** Active language code (controlled by the host). */
    current = input(this.cfg?.defaultLang, ...(ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []));
    /**
     * Compact mode: render a single text button showing the NEXT language's code
     * (click cycles to it) instead of the flag + dropdown. With 2 languages this
     * is a plain RU/EN toggle; with 3+ it cycles. Matches the reference QR card.
     */
    compact = input(false, ...(ngDevMode ? [{ debugName: "compact" }] : /* istanbul ignore next */ []));
    /** Emits the selected language code. */
    langChange = output();
    open = signal(false, ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    /** Localized aria-label ("Language" / "Язык" / …) for the active language. */
    switcherLabel = computed(() => chromeString(this.current() ?? this.cfg?.defaultLang, 'language', this.cfg?.strings), ...(ngDevMode ? [{ debugName: "switcherLabel" }] : /* istanbul ignore next */ []));
    currentLang = computed(() => this.languages().find((l) => l.code === this.current()), ...(ngDevMode ? [{ debugName: "currentLang" }] : /* istanbul ignore next */ []));
    /** The language the compact toggle advances to (wraps around the list). */
    nextLang = computed(() => {
        const langs = this.languages();
        if (!langs.length)
            return undefined;
        const i = langs.findIndex((l) => l.code === this.current());
        return langs[(i + 1) % langs.length];
    }, ...(ngDevMode ? [{ debugName: "nextLang" }] : /* istanbul ignore next */ []));
    choose(code) {
        this.open.set(false);
        if (code !== this.current())
            this.langChange.emit(code);
    }
    /** Open/close the listbox; on open, move focus to the active (or first) option
     *  so the popup is keyboard-operable per the WAI-ARIA listbox pattern. */
    toggle() {
        const willOpen = !this.open();
        this.open.set(willOpen);
        if (willOpen && typeof requestAnimationFrame !== 'undefined') {
            requestAnimationFrame(() => {
                const root = this.host.nativeElement;
                const el = (root.querySelector('.menu li.active') ??
                    root.querySelector('.menu li'));
                el?.focus();
            });
        }
    }
    /** Arrow-key roving focus between options (wraps top↔bottom). */
    move(dir, ev) {
        ev.preventDefault();
        const root = this.host.nativeElement;
        const items = Array.from(root.querySelectorAll('.menu li'));
        if (!items.length)
            return;
        const active = root.ownerDocument.activeElement;
        const i = active ? items.indexOf(active) : -1;
        items[(i + dir + items.length) % items.length]?.focus();
    }
    /** Escape: close the popup and return focus to the trigger. */
    closeToTrigger() {
        this.open.set(false);
        const trigger = this.host.nativeElement.querySelector('.trigger');
        trigger?.focus();
    }
    onDocClick(event) {
        if (!this.open())
            return;
        const target = event.target;
        if (target && !this.host.nativeElement.contains(target))
            this.open.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: LangSwitcher, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: LangSwitcher, isStandalone: true, selector: "ik-lang-switcher", inputs: { languages: { classPropertyName: "languages", publicName: "languages", isSignal: true, isRequired: false, transformFunction: null }, current: { classPropertyName: "current", publicName: "current", isSignal: true, isRequired: false, transformFunction: null }, compact: { classPropertyName: "compact", publicName: "compact", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { langChange: "langChange" }, host: { listeners: { "document:click": "onDocClick($event)" }, classAttribute: "ik-lang-switcher" }, ngImport: i0, template: `
        @if (compact()) {
            <!-- Minimal text toggle: shows the TARGET language code; click cycles to it. -->
            <button
                type="button"
                class="trigger trigger--compact"
                (click)="choose(nextLang()?.code ?? '')"
                [attr.aria-label]="'Switch language to ' + (nextLang()?.nativeName ?? '')"
                [title]="nextLang()?.nativeName ?? ''"
            >
                {{ (nextLang()?.code ?? current() ?? '').toUpperCase() }}
            </button>
        } @else {
            <button
                type="button"
                class="trigger"
                (click)="toggle()"
                (keydown.escape)="closeToTrigger()"
                [attr.aria-expanded]="open()"
                aria-haspopup="listbox"
                aria-controls="ik-lang-list"
                [attr.aria-label]="switcherLabel()"
            >
                <span class="flag" aria-hidden="true">{{ currentLang()?.flag }}</span>
                <span class="label">{{ currentLang()?.nativeName ?? current() ?? '—' }}</span>
            </button>

            @if (open()) {
                <ul class="menu" role="listbox" id="ik-lang-list" [attr.aria-label]="switcherLabel()">
                    @for (lang of languages(); track lang.code) {
                        <li
                            role="option"
                            tabindex="0"
                            [attr.aria-selected]="lang.code === current()"
                            [class.active]="lang.code === current()"
                            (click)="choose(lang.code)"
                            (keydown.enter)="choose(lang.code)"
                            (keydown.space)="$event.preventDefault(); choose(lang.code)"
                            (keydown.arrowdown)="move(1, $event)"
                            (keydown.arrowup)="move(-1, $event)"
                            (keydown.escape)="closeToTrigger()"
                        >
                            <span class="flag" aria-hidden="true">{{ lang.flag }}</span>
                            <span>{{ lang.nativeName }}</span>
                        </li>
                    }
                </ul>
            }
        }
    `, isInline: true, styles: [":host{position:relative;display:inline-block}.trigger{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);padding:var(--sp-2, .5rem) var(--sp-3, .75rem);border-radius:var(--r-md, 12px);border:1px solid var(--border, #e5e5e9);background:var(--bg-elev, #fff);color:var(--text, #09090f);font-size:var(--fs-sm, .875rem);transition:border-color var(--dur-fast, .15s) var(--ease-out, ease)}.trigger:hover{border-color:var(--border-strong, #cdcdd4)}.trigger:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.trigger--compact{justify-content:center;width:32px;height:32px;padding:0;border:1px solid transparent;background:none;border-radius:var(--r-sm, 8px);color:var(--text-mute, #5c5c6d);font-family:inherit;font-size:var(--fs-xs, .75rem);font-weight:var(--fw-bold, 700);letter-spacing:var(--ls-wide, .06em)}.trigger--compact:hover{background:var(--bg-mute, #f0f0f2);color:var(--text, #09090f);border-color:var(--border-strong, #cdcdd4)}.flag{font-size:1.1em;line-height:1}.menu{position:absolute;top:calc(100% + var(--sp-2, .5rem));inset-inline-end:0;min-width:10rem;z-index:var(--z-dropdown, 100);padding:var(--sp-1, .25rem);margin:0;list-style:none;background:var(--bg-elev, #fff);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-md, 12px);box-shadow:var(--shadow-md, 0 8px 24px rgba(0, 0, 0, .12))}.menu li{display:flex;align-items:center;gap:var(--sp-2, .5rem);padding:var(--sp-2, .5rem) var(--sp-3, .75rem);border-radius:var(--r-sm, 8px);font-size:var(--fs-sm, .875rem);color:var(--text, #09090f);cursor:pointer}.menu li:hover{background:var(--bg-mute, #f0f0f2)}.menu li.active{color:var(--brand, #6d28d9);font-weight:var(--fw-semi, 600)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: LangSwitcher, decorators: [{
            type: Component,
            args: [{ selector: 'ik-lang-switcher', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        @if (compact()) {
            <!-- Minimal text toggle: shows the TARGET language code; click cycles to it. -->
            <button
                type="button"
                class="trigger trigger--compact"
                (click)="choose(nextLang()?.code ?? '')"
                [attr.aria-label]="'Switch language to ' + (nextLang()?.nativeName ?? '')"
                [title]="nextLang()?.nativeName ?? ''"
            >
                {{ (nextLang()?.code ?? current() ?? '').toUpperCase() }}
            </button>
        } @else {
            <button
                type="button"
                class="trigger"
                (click)="toggle()"
                (keydown.escape)="closeToTrigger()"
                [attr.aria-expanded]="open()"
                aria-haspopup="listbox"
                aria-controls="ik-lang-list"
                [attr.aria-label]="switcherLabel()"
            >
                <span class="flag" aria-hidden="true">{{ currentLang()?.flag }}</span>
                <span class="label">{{ currentLang()?.nativeName ?? current() ?? '—' }}</span>
            </button>

            @if (open()) {
                <ul class="menu" role="listbox" id="ik-lang-list" [attr.aria-label]="switcherLabel()">
                    @for (lang of languages(); track lang.code) {
                        <li
                            role="option"
                            tabindex="0"
                            [attr.aria-selected]="lang.code === current()"
                            [class.active]="lang.code === current()"
                            (click)="choose(lang.code)"
                            (keydown.enter)="choose(lang.code)"
                            (keydown.space)="$event.preventDefault(); choose(lang.code)"
                            (keydown.arrowdown)="move(1, $event)"
                            (keydown.arrowup)="move(-1, $event)"
                            (keydown.escape)="closeToTrigger()"
                        >
                            <span class="flag" aria-hidden="true">{{ lang.flag }}</span>
                            <span>{{ lang.nativeName }}</span>
                        </li>
                    }
                </ul>
            }
        }
    `, host: { class: 'ik-lang-switcher', '(document:click)': 'onDocClick($event)' }, styles: [":host{position:relative;display:inline-block}.trigger{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);padding:var(--sp-2, .5rem) var(--sp-3, .75rem);border-radius:var(--r-md, 12px);border:1px solid var(--border, #e5e5e9);background:var(--bg-elev, #fff);color:var(--text, #09090f);font-size:var(--fs-sm, .875rem);transition:border-color var(--dur-fast, .15s) var(--ease-out, ease)}.trigger:hover{border-color:var(--border-strong, #cdcdd4)}.trigger:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.trigger--compact{justify-content:center;width:32px;height:32px;padding:0;border:1px solid transparent;background:none;border-radius:var(--r-sm, 8px);color:var(--text-mute, #5c5c6d);font-family:inherit;font-size:var(--fs-xs, .75rem);font-weight:var(--fw-bold, 700);letter-spacing:var(--ls-wide, .06em)}.trigger--compact:hover{background:var(--bg-mute, #f0f0f2);color:var(--text, #09090f);border-color:var(--border-strong, #cdcdd4)}.flag{font-size:1.1em;line-height:1}.menu{position:absolute;top:calc(100% + var(--sp-2, .5rem));inset-inline-end:0;min-width:10rem;z-index:var(--z-dropdown, 100);padding:var(--sp-1, .25rem);margin:0;list-style:none;background:var(--bg-elev, #fff);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-md, 12px);box-shadow:var(--shadow-md, 0 8px 24px rgba(0, 0, 0, .12))}.menu li{display:flex;align-items:center;gap:var(--sp-2, .5rem);padding:var(--sp-2, .5rem) var(--sp-3, .75rem);border-radius:var(--r-sm, 8px);font-size:var(--fs-sm, .875rem);color:var(--text, #09090f);cursor:pointer}.menu li:hover{background:var(--bg-mute, #f0f0f2)}.menu li.active{color:var(--brand, #6d28d9);font-weight:var(--fw-semi, 600)}\n"] }]
        }], propDecorators: { languages: [{ type: i0.Input, args: [{ isSignal: true, alias: "languages", required: false }] }], current: [{ type: i0.Input, args: [{ isSignal: true, alias: "current", required: false }] }], compact: [{ type: i0.Input, args: [{ isSignal: true, alias: "compact", required: false }] }], langChange: [{ type: i0.Output, args: ["langChange"] }] } });

const IK_THEME_OPTIONS = new InjectionToken('IK_THEME_OPTIONS');

const STORAGE_KEY$1 = 'theme'; // same key as the apps' ThemeService → drop-in compatible
const DARK_CLASS = 'app-dark';
/** aria-label strings per language (falls back to English) so the control is
 *  localized on multilingual sites instead of always announcing English. */
const THEME_STRINGS = {
    en: { theme: 'Theme', light: 'light', dark: 'dark', auto: 'auto' },
    ru: { theme: 'Тема', light: 'светлая', dark: 'тёмная', auto: 'авто' },
    es: { theme: 'Tema', light: 'claro', dark: 'oscuro', auto: 'automático' },
    pt: { theme: 'Tema', light: 'claro', dark: 'escuro', auto: 'automático' },
    ar: { theme: 'السمة', light: 'فاتح', dark: 'داكن', auto: 'تلقائي' },
    kk: { theme: 'Тақырып', light: 'ашық', dark: 'қараңғы', auto: 'авто' },
    zh: { theme: '主题', light: '浅色', dark: '深色', auto: '自动' },
    hi: { theme: 'थीम', light: 'हल्का', dark: 'गहरा', auto: 'स्वतः' },
    ur: { theme: 'تھیم', light: 'روشن', dark: 'گہرا', auto: 'خودکار' },
};
/**
 * Three-state theme toggle (light → dark → auto), mirroring the apps'
 * `ThemeService`: it toggles the `app-dark` class on <html>, persists the mode
 * under `theme`, and in `auto` mode follows the OS preference live. Where it writes
 * is configurable (`IK_THEME_OPTIONS`) — `provideSiteKitTabler()` makes it drive
 * Tabler's `data-bs-theme` instead.
 *
 * Click cycles the mode. `(themeChange)` emits the new mode.
 *
 * ```html
 * <ik-theme-toggle (themeChange)="onTheme($event)" />
 * ```
 */
class ThemeToggle {
    doc = inject(DOCUMENT);
    opts = inject(IK_THEME_OPTIONS, { optional: true }) ?? {};
    storageKey = this.opts.storageKey ?? STORAGE_KEY$1;
    darkClass = this.opts.darkClass === undefined ? DARK_CLASS : this.opts.darkClass;
    attributes = this.opts.attributes ?? [];
    /** Compact mode: small borderless button for in-card chrome (matches the reference). */
    compact = input(false, ...(ngDevMode ? [{ debugName: "compact" }] : /* istanbul ignore next */ []));
    /** Active language for the aria-label / title (falls back to English). */
    lang = input('en', ...(ngDevMode ? [{ debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Localized "Theme: <mode>" accessible name. */
    label = computed(() => {
        const s = THEME_STRINGS[this.lang()] ?? THEME_STRINGS['en']; // safe: 'en' is a fixed key
        return `${s.theme}: ${s[this.mode()]}`;
    }, ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Emits the active mode whenever it changes (and once on init). */
    themeChange = output();
    mode = signal('auto', ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    mql = null;
    onOsChange = (e) => {
        if (this.mode() === 'auto')
            this.applyDark(e.matches);
    };
    constructor() {
        const win = this.doc.defaultView;
        this.mql = win?.matchMedia?.('(prefers-color-scheme: dark)') ?? null;
        this.mql?.addEventListener?.('change', this.onOsChange);
        const saved = this.safeRead();
        const mode = saved === 'light' || saved === 'dark' || saved === 'auto' ? saved : 'auto';
        this.mode.set(mode);
        this.applyMode(mode); // apply immediately (avoids a theme flash before ngOnInit)
    }
    // Emit the initial mode here (not in the constructor) so a parent's
    // (themeChange) binding — wired after construction — actually receives it.
    ngOnInit() {
        this.themeChange.emit(this.mode());
    }
    ngOnDestroy() {
        this.mql?.removeEventListener?.('change', this.onOsChange);
    }
    cycle() {
        const order = ['light', 'dark', 'auto'];
        const next = order[(order.indexOf(this.mode()) + 1) % order.length]; // safe: modulo index always in bounds of the fixed-length array
        this.mode.set(next);
        this.safeStore(next);
        this.applyMode(next);
        this.themeChange.emit(next);
    }
    applyMode(mode) {
        if (mode === 'auto')
            this.applyDark(this.mql?.matches ?? false);
        else
            this.applyDark(mode === 'dark');
    }
    applyDark(dark) {
        const root = this.doc.documentElement;
        if (this.darkClass)
            root.classList.toggle(this.darkClass, dark);
        for (const a of this.attributes)
            root.setAttribute(a, dark ? 'dark' : 'light');
    }
    safeRead() {
        try {
            /* istanbul ignore next -- no-DOM guard: defaultView/localStorage are always present in a browser, so the optional-chain short-circuits run only under SSR. */
            return this.doc.defaultView?.localStorage?.getItem(this.storageKey) ?? null;
        }
        catch {
            return null;
        }
    }
    safeStore(mode) {
        try {
            this.doc.defaultView?.localStorage?.setItem(this.storageKey, mode);
        }
        catch {
            /* storage unavailable — ignore */
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ThemeToggle, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: ThemeToggle, isStandalone: true, selector: "ik-theme-toggle", inputs: { compact: { classPropertyName: "compact", publicName: "compact", isSignal: true, isRequired: false, transformFunction: null }, lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { themeChange: "themeChange" }, host: { classAttribute: "ik-theme-toggle" }, ngImport: i0, template: `
        <button
            type="button"
            (click)="cycle()"
            [class.compact]="compact()"
            [attr.aria-label]="label()"
            [title]="label()"
        >
            @switch (mode()) {
                @case ('light') {
                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        aria-hidden="true"
                    >
                        <circle cx="12" cy="12" r="4" />
                        <path
                            d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"
                        />
                    </svg>
                }
                @case ('dark') {
                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        aria-hidden="true"
                    >
                        <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
                    </svg>
                }
                @default {
                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        aria-hidden="true"
                    >
                        <circle cx="12" cy="12" r="9" />
                        <path d="M12 3a9 9 0 0 1 0 18Z" fill="currentColor" />
                    </svg>
                }
            }
        </button>
    `, isInline: true, styles: ["button{display:inline-grid;place-items:center;width:2.5rem;height:2.5rem;border-radius:var(--r-md, 12px);border:1px solid var(--border, #e5e5e9);background:var(--bg-elev, #fff);color:var(--text-mute, #5c5c6d);transition:color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease)}button:hover{color:var(--brand, #6d28d9);border-color:var(--border-strong, #cdcdd4)}button:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}svg{width:1.25rem;height:1.25rem}button.compact{width:32px;height:32px;border:1px solid transparent;background:none;border-radius:var(--r-sm, 8px);color:var(--text-mute, #5c5c6d)}button.compact:hover{background:var(--bg-mute, #f0f0f2);color:var(--text, #09090f);border-color:var(--border-strong, #cdcdd4)}button.compact svg{width:16px;height:16px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ThemeToggle, decorators: [{
            type: Component,
            args: [{ selector: 'ik-theme-toggle', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <button
            type="button"
            (click)="cycle()"
            [class.compact]="compact()"
            [attr.aria-label]="label()"
            [title]="label()"
        >
            @switch (mode()) {
                @case ('light') {
                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        aria-hidden="true"
                    >
                        <circle cx="12" cy="12" r="4" />
                        <path
                            d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"
                        />
                    </svg>
                }
                @case ('dark') {
                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        aria-hidden="true"
                    >
                        <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
                    </svg>
                }
                @default {
                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        aria-hidden="true"
                    >
                        <circle cx="12" cy="12" r="9" />
                        <path d="M12 3a9 9 0 0 1 0 18Z" fill="currentColor" />
                    </svg>
                }
            }
        </button>
    `, host: { class: 'ik-theme-toggle' }, styles: ["button{display:inline-grid;place-items:center;width:2.5rem;height:2.5rem;border-radius:var(--r-md, 12px);border:1px solid var(--border, #e5e5e9);background:var(--bg-elev, #fff);color:var(--text-mute, #5c5c6d);transition:color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease)}button:hover{color:var(--brand, #6d28d9);border-color:var(--border-strong, #cdcdd4)}button:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}svg{width:1.25rem;height:1.25rem}button.compact{width:32px;height:32px;border:1px solid transparent;background:none;border-radius:var(--r-sm, 8px);color:var(--text-mute, #5c5c6d)}button.compact:hover{background:var(--bg-mute, #f0f0f2);color:var(--text, #09090f);border-color:var(--border-strong, #cdcdd4)}button.compact svg{width:16px;height:16px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { compact: [{ type: i0.Input, args: [{ isSignal: true, alias: "compact", required: false }] }], lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], themeChange: [{ type: i0.Output, args: ["themeChange"] }] } });

const DEV_HOSTS = (h) => h === 'localhost' || h === '127.0.0.1' || h === '::1' || h.endsWith('.local') || h.endsWith('.localhost');
/**
 * Live build-integrity check — the data behind `ik-verify-mark`. On load (browser, non-dev)
 * it fetches `config.verify.manifestUrl`, SHA-256-hashes the bundles the page actually
 * loaded and compares them to the manifest:
 *   verified — all match · mismatch — at least one differs (tampered/outdated manifest) ·
 *   dev — localhost (suppressed) · pending — in flight · offline — manifest unreachable ·
 *   unknown — inconclusive · none — no `verify.manifestUrl` configured.
 *
 * Generalises each site's bespoke integrity service into one config-driven kit service.
 * Bind it to the mark: `<ik-verify-mark [status]="integrity.status()" [summary]="integrity.summary()">`.
 */
class IntegrityService {
    cfg = inject(SITE_KIT_CONFIG);
    status = signal('none', ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    manifest = signal(null, ...(ngDevMode ? [{ debugName: "manifest" }] : /* istanbul ignore next */ []));
    checks = signal([], ...(ngDevMode ? [{ debugName: "checks" }] : /* istanbul ignore next */ []));
    checkedAt = signal(null, ...(ngDevMode ? [{ debugName: "checkedAt" }] : /* istanbul ignore next */ []));
    /** Human-readable one-liner for the tooltip/popover (commit · published · SHA · status). */
    summary = computed(() => {
        const m = this.manifest();
        const parts = [];
        if (m?.commit)
            parts.push(`commit ${m.commit}`);
        if (m?.publishedAt)
            parts.push(`published ${m.publishedAt.slice(0, 10)}`);
        const matched = this.checks().find((c) => c.matched === true);
        if (matched?.actual)
            parts.push(`SHA-256 ${matched.actual.slice(0, 16)}…`);
        const bad = this.checks().find((c) => c.matched === false);
        if (bad)
            parts.push(`expected ${bad.expected.slice(0, 12)}… got ${(bad.actual ?? '∅').slice(0, 12)}…`);
        return parts.join(' · ');
    }, ...(ngDevMode ? [{ debugName: "summary" }] : /* istanbul ignore next */ []));
    constructor() {
        const url = this.cfg.verify?.manifestUrl;
        if (url)
            this.start(url);
    }
    /* istanbul ignore next -- browser-only: SSR guard + dev-host detection + load/network
       kickoff glue. The verification logic lives in run(), which is unit-tested with deps. */
    start(url) {
        if (typeof window === 'undefined')
            return;
        const host = window.location.hostname;
        if ((this.cfg.verify?.devHosts ?? []).includes(host) || DEV_HOSTS(host)) {
            this.status.set('dev');
            return;
        }
        this.status.set('pending');
        const kick = () => void this.run(url).catch(() => this.status.set('offline'));
        if (document.readyState === 'complete')
            setTimeout(kick, 0);
        else
            window.addEventListener('load', () => setTimeout(kick, 0), { once: true });
    }
    /** Fetch the manifest, hash the running bundles and set the status. Exposed for testing. */
    async run(url, deps = defaultDeps) {
        let manifest;
        try {
            const resp = await deps.fetch(url, { cache: 'no-cache' });
            if (!resp.ok)
                throw new Error(`manifest ${resp.status}`);
            manifest = (await resp.json());
        }
        catch {
            this.status.set('offline');
            return;
        }
        this.manifest.set(manifest);
        if (!deps.digest) {
            this.status.set('unknown');
            return;
        }
        const checks = [];
        for (const bundle of manifest.bundles ?? []) {
            // Prefer the bundle the page ACTUALLY loaded (by name pattern) over the manifest's
            // possibly-stale absolute URL, so a stale manifest reads as mismatch, not offline.
            const target = deps.findBundle(bundle.name) ?? bundle.url ?? null;
            if (!target) {
                checks.push({ name: bundle.name, expected: bundle.sha256, actual: null, matched: null });
                continue;
            }
            try {
                const r = await deps.fetch(target, { cache: 'force-cache' });
                if (!r.ok)
                    throw new Error(`fetch ${r.status}`);
                const hex = await deps.digest(await r.arrayBuffer());
                checks.push({
                    name: bundle.name,
                    expected: bundle.sha256,
                    actual: hex,
                    matched: hex === bundle.sha256,
                });
            }
            catch {
                checks.push({ name: bundle.name, expected: bundle.sha256, actual: null, matched: null });
            }
        }
        this.checks.set(checks);
        this.checkedAt.set(deps.now());
        if (checks.some((c) => c.matched === false))
            this.status.set('mismatch');
        else if (checks.length && checks.every((c) => c.matched === true))
            this.status.set('verified');
        else
            this.status.set('unknown');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: IntegrityService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: IntegrityService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: IntegrityService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });
/* istanbul ignore next -- browser-default I/O; tests inject their own deps */
async function sha256Hex(buf) {
    const hash = await crypto.subtle.digest('SHA-256', buf);
    return Array.from(new Uint8Array(hash))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
}
/* istanbul ignore next -- reads performance entries in a real browser; not exercised in unit tests */
function findRunningBundle(name) {
    const stem = name.replace(/\.js$/, '');
    const re = new RegExp(`/${stem}(?:-[A-Z0-9]+)?\\.js(?:\\?.*)?$`);
    const entries = performance.getEntriesByType('resource');
    return entries.find((e) => re.test(e.name))?.name ?? null;
}
/* istanbul ignore next -- thin wrapper over browser globals */
const defaultDeps = {
    fetch: (url, init) => fetch(url, init),
    // a getter, so `crypto.subtle` is read when a check runs, not when the module loads
    get digest() {
        return typeof crypto !== 'undefined' && crypto.subtle ? sha256Hex : null;
    },
    findBundle: findRunningBundle,
    now: () => new Date().toISOString(),
};

/** Built-in labels. Like the rest of the kit chrome, maintained in en + ru; other langs fall back to en. */
const VERIFY_LABELS = {
    en: {
        verified: 'Verified build',
        mismatch: 'Tampered build',
        pending: 'Checking integrity…',
        offline: 'Integrity check unavailable',
        unknown: 'Integrity unknown',
        dev: 'Dev build',
    },
    ru: {
        verified: 'Сборка подтверждена',
        mismatch: 'Сборка изменена',
        pending: 'Проверка целостности…',
        offline: 'Проверка недоступна',
        unknown: 'Целостность неизвестна',
        dev: 'Сборка разработки',
    },
};
/**
 * `ik-verify-mark` — wraps a brand glyph (projected, or passed as an inline-SVG string via
 * `[glyph]`) and tints it by a live {@link VerifyStatus}, with a small status dot and a
 * localized tooltip. The sanctioned way to surface build-integrity / authorship status on a
 * site's logo — the right fit for minimal chrome where there is no footer to carry
 * {@link VerifyBadge}. Drop it into `ik-nav`'s `[customBrand]` slot (or anywhere):
 *
 * ```html
 * <a slot="brand" routerLink="/" aria-label="Home">
 *   <ik-verify-mark [status]="integrity.status()" [lang]="lang.current()" [summary]="integrity.summary()">
 *     <svg …>…eye…</svg>
 *   </ik-verify-mark>
 * </a>
 * ```
 *
 * The status colour is applied via `color`, so a `currentColor`-based glyph tints automatically.
 * It owns no data: feed it a status from your own integrity service (or any verify source).
 */
class VerifyMark {
    sanitizer = inject(DomSanitizer);
    /** Live integrity / authorship status. Defaults to `none` (plain mark, no tint/dot/tooltip). */
    status = input('none', ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    /** Active language for the tooltip label (en/ru maintained; others fall back to en). */
    lang = input('en', ...(ngDevMode ? [{ debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Optional inline-SVG glyph; when set it renders instead of projected content. */
    glyph = input(...(ngDevMode ? [undefined, { debugName: "glyph" }] : /* istanbul ignore next */ []));
    /** Mark size in px (square). The projected/innerHTML SVG scales to fill it. */
    size = input(26, ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Extra tooltip detail appended after the status label (e.g. commit / SHA summary). */
    summary = input(...(ngDevMode ? [undefined, { debugName: "summary" }] : /* istanbul ignore next */ []));
    /** Per-language label overrides (deep-merged over the built-in en/ru set). */
    labels = input(...(ngDevMode ? [undefined, { debugName: "labels" }] : /* istanbul ignore next */ []));
    /** Show the live-status popover on hover/focus. Default true; set false for the bare mark. */
    popover = input(true, ...(ngDevMode ? [{ debugName: "popover" }] : /* istanbul ignore next */ []));
    /** Localized status label alone (no summary). Empty when status is `none`. */
    label = computed(() => {
        const s = this.status();
        if (s === 'none')
            return '';
        const l = this.lang() === 'ru' ? 'ru' : 'en';
        return this.labels()?.[l]?.[s] ?? VERIFY_LABELS[l][s];
    }, ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Trusted inline glyph, when provided as a string. */
    glyphHtml = computed(() => {
        const g = this.glyph();
        return g ? this.sanitizer.bypassSecurityTrustHtml(g) : null;
    }, ...(ngDevMode ? [{ debugName: "glyphHtml" }] : /* istanbul ignore next */ []));
    showDot = computed(() => {
        const s = this.status();
        return s === 'verified' || s === 'mismatch' || s === 'dev';
    }, ...(ngDevMode ? [{ debugName: "showDot" }] : /* istanbul ignore next */ []));
    /** Resolved tooltip: localized status label, optionally `· summary`. Empty when status is `none`. */
    tooltip = computed(() => {
        const s = this.status();
        if (s === 'none')
            return '';
        const l = this.lang() === 'ru' ? 'ru' : 'en';
        const label = this.labels()?.[l]?.[s] ?? VERIFY_LABELS[l][s];
        const sum = this.summary();
        return sum ? `${label} · ${sum}` : label;
    }, ...(ngDevMode ? [{ debugName: "tooltip" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: VerifyMark, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: VerifyMark, isStandalone: true, selector: "ik-verify-mark", inputs: { status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, glyph: { classPropertyName: "glyph", publicName: "glyph", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, summary: { classPropertyName: "summary", publicName: "summary", isSignal: true, isRequired: false, transformFunction: null }, labels: { classPropertyName: "labels", publicName: "labels", isSignal: true, isRequired: false, transformFunction: null }, popover: { classPropertyName: "popover", publicName: "popover", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
        <span class="mark mark--{{ status() }}" role="img" [attr.aria-label]="tooltip() || null">
            <span class="glyph" [style.width.px]="size()" [style.height.px]="size()">
                @if (glyphHtml(); as g) {
                    <span class="glyph-svg" [innerHTML]="g"></span>
                } @else {
                    <ng-content></ng-content>
                }
            </span>
            @if (showDot()) {
                <span class="dot" aria-hidden="true"></span>
            }
            @if (popover() && label()) {
                <!-- Live status, revealed on hover/focus of the mark (the mark itself stays a
                     plain link, e.g. "home"). Decorative — the status is on aria-label above. -->
                <span class="vpop" aria-hidden="true">
                    <span class="vpop__label">{{ label() }}</span>
                    @if (summary()) {
                        <span class="vpop__sum">{{ summary() }}</span>
                    }
                </span>
            }
        </span>
    `, isInline: true, styles: [":host{display:inline-flex;line-height:0}.mark{position:relative;display:inline-flex;align-items:center;color:inherit;transition:color var(--dur, .25s) var(--ease-out, ease)}.mark--verified{color:#4ade80}.mark--mismatch{color:#f87171}.mark--dev{color:#fbbf24}.glyph{display:inline-grid;place-items:center}.glyph-svg{display:contents}.glyph ::ng-deep svg{display:block;width:100%;height:100%}.dot{position:absolute;right:-3px;top:2px;width:6px;height:6px;border-radius:50%;background:currentColor;box-shadow:0 0 8px currentColor}.vpop{position:absolute;top:calc(100% + 8px);left:50%;z-index:var(--z-dropdown, 100);display:flex;flex-direction:column;gap:2px;width:max-content;max-width:17rem;padding:.5rem .625rem;background:var(--bg-elev, #fff);color:var(--text, #09090f);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-md, 12px);box-shadow:var(--shadow-md, 0 8px 24px rgba(9, 9, 15, .12));font:var(--fw-medium, 500) .72rem / 1.4 var(--font-display, system-ui, sans-serif);text-align:left;line-height:1.4;opacity:0;visibility:hidden;pointer-events:none;transform:translate(-50%) translateY(-4px);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),visibility 0s var(--dur-fast, .15s)}:host(:hover) .vpop,:host(:focus-within) .vpop{opacity:1;visibility:visible;transform:translate(-50%) translateY(0);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.vpop__label{font-weight:var(--fw-bold, 700);color:var(--text, #09090f);white-space:nowrap}.vpop__sum{color:var(--text-mute, #5c5c6d);font-size:.66rem;font-family:var(--font-mono, ui-monospace, monospace);word-break:break-word}@media(prefers-reduced-motion:reduce){.mark,.vpop{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: VerifyMark, decorators: [{
            type: Component,
            args: [{ selector: 'ik-verify-mark', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <span class="mark mark--{{ status() }}" role="img" [attr.aria-label]="tooltip() || null">
            <span class="glyph" [style.width.px]="size()" [style.height.px]="size()">
                @if (glyphHtml(); as g) {
                    <span class="glyph-svg" [innerHTML]="g"></span>
                } @else {
                    <ng-content></ng-content>
                }
            </span>
            @if (showDot()) {
                <span class="dot" aria-hidden="true"></span>
            }
            @if (popover() && label()) {
                <!-- Live status, revealed on hover/focus of the mark (the mark itself stays a
                     plain link, e.g. "home"). Decorative — the status is on aria-label above. -->
                <span class="vpop" aria-hidden="true">
                    <span class="vpop__label">{{ label() }}</span>
                    @if (summary()) {
                        <span class="vpop__sum">{{ summary() }}</span>
                    }
                </span>
            }
        </span>
    `, styles: [":host{display:inline-flex;line-height:0}.mark{position:relative;display:inline-flex;align-items:center;color:inherit;transition:color var(--dur, .25s) var(--ease-out, ease)}.mark--verified{color:#4ade80}.mark--mismatch{color:#f87171}.mark--dev{color:#fbbf24}.glyph{display:inline-grid;place-items:center}.glyph-svg{display:contents}.glyph ::ng-deep svg{display:block;width:100%;height:100%}.dot{position:absolute;right:-3px;top:2px;width:6px;height:6px;border-radius:50%;background:currentColor;box-shadow:0 0 8px currentColor}.vpop{position:absolute;top:calc(100% + 8px);left:50%;z-index:var(--z-dropdown, 100);display:flex;flex-direction:column;gap:2px;width:max-content;max-width:17rem;padding:.5rem .625rem;background:var(--bg-elev, #fff);color:var(--text, #09090f);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-md, 12px);box-shadow:var(--shadow-md, 0 8px 24px rgba(9, 9, 15, .12));font:var(--fw-medium, 500) .72rem / 1.4 var(--font-display, system-ui, sans-serif);text-align:left;line-height:1.4;opacity:0;visibility:hidden;pointer-events:none;transform:translate(-50%) translateY(-4px);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease),visibility 0s var(--dur-fast, .15s)}:host(:hover) .vpop,:host(:focus-within) .vpop{opacity:1;visibility:visible;transform:translate(-50%) translateY(0);transition:opacity var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.vpop__label{font-weight:var(--fw-bold, 700);color:var(--text, #09090f);white-space:nowrap}.vpop__sum{color:var(--text-mute, #5c5c6d);font-size:.66rem;font-family:var(--font-mono, ui-monospace, monospace);word-break:break-word}@media(prefers-reduced-motion:reduce){.mark,.vpop{transition:none}}\n"] }]
        }], propDecorators: { status: [{ type: i0.Input, args: [{ isSignal: true, alias: "status", required: false }] }], lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], glyph: [{ type: i0.Input, args: [{ isSignal: true, alias: "glyph", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], summary: [{ type: i0.Input, args: [{ isSignal: true, alias: "summary", required: false }] }], labels: [{ type: i0.Input, args: [{ isSignal: true, alias: "labels", required: false }] }], popover: [{ type: i0.Input, args: [{ isSignal: true, alias: "popover", required: false }] }] } });

/** Language-neutral slug for footer part ids — so `data-ik-part` stays the same in any language
 *  (e.g. footer.legal.privacy-policy, not footer.legal.Политика конфиденциальности). */
function footerPartSlug(s) {
    return s
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
}
/**
 * Site footer — rich, multi-column (mirrors the apps' public footer):
 *   • brand column: logo + name + subtitle + disclaimer + social slot
 *   • link columns: `config.footer.columns` (Proof / Source / Legal …)
 *   • bottom bar: live-dot + auto-ranged copyright + brand tagline + tech badges
 *
 * With no `config.footer.columns` it degrades to a brand + bottom-bar strip.
 *
 * ```html
 * <ik-footer><ik-social-links slot="extra" /></ik-footer>
 * ```
 */
class Footer {
    cfg = inject(SITE_KIT_CONFIG);
    sanitizer = inject(DomSanitizer);
    destroyRef = inject(DestroyRef);
    doc = inject(DOCUMENT);
    barTopRef = viewChild('barTopRef', ...(ngDevMode ? [{ debugName: "barTopRef" }] : /* istanbul ignore next */ []));
    /** Compact-footer marquee runs ONLY when the disclaimer doesn't fit its line
     *  (small screens); where it fits, the text is shown static. Measured below. */
    marquee = signal(false, ...(ngDevMode ? [{ debugName: "marquee" }] : /* istanbul ignore next */ []));
    /** Bottom-bar tagline marquee — runs only when the tagline is wider than its line. */
    tagMarquee = signal(false, ...(ngDevMode ? [{ debugName: "tagMarquee" }] : /* istanbul ignore next */ []));
    constructor() {
        /* istanbul ignore next -- afterNextRender DOM-measurement glue; not run in unit tests */
        afterNextRender(() => this.initMarquee());
    }
    /* istanbul ignore next -- DOM/ResizeObserver measurement glue; not exercised in unit tests */
    initMarquee() {
        const top = this.barTopRef()?.nativeElement;
        if (!top)
            return;
        const measure = () => {
            const cdisc = top.querySelector('.cdisc');
            const cseg = top.querySelector('.cdisc__seg');
            if (cdisc && cseg) {
                // The disclaimer fills the middle (flex:1); marquee when its text overflows that slot.
                this.marquee.set(cseg.scrollWidth > cdisc.clientWidth + 4);
            }
            const tagWin = top.querySelector('.tag__win');
            const tseg = top.querySelector('.tag__seg');
            if (tagWin && tseg) {
                // Tagline marquee when its text is wider than the (capped, centered) viewport.
                this.tagMarquee.set(tseg.scrollWidth > tagWin.clientWidth + 4);
            }
        };
        measure();
        if (typeof ResizeObserver === 'undefined')
            return;
        const ro = new ResizeObserver(measure);
        ro.observe(top);
        for (const sel of ['.cdisc', '.cdisc__seg', '.tag__win', '.tag__seg']) {
            const el = top.querySelector(sel);
            if (el)
                ro.observe(el);
        }
        this.destroyRef.onDestroy(() => ro.disconnect());
    }
    /** Trusted inline brand glyph (rendered in an inverted mark). */
    brandGlyph = computed(() => {
        const g = this.cfg.brand.glyph;
        return g ? this.sanitizer.bypassSecurityTrustHtml(g) : null;
    }, ...(ngDevMode ? [{ debugName: "brandGlyph" }] : /* istanbul ignore next */ []));
    /** Active language for locale-aware footer links. */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Override the auto-detected current year (mostly for tests/snapshots). */
    currentYear = input(new Date().getFullYear(), ...(ngDevMode ? [{ debugName: "currentYear" }] : /* istanbul ignore next */ []));
    activeLang = computed(() => this.lang() ?? this.cfg.defaultLang, ...(ngDevMode ? [{ debugName: "activeLang" }] : /* istanbul ignore next */ []));
    /** Resolve a LocalizedString for the active language. */
    lt(v) {
        return localizeText(v, this.activeLang(), this.cfg.defaultLang) ?? '';
    }
    /** Brand-column text (all per-language aware). */
    subtitle = computed(() => localizeText(this.cfg.footer?.subtitle, this.activeLang(), this.cfg.defaultLang), ...(ngDevMode ? [{ debugName: "subtitle" }] : /* istanbul ignore next */ []));
    disclaimer = computed(() => localizeText(this.cfg.footer?.disclaimer, this.activeLang(), this.cfg.defaultLang), ...(ngDevMode ? [{ debugName: "disclaimer" }] : /* istanbul ignore next */ []));
    /** Single-strip footer (no brand/link columns) — see SiteKitFooter.compact. */
    compact = computed(() => !!this.cfg.footer?.compact, ...(ngDevMode ? [{ debugName: "compact" }] : /* istanbul ignore next */ []));
    /** Drop the brand column in the full footer — see SiteKitFooter.hideBrand. */
    hideBrand = computed(() => !!this.cfg.footer?.hideBrand, ...(ngDevMode ? [{ debugName: "hideBrand" }] : /* istanbul ignore next */ []));
    /** Stack the link columns into one — see SiteKitFooter.stackColumns. */
    stackColumns = computed(() => !!this.cfg.footer?.stackColumns, ...(ngDevMode ? [{ debugName: "stackColumns" }] : /* istanbul ignore next */ []));
    /** Brand tagline shown in the bottom bar (per-language aware). */
    tagline = computed(() => localizeText(this.cfg.brand.tagline, this.activeLang(), this.cfg.defaultLang), ...(ngDevMode ? [{ debugName: "tagline" }] : /* istanbul ignore next */ []));
    /** Resolved nav columns from `footer.columns` (titles + labels localized). Legal links are
     *  NOT a column — they render in the bottom bar (`legalLinks()`), so a body-only policy entry
     *  opens its in-app panel in both full and compact modes. */
    /** Render a footer entry (column link OR legal link). A plain link resolves its locale-aware
     *  `url`; a legal entry (with `body`) becomes a panel opener (paras + UTC "updated"), with its
     *  optional `href` kept as the "open full version" link. Shared by columns() and legalLinks(). */
    renderEntry(l, lang) {
        const body = localizeText(l.body, lang, this.cfg.defaultLang) ?? '';
        const paras = body
            ? body
                .split(/\n{2,}/)
                .map((p) => p.trim())
                .filter(Boolean)
            : [];
        const href = 'url' in l && l.url
            ? resolveLinkHref(l, lang, this.cfg.defaultLang)
            : l.href;
        // Stable id slug: canonical (en→default) label, else the href's last path segment.
        const canonical = localizeText(l.label, 'en', this.cfg.defaultLang) ?? '';
        const hrefSlug = href ? ((href.split(/[?#]/)[0] ?? '').split('/').filter(Boolean).pop() ?? '') : '';
        return {
            key: footerPartSlug(canonical) || footerPartSlug(hrefSlug) || 'item',
            label: this.lt(l.label),
            href,
            external: l.external ?? /^https?:\/\//i.test(href ?? ''),
            paras,
            updated: l.updated
                ? this.fmtUpdated(l.updated, lang)
                : '',
        };
    }
    columns = computed(() => {
        const lang = this.activeLang();
        const cols = this.cfg.footer?.columns ?? [];
        const legal = this.legalLinks();
        return cols.map((c, i) => ({
            key: footerPartSlug(localizeText(c.title, 'en', this.cfg.defaultLang) ?? '') || `col-${i + 1}`,
            title: this.lt(c.title),
            // a column may host the legal entries (About / Privacy …) via `appendLegal`
            links: [...c.links.map((l) => this.renderEntry(l, lang)), ...(c.appendLegal ? legal : [])],
            // landmark defaults to true (backward-compatible); set landmark:false for utility columns
            landmark: c.landmark !== false,
        }));
    }, ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    /** Show legal links in the bottom bar? Default yes; `footer.barLegal: false` keeps the bar clean
     *  (e.g. when a column hosts them via `appendLegal`). */
    barLegal = computed(() => this.cfg.footer?.barLegal !== false, ...(ngDevMode ? [{ debugName: "barLegal" }] : /* istanbul ignore next */ []));
    /** "Our projects" family keys to render (footer.projects), with the CURRENT site auto-excluded
     *  (its brand.url origin is dropped) so a footer never links to itself. */
    familyKeys = computed(() => {
        const p = this.cfg.footer?.projects;
        if (!p)
            return [];
        const requested = p === true || p === 'all' ? [...IK_FAMILY_ORDER] : p;
        const self = this.originOf(this.cfg.brand.url);
        return requested.filter((k) => {
            const m = IK_FAMILY[k];
            return !!m && (!self || this.originOf(m.url) !== self);
        });
    }, ...(ngDevMode ? [{ debugName: "familyKeys" }] : /* istanbul ignore next */ []));
    originOf(url) {
        try {
            return url ? new URL(url).origin : '';
        }
        catch {
            return '';
        }
    }
    /** Flat legal links (Privacy · Terms …) for the bottom bar — labels localized; links with
     *  `body` open an in-app policy panel (paras split on blank lines) with a full-UTC "updated". */
    legalLinks = computed(() => this.cfg.legal.map((l) => this.renderEntry(l, this.activeLang())), ...(ngDevMode ? [{ debugName: "legalLinks" }] : /* istanbul ignore next */ []));
    /** Format an ISO timestamp as a full UTC datetime, e.g. "Last updated: 16 Jun 2026, 18:30 UTC". */
    fmtUpdated(iso, lang) {
        const d = new Date(iso);
        if (Number.isNaN(d.getTime()))
            return '';
        const prefix = lang === 'ru' ? 'Обновлено' : 'Last updated';
        const f = new Intl.DateTimeFormat(lang === 'ru' ? 'ru-RU' : 'en-GB', {
            day: 'numeric',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false,
            timeZone: 'UTC',
        });
        return `${prefix}: ${f.format(d)} UTC`;
    }
    // ── Policy panel (legal link with `body`) + integrity result (©): footer-dialog.ts ──
    /** Whether a live build-integrity check is configured — gates the clickable © (verify). */
    hasVerify = computed(() => !!this.cfg.verify?.manifestUrl, ...(ngDevMode ? [{ debugName: "hasVerify" }] : /* istanbul ignore next */ []));
    /** The © button's name when it opens the build-integrity result. */
    verifyTitle = computed(() => this.activeLang() === 'ru' ? 'Проверка целостности' : 'Build integrity', ...(ngDevMode ? [{ debugName: "verifyTitle" }] : /* istanbul ignore next */ []));
    /** Live build-integrity check (config.verify.manifestUrl) — the © result. */
    integrity = inject(IntegrityService);
    /** The build-integrity dialog's content, read off the live check. The © dialog only opens when
     *  verify is configured, so the status is never 'none' here. */
    verifyView = computed(() => ({
        title: this.verifyTitle(),
        status: this.integrity.status(),
        statusLabel: VERIFY_LABELS[this.activeLang() === 'ru' ? 'ru' : 'en'][this.integrity.status()],
        summary: this.integrity.summary(),
        checks: this.integrity.checks(),
    }), ...(ngDevMode ? [{ debugName: "verifyView" }] : /* istanbul ignore next */ []));
    openFullLabel = computed(() => this.activeLang() === 'ru' ? 'Открыть полную версию ↗' : 'Open full version ↗', ...(ngDevMode ? [{ debugName: "openFullLabel" }] : /* istanbul ignore next */ []));
    /** Localized accessible label for the dialog's Close button. */
    closeLabel = computed(() => (this.activeLang() === 'ru' ? 'Закрыть' : 'Close'), ...(ngDevMode ? [{ debugName: "closeLabel" }] : /* istanbul ignore next */ []));
    /** Open legal policy panel (null = closed). */
    policyDoc = signal(null, ...(ngDevMode ? [{ debugName: "policyDoc" }] : /* istanbul ignore next */ []));
    /** The control that opened a dialog — focus is restored to it on close (ARIA dialog pattern). */
    lastFocused = null;
    openPolicy(l) {
        this.lastFocused = this.doc.activeElement;
        this.verifyOpen.set(false);
        this.policyDoc.set(l);
    }
    /** Build-integrity result (opened from ©). */
    verifyOpen = signal(false, ...(ngDevMode ? [{ debugName: "verifyOpen" }] : /* istanbul ignore next */ []));
    openVerify() {
        this.lastFocused = this.doc.activeElement;
        this.policyDoc.set(null);
        this.verifyOpen.set(true);
    }
    /** A dialog closed (Escape, backdrop, close button): back to the control that opened it. */
    closeDialog() {
        this.policyDoc.set(null);
        this.verifyOpen.set(false);
        this.lastFocused?.focus?.();
        this.lastFocused = null;
    }
    /** Auto-ranged year — rendered as a (secret) link to the QR page, like the reference footer. */
    yearRange = computed(() => {
        const c = this.cfg.copyright;
        const now = this.currentYear();
        return c.startYear && c.startYear < now ? `${c.startYear}–${now}` : `${now}`;
    }, ...(ngDevMode ? [{ debugName: "yearRange" }] : /* istanbul ignore next */ []));
    /** Holder + suffix after the year ("Acme. All rights reserved.") — suffix localized.
     *  With brand.nameHidden the holder is dropped (just "© year" + optional suffix). */
    crRest = computed(() => {
        const c = this.cfg.copyright;
        const suffix = localizeText(c.suffix, this.activeLang(), this.cfg.defaultLang);
        if (this.cfg.brand.nameHidden)
            return suffix ?? '';
        // Holder — suffix joined with a SPACED EM DASH (not "Holder."): the typographically
        // correct phrase separator, and Russian requires the em dash set off by spaces.
        return `${c.holder}${suffix ? ` — ${suffix}` : ''}`;
    }, ...(ngDevMode ? [{ debugName: "crRest" }] : /* istanbul ignore next */ []));
    /** The clickable year's target — the QR page (deploy.routes.qr, else /qr). */
    qrHref = computed(() => this.cfg.deploy?.routes?.['qr'] ?? '/qr', ...(ngDevMode ? [{ debugName: "qrHref" }] : /* istanbul ignore next */ []));
    /** Localized accessible name for the secret year→QR link (was a bare, ambiguous "QR"). */
    qrLabel = computed(() => this.activeLang() === 'ru' ? 'Открыть QR-код' : 'Show QR code', ...(ngDevMode ? [{ debugName: "qrLabel" }] : /* istanbul ignore next */ []));
    /** Optional authorship/verify PAGE the © glyph links to (deploy.routes.verify). When a live
     *  integrity check (verify.manifestUrl) is configured the © opens that modal instead; with
     *  neither, the © is plain text. Lets a site point © at a proof page (e.g. ik-authorship-validator). */
    verifyRoute = computed(() => this.cfg.deploy?.routes?.['verify'], ...(ngDevMode ? [{ debugName: "verifyRoute" }] : /* istanbul ignore next */ []));
    /** Localized title for the © → verify-page link. */
    verifyLinkTitle = computed(() => this.activeLang() === 'ru' ? 'Проверка подлинности' : 'Verify authenticity', ...(ngDevMode ? [{ debugName: "verifyLinkTitle" }] : /* istanbul ignore next */ []));
    /** The licence's name (config.license → catalog, no text) + its page route — a footer link. */
    license = computed(() => licenseName(this.cfg, this.activeLang()), ...(ngDevMode ? [{ debugName: "license" }] : /* istanbul ignore next */ []));
    licenseHref = computed(() => this.cfg.deploy?.routes?.['license'] ?? '/license', ...(ngDevMode ? [{ debugName: "licenseHref" }] : /* istanbul ignore next */ []));
    // ── Opt-in utility affordances (all default off) ──
    /** Localized aria-label for the bottom-bar legal `<nav>` landmark (#10). */
    legalNavLabel = computed(() => this.activeLang() === 'ru' ? 'Правовая информация' : 'Legal', ...(ngDevMode ? [{ debugName: "legalNavLabel" }] : /* istanbul ignore next */ []));
    /** "Cookie settings" re-open link (#6) — needs `footer.cookieSettings`. */
    showCookieSettings = computed(() => !!this.cfg.footer?.cookieSettings, ...(ngDevMode ? [{ debugName: "showCookieSettings" }] : /* istanbul ignore next */ []));
    cookieSettingsLabel = computed(() => this.activeLang() === 'ru' ? 'Настройки cookie' : 'Cookie settings', ...(ngDevMode ? [{ debugName: "cookieSettingsLabel" }] : /* istanbul ignore next */ []));
    /** Emits when the user asks to re-open the consent banner; also dispatched as a document
     *  `ik:cookie-settings` event so `ik-cookie-consent` re-opens with zero host wiring. */
    cookieSettings = output();
    openCookieSettings() {
        this.cookieSettings.emit();
        this.doc.dispatchEvent(new CustomEvent('ik:cookie-settings'));
    }
    /** Footer lang switcher / theme toggle (#7) — re-emit the inner components' events. */
    showLangSwitcher = computed(() => !!this.cfg.footer?.langSwitcher, ...(ngDevMode ? [{ debugName: "showLangSwitcher" }] : /* istanbul ignore next */ []));
    showThemeToggle = computed(() => !!this.cfg.footer?.themeToggle, ...(ngDevMode ? [{ debugName: "showThemeToggle" }] : /* istanbul ignore next */ []));
    langChange = output();
    themeChange = output();
    /** Contact block (#8) — surfaced from `config.contact` when `footer.contact` is on. Returns
     *  null when nothing is displayable. `phoneHref` is the dialable form (digits + leading +). */
    contact = computed(() => {
        const c = this.cfg.contact;
        if (!this.cfg.footer?.contact || !c)
            return null;
        const has = c.company || c.location || c.phone || c.email;
        return has
            ? {
                company: c.company ?? '',
                location: c.location ?? '',
                phone: c.phone ?? '',
                phoneHref: (c.phone ?? '').replace(/[^\d+]/g, ''),
                email: c.email ?? '',
            }
            : null;
    }, ...(ngDevMode ? [{ debugName: "contact" }] : /* istanbul ignore next */ []));
    /** Back-to-top button (#9) — needs `footer.backToTop`. */
    showBackToTop = computed(() => !!this.cfg.footer?.backToTop, ...(ngDevMode ? [{ debugName: "showBackToTop" }] : /* istanbul ignore next */ []));
    backTopLabel = computed(() => (this.activeLang() === 'ru' ? 'Наверх' : 'Back to top'), ...(ngDevMode ? [{ debugName: "backTopLabel" }] : /* istanbul ignore next */ []));
    backToTop() {
        const reduce = this.doc.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
        this.doc.defaultView?.scrollTo?.({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
        // Move focus to the top landmark so keyboard/SR users continue from the start, not the
        // footer. Priority-ordered lookups (NOT one selector group — querySelector resolves a
        // group by document order, so a masthead <h1> could win over a later <main>).
        const target = this.doc.querySelector('main, [role="main"]') ??
            this.doc.querySelector('h1') ??
            this.doc.body;
        if (target) {
            const hadTabindex = target.hasAttribute('tabindex');
            if (!hadTabindex)
                target.setAttribute('tabindex', '-1');
            target.focus({ preventScroll: true });
            if (!hadTabindex)
                target.addEventListener('blur', () => target.removeAttribute('tabindex'), { once: true });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Footer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: Footer, isStandalone: true, selector: "ik-footer", inputs: { lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, currentYear: { classPropertyName: "currentYear", publicName: "currentYear", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { cookieSettings: "cookieSettings", langChange: "langChange", themeChange: "themeChange" }, host: { attributes: { "role": "contentinfo" }, classAttribute: "ik-footer" }, viewQueries: [{ propertyName: "barTopRef", first: true, predicate: ["barTopRef"], descendants: true, isSignal: true }], ngImport: i0, template: `
        @if (!compact()) {
            <div class="inner" [class.inner--brandless]="hideBrand()">
                @if (!hideBrand()) {
                    <div class="col brand-col" data-ik-part="footer.brand">
                        <a class="name" [href]="cfg.brand.url || '/'" data-ik-part="footer.brand.name">
                            @if (brandGlyph(); as g) {
                                <span class="mark" [innerHTML]="g"></span>
                            } @else if (cfg.brand.logoUrl) {
                                <img class="logo" [src]="cfg.brand.logoUrl" [alt]="cfg.brand.name" />
                            }
                            @if (!cfg.brand.nameHidden) {
                                <span>{{ cfg.brand.name }}</span>
                            }
                        </a>
                        @if (subtitle(); as sub) {
                            <p class="sub" data-ik-part="footer.brand.subtitle">{{ sub }}</p>
                        }
                        @if (disclaimer(); as disc) {
                            <p class="disc" data-ik-part="footer.brand.disclaimer">{{ disc }}</p>
                        }
                        @if (contact(); as c) {
                            <address
                                class="contact"
                                data-ik-part="footer.contact"
                                itemscope
                                itemtype="https://schema.org/Organization"
                            >
                                @if (c.company) {
                                    <span class="contact__org" itemprop="name">{{ c.company }}</span>
                                }
                                @if (c.location) {
                                    <span class="contact__row" itemprop="address">{{ c.location }}</span>
                                }
                                @if (c.phone) {
                                    <a class="contact__row" [href]="'tel:' + c.phoneHref"
                                        ><span itemprop="telephone">{{ c.phone }}</span></a
                                    >
                                }
                                @if (c.email) {
                                    <a class="contact__row" [href]="'mailto:' + c.email"
                                        ><span itemprop="email">{{ c.email }}</span></a
                                    >
                                }
                            </address>
                        }
                    </div>
                }

                <div class="cols" [class.cols--stack]="stackColumns()" data-ik-part="footer.columns">
                    @for (col of columns(); track col.title) {
                        <!-- Each column is a <nav> landmark by default; a utility column
                             (landmark:false) opts out via role="presentation" so the landmark
                             menu isn't flooded — the heading + links still render identically. -->
                        <nav
                            class="col"
                            [attr.role]="col.landmark ? null : 'presentation'"
                            [attr.aria-label]="col.landmark ? col.title : null"
                            [attr.data-ik-part]="'footer.col.' + col.key"
                        >
                            <h2 class="col-title">{{ col.title }}</h2>
                            <ul class="links">
                                @for (l of col.links; track l.label) {
                                    <li>
                                        @if (l.paras.length) {
                                            <button
                                                type="button"
                                                class="link"
                                                (click)="openPolicy(l)"
                                                [attr.data-ik-part]="'footer.col.' + col.key + '.' + l.key"
                                            >
                                                {{ l.label }}
                                            </button>
                                        } @else {
                                            <a
                                                [href]="l.href"
                                                [attr.target]="l.external ? '_blank' : null"
                                                [attr.rel]="l.external ? 'noopener noreferrer' : null"
                                                [attr.data-ik-part]="'footer.col.' + col.key + '.' + l.key"
                                                >{{ l.label }}</a
                                            >
                                        }
                                    </li>
                                }
                            </ul>
                        </nav>
                    }
                </div>
                <!-- Social + "our projects" share one full-width row below the brand+columns grid:
                     side by side when they fit, family wraps below when social fills the row. -->
                <div class="extras">
                    <div class="social" data-ik-part="footer.brand.social">
                        <ng-content select="[slot=extra]" />
                    </div>
                    @if (familyKeys().length) {
                        <div class="family" data-ik-part="footer.family">
                            <ik-family-links [lang]="activeLang()" [keys]="familyKeys()" />
                        </div>
                    }
                </div>
            </div>
            <!-- Utility row lives OUTSIDE .inner on purpose: .inner has content-visibility:auto
                 (→ contain:paint), which would clip the lang-switcher's absolutely-positioned
                 dropdown. As a sibling it escapes the contained box. -->
            @if (showLangSwitcher() || showThemeToggle() || showBackToTop()) {
                <div class="utils" data-ik-part="footer.utils">
                    @if (showLangSwitcher()) {
                        <ik-lang-switcher [current]="activeLang()" (langChange)="langChange.emit($event)" />
                    }
                    @if (showThemeToggle()) {
                        <ik-theme-toggle (themeChange)="themeChange.emit($event)" />
                    }
                    @if (showBackToTop()) {
                        <button type="button" class="to-top" (click)="backToTop()">
                            <span aria-hidden="true">↑</span> {{ backTopLabel() }}
                        </button>
                    }
                </div>
            }
        }

        @if (compact()) {
            <!-- Compact: ONE tidy bottom strip. meta (dot · © year · legal) | disclaimer | badges.
                 No brand mark (the reference footer is just a dot + year). -->
            <div class="bar bar--compact">
                <!-- Line 1: © (verify trigger) + year→QR + disclaimer (marquee when it doesn't fit)
                     + legal — all flow together, wrapping to extra rows only when they must. -->
                <div class="bar-top" #barTopRef>
                    <span class="bar-copy">
                        <span class="dot" aria-hidden="true"></span>
                        <span class="cr">
                            @if (hasVerify()) {
                                <button
                                    type="button"
                                    class="cr-mark"
                                    (click)="openVerify()"
                                    [attr.aria-label]="verifyTitle()"
                                    [title]="verifyTitle()"
                                >
                                    ©
                                </button>
                            } @else if (verifyRoute(); as vr) {
                                <a
                                    class="cr-mark"
                                    [href]="vr"
                                    [attr.aria-label]="verifyLinkTitle()"
                                    [title]="verifyLinkTitle()"
                                    >©</a
                                >
                            } @else {
                                <span aria-hidden="true">©</span>
                            }
                            <a
                                class="cr-year"
                                [href]="qrHref()"
                                [attr.aria-label]="qrLabel()"
                                [attr.title]="qrLabel()"
                                >{{ yearRange() }}</a
                            >&ngsp;{{ crRest() }}</span
                        >
                    </span>
                    @if (disclaimer(); as disc) {
                        <span class="cdisc" [class.cdisc--run]="marquee()" [attr.aria-label]="disc">
                            <span class="cdisc__track" aria-hidden="true">
                                <span class="cdisc__seg">{{ disc }}</span>
                                <span class="cdisc__seg">{{ disc }}</span>
                            </span>
                        </span>
                    }
                    @if ((barLegal() && legalLinks().length) || showCookieSettings()) {
                        <nav class="bar-legal" [attr.aria-label]="legalNavLabel()">
                            @if (barLegal()) {
                                @for (l of legalLinks(); track $index; let first = $first) {
                                    @if (!first) {
                                        <span class="sep">·</span>
                                    }
                                    @if (l.paras.length) {
                                        <button type="button" class="leg" (click)="openPolicy(l)">
                                            {{ l.label }}
                                        </button>
                                    } @else {
                                        <a class="leg" [href]="l.href">{{ l.label }}</a>
                                    }
                                }
                            }
                            @if (showCookieSettings()) {
                                @if (barLegal() && legalLinks().length) {
                                    <span class="sep">·</span>
                                }
                                <button type="button" class="leg" (click)="openCookieSettings()">
                                    {{ cookieSettingsLabel() }}
                                </button>
                            }
                        </nav>
                    }
                </div>
                @if (familyKeys().length) {
                    <div class="family family--compact">
                        <ik-family-links size="sm" [lang]="activeLang()" [keys]="familyKeys()" />
                    </div>
                }
                @if (cfg.technologies.length || cfg.signature !== false) {
                    <div class="badges">
                        <ik-technologies size="sm" [center]="true" [appendSiteKit]="true" />
                    </div>
                }
            </div>
        } @else {
            <div class="bar" #barTopRef data-ik-part="footer.bottom">
                <!-- "2-in-1": the live-status light IS the © — a green glowing badge with a
                     white ©, so there's no separate status dot. -->
                <span class="cr" data-ik-part="footer.copyright">
                    @if (hasVerify()) {
                        <button
                            type="button"
                            class="cr-mark cr-live"
                            (click)="openVerify()"
                            [attr.aria-label]="verifyTitle()"
                            [title]="verifyTitle()"
                        >
                            ©
                        </button>
                    } @else if (verifyRoute(); as vr) {
                        <a
                            class="cr-mark cr-live"
                            [href]="vr"
                            [attr.aria-label]="verifyLinkTitle()"
                            [title]="verifyLinkTitle()"
                            >©</a
                        >
                    } @else {
                        <span class="cr-live" aria-hidden="true">©</span>
                    }
                    <a
                        class="cr-year"
                        [href]="qrHref()"
                        [attr.aria-label]="qrLabel()"
                        [attr.title]="qrLabel()"
                        >{{ yearRange() }}</a
                    >
                    {{ crRest() }}</span
                >
                @if (hideBrand() && disclaimer(); as disc) {
                    <!-- Brand block (which normally holds the disclaimer) is hidden → keep the
                         disclaimer here as a marquee that fills the middle (scrolls when long). -->
                    <span
                        class="cdisc"
                        [class.cdisc--run]="marquee()"
                        [attr.aria-label]="disc"
                        data-ik-part="footer.disclaimer"
                    >
                        <span class="cdisc__track" aria-hidden="true">
                            <span class="cdisc__seg">{{ disc }}</span>
                            <span class="cdisc__seg">{{ disc }}</span>
                        </span>
                    </span>
                }
                <!-- Legal · cookie-settings · license grouped in ONE labelled <nav> landmark so AT
                     users can jump to it; each entry keeps its leading "·" so the visual flow
                     (© year · Privacy · Terms · License) is unchanged. -->
                @if ((barLegal() && legalLinks().length) || showCookieSettings() || license()) {
                    <nav class="bar-nav" [attr.aria-label]="legalNavLabel()" data-ik-part="footer.legal-nav">
                        @if (barLegal()) {
                            @for (l of legalLinks(); track $index) {
                                <span class="sep">·</span>
                                @if (l.paras.length) {
                                    <button
                                        type="button"
                                        class="leg"
                                        (click)="openPolicy(l)"
                                        [attr.data-ik-part]="'footer.legal.' + l.key"
                                    >
                                        {{ l.label }}
                                    </button>
                                } @else {
                                    <a
                                        class="leg"
                                        [href]="l.href"
                                        [attr.data-ik-part]="'footer.legal.' + l.key"
                                        >{{ l.label }}</a
                                    >
                                }
                            }
                        }
                        @if (showCookieSettings()) {
                            <span class="sep">·</span>
                            <button
                                type="button"
                                class="leg"
                                (click)="openCookieSettings()"
                                data-ik-part="footer.cookie-settings"
                            >
                                {{ cookieSettingsLabel() }}
                            </button>
                        }
                        @if (license(); as l) {
                            <span class="sep">·</span>
                            <a
                                class="lic"
                                [href]="licenseHref()"
                                [title]="l.name"
                                data-ik-part="footer.license"
                                >{{ l.name }}</a
                            >
                        }
                    </nav>
                }
                @if (tagline(); as tag) {
                    <span class="tag" [class.tag--run]="tagMarquee()">
                        <span class="tag__win" data-ik-part="footer.tagline">
                            <span class="tag__track">
                                <span class="tag__seg">{{ tag }}</span>
                                <span class="tag__seg" aria-hidden="true">{{ tag }}</span>
                            </span>
                        </span>
                    </span>
                }
                @if (cfg.technologies.length || cfg.signature !== false || cfg.pageSpeed) {
                    <div class="badges" data-ik-part="footer.badges">
                        <ik-technologies
                            size="sm"
                            [center]="true"
                            [appendSiteKit]="true"
                            [showPageSpeed]="true"
                            [lang]="activeLang()"
                        />
                    </div>
                }
            </div>
        }

        <!-- The policy panel (a legal link with \`body\`) or the build-integrity result (from ©):
             a chunk of its own (footer-dialog.ts), fetched when a dialog first opens. -->
        @if (policyDoc() || verifyOpen()) {
            @defer (on immediate) {
                <ik-footer-dialog
                    [policy]="policyDoc()"
                    [verify]="verifyOpen() ? verifyView() : null"
                    [fullLabel]="openFullLabel()"
                    (closed)="closeDialog()"
                >
                    <ik-close [autoFocus]="true" [label]="closeLabel()" (closed)="closeDialog()" />
                </ik-footer-dialog>
            }
        }
    `, isInline: true, styles: [":host{display:block;border-top:1px solid var(--border, #e5e5e9);background:var(--bg, #fff);color:var(--text-mute, #51515e);font-family:var(--font-display, system-ui, sans-serif);font-size:var(--fs-sm, .875rem)}.inner{display:grid;grid-template-columns:minmax(13rem,1.3fr) 2.6fr;align-items:start;column-gap:var(--sp-8, 2rem);row-gap:0;max-width:var(--container, 72rem);margin-inline:auto;content-visibility:auto;contain-intrinsic-size:auto 320px;padding:var(--sp-12, 3rem) var(--gutter, 1.5rem) var(--sp-6, 1.5rem)}.cols{display:grid;grid-template-columns:1fr;gap:var(--sp-6, 1.5rem) var(--sp-8, 2rem);align-items:start}@media(min-width:768px){.cols:not(.cols--stack){grid-template-columns:repeat(auto-fit,minmax(8.5rem,1fr));align-items:stretch}}.cols .col{border-left:1px solid var(--border-soft, #f0f0f2);padding-left:var(--sp-6, 1.5rem)}.col{display:flex;flex-direction:column;gap:var(--sp-3, .75rem);min-width:0}.brand-col{gap:var(--sp-4, 1rem)}.inner--brandless,.cols--stack{grid-template-columns:1fr}.extras{grid-column:1 / -1;margin-top:var(--sp-6, 1.5rem);display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:var(--sp-2, .5rem);line-height:0}.extras .social,.extras .family,.extras ::ng-deep ik-social-links,.extras ::ng-deep ik-social-links .row,.extras ::ng-deep ik-family-links,.extras ::ng-deep ik-family-links .row{display:contents}.family--compact{display:flex;justify-content:center;margin-top:0}@media(max-width:560px){.inner{grid-template-columns:1fr;column-gap:var(--sp-6, 1.5rem)}.cols{margin-top:var(--sp-6, 1.5rem)}}.name{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);font-family:var(--font-brand, system-ui, sans-serif);font-weight:var(--fw-bold, 700);font-size:var(--fs-lg, 1.125rem);letter-spacing:var(--ls-tight, -.02em);color:var(--text, #09090f);text-decoration:none;width:fit-content}.logo{height:26px;width:auto;border-radius:6px;display:block}.mark{display:grid;place-items:center;width:28px;height:28px;border-radius:8px;background:var(--text, #09090f);color:var(--bg, #fff);flex-shrink:0}.mark ::ng-deep svg{display:block;width:60%;height:60%}.sub{margin:calc(-1 * var(--sp-2, .5rem)) 0 0;font-size:var(--fs-xs, .75rem);color:var(--text-dim, #74747f)}.disc{margin:0;font-size:var(--fs-xs, .75rem);color:var(--text-mute, #51515e);line-height:1.6;max-width:38ch}.social{display:flex;align-items:center;flex-wrap:wrap;gap:var(--sp-2, .5rem);--ik-social-size: 2.25rem}.social:empty{display:none}.social ::ng-deep ik-social-links{display:contents}.social ::ng-deep ik-social-links ul{display:contents}.col-title{margin:0;font-size:var(--fs-xs, .75rem);font-weight:var(--fw-semi, 600);letter-spacing:var(--ls-wide, .06em);text-transform:uppercase;color:var(--text-dim, #74747f)}.links{display:flex;flex-direction:column;gap:var(--sp-2, .5rem);margin:0;padding:0;list-style:none}.links a,.links button.link{font-size:var(--fs-sm, .875rem);color:var(--text-mute, #51515e);text-decoration:none;transition:color var(--dur-fast, .15s) var(--ease-out, ease)}.links button.link{margin:0;padding:0;border:0;background:none;cursor:pointer;text-align:left;font-family:inherit;line-height:inherit}.links a:hover,.links button.link:hover,.name:hover{color:var(--text, #09090f)}.bar{display:flex;align-items:center;flex-wrap:wrap;justify-content:center;gap:var(--sp-2, .5rem);max-width:var(--container, 72rem);margin-inline:auto;padding:var(--sp-4, 1rem) var(--gutter, 1.5rem);border-top:1px solid var(--border-soft, #f0f0f2);font-size:var(--fs-xs, .75rem);color:var(--text-dim, #74747f)}.dot{width:6px;height:6px;border-radius:50%;background:var(--success, #16a34a);box-shadow:0 0 8px color-mix(in oklch,var(--success, #16a34a) 60%,transparent);flex-shrink:0}.bar>.dot{display:none}.sep{opacity:.5}.cr-year{color:inherit;text-decoration:none;cursor:pointer;margin-inline-start:.35em;transition:color var(--dur-base, .22s) var(--ease-out, ease)}.lic,.leg{color:inherit;text-decoration:none}button.leg{margin:0;padding:0;border:0;background:none;font:inherit;cursor:pointer}.lic:hover,.leg:hover,.cr-year:hover{color:var(--brand, #6d28d9)}.cr-mark{margin:0;padding:0;border:0;background:none;font:inherit;color:inherit;cursor:pointer;text-decoration:none;transition:color var(--dur-base, .22s) var(--ease-out, ease)}.cr-mark:hover{color:var(--brand, #6d28d9)}.badges{flex-basis:100%;margin-top:var(--sp-1, .25rem);display:flex;justify-content:center;align-items:center}.bar--compact{flex-direction:column;align-items:center;justify-content:center;text-align:center;border-top:none;gap:.55rem;padding-block:1rem;font-size:.66rem}.bar-top{display:flex;align-items:center;justify-content:center;flex-wrap:nowrap;gap:.3rem .6rem;width:100%;min-width:0}.bar-copy{display:inline-flex;align-items:center;gap:.35rem;flex-shrink:0}.bar-legal{display:inline-flex;align-items:center;flex-wrap:nowrap;flex-shrink:0;justify-content:center;gap:.3rem .45rem}.bar--compact .cr,.bar--compact .leg,.bar--compact .sep{white-space:nowrap}.bar--compact .dot{width:5px;height:5px;background:var(--brand, #06b6d4);box-shadow:none}.cdisc{flex:1 1 0;min-width:0;overflow:hidden;display:flex;justify-content:center;color:var(--text-dim, #74747f);font-size:.85em;line-height:1.35}.cdisc__track{display:inline-flex;flex-wrap:nowrap;white-space:nowrap}.cdisc__seg{white-space:nowrap}.cdisc:not(.cdisc--run) .cdisc__seg:nth-child(2){display:none}.cdisc--run{justify-content:flex-start;-webkit-mask-image:linear-gradient(to right,transparent,#000 1.2rem,#000 calc(100% - 1.2rem),transparent);mask-image:linear-gradient(to right,transparent,#000 1.2rem,#000 calc(100% - 1.2rem),transparent)}.cdisc--run .cdisc__track{will-change:transform;animation:ik-cdisc-marquee 22s linear infinite}.cdisc--run .cdisc__seg{padding-right:1rem}@media(max-width:600px){.bar--compact{font-size:clamp(.44rem,2.3vw,.62rem)}.cdisc{display:none}.bar--compact .bar-top{gap:.2rem .35rem}.bar--compact .bar-legal{gap:.2rem .3rem}}@keyframes ik-cdisc-marquee{0%{transform:translate(0)}to{transform:translate(-50%)}}.cdisc--run:hover .cdisc__track{animation-play-state:paused}.tag{min-width:0;max-width:100%;display:flex;justify-content:center}.tag__win{min-width:0;max-width:100%;overflow:hidden;display:flex;justify-content:center}.tag__track{display:inline-flex;flex-wrap:nowrap;white-space:nowrap}.tag__seg{white-space:nowrap}.tag:not(.tag--run) .tag__seg:nth-child(2){display:none}.tag--run .tag__win{justify-content:flex-start;-webkit-mask-image:linear-gradient(to right,transparent,#000 1rem,#000 calc(100% - 1rem),transparent);mask-image:linear-gradient(to right,transparent,#000 1rem,#000 calc(100% - 1rem),transparent)}.tag--run .tag__track{will-change:transform;animation:ik-cdisc-marquee 22s linear infinite}.tag--run .tag__seg{padding-right:1rem}.tag--run:hover .tag__track{animation-play-state:paused}@media(prefers-reduced-motion:reduce){.cdisc--run .cdisc__track,.tag--run .tag__track{animation:none}.cdisc--run .cdisc__seg:nth-child(2),.tag--run .tag__seg:nth-child(2){display:none}}.bar--compact .badges{display:block;width:100%}.bar--compact .badges ik-technologies{display:block;width:100%}@media(max-width:480px){.bar--compact .badges{display:block;width:100%}.bar--compact .badges ::ng-deep .ik-tech{display:grid!important;grid-template-columns:repeat(3,1fr);gap:6px;width:100%}.bar--compact .badges ::ng-deep .ik-tech a{justify-self:stretch;justify-content:center;width:100%!important;box-sizing:border-box}}@media(max-width:900px){.bar:not(.bar--compact) .badges{display:block;width:100%;margin-left:0}.bar:not(.bar--compact) .badges ::ng-deep .ik-tech{display:grid!important;grid-template-columns:repeat(var(--ik-footer-badge-cols, 4),1fr);gap:6px;width:100%}.bar:not(.bar--compact) .badges ::ng-deep .ik-tech a{justify-self:stretch;justify-content:center;width:100%!important;box-sizing:border-box}}.name:focus-visible,.links a:focus-visible,.links button.link:focus-visible,.leg:focus-visible,.lic:focus-visible,.cr-mark:focus-visible,.cr-year:focus-visible,.contact a:focus-visible,.to-top:focus-visible{outline:none;border-radius:4px;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.cr-mark,.cr-year{padding-block:4px}.cr-live{color:var(--ik-copyright-tint, var(--success, #16a34a));text-shadow:0 0 4px color-mix(in oklch,var(--success, #16a34a) 40%,transparent);text-decoration:none}.cr-live:hover{color:var(--ik-copyright-tint, var(--success, #16a34a));filter:brightness(1.2)}.links a,.links button.link,.bar-nav .leg,.bar-nav .lic,.bar-legal .leg{padding-block:4px}.bar-nav{display:inline-flex;align-items:center;flex-wrap:wrap;justify-content:center;gap:var(--sp-2, .5rem)}.contact{display:flex;flex-direction:column;gap:var(--sp-1, .25rem);font-style:normal;font-size:var(--fs-xs, .75rem);color:var(--text-mute, #51515e)}.contact__org{font-weight:var(--fw-semi, 600);color:var(--text, #09090f)}.contact a.contact__row{color:inherit;text-decoration:none;width:fit-content}.contact a.contact__row:hover{color:var(--brand, #6d28d9)}.utils{max-width:var(--container, 72rem);margin-inline:auto;padding:0 var(--gutter, 1.5rem) var(--sp-6, 1.5rem);display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:var(--sp-3, .75rem)}.to-top{display:inline-flex;align-items:center;gap:.35em;min-height:24px;padding:.4em .85em;border:1px solid var(--border, #e5e5e9);border-radius:var(--r-full, 999px);background:var(--bg-elev, #fff);color:var(--text-mute, #51515e);cursor:pointer;font:inherit;font-size:var(--fs-xs, .75rem);text-decoration:none;transition:color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease)}.to-top:hover{color:var(--brand, #6d28d9);border-color:color-mix(in oklch,var(--brand, #6d28d9) 45%,transparent)}\n"], dependencies: [{ kind: "component", type: Technologies, selector: "ik-technologies", inputs: ["size", "center", "appendSiteKit", "showPageSpeed", "lang"] }, { kind: "component", type: FamilyLinks, selector: "ik-family-links", inputs: ["size", "lang", "keys"] }, { kind: "component", type: LangSwitcher, selector: "ik-lang-switcher", inputs: ["languages", "current", "compact"], outputs: ["langChange"] }, { kind: "component", type: ThemeToggle, selector: "ik-theme-toggle", inputs: ["compact", "lang"], outputs: ["themeChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, deferBlockDependencies: [() => [Promise.resolve().then(function () { return closeButton; }).then(m => m.IkClose), import('./ilia-ae-site-kit-footer-dialog-Cfdz3T1q.mjs').then(m => m.FooterDialog)]] });
}
i0.ɵɵngDeclareClassMetadataAsync({ minVersion: "18.0.0", version: "21.2.15", ngImport: i0, type: Footer, resolveDeferredDeps: () => [Promise.resolve().then(function () { return closeButton; }).then(m => m.IkClose), import('./ilia-ae-site-kit-footer-dialog-Cfdz3T1q.mjs').then(m => m.FooterDialog)], resolveMetadata: (IkClose, FooterDialog) => ({ decorators: [{
                type: Component,
                args: [{ selector: 'ik-footer', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [Technologies, FamilyLinks, IkClose, LangSwitcher, ThemeToggle, FooterDialog], template: `
        @if (!compact()) {
            <div class="inner" [class.inner--brandless]="hideBrand()">
                @if (!hideBrand()) {
                    <div class="col brand-col" data-ik-part="footer.brand">
                        <a class="name" [href]="cfg.brand.url || '/'" data-ik-part="footer.brand.name">
                            @if (brandGlyph(); as g) {
                                <span class="mark" [innerHTML]="g"></span>
                            } @else if (cfg.brand.logoUrl) {
                                <img class="logo" [src]="cfg.brand.logoUrl" [alt]="cfg.brand.name" />
                            }
                            @if (!cfg.brand.nameHidden) {
                                <span>{{ cfg.brand.name }}</span>
                            }
                        </a>
                        @if (subtitle(); as sub) {
                            <p class="sub" data-ik-part="footer.brand.subtitle">{{ sub }}</p>
                        }
                        @if (disclaimer(); as disc) {
                            <p class="disc" data-ik-part="footer.brand.disclaimer">{{ disc }}</p>
                        }
                        @if (contact(); as c) {
                            <address
                                class="contact"
                                data-ik-part="footer.contact"
                                itemscope
                                itemtype="https://schema.org/Organization"
                            >
                                @if (c.company) {
                                    <span class="contact__org" itemprop="name">{{ c.company }}</span>
                                }
                                @if (c.location) {
                                    <span class="contact__row" itemprop="address">{{ c.location }}</span>
                                }
                                @if (c.phone) {
                                    <a class="contact__row" [href]="'tel:' + c.phoneHref"
                                        ><span itemprop="telephone">{{ c.phone }}</span></a
                                    >
                                }
                                @if (c.email) {
                                    <a class="contact__row" [href]="'mailto:' + c.email"
                                        ><span itemprop="email">{{ c.email }}</span></a
                                    >
                                }
                            </address>
                        }
                    </div>
                }

                <div class="cols" [class.cols--stack]="stackColumns()" data-ik-part="footer.columns">
                    @for (col of columns(); track col.title) {
                        <!-- Each column is a <nav> landmark by default; a utility column
                             (landmark:false) opts out via role="presentation" so the landmark
                             menu isn't flooded — the heading + links still render identically. -->
                        <nav
                            class="col"
                            [attr.role]="col.landmark ? null : 'presentation'"
                            [attr.aria-label]="col.landmark ? col.title : null"
                            [attr.data-ik-part]="'footer.col.' + col.key"
                        >
                            <h2 class="col-title">{{ col.title }}</h2>
                            <ul class="links">
                                @for (l of col.links; track l.label) {
                                    <li>
                                        @if (l.paras.length) {
                                            <button
                                                type="button"
                                                class="link"
                                                (click)="openPolicy(l)"
                                                [attr.data-ik-part]="'footer.col.' + col.key + '.' + l.key"
                                            >
                                                {{ l.label }}
                                            </button>
                                        } @else {
                                            <a
                                                [href]="l.href"
                                                [attr.target]="l.external ? '_blank' : null"
                                                [attr.rel]="l.external ? 'noopener noreferrer' : null"
                                                [attr.data-ik-part]="'footer.col.' + col.key + '.' + l.key"
                                                >{{ l.label }}</a
                                            >
                                        }
                                    </li>
                                }
                            </ul>
                        </nav>
                    }
                </div>
                <!-- Social + "our projects" share one full-width row below the brand+columns grid:
                     side by side when they fit, family wraps below when social fills the row. -->
                <div class="extras">
                    <div class="social" data-ik-part="footer.brand.social">
                        <ng-content select="[slot=extra]" />
                    </div>
                    @if (familyKeys().length) {
                        <div class="family" data-ik-part="footer.family">
                            <ik-family-links [lang]="activeLang()" [keys]="familyKeys()" />
                        </div>
                    }
                </div>
            </div>
            <!-- Utility row lives OUTSIDE .inner on purpose: .inner has content-visibility:auto
                 (→ contain:paint), which would clip the lang-switcher's absolutely-positioned
                 dropdown. As a sibling it escapes the contained box. -->
            @if (showLangSwitcher() || showThemeToggle() || showBackToTop()) {
                <div class="utils" data-ik-part="footer.utils">
                    @if (showLangSwitcher()) {
                        <ik-lang-switcher [current]="activeLang()" (langChange)="langChange.emit($event)" />
                    }
                    @if (showThemeToggle()) {
                        <ik-theme-toggle (themeChange)="themeChange.emit($event)" />
                    }
                    @if (showBackToTop()) {
                        <button type="button" class="to-top" (click)="backToTop()">
                            <span aria-hidden="true">↑</span> {{ backTopLabel() }}
                        </button>
                    }
                </div>
            }
        }

        @if (compact()) {
            <!-- Compact: ONE tidy bottom strip. meta (dot · © year · legal) | disclaimer | badges.
                 No brand mark (the reference footer is just a dot + year). -->
            <div class="bar bar--compact">
                <!-- Line 1: © (verify trigger) + year→QR + disclaimer (marquee when it doesn't fit)
                     + legal — all flow together, wrapping to extra rows only when they must. -->
                <div class="bar-top" #barTopRef>
                    <span class="bar-copy">
                        <span class="dot" aria-hidden="true"></span>
                        <span class="cr">
                            @if (hasVerify()) {
                                <button
                                    type="button"
                                    class="cr-mark"
                                    (click)="openVerify()"
                                    [attr.aria-label]="verifyTitle()"
                                    [title]="verifyTitle()"
                                >
                                    ©
                                </button>
                            } @else if (verifyRoute(); as vr) {
                                <a
                                    class="cr-mark"
                                    [href]="vr"
                                    [attr.aria-label]="verifyLinkTitle()"
                                    [title]="verifyLinkTitle()"
                                    >©</a
                                >
                            } @else {
                                <span aria-hidden="true">©</span>
                            }
                            <a
                                class="cr-year"
                                [href]="qrHref()"
                                [attr.aria-label]="qrLabel()"
                                [attr.title]="qrLabel()"
                                >{{ yearRange() }}</a
                            >&ngsp;{{ crRest() }}</span
                        >
                    </span>
                    @if (disclaimer(); as disc) {
                        <span class="cdisc" [class.cdisc--run]="marquee()" [attr.aria-label]="disc">
                            <span class="cdisc__track" aria-hidden="true">
                                <span class="cdisc__seg">{{ disc }}</span>
                                <span class="cdisc__seg">{{ disc }}</span>
                            </span>
                        </span>
                    }
                    @if ((barLegal() && legalLinks().length) || showCookieSettings()) {
                        <nav class="bar-legal" [attr.aria-label]="legalNavLabel()">
                            @if (barLegal()) {
                                @for (l of legalLinks(); track $index; let first = $first) {
                                    @if (!first) {
                                        <span class="sep">·</span>
                                    }
                                    @if (l.paras.length) {
                                        <button type="button" class="leg" (click)="openPolicy(l)">
                                            {{ l.label }}
                                        </button>
                                    } @else {
                                        <a class="leg" [href]="l.href">{{ l.label }}</a>
                                    }
                                }
                            }
                            @if (showCookieSettings()) {
                                @if (barLegal() && legalLinks().length) {
                                    <span class="sep">·</span>
                                }
                                <button type="button" class="leg" (click)="openCookieSettings()">
                                    {{ cookieSettingsLabel() }}
                                </button>
                            }
                        </nav>
                    }
                </div>
                @if (familyKeys().length) {
                    <div class="family family--compact">
                        <ik-family-links size="sm" [lang]="activeLang()" [keys]="familyKeys()" />
                    </div>
                }
                @if (cfg.technologies.length || cfg.signature !== false) {
                    <div class="badges">
                        <ik-technologies size="sm" [center]="true" [appendSiteKit]="true" />
                    </div>
                }
            </div>
        } @else {
            <div class="bar" #barTopRef data-ik-part="footer.bottom">
                <!-- "2-in-1": the live-status light IS the © — a green glowing badge with a
                     white ©, so there's no separate status dot. -->
                <span class="cr" data-ik-part="footer.copyright">
                    @if (hasVerify()) {
                        <button
                            type="button"
                            class="cr-mark cr-live"
                            (click)="openVerify()"
                            [attr.aria-label]="verifyTitle()"
                            [title]="verifyTitle()"
                        >
                            ©
                        </button>
                    } @else if (verifyRoute(); as vr) {
                        <a
                            class="cr-mark cr-live"
                            [href]="vr"
                            [attr.aria-label]="verifyLinkTitle()"
                            [title]="verifyLinkTitle()"
                            >©</a
                        >
                    } @else {
                        <span class="cr-live" aria-hidden="true">©</span>
                    }
                    <a
                        class="cr-year"
                        [href]="qrHref()"
                        [attr.aria-label]="qrLabel()"
                        [attr.title]="qrLabel()"
                        >{{ yearRange() }}</a
                    >
                    {{ crRest() }}</span
                >
                @if (hideBrand() && disclaimer(); as disc) {
                    <!-- Brand block (which normally holds the disclaimer) is hidden → keep the
                         disclaimer here as a marquee that fills the middle (scrolls when long). -->
                    <span
                        class="cdisc"
                        [class.cdisc--run]="marquee()"
                        [attr.aria-label]="disc"
                        data-ik-part="footer.disclaimer"
                    >
                        <span class="cdisc__track" aria-hidden="true">
                            <span class="cdisc__seg">{{ disc }}</span>
                            <span class="cdisc__seg">{{ disc }}</span>
                        </span>
                    </span>
                }
                <!-- Legal · cookie-settings · license grouped in ONE labelled <nav> landmark so AT
                     users can jump to it; each entry keeps its leading "·" so the visual flow
                     (© year · Privacy · Terms · License) is unchanged. -->
                @if ((barLegal() && legalLinks().length) || showCookieSettings() || license()) {
                    <nav class="bar-nav" [attr.aria-label]="legalNavLabel()" data-ik-part="footer.legal-nav">
                        @if (barLegal()) {
                            @for (l of legalLinks(); track $index) {
                                <span class="sep">·</span>
                                @if (l.paras.length) {
                                    <button
                                        type="button"
                                        class="leg"
                                        (click)="openPolicy(l)"
                                        [attr.data-ik-part]="'footer.legal.' + l.key"
                                    >
                                        {{ l.label }}
                                    </button>
                                } @else {
                                    <a
                                        class="leg"
                                        [href]="l.href"
                                        [attr.data-ik-part]="'footer.legal.' + l.key"
                                        >{{ l.label }}</a
                                    >
                                }
                            }
                        }
                        @if (showCookieSettings()) {
                            <span class="sep">·</span>
                            <button
                                type="button"
                                class="leg"
                                (click)="openCookieSettings()"
                                data-ik-part="footer.cookie-settings"
                            >
                                {{ cookieSettingsLabel() }}
                            </button>
                        }
                        @if (license(); as l) {
                            <span class="sep">·</span>
                            <a
                                class="lic"
                                [href]="licenseHref()"
                                [title]="l.name"
                                data-ik-part="footer.license"
                                >{{ l.name }}</a
                            >
                        }
                    </nav>
                }
                @if (tagline(); as tag) {
                    <span class="tag" [class.tag--run]="tagMarquee()">
                        <span class="tag__win" data-ik-part="footer.tagline">
                            <span class="tag__track">
                                <span class="tag__seg">{{ tag }}</span>
                                <span class="tag__seg" aria-hidden="true">{{ tag }}</span>
                            </span>
                        </span>
                    </span>
                }
                @if (cfg.technologies.length || cfg.signature !== false || cfg.pageSpeed) {
                    <div class="badges" data-ik-part="footer.badges">
                        <ik-technologies
                            size="sm"
                            [center]="true"
                            [appendSiteKit]="true"
                            [showPageSpeed]="true"
                            [lang]="activeLang()"
                        />
                    </div>
                }
            </div>
        }

        <!-- The policy panel (a legal link with \`body\`) or the build-integrity result (from ©):
             a chunk of its own (footer-dialog.ts), fetched when a dialog first opens. -->
        @if (policyDoc() || verifyOpen()) {
            @defer (on immediate) {
                <ik-footer-dialog
                    [policy]="policyDoc()"
                    [verify]="verifyOpen() ? verifyView() : null"
                    [fullLabel]="openFullLabel()"
                    (closed)="closeDialog()"
                >
                    <ik-close [autoFocus]="true" [label]="closeLabel()" (closed)="closeDialog()" />
                </ik-footer-dialog>
            }
        }
    `, host: { class: 'ik-footer', role: 'contentinfo' }, styles: [":host{display:block;border-top:1px solid var(--border, #e5e5e9);background:var(--bg, #fff);color:var(--text-mute, #51515e);font-family:var(--font-display, system-ui, sans-serif);font-size:var(--fs-sm, .875rem)}.inner{display:grid;grid-template-columns:minmax(13rem,1.3fr) 2.6fr;align-items:start;column-gap:var(--sp-8, 2rem);row-gap:0;max-width:var(--container, 72rem);margin-inline:auto;content-visibility:auto;contain-intrinsic-size:auto 320px;padding:var(--sp-12, 3rem) var(--gutter, 1.5rem) var(--sp-6, 1.5rem)}.cols{display:grid;grid-template-columns:1fr;gap:var(--sp-6, 1.5rem) var(--sp-8, 2rem);align-items:start}@media(min-width:768px){.cols:not(.cols--stack){grid-template-columns:repeat(auto-fit,minmax(8.5rem,1fr));align-items:stretch}}.cols .col{border-left:1px solid var(--border-soft, #f0f0f2);padding-left:var(--sp-6, 1.5rem)}.col{display:flex;flex-direction:column;gap:var(--sp-3, .75rem);min-width:0}.brand-col{gap:var(--sp-4, 1rem)}.inner--brandless,.cols--stack{grid-template-columns:1fr}.extras{grid-column:1 / -1;margin-top:var(--sp-6, 1.5rem);display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:var(--sp-2, .5rem);line-height:0}.extras .social,.extras .family,.extras ::ng-deep ik-social-links,.extras ::ng-deep ik-social-links .row,.extras ::ng-deep ik-family-links,.extras ::ng-deep ik-family-links .row{display:contents}.family--compact{display:flex;justify-content:center;margin-top:0}@media(max-width:560px){.inner{grid-template-columns:1fr;column-gap:var(--sp-6, 1.5rem)}.cols{margin-top:var(--sp-6, 1.5rem)}}.name{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);font-family:var(--font-brand, system-ui, sans-serif);font-weight:var(--fw-bold, 700);font-size:var(--fs-lg, 1.125rem);letter-spacing:var(--ls-tight, -.02em);color:var(--text, #09090f);text-decoration:none;width:fit-content}.logo{height:26px;width:auto;border-radius:6px;display:block}.mark{display:grid;place-items:center;width:28px;height:28px;border-radius:8px;background:var(--text, #09090f);color:var(--bg, #fff);flex-shrink:0}.mark ::ng-deep svg{display:block;width:60%;height:60%}.sub{margin:calc(-1 * var(--sp-2, .5rem)) 0 0;font-size:var(--fs-xs, .75rem);color:var(--text-dim, #74747f)}.disc{margin:0;font-size:var(--fs-xs, .75rem);color:var(--text-mute, #51515e);line-height:1.6;max-width:38ch}.social{display:flex;align-items:center;flex-wrap:wrap;gap:var(--sp-2, .5rem);--ik-social-size: 2.25rem}.social:empty{display:none}.social ::ng-deep ik-social-links{display:contents}.social ::ng-deep ik-social-links ul{display:contents}.col-title{margin:0;font-size:var(--fs-xs, .75rem);font-weight:var(--fw-semi, 600);letter-spacing:var(--ls-wide, .06em);text-transform:uppercase;color:var(--text-dim, #74747f)}.links{display:flex;flex-direction:column;gap:var(--sp-2, .5rem);margin:0;padding:0;list-style:none}.links a,.links button.link{font-size:var(--fs-sm, .875rem);color:var(--text-mute, #51515e);text-decoration:none;transition:color var(--dur-fast, .15s) var(--ease-out, ease)}.links button.link{margin:0;padding:0;border:0;background:none;cursor:pointer;text-align:left;font-family:inherit;line-height:inherit}.links a:hover,.links button.link:hover,.name:hover{color:var(--text, #09090f)}.bar{display:flex;align-items:center;flex-wrap:wrap;justify-content:center;gap:var(--sp-2, .5rem);max-width:var(--container, 72rem);margin-inline:auto;padding:var(--sp-4, 1rem) var(--gutter, 1.5rem);border-top:1px solid var(--border-soft, #f0f0f2);font-size:var(--fs-xs, .75rem);color:var(--text-dim, #74747f)}.dot{width:6px;height:6px;border-radius:50%;background:var(--success, #16a34a);box-shadow:0 0 8px color-mix(in oklch,var(--success, #16a34a) 60%,transparent);flex-shrink:0}.bar>.dot{display:none}.sep{opacity:.5}.cr-year{color:inherit;text-decoration:none;cursor:pointer;margin-inline-start:.35em;transition:color var(--dur-base, .22s) var(--ease-out, ease)}.lic,.leg{color:inherit;text-decoration:none}button.leg{margin:0;padding:0;border:0;background:none;font:inherit;cursor:pointer}.lic:hover,.leg:hover,.cr-year:hover{color:var(--brand, #6d28d9)}.cr-mark{margin:0;padding:0;border:0;background:none;font:inherit;color:inherit;cursor:pointer;text-decoration:none;transition:color var(--dur-base, .22s) var(--ease-out, ease)}.cr-mark:hover{color:var(--brand, #6d28d9)}.badges{flex-basis:100%;margin-top:var(--sp-1, .25rem);display:flex;justify-content:center;align-items:center}.bar--compact{flex-direction:column;align-items:center;justify-content:center;text-align:center;border-top:none;gap:.55rem;padding-block:1rem;font-size:.66rem}.bar-top{display:flex;align-items:center;justify-content:center;flex-wrap:nowrap;gap:.3rem .6rem;width:100%;min-width:0}.bar-copy{display:inline-flex;align-items:center;gap:.35rem;flex-shrink:0}.bar-legal{display:inline-flex;align-items:center;flex-wrap:nowrap;flex-shrink:0;justify-content:center;gap:.3rem .45rem}.bar--compact .cr,.bar--compact .leg,.bar--compact .sep{white-space:nowrap}.bar--compact .dot{width:5px;height:5px;background:var(--brand, #06b6d4);box-shadow:none}.cdisc{flex:1 1 0;min-width:0;overflow:hidden;display:flex;justify-content:center;color:var(--text-dim, #74747f);font-size:.85em;line-height:1.35}.cdisc__track{display:inline-flex;flex-wrap:nowrap;white-space:nowrap}.cdisc__seg{white-space:nowrap}.cdisc:not(.cdisc--run) .cdisc__seg:nth-child(2){display:none}.cdisc--run{justify-content:flex-start;-webkit-mask-image:linear-gradient(to right,transparent,#000 1.2rem,#000 calc(100% - 1.2rem),transparent);mask-image:linear-gradient(to right,transparent,#000 1.2rem,#000 calc(100% - 1.2rem),transparent)}.cdisc--run .cdisc__track{will-change:transform;animation:ik-cdisc-marquee 22s linear infinite}.cdisc--run .cdisc__seg{padding-right:1rem}@media(max-width:600px){.bar--compact{font-size:clamp(.44rem,2.3vw,.62rem)}.cdisc{display:none}.bar--compact .bar-top{gap:.2rem .35rem}.bar--compact .bar-legal{gap:.2rem .3rem}}@keyframes ik-cdisc-marquee{0%{transform:translate(0)}to{transform:translate(-50%)}}.cdisc--run:hover .cdisc__track{animation-play-state:paused}.tag{min-width:0;max-width:100%;display:flex;justify-content:center}.tag__win{min-width:0;max-width:100%;overflow:hidden;display:flex;justify-content:center}.tag__track{display:inline-flex;flex-wrap:nowrap;white-space:nowrap}.tag__seg{white-space:nowrap}.tag:not(.tag--run) .tag__seg:nth-child(2){display:none}.tag--run .tag__win{justify-content:flex-start;-webkit-mask-image:linear-gradient(to right,transparent,#000 1rem,#000 calc(100% - 1rem),transparent);mask-image:linear-gradient(to right,transparent,#000 1rem,#000 calc(100% - 1rem),transparent)}.tag--run .tag__track{will-change:transform;animation:ik-cdisc-marquee 22s linear infinite}.tag--run .tag__seg{padding-right:1rem}.tag--run:hover .tag__track{animation-play-state:paused}@media(prefers-reduced-motion:reduce){.cdisc--run .cdisc__track,.tag--run .tag__track{animation:none}.cdisc--run .cdisc__seg:nth-child(2),.tag--run .tag__seg:nth-child(2){display:none}}.bar--compact .badges{display:block;width:100%}.bar--compact .badges ik-technologies{display:block;width:100%}@media(max-width:480px){.bar--compact .badges{display:block;width:100%}.bar--compact .badges ::ng-deep .ik-tech{display:grid!important;grid-template-columns:repeat(3,1fr);gap:6px;width:100%}.bar--compact .badges ::ng-deep .ik-tech a{justify-self:stretch;justify-content:center;width:100%!important;box-sizing:border-box}}@media(max-width:900px){.bar:not(.bar--compact) .badges{display:block;width:100%;margin-left:0}.bar:not(.bar--compact) .badges ::ng-deep .ik-tech{display:grid!important;grid-template-columns:repeat(var(--ik-footer-badge-cols, 4),1fr);gap:6px;width:100%}.bar:not(.bar--compact) .badges ::ng-deep .ik-tech a{justify-self:stretch;justify-content:center;width:100%!important;box-sizing:border-box}}.name:focus-visible,.links a:focus-visible,.links button.link:focus-visible,.leg:focus-visible,.lic:focus-visible,.cr-mark:focus-visible,.cr-year:focus-visible,.contact a:focus-visible,.to-top:focus-visible{outline:none;border-radius:4px;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.cr-mark,.cr-year{padding-block:4px}.cr-live{color:var(--ik-copyright-tint, var(--success, #16a34a));text-shadow:0 0 4px color-mix(in oklch,var(--success, #16a34a) 40%,transparent);text-decoration:none}.cr-live:hover{color:var(--ik-copyright-tint, var(--success, #16a34a));filter:brightness(1.2)}.links a,.links button.link,.bar-nav .leg,.bar-nav .lic,.bar-legal .leg{padding-block:4px}.bar-nav{display:inline-flex;align-items:center;flex-wrap:wrap;justify-content:center;gap:var(--sp-2, .5rem)}.contact{display:flex;flex-direction:column;gap:var(--sp-1, .25rem);font-style:normal;font-size:var(--fs-xs, .75rem);color:var(--text-mute, #51515e)}.contact__org{font-weight:var(--fw-semi, 600);color:var(--text, #09090f)}.contact a.contact__row{color:inherit;text-decoration:none;width:fit-content}.contact a.contact__row:hover{color:var(--brand, #6d28d9)}.utils{max-width:var(--container, 72rem);margin-inline:auto;padding:0 var(--gutter, 1.5rem) var(--sp-6, 1.5rem);display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:var(--sp-3, .75rem)}.to-top{display:inline-flex;align-items:center;gap:.35em;min-height:24px;padding:.4em .85em;border:1px solid var(--border, #e5e5e9);border-radius:var(--r-full, 999px);background:var(--bg-elev, #fff);color:var(--text-mute, #51515e);cursor:pointer;font:inherit;font-size:var(--fs-xs, .75rem);text-decoration:none;transition:color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease)}.to-top:hover{color:var(--brand, #6d28d9);border-color:color-mix(in oklch,var(--brand, #6d28d9) 45%,transparent)}\n"] }]
            }], ctorParameters: () => [], propDecorators: { barTopRef: [{ type: i0.ViewChild, args: ['barTopRef', { isSignal: true }] }], lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], currentYear: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentYear", required: false }] }], cookieSettings: [{ type: i0.Output, args: ["cookieSettings"] }], langChange: [{ type: i0.Output, args: ["langChange"] }], themeChange: [{ type: i0.Output, args: ["themeChange"] }] } }) });

/**
 * Internal share/copy helper for {@link ContactQr}. Provided at the component
 * level (NOT `providedIn`) so each ContactQr keeps its own `copied` flash state.
 * Not part of the public API — an implementation detail of the component.
 */
class ShareService {
    document = inject(DOCUMENT);
    copied = signal(false, ...(ngDevMode ? [{ debugName: "copied" }] : /* istanbul ignore next */ []));
    share(kind, payload) {
        const win = this.document.defaultView;
        /* istanbul ignore next -- no-DOM guard: defaultView is always present in a browser. */
        if (!win)
            return;
        const url = payload.url;
        const enc = encodeURIComponent(payload.url);
        const text = encodeURIComponent(payload.text);
        switch (kind) {
            case 'native': {
                if (typeof win.navigator?.share === 'function') {
                    win.navigator.share({ title: payload.title, url }).catch(() => undefined);
                }
                else {
                    this.copyText(payload.url);
                }
                return;
            }
            case 'copy':
                this.copyText(payload.url);
                return;
            case 'telegram':
                this.openExternal(`https://t.me/share/url?url=${enc}&text=${text}`);
                return;
            case 'whatsapp':
                this.openExternal(`https://wa.me/?text=${text}`);
                return;
            case 'x':
                this.openExternal(`https://twitter.com/intent/tweet?url=${enc}&text=${text}`);
                return;
            case 'linkedin':
                this.openExternal(`https://www.linkedin.com/sharing/share-offsite/?url=${enc}`);
                return;
            case 'facebook':
                this.openExternal(`https://www.facebook.com/sharer/sharer.php?u=${enc}`);
                return;
            case 'vk':
                this.openExternal(`https://vk.com/share.php?url=${enc}`);
                return;
            case 'email':
                this.openExternal(`mailto:?subject=${encodeURIComponent(payload.title)}&body=${text}%0A%0A${enc}`);
                return;
        }
    }
    copyText(text) {
        const win = this.document.defaultView;
        const flash = () => {
            this.copied.set(true);
            setTimeout(() => this.copied.set(false), 1800);
        };
        if (win?.navigator?.clipboard?.writeText) {
            win.navigator.clipboard
                .writeText(text)
                .then(flash)
                .catch(() => this.copyFallback(text, flash));
            return;
        }
        this.copyFallback(text, flash);
    }
    copyFallback(text, done) {
        const ta = this.document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        this.document.body.appendChild(ta);
        ta.select();
        try {
            this.document.execCommand('copy');
            done();
        }
        catch {
            /* noop */
        }
        this.document.body.removeChild(ta);
    }
    openExternal(href) {
        this.document.defaultView?.open(href, '_blank', 'noopener,noreferrer');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ShareService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ShareService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ShareService, decorators: [{
            type: Injectable
        }] });

let loaded;
let pending;
/** The generator once it has loaded, else undefined (render the QR when it arrives). */
function qrcodeIfLoaded() {
    return loaded;
}
/** Loads the generator (once) and resolves to its factory. */
function loadQrcode() {
    return (pending ??= import('qrcode-generator').then((m) => {
        // the CommonJS export arrives as `default` under ESM interop; plain when bundled as ESM
        const f = (m.default ?? m);
        loaded = f;
        return f;
    }));
}

/**
 * Inline share icons — these are *library-constant* SVG strings (never config or
 * user values), so it is safe to `bypassSecurityTrustHtml` them once up-front.
 * Verbatim from the reference QR page so the chip set stays pixel-identical.
 */
const SHARE_ICONS = {
    native: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><path d="M16 6l-4-4-4 4"/><path d="M12 2v14"/></svg>`,
    copy: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
    telegram: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.94 4.34c-.31-.26-.78-.3-1.18-.13L2.77 11.7c-.46.19-.74.66-.7 1.16.05.5.41.91.9 1.02l4.51 1.04 1.74 5.38c.13.39.46.67.86.74.4.06.81-.1 1.05-.42l2.33-3.05 4.59 3.39c.21.16.46.24.71.24.16 0 .31-.03.46-.09.4-.16.69-.51.76-.94l2.32-13.74c.07-.42-.11-.84-.46-1.09zM9.74 14.45l-.65 3.55-1.13-3.5 7.7-5.7-5.92 5.65z"/></svg>`,
    whatsapp: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.5 14.4c-.3-.15-1.77-.87-2.04-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.17.2-.35.22-.65.07-1.77-.88-2.93-1.58-4.1-3.58-.31-.53.31-.5.88-1.65.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51l-.57-.01c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.06 2.88 1.21 3.07.15.2 2.09 3.2 5.07 4.49.71.3 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.08 1.77-.72 2.02-1.42.25-.7.25-1.3.17-1.42-.07-.13-.27-.2-.57-.35zM12 2C6.48 2 2 6.48 2 12c0 1.78.46 3.45 1.27 4.9L2 22l5.25-1.38A9.93 9.93 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm5.83 14.83A8 8 0 0 1 7.7 18.04l-.4-.24-3.07.81.82-2.99-.26-.41A8 8 0 1 1 17.83 16.83z"/></svg>`,
    x: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231 5.451-6.231zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77z"/></svg>`,
    linkedin: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.13 1.45-2.13 2.94v5.67H9.36V9h3.41v1.56h.05c.47-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.55C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.72V1.72C24 .77 23.2 0 22.22 0z"/></svg>`,
    facebook: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/></svg>`,
    vk: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93v6.13C2 20.67 3.33 22 8.93 22h6.13c5.6 0 6.93-1.33 6.93-6.93V8.93C22 3.33 20.67 2 15.07 2zm3.07 14.27h-1.45c-.55 0-.72-.44-1.71-1.43-.85-.83-1.23-.94-1.43-.94-.28 0-.36.08-.36.47v1.31c0 .33-.11.53-.96.53-1.43 0-3-.86-4.11-2.46C6.4 11.53 5.94 9.81 5.94 9.46c0-.2.08-.39.47-.39h1.45c.36 0 .49.16.62.55.69 2.02 1.86 3.79 2.34 3.79.18 0 .26-.08.26-.55v-2.13c-.06-.97-.58-1.06-.58-1.41 0-.16.14-.33.36-.33h2.28c.31 0 .42.16.42.53v2.86c0 .31.13.42.22.42.18 0 .33-.11.66-.44 1.04-1.16 1.78-2.95 1.78-2.95.09-.2.25-.39.61-.39h1.45c.44 0 .53.22.44.53-.18.85-1.96 3.36-1.96 3.36-.16.25-.22.36 0 .64.16.2.69.66 1.04 1.07.66.74 1.16 1.36 1.31 1.79.13.42-.09.64-.53.64z"/></svg>`,
    email: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 7l10 7 10-7"/></svg>`,
};
const CHECK_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>`;
const ARROW_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>`;
/** Diagonal arrow for EXTERNAL links (↗), matching the reference QR card. */
const EXT_ARROW_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7M8 7h9v9"/></svg>`;
/** Leading icons for contact channels (telegram/whatsapp/email reuse the share set). */
// a pure IIFE: the property reads below would otherwise keep the icon sets in every app
const CHANNEL_ICONS = /* @__PURE__ */ (() => ({
    telegram: SHARE_ICONS.telegram,
    whatsapp: SHARE_ICONS.whatsapp,
    email: SHARE_ICONS.email,
    phone: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
    website: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 0 20 15.3 15.3 0 0 1 0-20z"/></svg>`,
    form: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z"/></svg>`,
}))();
/** Brand channel names are proper nouns → kept literal (never localized). */
const BRAND_LABELS = {
    telegram: 'Telegram',
    whatsapp: 'WhatsApp',
    x: 'X',
    linkedin: 'LinkedIn',
    facebook: 'Facebook',
    vk: 'VK',
};
/** Used when `config.contact.share` is not provided. */
const DEFAULT_SHARE = ['native', 'copy', 'telegram', 'whatsapp', 'email'];
/**
 * Rich contact card built around a QR code.
 *
 * The QR is generated client-side from `config.contact.qr.data` (or `brand.url`)
 * with a crisp custom renderer (error-correction 'H', single black path on a
 * white quiet-zone) — unless `config.contact.qr.src` is set, in which case that
 * image is shown verbatim. The QR always sits on a white frame so it stays
 * scannable in dark theme. With `showDetails` it also lists the contact
 * channels, locale-aware quick links and a row of share buttons.
 *
 * Chrome labels (scan hint, section titles, copy/share/email/website) are
 * localized via `qrString(effLang, …)`; brand channel names stay literal.
 *
 * ```html
 * <ik-contact-qr [lang]="translate.currentLang" />
 * <ik-contact-qr [showDetails]="false" />
 * ```
 */
class ContactQr {
    cfg = inject(SITE_KIT_CONFIG);
    sanitizer = inject(DomSanitizer);
    document = inject(DOCUMENT);
    share = inject(ShareService);
    /** Show the channel list, quick links and share buttons under the QR. */
    showDetails = input(true, ...(ngDevMode ? [{ debugName: "showDetails" }] : /* istanbul ignore next */ []));
    /** Active language code (host binds `[lang]="translate.currentLang"`). */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /**
     * Small pill in the top-right of the header (e.g. "CARD"). Content, so it accepts
     * a per-language map and translates with `[lang]`: `{ en: 'CARD', ru: 'ВИЗИТКА' }`.
     */
    eyebrow = input(...(ngDevMode ? [undefined, { debugName: "eyebrow" }] : /* istanbul ignore next */ []));
    /**
     * Share-button layout override: 'grid' (vertical icon-over-label tiles) or
     * 'inline' (horizontal icon-left/label-right rows). When unset, falls back to
     * `config.contact.shareLayout`, then 'grid'.
     */
    shareLayout = input(...(ngDevMode ? [undefined, { debugName: "shareLayout" }] : /* istanbul ignore next */ []));
    /**
     * Share icon colour theme override: 'mono' (neutral, accent on hover) or
     * 'color' (brand colours at rest). Unset → `config.contact.shareTheme` → 'mono'.
     */
    shareTheme = input(...(ngDevMode ? [undefined, { debugName: "shareTheme" }] : /* istanbul ignore next */ []));
    /**
     * Section-divider style override ('top' | 'center' | 'center-dashed'). Unset →
     * `config.contact.sectionDivider` → 'top'.
     */
    sectionDivider = input(...(ngDevMode ? [undefined, { debugName: "sectionDivider" }] : /* istanbul ignore next */ []));
    copied = this.share.copied;
    /** Resolved presentation knobs: explicit input wins, else config, else default. */
    effShareLayout = computed(() => this.shareLayout() ?? this.cfg.contact?.shareLayout ?? 'grid', ...(ngDevMode ? [{ debugName: "effShareLayout" }] : /* istanbul ignore next */ []));
    effShareTheme = computed(() => this.shareTheme() ?? this.cfg.contact?.shareTheme ?? 'mono', ...(ngDevMode ? [{ debugName: "effShareTheme" }] : /* istanbul ignore next */ []));
    effDivider = computed(() => this.sectionDivider() ?? this.cfg.contact?.sectionDivider ?? 'top', ...(ngDevMode ? [{ debugName: "effDivider" }] : /* istanbul ignore next */ []));
    /** Eyebrow pill text resolved for the active language. */
    effEyebrow = computed(() => this.pickLang(this.eyebrow()), ...(ngDevMode ? [{ debugName: "effEyebrow" }] : /* istanbul ignore next */ []));
    /** Library-constant SVGs → safe to trust once. */
    checkIcon = this.sanitizer.bypassSecurityTrustHtml(CHECK_ICON);
    arrowIcon = this.sanitizer.bypassSecurityTrustHtml(ARROW_ICON);
    extArrowIcon = this.sanitizer.bypassSecurityTrustHtml(EXT_ARROW_ICON);
    /** Effective language: explicit input wins, else the config default. */
    effLang = computed(() => this.lang() ?? this.cfg.defaultLang, ...(ngDevMode ? [{ debugName: "effLang" }] : /* istanbul ignore next */ []));
    monogram = computed(() => this.cfg.brand.monogram ?? this.cfg.brand.name.charAt(0), ...(ngDevMode ? [{ debugName: "monogram" }] : /* istanbul ignore next */ []));
    /** Trusted inline brand glyph (paths use currentColor) for the mark + emblem. */
    brandGlyph = computed(() => {
        const g = this.cfg.brand.glyph;
        return g ? this.sanitizer.bypassSecurityTrustHtml(g) : null;
    }, ...(ngDevMode ? [{ debugName: "brandGlyph" }] : /* istanbul ignore next */ []));
    /**
     * Header subtitle on the QR card — an explicit `contact.company` ONLY.
     * Deliberately NOT the brand tagline (that's the site's hero line, used in
     * nav/footer): a card that wants a subtitle sets `contact.company`; deposit
     * leaves it empty → the brand word stands alone (matches the reference card).
     */
    subtitle = computed(() => this.cfg.contact?.company ?? null, ...(ngDevMode ? [{ debugName: "subtitle" }] : /* istanbul ignore next */ []));
    /** Lede shown above the QR (config.contact.qr.lede) — per-language aware. */
    lede = computed(() => this.pickLang(this.cfg.contact?.qr?.lede), ...(ngDevMode ? [{ debugName: "lede" }] : /* istanbul ignore next */ []));
    /** Resolve a string-or-per-language-map field for the active language. */
    pickLang(v) {
        if (v == null)
            return null;
        if (typeof v === 'string')
            return v;
        return v[this.effLang()] ?? v[this.cfg.defaultLang] ?? Object.values(v)[0] ?? null;
    }
    person = computed(() => {
        const c = this.cfg.contact;
        if (!c)
            return null;
        if (!c.person && !c.role && !c.location)
            return null;
        return { person: c.person, role: c.role, location: c.location };
    }, ...(ngDevMode ? [{ debugName: "person" }] : /* istanbul ignore next */ []));
    // ── localized chrome ──────────────────────────────────────
    /** Scan hint under the QR: explicit caption (per-language) wins, else localized 'scan'. */
    scanHint = computed(() => this.pickLang(this.cfg.contact?.qr?.caption) ?? this.tr('scan'), ...(ngDevMode ? [{ debugName: "scanHint" }] : /* istanbul ignore next */ []));
    linksTitle = computed(() => this.tr('linksTitle'), ...(ngDevMode ? [{ debugName: "linksTitle" }] : /* istanbul ignore next */ []));
    shareTitle = computed(() => this.tr('shareTitle'), ...(ngDevMode ? [{ debugName: "shareTitle" }] : /* istanbul ignore next */ []));
    copiedLabel = computed(() => this.tr('copied'), ...(ngDevMode ? [{ debugName: "copiedLabel" }] : /* istanbul ignore next */ []));
    // ── QR source ─────────────────────────────────────────────
    /**
     * QR-encoded value for a language: explicit per-lang `qr.urls[lang]` wins,
     * else `qr.localize` adds the `/<lang>` prefix to `data`, else `data`/brand.
     * So switching language (slotted lang-switcher) re-points the QR.
     */
    qrTarget(lang) {
        const q = this.cfg.contact?.qr;
        const base = q?.data ?? this.cfg.brand.url ?? '';
        if (q?.urls?.[lang])
            return q.urls[lang];
        if (q?.localize && base)
            return localizeUrl(base, lang, { defaultLang: this.cfg.defaultLang });
        return base;
    }
    /** Value encoded into the QR (or the click-through fallback). */
    qrData = computed(() => this.qrTarget(this.effLang()), ...(ngDevMode ? [{ debugName: "qrData" }] : /* istanbul ignore next */ []));
    /** Pre-rendered image source — when set, skip generation entirely. */
    qrImg = computed(() => this.cfg.contact?.qr?.src ?? null, ...(ngDevMode ? [{ debugName: "qrImg" }] : /* istanbul ignore next */ []));
    qrHref = computed(() => this.cfg.contact?.qr?.href ?? null, ...(ngDevMode ? [{ debugName: "qrHref" }] : /* istanbul ignore next */ []));
    alt = computed(() => this.cfg.contact?.qr?.alt ?? `${this.cfg.brand.name} — QR`, ...(ngDevMode ? [{ debugName: "alt" }] : /* istanbul ignore next */ []));
    /** Decorative L-corner accents around the white frame. Default 'none'. */
    corners = computed(() => this.cfg.contact?.qr?.corners ?? 'none', ...(ngDevMode ? [{ debugName: "corners" }] : /* istanbul ignore next */ []));
    /**
     * Center brand badge model, or null when off. Opt-OUT (`badge: false`);
     * default ON when the brand has a logo or a monogram/name to show. Prefers
     * the brand logo image, else the monogram letter on a brand gradient.
     */
    badge = computed(() => {
        const opt = this.cfg.contact?.qr?.badge;
        const logo = this.cfg.brand.logoUrl ?? null;
        const mono = this.monogram();
        if (opt === false)
            return null;
        // Default ON only when there's something to render.
        if (opt === undefined && !logo && !mono)
            return null;
        return { logo, mono };
    }, ...(ngDevMode ? [{ debugName: "badge" }] : /* istanbul ignore next */ []));
    /** The QR generator: a lazy chunk (qrcode-loader.ts), set when it arrives; the SVG renders then. */
    qrcode = signal(qrcodeIfLoaded(), ...(ngDevMode ? [{ debugName: "qrcode" }] : /* istanbul ignore next */ []));
    constructor() {
        if (!this.qrcode() && !this.qrImg())
            void loadQrcode().then((f) => this.qrcode.set(f));
    }
    /**
     * Generated QR SVG (only consulted when `qrImg()` is null). Custom renderer
     * for crisp output: error-correction 'H', a 2-module quiet margin, and a
     * single black `<path>` on a white background. Failures degrade to empty.
     */
    qrSvg = computed(() => {
        const data = this.qrData();
        const qrcode = this.qrcode();
        try {
            if (!data || !qrcode)
                return this.sanitizer.bypassSecurityTrustHtml('');
            const qr = qrcode(0, 'H');
            qr.addData(data);
            qr.make();
            const count = qr.getModuleCount();
            const margin = 2;
            const size = count + margin * 2;
            let path = '';
            for (let r = 0; r < count; r++) {
                for (let c = 0; c < count; c++) {
                    if (qr.isDark(r, c)) {
                        path += `M${c + margin} ${r + margin}h1v1h-1z`;
                    }
                }
            }
            const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" ` +
                `shape-rendering="crispEdges" preserveAspectRatio="xMidYMid meet">` +
                `<rect width="${size}" height="${size}" fill="#ffffff"/>` +
                `<path d="${path}" fill="#0a0a0c"/>` +
                `</svg>`;
            return this.sanitizer.bypassSecurityTrustHtml(svg);
        }
        catch {
            return this.sanitizer.bypassSecurityTrustHtml('');
        }
    }, ...(ngDevMode ? [{ debugName: "qrSvg" }] : /* istanbul ignore next */ []));
    // ── channels & links ──────────────────────────────────────
    /** Contact channels (telegram/whatsapp/email/phone/website/contact-form) as icon links. */
    channels = computed(() => {
        const c = this.cfg.contact;
        if (!c)
            return [];
        const ico = (k) => this.sanitizer.bypassSecurityTrustHtml(CHANNEL_ICONS[k] ?? '');
        const out = [];
        if (c.telegram)
            out.push({
                label: this.prettyTelegram(c.telegram),
                href: c.telegram,
                external: true,
                icon: ico('telegram'),
            });
        if (c.whatsapp)
            out.push({
                label: this.waLabel(c.whatsapp),
                href: this.waHref(c.whatsapp),
                external: true,
                icon: ico('whatsapp'),
            });
        if (c.email)
            out.push({ label: c.email, href: `mailto:${c.email}`, external: false, icon: ico('email') });
        if (c.phone)
            out.push({
                label: formatPhone(c.phone),
                href: `tel:${c.phone.replace(/[^\d+]/g, '')}`,
                external: false,
                icon: ico('phone'),
            });
        if (c.website)
            out.push({
                label: this.tr('website'),
                href: c.website,
                external: this.isExternal(c.website),
                icon: ico('website'),
            });
        if (c.contactForm)
            out.push({
                label: this.tr('contactForm'),
                href: c.contactForm,
                external: this.isExternal(c.contactForm),
                icon: ico('form'),
            });
        return out;
    }, ...(ngDevMode ? [{ debugName: "channels" }] : /* istanbul ignore next */ []));
    /** WhatsApp: a wa.me link as-is, else build one from the digits. */
    waHref(v) {
        return /^https?:\/\//i.test(v) ? v : `https://wa.me/${v.replace(/[^\d]/g, '')}`;
    }
    waLabel(v) {
        const d = v.replace(/[^\d]/g, '');
        return d ? formatPhone(`+${d}`) : 'WhatsApp';
    }
    /** Config quick links, resolved locale-aware. */
    quickLinks = computed(() => {
        const links = this.cfg.contact?.quickLinks ?? [];
        const lang = this.effLang();
        const brandHost = this.hostOf(this.cfg.brand.url ?? '');
        return links.map((link) => {
            const href = this.resolveLink(link, lang);
            // Same-site links (the brand's own host) read as internal (→); only a
            // different host (e.g. GitHub) is "external" and gets the ↗ arrow + new tab.
            const external = link.external ?? (this.isExternal(href) && this.hostOf(href) !== brandHost);
            return { label: localizeText(link.label, lang, this.cfg.defaultLang) ?? '', href, external };
        });
    }, ...(ngDevMode ? [{ debugName: "quickLinks" }] : /* istanbul ignore next */ []));
    /** Hostname of a URL (resolved against brand.url for relative paths); '' if unparseable. */
    hostOf(url) {
        try {
            return new URL(url, this.cfg.brand.url ?? 'https://localhost').host;
        }
        catch {
            return '';
        }
    }
    /** Share chips — exactly `config.contact.share` when set, else the default set. */
    shareButtons = computed(() => {
        const kinds = this.cfg.contact?.share ?? DEFAULT_SHARE;
        const overrides = this.cfg.contact?.shareColors;
        return kinds.map((kind) => ({
            kind,
            label: this.shareLabel(kind),
            icon: this.sanitizer.bypassSecurityTrustHtml(SHARE_ICONS[kind]),
            // Default null → inherits the theme `--brand` (one colour for all chips).
            // Set a channel in `config.contact.shareColors` to opt into a custom tint.
            accent: overrides?.[kind] ?? null,
        }));
    }, ...(ngDevMode ? [{ debugName: "shareButtons" }] : /* istanbul ignore next */ []));
    // ── sharing ───────────────────────────────────────────────
    /** Target encoded into every share intent (locale-aware, mirrors the QR). */
    shareTarget() {
        const q = this.cfg.contact?.qr;
        return q?.href ?? (this.qrTarget(this.effLang()) || this.cfg.brand.url || this.pageUrl());
    }
    pageUrl() {
        /* istanbul ignore next -- no-DOM guard: in a browser location.href is always set, so the brand.url fallback runs only under SSR/no-window. */
        return this.document.defaultView?.location.href ?? this.cfg.brand.url ?? '';
    }
    onShare(kind) {
        this.share.share(kind, {
            url: this.shareTarget(),
            title: this.cfg.brand.name,
            text: this.shareText(),
        });
    }
    // ── helpers ───────────────────────────────────────────────
    tr(key) {
        return qrString(this.effLang(), key, this.cfg.strings);
    }
    /** Brand channels stay literal; functional chips are localized. */
    shareLabel(kind) {
        switch (kind) {
            case 'native':
                return this.tr('share');
            case 'copy':
                return this.tr('copy');
            case 'email':
                return this.tr('email');
            /* istanbul ignore next -- unreachable: every kind reaching `default` (telegram/whatsapp/x/linkedin/facebook/vk) is keyed in BRAND_LABELS, so the `?? kind` fallback never runs for a valid SiteKitShareKind. */
            default:
                return BRAND_LABELS[kind] ?? kind;
        }
    }
    shareText() {
        return this.cfg.brand.tagline
            ? `${this.cfg.brand.name} — ${this.cfg.brand.tagline}`
            : this.cfg.brand.name;
    }
    resolveLink(link, lang) {
        return resolveLinkHref(link, lang, this.cfg.defaultLang);
    }
    isExternal(url) {
        return /^https?:\/\//i.test(url);
    }
    prettyTelegram(url) {
        const handle = url.replace(/^https?:\/\/(t\.me\/)?/i, '');
        return handle && handle !== url ? `@${handle}` : url;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ContactQr, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: ContactQr, isStandalone: true, selector: "ik-contact-qr", inputs: { showDetails: { classPropertyName: "showDetails", publicName: "showDetails", isSignal: true, isRequired: false, transformFunction: null }, lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, eyebrow: { classPropertyName: "eyebrow", publicName: "eyebrow", isSignal: true, isRequired: false, transformFunction: null }, shareLayout: { classPropertyName: "shareLayout", publicName: "shareLayout", isSignal: true, isRequired: false, transformFunction: null }, shareTheme: { classPropertyName: "shareTheme", publicName: "shareTheme", isSignal: true, isRequired: false, transformFunction: null }, sectionDivider: { classPropertyName: "sectionDivider", publicName: "sectionDivider", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ik-contact-qr" }, providers: [ShareService], ngImport: i0, template: `
        <div class="shell">
            <div class="qr-bg" aria-hidden="true">
                <div class="qr-grid"></div>
                <div class="qr-glow qr-glow-a"></div>
                <div class="qr-glow qr-glow-b"></div>
                <div class="qr-glow qr-glow-c"></div>
            </div>
            <article
                class="card"
                [class.card--div-center]="effDivider() !== 'top'"
                [class.card--div-dashed]="effDivider() === 'center-dashed'"
            >
                <header class="head">
                    <div class="head__brand">
                        @if (brandGlyph(); as g) {
                            <span class="mono mono--glyph" [innerHTML]="g"></span>
                        } @else if (cfg.brand.logoUrl; as logo) {
                            <img class="mono mono--img" [src]="logo" [alt]="cfg.brand.name" />
                        } @else {
                            <span class="mono">{{ monogram() }}</span>
                        }
                        <div class="head__text">
                            @if (!cfg.brand.nameHidden) {
                                <span class="brand-name">{{ cfg.brand.name }}</span>
                            }
                            @if (subtitle(); as sub) {
                                <span class="brand-sub">{{ sub }}</span>
                            }
                        </div>
                    </div>
                    <div class="head__actions">
                        <ng-content select="[slot=actions]" />
                        @if (effEyebrow(); as e) {
                            <span class="eyebrow">{{ e }}</span>
                        }
                    </div>
                </header>

                @if (person(); as p) {
                    <div class="person">
                        @if (p.person) {
                            <span class="person__name">{{ p.person }}</span>
                        }
                        @if (p.role) {
                            <span class="person__role">{{ p.role }}</span>
                        }
                        @if (p.location) {
                            <span class="person__loc">{{ p.location }}</span>
                        }
                    </div>
                }

                @if (lede(); as l) {
                    <p class="lede">{{ l }}</p>
                }

                <figure class="qr-wrap">
                    <!-- Shared QR-frame interior, rendered inside either an <a> (when a target
                         href exists) or a plain <span>. ng-container adds no DOM node. -->
                    <ng-template #qrFrameInner>
                        @if (qrImg(); as img) {
                            <img class="qr" [src]="img" [alt]="alt()" />
                        } @else {
                            <span class="qr" [innerHTML]="qrSvg()"></span>
                        }
                        @if (badge(); as b) {
                            <span class="badge" aria-hidden="true">
                                @if (brandGlyph(); as g) {
                                    <span class="badge__glyph" [innerHTML]="g"></span>
                                } @else {
                                    <span class="badge__text">{{ b.mono }}</span>
                                }
                            </span>
                        }
                        @if (corners() !== 'none') {
                            <span class="corner corner--tl" aria-hidden="true"></span>
                            <span class="corner corner--tr" aria-hidden="true"></span>
                            <span class="corner corner--bl" aria-hidden="true"></span>
                            <span class="corner corner--br" aria-hidden="true"></span>
                        }
                    </ng-template>
                    @if (qrHref(); as href) {
                        <a
                            class="frame"
                            [class.frame--solid]="corners() === 'solid'"
                            [class.frame--dashed]="corners() === 'dashed'"
                            [href]="href"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <ng-container [ngTemplateOutlet]="qrFrameInner" />
                        </a>
                    } @else {
                        <span
                            class="frame"
                            [class.frame--solid]="corners() === 'solid'"
                            [class.frame--dashed]="corners() === 'dashed'"
                        >
                            <ng-container [ngTemplateOutlet]="qrFrameInner" />
                        </span>
                    }
                    @if (scanHint(); as cap) {
                        <figcaption>{{ cap }}</figcaption>
                    }
                </figure>

                @if (showDetails()) {
                    @if (channels().length) {
                        <ul class="links" role="list">
                            @for (ch of channels(); track ch.href) {
                                <a
                                    class="link"
                                    [href]="ch.href"
                                    [attr.target]="ch.external ? '_blank' : null"
                                    [attr.rel]="ch.external ? 'noopener noreferrer' : null"
                                >
                                    @if (ch.icon; as ic) {
                                        <span class="link__icon" [innerHTML]="ic"></span>
                                    }
                                    <span class="link__label">{{ ch.label }}</span>
                                    <span
                                        class="link__arrow"
                                        [innerHTML]="ch.external ? extArrowIcon : arrowIcon"
                                    ></span>
                                </a>
                            }
                        </ul>
                    }

                    @if (shareButtons().length) {
                        <section class="section">
                            <h2 class="section__title">{{ shareTitle() }}</h2>
                            <div
                                class="share"
                                [class.share--inline]="effShareLayout() === 'inline'"
                                [class.share--color]="effShareTheme() === 'color'"
                            >
                                @for (btn of shareButtons(); track btn.kind) {
                                    <button
                                        type="button"
                                        class="chip"
                                        (click)="onShare(btn.kind)"
                                        [class.chip--ok]="btn.kind === 'copy' && copied()"
                                        [style.--chip-accent]="btn.accent"
                                        [attr.aria-label]="btn.label"
                                    >
                                        <span
                                            class="chip__icon"
                                            [innerHTML]="
                                                btn.kind === 'copy' && copied() ? checkIcon : btn.icon
                                            "
                                        ></span>
                                        <span class="chip__label">
                                            @if (btn.kind === 'copy' && copied()) {
                                                {{ copiedLabel() }}
                                            } @else {
                                                {{ btn.label }}
                                            }
                                        </span>
                                    </button>
                                }
                            </div>
                        </section>
                    }

                    @if (quickLinks().length) {
                        <section class="section">
                            <h2 class="section__title">{{ linksTitle() }}</h2>
                            <ul class="links" role="list">
                                @for (ql of quickLinks(); track ql.href) {
                                    <a
                                        class="link"
                                        [href]="ql.href"
                                        [attr.target]="ql.external ? '_blank' : null"
                                        [attr.rel]="ql.external ? 'noopener noreferrer' : null"
                                    >
                                        <span class="link__label">{{ ql.label }}</span>
                                        <span
                                            class="link__arrow"
                                            [innerHTML]="ql.external ? extArrowIcon : arrowIcon"
                                        ></span>
                                    </a>
                                }
                            </ul>
                        </section>
                    }
                }
            </article>
        </div>
    `, isInline: true, styles: [":host{display:block}.shell{position:relative;display:flex;align-items:center;justify-content:center;width:100%;padding:clamp(2.5rem,7vh,5rem) 1rem;overflow:hidden;isolation:isolate}.qr-bg{position:absolute;inset:0;z-index:0;background:linear-gradient(135deg,color-mix(in oklch,var(--brand, #6d28d9) 6%,var(--bg, #09090b)) 0%,var(--bg, #09090b) 50%,color-mix(in oklch,var(--brand-strong, var(--brand, #6d28d9)) 4%,var(--bg, #09090b)) 100%)}.qr-grid{position:absolute;inset:0;background-image:linear-gradient(color-mix(in oklch,var(--brand, #6d28d9) 8%,transparent) 1px,transparent 1px),linear-gradient(90deg,color-mix(in oklch,var(--brand, #6d28d9) 8%,transparent) 1px,transparent 1px);background-size:36px 36px;-webkit-mask-image:radial-gradient(ellipse 80% 70% at 50% 40%,#000 30%,transparent 80%);mask-image:radial-gradient(ellipse 80% 70% at 50% 40%,#000 30%,transparent 80%)}.qr-glow{position:absolute;border-radius:50%;filter:blur(90px);opacity:.55;animation:ik-qr-float 22s ease-in-out infinite}.qr-glow-a{top:-10%;left:-10%;width:380px;height:380px;background:radial-gradient(circle,color-mix(in oklch,var(--brand, #6d28d9) 60%,transparent),transparent 70%)}.qr-glow-b{bottom:-10%;right:-8%;width:420px;height:420px;background:radial-gradient(circle,color-mix(in oklch,var(--brand-strong, var(--brand, #6d28d9)) 35%,transparent),transparent 70%);animation-duration:26s;animation-delay:-8s}.qr-glow-c{top:30%;right:-20%;width:320px;height:320px;background:radial-gradient(circle,color-mix(in oklch,var(--info, #2563eb) 30%,transparent),transparent 70%);animation-duration:30s;animation-delay:-14s}@keyframes ik-qr-float{0%,to{transform:translate(0) scale(1)}33%{transform:translate(30px,-20px) scale(1.05)}66%{transform:translate(-20px,30px) scale(.95)}}.card{position:relative;z-index:1;width:100%;max-width:460px;display:flex;flex-direction:column;gap:1.15rem;padding:1.6rem 1.6rem 1.4rem;background:color-mix(in oklch,var(--bg-elev, #18181b) 88%,transparent);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border:1px solid color-mix(in oklch,var(--brand, #6d28d9) 12%,var(--border, #27272a));border-radius:1.4rem;box-shadow:0 30px 80px -20px color-mix(in oklch,var(--text, #000) 18%,transparent),0 0 0 1px color-mix(in oklch,var(--bg-elev, #18181b) 60%,transparent) inset;text-align:center;animation:ik-cq-rise .6s cubic-bezier(.2,.8,.2,1) both}@keyframes ik-cq-rise{0%{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){.qr-glow,.card{animation:none}}.head{display:flex;align-items:center;justify-content:space-between;gap:.5rem;text-align:left}.head__brand{display:inline-flex;align-items:center;gap:.55rem;min-width:0}.head__actions{display:inline-flex;align-items:center;gap:.25rem;flex-shrink:0}.eyebrow{display:inline-flex;align-items:center;padding:.28rem .65rem;font-size:.58rem;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:var(--brand-strong, var(--brand, #6d28d9));background:color-mix(in oklch,var(--brand, #6d28d9) 16%,transparent);border:1px solid color-mix(in oklch,var(--brand, #6d28d9) 22%,transparent);border-radius:999px;margin-left:.35rem;white-space:nowrap}.mono{display:grid;place-items:center;width:36px;height:36px;flex-shrink:0;border-radius:10px;background:linear-gradient(135deg,color-mix(in oklch,var(--brand, #6d28d9) 22%,transparent),color-mix(in oklch,var(--brand, #6d28d9) 6%,transparent));color:var(--brand, #6d28d9);font-family:var(--font-brand, system-ui, sans-serif);font-size:1.05rem;font-weight:var(--fw-black, 800)}.mono--img{background:transparent;object-fit:contain}.mono--glyph ::ng-deep svg{display:block;width:22px;height:22px}.head__text{display:flex;flex-direction:column;min-width:0}.brand-name{font-family:var(--font-brand, system-ui, sans-serif);font-size:1.05rem;font-weight:600;letter-spacing:-.02em;line-height:1;color:var(--text, #09090f)}.brand-sub{font-size:var(--fs-sm, .875rem);color:var(--text-mute, #5c5c6d)}.person{display:flex;flex-direction:column;gap:2px;padding-bottom:var(--sp-1, .25rem)}.person__name{font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-semi, 600);color:var(--text, #09090f)}.person__role{font-size:var(--fs-sm, .875rem);color:var(--brand, #6d28d9);font-weight:var(--fw-medium, 500)}.person__loc{font-size:var(--fs-sm, .875rem);color:var(--text-dim, #8e8ea0)}.qr-wrap{display:flex;flex-direction:column;align-items:center;gap:.7rem;margin:0}.frame{position:relative;display:flex;align-items:center;justify-content:center;width:var(--ik-qr-size, 280px);height:var(--ik-qr-size, 280px);padding:14px;background:#fff;border-radius:1rem;box-shadow:0 4px 16px color-mix(in oklch,var(--text, #000) 12%,transparent),0 0 0 1px color-mix(in oklch,var(--text, #000) 8%,transparent);line-height:0}.qr{display:block;width:100%;height:100%}.qr img,.frame img.qr{width:100%;height:100%;image-rendering:pixelated}.qr ::ng-deep svg{display:block;width:100%;height:100%}.badge{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:grid;place-items:center;width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,var(--brand, #6d28d9),var(--brand-strong, var(--brand, #6d28d9)));box-shadow:0 0 0 6px #fff,0 6px 18px color-mix(in oklch,var(--brand, #6d28d9) 35%,transparent);overflow:hidden;line-height:1;pointer-events:none}.badge__text{font-family:var(--font-brand, system-ui, sans-serif);font-size:1.4rem;font-weight:var(--fw-black, 800);color:#fff}.badge__img{width:30px;height:30px;object-fit:contain}.badge__glyph{display:inline-flex;align-items:center;justify-content:center;color:#fff}.badge__glyph ::ng-deep svg{display:block;width:28px;height:28px}.corner{position:absolute;width:16px;height:16px;border-color:var(--brand, #6d28d9);border-style:solid;border-width:0;pointer-events:none}.frame--dashed .corner{border-style:dashed}.corner--tl{top:-2px;left:-2px;border-top-width:3px;border-left-width:3px;border-top-left-radius:.9rem}.corner--tr{top:-2px;right:-2px;border-top-width:3px;border-right-width:3px;border-top-right-radius:.9rem}.corner--bl{bottom:-2px;left:-2px;border-bottom-width:3px;border-left-width:3px;border-bottom-left-radius:.9rem}.corner--br{bottom:-2px;right:-2px;border-bottom-width:3px;border-right-width:3px;border-bottom-right-radius:.9rem}figcaption{font-size:.72rem;color:var(--text-dim, #8e8ea0);font-style:italic;line-height:1.5;text-align:center;text-wrap:balance;max-width:36ch;margin-inline:auto}.lede{margin:0 auto;font-size:.9rem;line-height:1.5;color:var(--text-mute, #5c5c6d);text-align:center;text-wrap:balance;max-width:36ch}.section{display:flex;flex-direction:column;gap:.55rem;text-align:left}.section__title{margin:0;padding-top:.8rem;border-top:1px dashed var(--border, #27272a);font-size:.58rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--text-dim, #8e8ea0);text-align:left}.card--div-center .section__title{display:flex;align-items:center;gap:.75rem;padding-top:0;border-top:0;text-align:center;white-space:nowrap}.card--div-center .section__title:before,.card--div-center .section__title:after{content:\"\";flex:1 1 0;min-width:0;border-top:1px solid var(--border, #27272a)}.card--div-dashed .section__title:before,.card--div-dashed .section__title:after{border-top-style:dashed}.card--div-center .section{gap:1.15rem}.links{display:flex;flex-direction:column;gap:.3rem;margin:0;padding:0;list-style:none;text-align:left}.link{display:flex;align-items:center;justify-content:space-between;gap:var(--sp-3, .75rem);padding:.65rem .85rem;border-radius:.55rem;border:1px solid transparent;color:var(--text, #09090f);font-size:.82rem;font-weight:600;text-decoration:none;transition:background var(--dur-base, .22s) var(--ease-out, ease),border-color var(--dur-base, .22s) var(--ease-out, ease),color var(--dur-base, .22s) var(--ease-out, ease)}.link:hover{background:var(--bg-mute, #f0f0f2);border-color:var(--border, #e5e5e9)}.link__icon{display:inline-flex;align-items:center;justify-content:center;width:1.1rem;height:1.1rem;flex-shrink:0;color:var(--brand, #6d28d9)}.link__icon ::ng-deep svg{width:100%;height:100%}.link__label{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.link__arrow{display:inline-flex;width:1rem;height:1rem;flex-shrink:0;color:var(--brand, #6d28d9);transition:color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.link__arrow ::ng-deep svg{width:100%;height:100%}.link:hover .link__arrow{color:var(--brand, #6d28d9);transform:translate(2px)}.share{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--sp-2, .5rem)}.chip{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-width:0;padding:.625rem .375rem;background:var(--bg-elev, #fff);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-md, 12px);color:var(--text, #09090f);font-family:inherit;font-size:var(--fs-xs, .75rem);font-weight:var(--fw-semi, 600);cursor:pointer;overflow:hidden;transition:background var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.chip:hover{background:var(--bg-mute, #f0f0f2);border-color:var(--border-strong, #cdcdd4);transform:translateY(-1px)}.chip:active{transform:translateY(0)}.chip:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.chip__icon{display:inline-flex;align-items:center;justify-content:center;width:1.25rem;height:1.25rem;flex-shrink:0;color:var(--brand, #6d28d9)}.chip__icon ::ng-deep svg{width:100%;height:100%}.chip__label{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.share--inline .chip{flex-direction:row;align-items:center;justify-content:flex-start;gap:.55rem;padding:.65rem .7rem;font-size:.76rem;background:var(--bg-mute, #1c1c20);border-radius:.65rem;text-align:left}.share--inline .chip__icon{width:18px;height:18px;color:var(--text, #09090f)}.share--inline .chip:hover{color:var(--chip-accent, var(--brand, #6d28d9));border-color:color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 45%,transparent);background:color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 8%,var(--bg-elev, #fff));box-shadow:0 4px 12px color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 18%,transparent)}.share--inline .chip:hover .chip__icon,.share--color .chip__icon{color:var(--chip-accent, var(--brand, #6d28d9))}.share--color .chip:hover{border-color:color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 45%,transparent);background:color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 10%,var(--bg-elev, #fff))}.chip--ok,.share--inline .chip--ok{color:var(--success, #16a34a)!important;border-color:color-mix(in oklch,var(--success, #16a34a) 45%,transparent)!important;background:color-mix(in oklch,var(--success, #16a34a) 14%,var(--bg-elev, #18181b))!important}.chip--ok .chip__icon{color:var(--success, #16a34a)!important}@media(prefers-reduced-motion:reduce){.card{animation:none}.link:hover .link__arrow,.chip:hover{transform:none}}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ContactQr, decorators: [{
            type: Component,
            args: [{ selector: 'ik-contact-qr', standalone: true, imports: [NgTemplateOutlet], providers: [ShareService], changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <div class="shell">
            <div class="qr-bg" aria-hidden="true">
                <div class="qr-grid"></div>
                <div class="qr-glow qr-glow-a"></div>
                <div class="qr-glow qr-glow-b"></div>
                <div class="qr-glow qr-glow-c"></div>
            </div>
            <article
                class="card"
                [class.card--div-center]="effDivider() !== 'top'"
                [class.card--div-dashed]="effDivider() === 'center-dashed'"
            >
                <header class="head">
                    <div class="head__brand">
                        @if (brandGlyph(); as g) {
                            <span class="mono mono--glyph" [innerHTML]="g"></span>
                        } @else if (cfg.brand.logoUrl; as logo) {
                            <img class="mono mono--img" [src]="logo" [alt]="cfg.brand.name" />
                        } @else {
                            <span class="mono">{{ monogram() }}</span>
                        }
                        <div class="head__text">
                            @if (!cfg.brand.nameHidden) {
                                <span class="brand-name">{{ cfg.brand.name }}</span>
                            }
                            @if (subtitle(); as sub) {
                                <span class="brand-sub">{{ sub }}</span>
                            }
                        </div>
                    </div>
                    <div class="head__actions">
                        <ng-content select="[slot=actions]" />
                        @if (effEyebrow(); as e) {
                            <span class="eyebrow">{{ e }}</span>
                        }
                    </div>
                </header>

                @if (person(); as p) {
                    <div class="person">
                        @if (p.person) {
                            <span class="person__name">{{ p.person }}</span>
                        }
                        @if (p.role) {
                            <span class="person__role">{{ p.role }}</span>
                        }
                        @if (p.location) {
                            <span class="person__loc">{{ p.location }}</span>
                        }
                    </div>
                }

                @if (lede(); as l) {
                    <p class="lede">{{ l }}</p>
                }

                <figure class="qr-wrap">
                    <!-- Shared QR-frame interior, rendered inside either an <a> (when a target
                         href exists) or a plain <span>. ng-container adds no DOM node. -->
                    <ng-template #qrFrameInner>
                        @if (qrImg(); as img) {
                            <img class="qr" [src]="img" [alt]="alt()" />
                        } @else {
                            <span class="qr" [innerHTML]="qrSvg()"></span>
                        }
                        @if (badge(); as b) {
                            <span class="badge" aria-hidden="true">
                                @if (brandGlyph(); as g) {
                                    <span class="badge__glyph" [innerHTML]="g"></span>
                                } @else {
                                    <span class="badge__text">{{ b.mono }}</span>
                                }
                            </span>
                        }
                        @if (corners() !== 'none') {
                            <span class="corner corner--tl" aria-hidden="true"></span>
                            <span class="corner corner--tr" aria-hidden="true"></span>
                            <span class="corner corner--bl" aria-hidden="true"></span>
                            <span class="corner corner--br" aria-hidden="true"></span>
                        }
                    </ng-template>
                    @if (qrHref(); as href) {
                        <a
                            class="frame"
                            [class.frame--solid]="corners() === 'solid'"
                            [class.frame--dashed]="corners() === 'dashed'"
                            [href]="href"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <ng-container [ngTemplateOutlet]="qrFrameInner" />
                        </a>
                    } @else {
                        <span
                            class="frame"
                            [class.frame--solid]="corners() === 'solid'"
                            [class.frame--dashed]="corners() === 'dashed'"
                        >
                            <ng-container [ngTemplateOutlet]="qrFrameInner" />
                        </span>
                    }
                    @if (scanHint(); as cap) {
                        <figcaption>{{ cap }}</figcaption>
                    }
                </figure>

                @if (showDetails()) {
                    @if (channels().length) {
                        <ul class="links" role="list">
                            @for (ch of channels(); track ch.href) {
                                <a
                                    class="link"
                                    [href]="ch.href"
                                    [attr.target]="ch.external ? '_blank' : null"
                                    [attr.rel]="ch.external ? 'noopener noreferrer' : null"
                                >
                                    @if (ch.icon; as ic) {
                                        <span class="link__icon" [innerHTML]="ic"></span>
                                    }
                                    <span class="link__label">{{ ch.label }}</span>
                                    <span
                                        class="link__arrow"
                                        [innerHTML]="ch.external ? extArrowIcon : arrowIcon"
                                    ></span>
                                </a>
                            }
                        </ul>
                    }

                    @if (shareButtons().length) {
                        <section class="section">
                            <h2 class="section__title">{{ shareTitle() }}</h2>
                            <div
                                class="share"
                                [class.share--inline]="effShareLayout() === 'inline'"
                                [class.share--color]="effShareTheme() === 'color'"
                            >
                                @for (btn of shareButtons(); track btn.kind) {
                                    <button
                                        type="button"
                                        class="chip"
                                        (click)="onShare(btn.kind)"
                                        [class.chip--ok]="btn.kind === 'copy' && copied()"
                                        [style.--chip-accent]="btn.accent"
                                        [attr.aria-label]="btn.label"
                                    >
                                        <span
                                            class="chip__icon"
                                            [innerHTML]="
                                                btn.kind === 'copy' && copied() ? checkIcon : btn.icon
                                            "
                                        ></span>
                                        <span class="chip__label">
                                            @if (btn.kind === 'copy' && copied()) {
                                                {{ copiedLabel() }}
                                            } @else {
                                                {{ btn.label }}
                                            }
                                        </span>
                                    </button>
                                }
                            </div>
                        </section>
                    }

                    @if (quickLinks().length) {
                        <section class="section">
                            <h2 class="section__title">{{ linksTitle() }}</h2>
                            <ul class="links" role="list">
                                @for (ql of quickLinks(); track ql.href) {
                                    <a
                                        class="link"
                                        [href]="ql.href"
                                        [attr.target]="ql.external ? '_blank' : null"
                                        [attr.rel]="ql.external ? 'noopener noreferrer' : null"
                                    >
                                        <span class="link__label">{{ ql.label }}</span>
                                        <span
                                            class="link__arrow"
                                            [innerHTML]="ql.external ? extArrowIcon : arrowIcon"
                                        ></span>
                                    </a>
                                }
                            </ul>
                        </section>
                    }
                }
            </article>
        </div>
    `, host: { class: 'ik-contact-qr' }, styles: [":host{display:block}.shell{position:relative;display:flex;align-items:center;justify-content:center;width:100%;padding:clamp(2.5rem,7vh,5rem) 1rem;overflow:hidden;isolation:isolate}.qr-bg{position:absolute;inset:0;z-index:0;background:linear-gradient(135deg,color-mix(in oklch,var(--brand, #6d28d9) 6%,var(--bg, #09090b)) 0%,var(--bg, #09090b) 50%,color-mix(in oklch,var(--brand-strong, var(--brand, #6d28d9)) 4%,var(--bg, #09090b)) 100%)}.qr-grid{position:absolute;inset:0;background-image:linear-gradient(color-mix(in oklch,var(--brand, #6d28d9) 8%,transparent) 1px,transparent 1px),linear-gradient(90deg,color-mix(in oklch,var(--brand, #6d28d9) 8%,transparent) 1px,transparent 1px);background-size:36px 36px;-webkit-mask-image:radial-gradient(ellipse 80% 70% at 50% 40%,#000 30%,transparent 80%);mask-image:radial-gradient(ellipse 80% 70% at 50% 40%,#000 30%,transparent 80%)}.qr-glow{position:absolute;border-radius:50%;filter:blur(90px);opacity:.55;animation:ik-qr-float 22s ease-in-out infinite}.qr-glow-a{top:-10%;left:-10%;width:380px;height:380px;background:radial-gradient(circle,color-mix(in oklch,var(--brand, #6d28d9) 60%,transparent),transparent 70%)}.qr-glow-b{bottom:-10%;right:-8%;width:420px;height:420px;background:radial-gradient(circle,color-mix(in oklch,var(--brand-strong, var(--brand, #6d28d9)) 35%,transparent),transparent 70%);animation-duration:26s;animation-delay:-8s}.qr-glow-c{top:30%;right:-20%;width:320px;height:320px;background:radial-gradient(circle,color-mix(in oklch,var(--info, #2563eb) 30%,transparent),transparent 70%);animation-duration:30s;animation-delay:-14s}@keyframes ik-qr-float{0%,to{transform:translate(0) scale(1)}33%{transform:translate(30px,-20px) scale(1.05)}66%{transform:translate(-20px,30px) scale(.95)}}.card{position:relative;z-index:1;width:100%;max-width:460px;display:flex;flex-direction:column;gap:1.15rem;padding:1.6rem 1.6rem 1.4rem;background:color-mix(in oklch,var(--bg-elev, #18181b) 88%,transparent);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border:1px solid color-mix(in oklch,var(--brand, #6d28d9) 12%,var(--border, #27272a));border-radius:1.4rem;box-shadow:0 30px 80px -20px color-mix(in oklch,var(--text, #000) 18%,transparent),0 0 0 1px color-mix(in oklch,var(--bg-elev, #18181b) 60%,transparent) inset;text-align:center;animation:ik-cq-rise .6s cubic-bezier(.2,.8,.2,1) both}@keyframes ik-cq-rise{0%{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){.qr-glow,.card{animation:none}}.head{display:flex;align-items:center;justify-content:space-between;gap:.5rem;text-align:left}.head__brand{display:inline-flex;align-items:center;gap:.55rem;min-width:0}.head__actions{display:inline-flex;align-items:center;gap:.25rem;flex-shrink:0}.eyebrow{display:inline-flex;align-items:center;padding:.28rem .65rem;font-size:.58rem;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:var(--brand-strong, var(--brand, #6d28d9));background:color-mix(in oklch,var(--brand, #6d28d9) 16%,transparent);border:1px solid color-mix(in oklch,var(--brand, #6d28d9) 22%,transparent);border-radius:999px;margin-left:.35rem;white-space:nowrap}.mono{display:grid;place-items:center;width:36px;height:36px;flex-shrink:0;border-radius:10px;background:linear-gradient(135deg,color-mix(in oklch,var(--brand, #6d28d9) 22%,transparent),color-mix(in oklch,var(--brand, #6d28d9) 6%,transparent));color:var(--brand, #6d28d9);font-family:var(--font-brand, system-ui, sans-serif);font-size:1.05rem;font-weight:var(--fw-black, 800)}.mono--img{background:transparent;object-fit:contain}.mono--glyph ::ng-deep svg{display:block;width:22px;height:22px}.head__text{display:flex;flex-direction:column;min-width:0}.brand-name{font-family:var(--font-brand, system-ui, sans-serif);font-size:1.05rem;font-weight:600;letter-spacing:-.02em;line-height:1;color:var(--text, #09090f)}.brand-sub{font-size:var(--fs-sm, .875rem);color:var(--text-mute, #5c5c6d)}.person{display:flex;flex-direction:column;gap:2px;padding-bottom:var(--sp-1, .25rem)}.person__name{font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-semi, 600);color:var(--text, #09090f)}.person__role{font-size:var(--fs-sm, .875rem);color:var(--brand, #6d28d9);font-weight:var(--fw-medium, 500)}.person__loc{font-size:var(--fs-sm, .875rem);color:var(--text-dim, #8e8ea0)}.qr-wrap{display:flex;flex-direction:column;align-items:center;gap:.7rem;margin:0}.frame{position:relative;display:flex;align-items:center;justify-content:center;width:var(--ik-qr-size, 280px);height:var(--ik-qr-size, 280px);padding:14px;background:#fff;border-radius:1rem;box-shadow:0 4px 16px color-mix(in oklch,var(--text, #000) 12%,transparent),0 0 0 1px color-mix(in oklch,var(--text, #000) 8%,transparent);line-height:0}.qr{display:block;width:100%;height:100%}.qr img,.frame img.qr{width:100%;height:100%;image-rendering:pixelated}.qr ::ng-deep svg{display:block;width:100%;height:100%}.badge{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:grid;place-items:center;width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,var(--brand, #6d28d9),var(--brand-strong, var(--brand, #6d28d9)));box-shadow:0 0 0 6px #fff,0 6px 18px color-mix(in oklch,var(--brand, #6d28d9) 35%,transparent);overflow:hidden;line-height:1;pointer-events:none}.badge__text{font-family:var(--font-brand, system-ui, sans-serif);font-size:1.4rem;font-weight:var(--fw-black, 800);color:#fff}.badge__img{width:30px;height:30px;object-fit:contain}.badge__glyph{display:inline-flex;align-items:center;justify-content:center;color:#fff}.badge__glyph ::ng-deep svg{display:block;width:28px;height:28px}.corner{position:absolute;width:16px;height:16px;border-color:var(--brand, #6d28d9);border-style:solid;border-width:0;pointer-events:none}.frame--dashed .corner{border-style:dashed}.corner--tl{top:-2px;left:-2px;border-top-width:3px;border-left-width:3px;border-top-left-radius:.9rem}.corner--tr{top:-2px;right:-2px;border-top-width:3px;border-right-width:3px;border-top-right-radius:.9rem}.corner--bl{bottom:-2px;left:-2px;border-bottom-width:3px;border-left-width:3px;border-bottom-left-radius:.9rem}.corner--br{bottom:-2px;right:-2px;border-bottom-width:3px;border-right-width:3px;border-bottom-right-radius:.9rem}figcaption{font-size:.72rem;color:var(--text-dim, #8e8ea0);font-style:italic;line-height:1.5;text-align:center;text-wrap:balance;max-width:36ch;margin-inline:auto}.lede{margin:0 auto;font-size:.9rem;line-height:1.5;color:var(--text-mute, #5c5c6d);text-align:center;text-wrap:balance;max-width:36ch}.section{display:flex;flex-direction:column;gap:.55rem;text-align:left}.section__title{margin:0;padding-top:.8rem;border-top:1px dashed var(--border, #27272a);font-size:.58rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--text-dim, #8e8ea0);text-align:left}.card--div-center .section__title{display:flex;align-items:center;gap:.75rem;padding-top:0;border-top:0;text-align:center;white-space:nowrap}.card--div-center .section__title:before,.card--div-center .section__title:after{content:\"\";flex:1 1 0;min-width:0;border-top:1px solid var(--border, #27272a)}.card--div-dashed .section__title:before,.card--div-dashed .section__title:after{border-top-style:dashed}.card--div-center .section{gap:1.15rem}.links{display:flex;flex-direction:column;gap:.3rem;margin:0;padding:0;list-style:none;text-align:left}.link{display:flex;align-items:center;justify-content:space-between;gap:var(--sp-3, .75rem);padding:.65rem .85rem;border-radius:.55rem;border:1px solid transparent;color:var(--text, #09090f);font-size:.82rem;font-weight:600;text-decoration:none;transition:background var(--dur-base, .22s) var(--ease-out, ease),border-color var(--dur-base, .22s) var(--ease-out, ease),color var(--dur-base, .22s) var(--ease-out, ease)}.link:hover{background:var(--bg-mute, #f0f0f2);border-color:var(--border, #e5e5e9)}.link__icon{display:inline-flex;align-items:center;justify-content:center;width:1.1rem;height:1.1rem;flex-shrink:0;color:var(--brand, #6d28d9)}.link__icon ::ng-deep svg{width:100%;height:100%}.link__label{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.link__arrow{display:inline-flex;width:1rem;height:1rem;flex-shrink:0;color:var(--brand, #6d28d9);transition:color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.link__arrow ::ng-deep svg{width:100%;height:100%}.link:hover .link__arrow{color:var(--brand, #6d28d9);transform:translate(2px)}.share{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--sp-2, .5rem)}.chip{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-width:0;padding:.625rem .375rem;background:var(--bg-elev, #fff);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-md, 12px);color:var(--text, #09090f);font-family:inherit;font-size:var(--fs-xs, .75rem);font-weight:var(--fw-semi, 600);cursor:pointer;overflow:hidden;transition:background var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.chip:hover{background:var(--bg-mute, #f0f0f2);border-color:var(--border-strong, #cdcdd4);transform:translateY(-1px)}.chip:active{transform:translateY(0)}.chip:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.chip__icon{display:inline-flex;align-items:center;justify-content:center;width:1.25rem;height:1.25rem;flex-shrink:0;color:var(--brand, #6d28d9)}.chip__icon ::ng-deep svg{width:100%;height:100%}.chip__label{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.share--inline .chip{flex-direction:row;align-items:center;justify-content:flex-start;gap:.55rem;padding:.65rem .7rem;font-size:.76rem;background:var(--bg-mute, #1c1c20);border-radius:.65rem;text-align:left}.share--inline .chip__icon{width:18px;height:18px;color:var(--text, #09090f)}.share--inline .chip:hover{color:var(--chip-accent, var(--brand, #6d28d9));border-color:color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 45%,transparent);background:color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 8%,var(--bg-elev, #fff));box-shadow:0 4px 12px color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 18%,transparent)}.share--inline .chip:hover .chip__icon,.share--color .chip__icon{color:var(--chip-accent, var(--brand, #6d28d9))}.share--color .chip:hover{border-color:color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 45%,transparent);background:color-mix(in oklch,var(--chip-accent, var(--brand, #6d28d9)) 10%,var(--bg-elev, #fff))}.chip--ok,.share--inline .chip--ok{color:var(--success, #16a34a)!important;border-color:color-mix(in oklch,var(--success, #16a34a) 45%,transparent)!important;background:color-mix(in oklch,var(--success, #16a34a) 14%,var(--bg-elev, #18181b))!important}.chip--ok .chip__icon{color:var(--success, #16a34a)!important}@media(prefers-reduced-motion:reduce){.card{animation:none}.link:hover .link__arrow,.chip:hover{transform:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { showDetails: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDetails", required: false }] }], lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], eyebrow: [{ type: i0.Input, args: [{ isSignal: true, alias: "eyebrow", required: false }] }], shareLayout: [{ type: i0.Input, args: [{ isSignal: true, alias: "shareLayout", required: false }] }], shareTheme: [{ type: i0.Input, args: [{ isSignal: true, alias: "shareTheme", required: false }] }], sectionDivider: [{ type: i0.Input, args: [{ isSignal: true, alias: "sectionDivider", required: false }] }] } });

/**
 * Built-in, library-authored inline SVGs (constant strings, currentColor).
 * Brand marks use single-path icons; generic channels use simple geometric glyphs.
 * These are trusted constants — safe to render as innerHTML. User-supplied
 * `kind: 'custom'` icons are NOT rendered here (they go through an <img src>).
 */
const SOCIAL_ICONS = {
    telegram: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.94 4.4 18.7 19.7c-.24 1.08-.88 1.34-1.78.84l-4.92-3.63-2.37 2.28c-.26.26-.48.48-.99.48l.35-5.02 9.13-8.25c.4-.35-.09-.55-.62-.2L4.2 13.13l-4.86-1.52C-.7 11.3-.72 10.55.86 9.93L20.27 2.4c.88-.33 1.65.2 1.67 2Z" transform="translate(1.2 0)"/></svg>`,
    whatsapp: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.47 14.38c-.3-.15-1.74-.86-2-.95-.27-.1-.46-.15-.65.15-.2.3-.75.95-.92 1.14-.17.2-.34.22-.63.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.05-.17-.3-.02-.46.13-.6.13-.14.3-.34.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.65-1.57-.9-2.15-.24-.57-.48-.5-.65-.5h-.56c-.2 0-.52.07-.8.37s-1.05 1.02-1.05 2.5 1.07 2.9 1.22 3.1c.15.2 2.11 3.23 5.12 4.53.72.3 1.27.49 1.7.63.72.23 1.37.2 1.88.12.58-.08 1.74-.71 1.98-1.4.25-.68.25-1.27.18-1.4-.07-.12-.27-.2-.56-.34Z M12.04 2C6.58 2 2.13 6.45 2.13 11.9c0 1.75.46 3.45 1.32 4.95L2 22l5.3-1.39a9.86 9.86 0 0 0 4.73 1.2h.01c5.46 0 9.9-4.45 9.9-9.9C21.94 6.45 17.5 2 12.04 2Zm0 18.06h-.01a8.2 8.2 0 0 1-4.18-1.15l-.3-.18-3.1.82.82-3.03-.2-.31a8.18 8.18 0 0 1-1.26-4.37c0-4.53 3.7-8.22 8.24-8.22 2.2 0 4.27.86 5.82 2.42a8.17 8.17 0 0 1 2.41 5.81c0 4.54-3.69 8.23-8.23 8.23Z"/></svg>`,
    email: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 6 10-6"/></svg>`,
    phone: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"/></svg>`,
    github: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.58 2 12.25c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22.68-.49v-1.7c-2.78.62-3.37-1.37-3.37-1.37-.45-1.18-1.1-1.5-1.1-1.5-.91-.63.07-.62.07-.62 1 .07 1.53 1.06 1.53 1.06.9 1.57 2.34 1.12 2.91.85.09-.66.35-1.12.63-1.38-2.22-.26-4.56-1.14-4.56-5.07 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.3.1-2.7 0 0 .84-.28 2.75 1.05a9.3 9.3 0 0 1 5 0c1.91-1.33 2.75-1.05 2.75-1.05.55 1.4.2 2.44.1 2.7.64.72 1.03 1.63 1.03 2.75 0 3.94-2.34 4.8-4.57 5.06.36.32.68.94.68 1.9v2.82c0 .27.18.6.69.49A10.26 10.26 0 0 0 22 12.25C22 6.58 17.52 2 12 2Z"/></svg>`,
    linkedin: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.13 1.45-2.13 2.94v5.67H9.35V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28ZM5.34 7.43a2.06 2.06 0 1 1 0-4.13 2.06 2.06 0 0 1 0 4.13ZM7.12 20.45H3.55V9h3.57v11.45ZM22.22 0H1.77C.8 0 0 .78 0 1.74v20.5C0 23.22.8 24 1.77 24h20.45c.98 0 1.78-.78 1.78-1.76V1.74C24 .78 23.2 0 22.22 0Z"/></svg>`,
    x: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.24 2.25h3.31l-7.23 8.26L22.13 21.75h-6.66l-5.22-6.82-5.97 6.82H.96l7.73-8.84L1.65 2.25h6.83l4.72 6.24 5.04-6.24Zm-1.16 17.52h1.83L7.01 4.13H5.04l12.04 15.64Z"/></svg>`,
    instagram: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1.2" fill="currentColor" stroke="none"/></svg>`,
    youtube: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.5 6.2a3 3 0 0 0-2.12-2.12C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.53A3 3 0 0 0 .5 6.2 31.4 31.4 0 0 0 0 12a31.4 31.4 0 0 0 .5 5.8 3 3 0 0 0 2.12 2.12c1.88.53 9.38.53 9.38.53s7.5 0 9.38-.53a3 3 0 0 0 2.12-2.12A31.4 31.4 0 0 0 24 12a31.4 31.4 0 0 0-.5-5.8ZM9.6 15.6V8.4l6.2 3.6-6.2 3.6Z"/></svg>`,
    website: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10Z"/></svg>`,
};
/** Default accessible labels per channel, in Russian (see SOCIAL_LABELS_BY_LANG). */
const SOCIAL_LABELS = {
    telegram: 'Telegram',
    whatsapp: 'WhatsApp',
    email: 'Email',
    phone: 'Телефон',
    github: 'GitHub',
    linkedin: 'LinkedIn',
    x: 'X',
    instagram: 'Instagram',
    youtube: 'YouTube',
    website: 'Сайт',
    custom: 'Ссылка',
};
/** The default labels in English — for every language but Russian. A plain literal, not a spread of
 *  SOCIAL_LABELS: a top-level spread is code that runs on import and keeps both tables in every app. */
const SOCIAL_LABELS_EN = {
    telegram: 'Telegram',
    whatsapp: 'WhatsApp',
    email: 'Email',
    phone: 'Phone',
    github: 'GitHub',
    linkedin: 'LinkedIn',
    x: 'X',
    instagram: 'Instagram',
    youtube: 'YouTube',
    website: 'Website',
    custom: 'Link',
};
/** The default accessible label of a channel in a language: Russian for `ru`, else English. */
function socialLabel(kind, lang) {
    return (lang === 'ru' ? SOCIAL_LABELS : SOCIAL_LABELS_EN)[kind];
}

/**
 * Row of social / contact channels, driven by `config.social`.
 *
 * Known kinds render a built-in icon; `kind: 'custom'` renders the `icon`
 * URL via <img>. External links get `rel="noopener noreferrer"`.
 *
 * ```html
 * <ik-social-links />
 * <ik-social-links size="lg" />
 * ```
 */
class SocialLinks {
    cfg = inject(SITE_KIT_CONFIG);
    sanitizer = inject(DomSanitizer);
    /** Visual size hint, reflected to a host attribute for CSS. */
    size = input('md', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Active language for locale-aware hrefs (localize / pathByLang / urls). */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    links = computed(() => {
        const lang = this.lang() ?? this.cfg.defaultLang;
        return this.cfg.social.map((link) => {
            const label = localizeText(link.label, lang, this.cfg.defaultLang) ?? socialLabel(link.kind, lang);
            const href = resolveLinkHref(link, lang, this.cfg.defaultLang);
            if (link.kind === 'custom') {
                return { link, label, href, svg: null, imgUrl: link.icon ?? null };
            }
            const raw = SOCIAL_ICONS[link.kind];
            return { link, label, href, svg: this.sanitizer.bypassSecurityTrustHtml(raw), imgUrl: null };
        });
    }, ...(ngDevMode ? [{ debugName: "links" }] : /* istanbul ignore next */ []));
    isExternal(url) {
        return /^https?:\/\//i.test(url);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: SocialLinks, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: SocialLinks, isStandalone: true, selector: "ik-social-links", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.size": "size()" }, classAttribute: "ik-social-links" }, ngImport: i0, template: `
        @if (links().length) {
            <ul class="row">
                @for (item of links(); track item.link.url) {
                    <li>
                        <a
                            [href]="item.href"
                            [attr.aria-label]="item.label"
                            [attr.title]="item.label"
                            [attr.target]="isExternal(item.href) ? '_blank' : null"
                            [attr.rel]="isExternal(item.href) ? 'noopener noreferrer' : null"
                        >
                            @if (item.svg) {
                                <span class="icon" [innerHTML]="item.svg"></span>
                            } @else if (item.imgUrl) {
                                <img class="icon" [src]="item.imgUrl" [alt]="item.label" />
                            } @else {
                                <span class="fallback">{{ item.label }}</span>
                            }
                        </a>
                    </li>
                }
            </ul>
        }
    `, isInline: true, styles: [":host{display:block}.row{display:inline-flex;flex-wrap:wrap;gap:var(--sp-2, .5rem);list-style:none;margin:0;padding:0}a{display:inline-grid;place-items:center;width:var(--ik-social-size, 2.5rem);height:var(--ik-social-size, 2.5rem);border-radius:var(--r-md, 12px);border:1px solid var(--border, #e5e5e9);background:var(--bg-elev, #fff);color:var(--text-mute, #5c5c6d);transition:color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}a:hover{color:var(--brand, #6d28d9);border-color:var(--border-strong, #cdcdd4);transform:translateY(-2px)}a:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.icon{display:block;width:55%;height:55%}.icon ::ng-deep svg,.icon img{display:block;width:100%;height:100%}.fallback{font-size:var(--fs-xs, .75rem);padding-inline:var(--sp-2, .5rem)}:host([size=\"lg\"]) a{--ik-social-size: 3rem}:host([size=\"sm\"]) a{--ik-social-size: 2rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: SocialLinks, decorators: [{
            type: Component,
            args: [{ selector: 'ik-social-links', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        @if (links().length) {
            <ul class="row">
                @for (item of links(); track item.link.url) {
                    <li>
                        <a
                            [href]="item.href"
                            [attr.aria-label]="item.label"
                            [attr.title]="item.label"
                            [attr.target]="isExternal(item.href) ? '_blank' : null"
                            [attr.rel]="isExternal(item.href) ? 'noopener noreferrer' : null"
                        >
                            @if (item.svg) {
                                <span class="icon" [innerHTML]="item.svg"></span>
                            } @else if (item.imgUrl) {
                                <img class="icon" [src]="item.imgUrl" [alt]="item.label" />
                            } @else {
                                <span class="fallback">{{ item.label }}</span>
                            }
                        </a>
                    </li>
                }
            </ul>
        }
    `, host: { class: 'ik-social-links', '[attr.size]': 'size()' }, styles: [":host{display:block}.row{display:inline-flex;flex-wrap:wrap;gap:var(--sp-2, .5rem);list-style:none;margin:0;padding:0}a{display:inline-grid;place-items:center;width:var(--ik-social-size, 2.5rem);height:var(--ik-social-size, 2.5rem);border-radius:var(--r-md, 12px);border:1px solid var(--border, #e5e5e9);background:var(--bg-elev, #fff);color:var(--text-mute, #5c5c6d);transition:color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}a:hover{color:var(--brand, #6d28d9);border-color:var(--border-strong, #cdcdd4);transform:translateY(-2px)}a:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}.icon{display:block;width:55%;height:55%}.icon ::ng-deep svg,.icon img{display:block;width:100%;height:100%}.fallback{font-size:var(--fs-xs, .75rem);padding-inline:var(--sp-2, .5rem)}:host([size=\"lg\"]) a{--ik-social-size: 3rem}:host([size=\"sm\"]) a{--ik-social-size: 2rem}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }] } });

/**
 * Shared "close" affordance — ONE definition for every dismiss control in the kit
 * (mobile-menu close, cookie-policy panel ×, …). A bordered round chip with the ×
 * glyph; the consumer supplies the localized label and listens for `closed`.
 *
 * ```html
 * <ik-close [label]="t('close')" (closed)="dismiss()" />
 * ```
 */
class IkClose {
    /** Accessible label (localized by the consumer). */
    label = input('Close', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Focus the button once rendered — for dialogs/panels that open on demand. */
    autoFocus = input(false, ...(ngDevMode ? [{ debugName: "autoFocus" }] : /* istanbul ignore next */ []));
    /** Fired on click. */
    closed = output();
    btn = viewChild.required('btn');
    ngAfterViewInit() {
        if (this.autoFocus())
            this.btn().nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: IkClose, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.15", type: IkClose, isStandalone: true, selector: "ik-close", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, autoFocus: { classPropertyName: "autoFocus", publicName: "autoFocus", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closed: "closed" }, host: { classAttribute: "ik-close" }, viewQueries: [{ propertyName: "btn", first: true, predicate: ["btn"], descendants: true, isSignal: true }], ngImport: i0, template: `
        <button
            #btn
            type="button"
            class="ik-close__btn"
            [attr.aria-label]="label()"
            [attr.title]="label()"
            (click)="closed.emit($event)"
        >
            <svg
                viewBox="0 0 24 24"
                width="22"
                height="22"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                aria-hidden="true"
            >
                <path d="M6 6l12 12M18 6L6 18" />
            </svg>
        </button>
    `, isInline: true, styles: [":host{display:inline-flex}.ik-close__btn{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;padding:0;border-radius:var(--r-full, 999px);color:var(--text-mute, #5c5c6d);background:transparent;border:1px solid var(--border, #e5e5e9);cursor:pointer;font:inherit;transition:color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease)}.ik-close__btn:hover{color:var(--text, #09090f);border-color:var(--border-strong, #cdcdd4);background:color-mix(in oklab,currentColor 12%,transparent)}.ik-close__btn:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: IkClose, decorators: [{
            type: Component,
            args: [{ selector: 'ik-close', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <button
            #btn
            type="button"
            class="ik-close__btn"
            [attr.aria-label]="label()"
            [attr.title]="label()"
            (click)="closed.emit($event)"
        >
            <svg
                viewBox="0 0 24 24"
                width="22"
                height="22"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                aria-hidden="true"
            >
                <path d="M6 6l12 12M18 6L6 18" />
            </svg>
        </button>
    `, host: { class: 'ik-close' }, styles: [":host{display:inline-flex}.ik-close__btn{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;padding:0;border-radius:var(--r-full, 999px);color:var(--text-mute, #5c5c6d);background:transparent;border:1px solid var(--border, #e5e5e9);cursor:pointer;font:inherit;transition:color var(--dur-fast, .15s) var(--ease-out, ease),border-color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease)}.ik-close__btn:hover{color:var(--text, #09090f);border-color:var(--border-strong, #cdcdd4);background:color-mix(in oklab,currentColor 12%,transparent)}.ik-close__btn:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], autoFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoFocus", required: false }] }], closed: [{ type: i0.Output, args: ["closed"] }], btn: [{ type: i0.ViewChild, args: ['btn', { isSignal: true }] }] } });

var closeButton = /*#__PURE__*/Object.freeze({
    __proto__: null,
    IkClose: IkClose
});

const STORAGE_KEY = 'ik-cookie-consent';
/**
 * Cookie / privacy consent banner — ANGULAR-ONLY. GDPR-minded: symmetric Accept /
 * Reject, a close (×) that means "essential only" (= reject), an optional auto-close
 * timer (also = reject — never an implicit accept), a "learn more" button that opens the
 * FULL localized cookie policy in an in-app panel (no external link), and Escape-to-dismiss.
 * Remembers the choice in localStorage; `reopen()` re-shows it. Texts/policy come from
 * `config.cookie` (or inputs), else the built-in localized copy.
 *
 * ```html
 * <ik-cookie-consent [lang]="translate.currentLang" (consentChange)="onConsent($event)" />
 * ```
 */
class CookieConsent {
    doc = inject(DOCUMENT);
    cfg = inject(SITE_KIT_CONFIG, { optional: true });
    timerId;
    /** Active language (for built-in text). Defaults to the config's default language. */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Optional explicit overrides; when omitted, `config.cookie` then built-in localized text is used. */
    messageText = input(...(ngDevMode ? [undefined, { debugName: "messageText" }] : /* istanbul ignore next */ []));
    acceptText = input(...(ngDevMode ? [undefined, { debugName: "acceptText" }] : /* istanbul ignore next */ []));
    rejectText = input(...(ngDevMode ? [undefined, { debugName: "rejectText" }] : /* istanbul ignore next */ []));
    moreText = input(...(ngDevMode ? [undefined, { debugName: "moreText" }] : /* istanbul ignore next */ []));
    /** Policy-panel body override; else `config.cookie.policyBody`, else the built-in localized full policy. Blank lines = paragraphs. */
    policyBodyText = input(...(ngDevMode ? [undefined, { debugName: "policyBodyText" }] : /* istanbul ignore next */ []));
    /** Direct full-policy URL override; else `config.cookie.policyHref` resolved for the active language. */
    policyHref = input(...(ngDevMode ? [undefined, { debugName: "policyHref" }] : /* istanbul ignore next */ []));
    /** Placement override; else `config.cookie.position`, else `bottom`. */
    placement = input(...(ngDevMode ? [undefined, { debugName: "placement" }] : /* istanbul ignore next */ []));
    /** Auto-dismiss (as REJECT) after N ms; else `config.cookie.autoCloseMs`. 0 = off. */
    autoClose = input(...(ngDevMode ? [undefined, { debugName: "autoClose" }] : /* istanbul ignore next */ []));
    /** Emits once the user makes (or has made) a choice. */
    consentChange = output();
    effLang = computed(() => this.lang() ?? this.cfg?.defaultLang, ...(ngDevMode ? [{ debugName: "effLang" }] : /* istanbul ignore next */ []));
    cc = computed(() => this.cfg?.cookie ?? {}, ...(ngDevMode ? [{ debugName: "cc" }] : /* istanbul ignore next */ []));
    def = computed(() => this.cfg?.defaultLang, ...(ngDevMode ? [{ debugName: "def" }] : /* istanbul ignore next */ []));
    msg = computed(() => this.messageText() ??
        localizeText(this.cc().message, this.effLang(), this.def()) ??
        cookieString(this.effLang(), 'cookieText', this.cfg?.strings), ...(ngDevMode ? [{ debugName: "msg" }] : /* istanbul ignore next */ []));
    accept = computed(() => this.acceptText() ??
        localizeText(this.cc().accept, this.effLang(), this.def()) ??
        cookieString(this.effLang(), 'cookieAccept', this.cfg?.strings), ...(ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []));
    reject = computed(() => this.rejectText() ??
        localizeText(this.cc().reject, this.effLang(), this.def()) ??
        cookieString(this.effLang(), 'cookieReject', this.cfg?.strings), ...(ngDevMode ? [{ debugName: "reject" }] : /* istanbul ignore next */ []));
    more = computed(() => this.moreText() ??
        localizeText(this.cc().more, this.effLang(), this.def()) ??
        cookieString(this.effLang(), 'cookieMore', this.cfg?.strings), ...(ngDevMode ? [{ debugName: "more" }] : /* istanbul ignore next */ []));
    barLabel = computed(() => cookieString(this.effLang(), 'cookieLabel', this.cfg?.strings), ...(ngDevMode ? [{ debugName: "barLabel" }] : /* istanbul ignore next */ []));
    position = computed(() => this.placement() ?? this.cc().position ?? 'bottom', ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    // "Learn more" policy panel: localized title + the full policy split into paragraphs.
    policyTitle = computed(() => cookieString(this.effLang(), 'cookiePolicyTitle', this.cfg?.strings), ...(ngDevMode ? [{ debugName: "policyTitle" }] : /* istanbul ignore next */ []));
    dismissLabel = computed(() => chromeString(this.effLang(), 'close', this.cfg?.strings), ...(ngDevMode ? [{ debugName: "dismissLabel" }] : /* istanbul ignore next */ []));
    fullPolicy = computed(() => cookieString(this.effLang(), 'cookieFullPolicy', this.cfg?.strings), ...(ngDevMode ? [{ debugName: "fullPolicy" }] : /* istanbul ignore next */ []));
    /** Optional link to the official full policy — resolved for the active language (input → config). */
    policy = computed(() => {
        if (this.policyHref())
            return this.policyHref();
        const h = this.cc().policyHref;
        // effLang() is always defined here (a policyHref implies a provided config with defaultLang).
        return h ? resolveLinkHref(h, this.effLang(), this.def()) : undefined;
    }, ...(ngDevMode ? [{ debugName: "policy" }] : /* istanbul ignore next */ []));
    policyParas = computed(() => {
        const body = this.policyBodyText() ??
            localizeText(this.cc().policyBody, this.effLang(), this.def()) ??
            cookieString(this.effLang(), 'cookiePolicyBody', this.cfg?.strings);
        return body
            .split(/\n\s*\n/)
            .map((s) => s.trim())
            .filter(Boolean);
    }, ...(ngDevMode ? [{ debugName: "policyParas" }] : /* istanbul ignore next */ []));
    /** Effective auto-close delay (ms): input → config → 0 (off). Drives the countdown bar. */
    timerMs = computed(() => this.autoClose() ?? this.cc().autoCloseMs ?? 0, ...(ngDevMode ? [{ debugName: "timerMs" }] : /* istanbul ignore next */ []));
    visible = signal(false, ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    policyOpen = signal(false, ...(ngDevMode ? [{ debugName: "policyOpen" }] : /* istanbul ignore next */ []));
    counting = signal(false, ...(ngDevMode ? [{ debugName: "counting" }] : /* istanbul ignore next */ []));
    /** Re-open requested from elsewhere (e.g. the footer's "Cookie settings" link, which
     *  dispatches a document `ik:cookie-settings` event) — re-show the banner with no host wiring. */
    onReopenRequest = () => this.reopen();
    // Runs after the parent wired (consentChange), so the restored value is delivered.
    ngOnInit() {
        const stored = this.safeRead();
        if (stored === 'accepted' || stored === 'rejected') {
            this.consentChange.emit(stored);
        }
        else {
            this.visible.set(true);
            this.armTimer();
        }
        // Guarded like the rest of this file's DOM access (no-op under SSR / no DOM).
        if (this.doc.defaultView)
            this.doc.addEventListener('ik:cookie-settings', this.onReopenRequest);
    }
    ngOnDestroy() {
        this.clearTimer();
        this.doc.removeEventListener('ik:cookie-settings', this.onReopenRequest);
    }
    /** Re-show the banner so the user can change their choice (e.g. a "Cookie settings" link). */
    reopen() {
        this.visible.set(true);
        this.armTimer();
    }
    /** Open the localized "learn more" policy panel; pauses the auto-close timer while reading. */
    openPolicy() {
        this.clearTimer();
        this.policyOpen.set(true);
    }
    /** Close the policy panel (the banner stays as it was). */
    closePolicy() {
        this.policyOpen.set(false);
    }
    decide(choice) {
        this.clearTimer();
        this.safeStore(choice);
        this.visible.set(false);
        this.consentChange.emit(choice);
    }
    /** Auto-dismiss as REJECT after the configured delay (never an implicit accept). */
    armTimer() {
        const ms = this.timerMs();
        const win = this.doc.defaultView;
        this.clearTimer();
        if (ms > 0 && win) {
            this.counting.set(true); // start the countdown bar on the reject button
            this.timerId = win.setTimeout(() => this.decide('rejected'), ms);
        }
    }
    clearTimer() {
        this.counting.set(false);
        if (this.timerId !== undefined) {
            this.doc.defaultView?.clearTimeout(this.timerId);
            this.timerId = undefined;
        }
    }
    safeRead() {
        try {
            /* istanbul ignore next -- no-DOM guard: defaultView/localStorage are always present in a browser; the missing-key (`?? null`) and throwing (catch) paths are tested. */
            return this.doc.defaultView?.localStorage?.getItem(STORAGE_KEY) ?? null;
        }
        catch {
            return null;
        }
    }
    safeStore(choice) {
        /* istanbul ignore next -- no-DOM guard: localStorage is always present in a browser; the throwing (catch) path is tested. */
        try {
            this.doc.defaultView?.localStorage?.setItem(STORAGE_KEY, choice);
        }
        catch {
            /* storage unavailable — banner just reappears next visit */
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: CookieConsent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: CookieConsent, isStandalone: true, selector: "ik-cookie-consent", inputs: { lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, messageText: { classPropertyName: "messageText", publicName: "messageText", isSignal: true, isRequired: false, transformFunction: null }, acceptText: { classPropertyName: "acceptText", publicName: "acceptText", isSignal: true, isRequired: false, transformFunction: null }, rejectText: { classPropertyName: "rejectText", publicName: "rejectText", isSignal: true, isRequired: false, transformFunction: null }, moreText: { classPropertyName: "moreText", publicName: "moreText", isSignal: true, isRequired: false, transformFunction: null }, policyBodyText: { classPropertyName: "policyBodyText", publicName: "policyBodyText", isSignal: true, isRequired: false, transformFunction: null }, policyHref: { classPropertyName: "policyHref", publicName: "policyHref", isSignal: true, isRequired: false, transformFunction: null }, placement: { classPropertyName: "placement", publicName: "placement", isSignal: true, isRequired: false, transformFunction: null }, autoClose: { classPropertyName: "autoClose", publicName: "autoClose", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { consentChange: "consentChange" }, host: { classAttribute: "ik-cookie-consent" }, ngImport: i0, template: `
        @if (visible()) {
            <div
                class="bar"
                [class.bar--corner]="position() === 'corner'"
                role="dialog"
                aria-modal="false"
                [attr.aria-label]="barLabel()"
                (keydown.escape)="decide('rejected')"
            >
                <p class="text">
                    {{ msg() }}
                    <button type="button" class="policy" (click)="openPolicy()">{{ more() }}</button>
                </p>
                <div class="actions">
                    <button type="button" class="ghost" (click)="decide('rejected')">
                        @if (counting()) {
                            <ik-countdown [durationMs]="timerMs()" />
                        }
                        <span class="cc-ghost-label">{{ reject() }}</span>
                    </button>
                    <button type="button" class="solid" (click)="decide('accepted')">{{ accept() }}</button>
                </div>
            </div>
        }
        @if (policyOpen()) {
            <!-- Modal: Esc closes; focus is auto-placed on the close button (autoFocus). -->
            <!-- eslint-disable-next-line @angular-eslint/template/interactive-supports-focus -->
            <div class="ik-cc-modal" (keydown.escape)="closePolicy()">
                <!-- Backdrop scrim: click-to-dismiss; keyboard users use Esc or the close button. -->
                <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
                <div class="ik-cc-modal__scrim" (click)="closePolicy()"></div>
                <div
                    class="ik-cc-modal__sheet"
                    role="dialog"
                    aria-modal="true"
                    [attr.aria-label]="policyTitle()"
                >
                    <header class="ik-cc-modal__head">
                        <h2 class="ik-cc-modal__title">{{ policyTitle() }}</h2>
                        <ik-close
                            class="ik-cc-modal__x"
                            [label]="dismissLabel()"
                            [autoFocus]="true"
                            (closed)="closePolicy()"
                        />
                    </header>
                    <div class="ik-cc-modal__body">
                        @for (para of policyParas(); track $index) {
                            <p>{{ para }}</p>
                        }
                        @if (policy(); as href) {
                            <a
                                class="ik-cc-modal__full"
                                [href]="href"
                                target="_blank"
                                rel="noopener noreferrer"
                                >{{ fullPolicy() }} ↗</a
                            >
                        }
                    </div>
                </div>
            </div>
        }
    `, isInline: true, styles: [".bar{position:fixed;left:50%;transform:translate(-50%);bottom:var(--sp-4, 1rem);z-index:var(--z-toast, 3000);width:min(var(--container-narrow, 42rem),calc(100vw - 2 * var(--sp-4, 1rem)));display:flex;flex-wrap:wrap;align-items:center;gap:var(--sp-3, .75rem) var(--sp-4, 1rem);padding:var(--sp-4, 1rem) var(--sp-5, 1.25rem);background:var(--bg-elev, #fff);color:var(--text, #09090f);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);box-shadow:var(--shadow-lg, 0 20px 48px rgba(0, 0, 0, .18));font-size:var(--fs-sm, .875rem);animation:ik-cc-in var(--dur-base, .25s) var(--ease-out, ease)}.bar--corner{left:var(--sp-4, 1rem);transform:none;width:min(24rem,calc(100vw - 2 * var(--sp-4, 1rem)))}@keyframes ik-cc-in{0%{opacity:0;transform:translate(-50%,12px)}}.bar--corner{animation:ik-cc-in-c var(--dur-base, .25s) var(--ease-out, ease)}@keyframes ik-cc-in-c{0%{opacity:0;transform:translateY(12px)}}.text{flex:1 1 16rem;line-height:var(--lh-base, 1.6);color:var(--text-mute, #5c5c6d);margin:0}.policy{padding:0;color:var(--brand, #6d28d9);text-decoration:underline;text-underline-offset:.18em;white-space:nowrap}.policy:hover{color:var(--brand-strong, #5b21b6)}.policy:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3));border-radius:4px}.actions{display:inline-flex;gap:var(--sp-2, .5rem);margin-left:auto;flex-shrink:0}button{font:inherit;cursor:pointer;border:0;background:transparent}.ghost,.solid{min-height:44px;padding:var(--sp-2, .5rem) var(--sp-4, 1rem);border-radius:var(--r-full, 999px);font-weight:var(--fw-semi, 600);transition:background var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease)}.ghost{position:relative;overflow:hidden;border:1px solid var(--border-strong, #cdcdd4);color:var(--text-mute, #5c5c6d);--ik-countdown-fill: color-mix(in srgb, var(--brand, #6d28d9) 24%, transparent)}.cc-ghost-label{position:relative;z-index:1}.ghost:hover{color:var(--text, #09090f);background:var(--bg-mute, #f0f0f2)}.solid{background:var(--brand, #6d28d9);color:var(--text-on-brand, #fff);box-shadow:var(--shadow-sm, 0 2px 8px rgba(0, 0, 0, .06))}.solid:hover{background:var(--brand-strong, #5b21b6)}button:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}@media(max-width:40rem){.bar,.bar--corner{left:var(--sp-2, .5rem);right:var(--sp-2, .5rem);transform:none;width:auto;bottom:var(--sp-2, .5rem);padding:var(--sp-4, 1rem);flex-direction:column;align-items:stretch;gap:var(--sp-3, .75rem)}.text{flex:0 0 auto}.actions{width:100%;margin-left:0}.ghost,.solid{flex:1 1 0;min-height:48px}}@media(max-width:22rem){.actions{flex-direction:column}}@media(prefers-reduced-motion:reduce){.bar,.bar--corner{animation:none}}.ik-cc-modal{position:fixed;inset:0;z-index:calc(var(--z-toast, 3000) + 10);display:flex;align-items:center;justify-content:center;padding:var(--sp-4, 1rem)}.ik-cc-modal__scrim{position:absolute;inset:0;background:#09090f8c;-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px);animation:ik-cc-fade var(--dur-base, .25s) var(--ease-out, ease)}.ik-cc-modal__sheet{position:relative;z-index:1;display:flex;flex-direction:column;width:min(40rem,100%);max-height:min(85vh,100%);background:var(--bg-elev, #fff);color:var(--text, #09090f);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);box-shadow:var(--shadow-lg, 0 20px 48px rgba(0, 0, 0, .18));overflow:hidden;animation:ik-cc-pop var(--dur-base, .25s) var(--ease-out, ease)}@keyframes ik-cc-fade{0%{opacity:0}}@keyframes ik-cc-pop{0%{opacity:0;transform:translateY(8px) scale(.98)}}.ik-cc-modal__head{display:flex;align-items:flex-start;gap:var(--sp-3, .75rem);padding:var(--sp-5, 1.25rem) var(--sp-5, 1.25rem) var(--sp-4, 1rem);border-bottom:1px solid var(--border, #e5e5e9)}.ik-cc-modal__title{flex:1;margin:0;font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-bold, 700);line-height:var(--lh-tight, 1.25)}.ik-cc-modal__x{flex-shrink:0}.ik-cc-modal__body{overflow-y:auto;-webkit-overflow-scrolling:touch;padding:var(--sp-5, 1.25rem);display:flex;flex-direction:column;gap:var(--sp-4, 1rem);line-height:var(--lh-base, 1.6);color:var(--text-mute, #5c5c6d);font-size:var(--fs-sm, .875rem)}.ik-cc-modal__body p{margin:0}.ik-cc-modal__full{align-self:flex-start;color:var(--brand, #6d28d9);font-weight:var(--fw-semi, 600);text-decoration:underline;text-underline-offset:.18em}.ik-cc-modal__full:hover{color:var(--brand-strong, #5b21b6)}.ik-cc-modal__full:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3));border-radius:6px}@media(max-width:40rem){.ik-cc-modal{padding:0;align-items:stretch}.ik-cc-modal__sheet{width:100%;height:100%;max-height:100%;border:0;border-radius:0}}@media(prefers-reduced-motion:reduce){.ik-cc-modal__scrim,.ik-cc-modal__sheet{animation:none}}\n"], dependencies: [{ kind: "component", type: IkClose, selector: "ik-close", inputs: ["label", "autoFocus"], outputs: ["closed"] }, { kind: "component", type: IkCountdown, selector: "ik-countdown", inputs: ["durationMs", "loop"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: CookieConsent, decorators: [{
            type: Component,
            args: [{ selector: 'ik-cookie-consent', standalone: true, imports: [IkClose, IkCountdown], changeDetection: ChangeDetectionStrategy.OnPush, template: `
        @if (visible()) {
            <div
                class="bar"
                [class.bar--corner]="position() === 'corner'"
                role="dialog"
                aria-modal="false"
                [attr.aria-label]="barLabel()"
                (keydown.escape)="decide('rejected')"
            >
                <p class="text">
                    {{ msg() }}
                    <button type="button" class="policy" (click)="openPolicy()">{{ more() }}</button>
                </p>
                <div class="actions">
                    <button type="button" class="ghost" (click)="decide('rejected')">
                        @if (counting()) {
                            <ik-countdown [durationMs]="timerMs()" />
                        }
                        <span class="cc-ghost-label">{{ reject() }}</span>
                    </button>
                    <button type="button" class="solid" (click)="decide('accepted')">{{ accept() }}</button>
                </div>
            </div>
        }
        @if (policyOpen()) {
            <!-- Modal: Esc closes; focus is auto-placed on the close button (autoFocus). -->
            <!-- eslint-disable-next-line @angular-eslint/template/interactive-supports-focus -->
            <div class="ik-cc-modal" (keydown.escape)="closePolicy()">
                <!-- Backdrop scrim: click-to-dismiss; keyboard users use Esc or the close button. -->
                <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
                <div class="ik-cc-modal__scrim" (click)="closePolicy()"></div>
                <div
                    class="ik-cc-modal__sheet"
                    role="dialog"
                    aria-modal="true"
                    [attr.aria-label]="policyTitle()"
                >
                    <header class="ik-cc-modal__head">
                        <h2 class="ik-cc-modal__title">{{ policyTitle() }}</h2>
                        <ik-close
                            class="ik-cc-modal__x"
                            [label]="dismissLabel()"
                            [autoFocus]="true"
                            (closed)="closePolicy()"
                        />
                    </header>
                    <div class="ik-cc-modal__body">
                        @for (para of policyParas(); track $index) {
                            <p>{{ para }}</p>
                        }
                        @if (policy(); as href) {
                            <a
                                class="ik-cc-modal__full"
                                [href]="href"
                                target="_blank"
                                rel="noopener noreferrer"
                                >{{ fullPolicy() }} ↗</a
                            >
                        }
                    </div>
                </div>
            </div>
        }
    `, host: { class: 'ik-cookie-consent' }, styles: [".bar{position:fixed;left:50%;transform:translate(-50%);bottom:var(--sp-4, 1rem);z-index:var(--z-toast, 3000);width:min(var(--container-narrow, 42rem),calc(100vw - 2 * var(--sp-4, 1rem)));display:flex;flex-wrap:wrap;align-items:center;gap:var(--sp-3, .75rem) var(--sp-4, 1rem);padding:var(--sp-4, 1rem) var(--sp-5, 1.25rem);background:var(--bg-elev, #fff);color:var(--text, #09090f);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);box-shadow:var(--shadow-lg, 0 20px 48px rgba(0, 0, 0, .18));font-size:var(--fs-sm, .875rem);animation:ik-cc-in var(--dur-base, .25s) var(--ease-out, ease)}.bar--corner{left:var(--sp-4, 1rem);transform:none;width:min(24rem,calc(100vw - 2 * var(--sp-4, 1rem)))}@keyframes ik-cc-in{0%{opacity:0;transform:translate(-50%,12px)}}.bar--corner{animation:ik-cc-in-c var(--dur-base, .25s) var(--ease-out, ease)}@keyframes ik-cc-in-c{0%{opacity:0;transform:translateY(12px)}}.text{flex:1 1 16rem;line-height:var(--lh-base, 1.6);color:var(--text-mute, #5c5c6d);margin:0}.policy{padding:0;color:var(--brand, #6d28d9);text-decoration:underline;text-underline-offset:.18em;white-space:nowrap}.policy:hover{color:var(--brand-strong, #5b21b6)}.policy:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3));border-radius:4px}.actions{display:inline-flex;gap:var(--sp-2, .5rem);margin-left:auto;flex-shrink:0}button{font:inherit;cursor:pointer;border:0;background:transparent}.ghost,.solid{min-height:44px;padding:var(--sp-2, .5rem) var(--sp-4, 1rem);border-radius:var(--r-full, 999px);font-weight:var(--fw-semi, 600);transition:background var(--dur-fast, .15s) var(--ease-out, ease),color var(--dur-fast, .15s) var(--ease-out, ease)}.ghost{position:relative;overflow:hidden;border:1px solid var(--border-strong, #cdcdd4);color:var(--text-mute, #5c5c6d);--ik-countdown-fill: color-mix(in srgb, var(--brand, #6d28d9) 24%, transparent)}.cc-ghost-label{position:relative;z-index:1}.ghost:hover{color:var(--text, #09090f);background:var(--bg-mute, #f0f0f2)}.solid{background:var(--brand, #6d28d9);color:var(--text-on-brand, #fff);box-shadow:var(--shadow-sm, 0 2px 8px rgba(0, 0, 0, .06))}.solid:hover{background:var(--brand-strong, #5b21b6)}button:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3))}@media(max-width:40rem){.bar,.bar--corner{left:var(--sp-2, .5rem);right:var(--sp-2, .5rem);transform:none;width:auto;bottom:var(--sp-2, .5rem);padding:var(--sp-4, 1rem);flex-direction:column;align-items:stretch;gap:var(--sp-3, .75rem)}.text{flex:0 0 auto}.actions{width:100%;margin-left:0}.ghost,.solid{flex:1 1 0;min-height:48px}}@media(max-width:22rem){.actions{flex-direction:column}}@media(prefers-reduced-motion:reduce){.bar,.bar--corner{animation:none}}.ik-cc-modal{position:fixed;inset:0;z-index:calc(var(--z-toast, 3000) + 10);display:flex;align-items:center;justify-content:center;padding:var(--sp-4, 1rem)}.ik-cc-modal__scrim{position:absolute;inset:0;background:#09090f8c;-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px);animation:ik-cc-fade var(--dur-base, .25s) var(--ease-out, ease)}.ik-cc-modal__sheet{position:relative;z-index:1;display:flex;flex-direction:column;width:min(40rem,100%);max-height:min(85vh,100%);background:var(--bg-elev, #fff);color:var(--text, #09090f);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 16px);box-shadow:var(--shadow-lg, 0 20px 48px rgba(0, 0, 0, .18));overflow:hidden;animation:ik-cc-pop var(--dur-base, .25s) var(--ease-out, ease)}@keyframes ik-cc-fade{0%{opacity:0}}@keyframes ik-cc-pop{0%{opacity:0;transform:translateY(8px) scale(.98)}}.ik-cc-modal__head{display:flex;align-items:flex-start;gap:var(--sp-3, .75rem);padding:var(--sp-5, 1.25rem) var(--sp-5, 1.25rem) var(--sp-4, 1rem);border-bottom:1px solid var(--border, #e5e5e9)}.ik-cc-modal__title{flex:1;margin:0;font-size:var(--fs-lg, 1.125rem);font-weight:var(--fw-bold, 700);line-height:var(--lh-tight, 1.25)}.ik-cc-modal__x{flex-shrink:0}.ik-cc-modal__body{overflow-y:auto;-webkit-overflow-scrolling:touch;padding:var(--sp-5, 1.25rem);display:flex;flex-direction:column;gap:var(--sp-4, 1rem);line-height:var(--lh-base, 1.6);color:var(--text-mute, #5c5c6d);font-size:var(--fs-sm, .875rem)}.ik-cc-modal__body p{margin:0}.ik-cc-modal__full{align-self:flex-start;color:var(--brand, #6d28d9);font-weight:var(--fw-semi, 600);text-decoration:underline;text-underline-offset:.18em}.ik-cc-modal__full:hover{color:var(--brand-strong, #5b21b6)}.ik-cc-modal__full:focus-visible{outline:none;box-shadow:var(--ring, 0 0 0 3px rgba(109, 40, 217, .3));border-radius:6px}@media(max-width:40rem){.ik-cc-modal{padding:0;align-items:stretch}.ik-cc-modal__sheet{width:100%;height:100%;max-height:100%;border:0;border-radius:0}}@media(prefers-reduced-motion:reduce){.ik-cc-modal__scrim,.ik-cc-modal__sheet{animation:none}}\n"] }]
        }], propDecorators: { lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], messageText: [{ type: i0.Input, args: [{ isSignal: true, alias: "messageText", required: false }] }], acceptText: [{ type: i0.Input, args: [{ isSignal: true, alias: "acceptText", required: false }] }], rejectText: [{ type: i0.Input, args: [{ isSignal: true, alias: "rejectText", required: false }] }], moreText: [{ type: i0.Input, args: [{ isSignal: true, alias: "moreText", required: false }] }], policyBodyText: [{ type: i0.Input, args: [{ isSignal: true, alias: "policyBodyText", required: false }] }], policyHref: [{ type: i0.Input, args: [{ isSignal: true, alias: "policyHref", required: false }] }], placement: [{ type: i0.Input, args: [{ isSignal: true, alias: "placement", required: false }] }], autoClose: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoClose", required: false }] }], consentChange: [{ type: i0.Output, args: ["consentChange"] }] } });

/**
 * Runs the kit inside a **Tabler** (Bootstrap 5) app. Two halves:
 *
 * 1. **Styles** — load ONE bridge stylesheet after Tabler (and NOT `site-kit-tokens.css`): kit
 *    components then take Tabler's colours, fonts, radii, shadows and its light/dark theme. Kit
 *    tokens are declared on the `ik-*` elements only, so the app's own custom properties stay as
 *    they are.
 *    - Tabler from `tabler.min.css` (`--tblr-*` variables):
 *      `node_modules/@ilia-ae/site-kit/src/lib/styles/site-kit-tabler.css`
 *    - Tabler built from its Sass sources (unprefixed `--body-bg`, `--primary`):
 *      `node_modules/@ilia-ae/site-kit/src/lib/styles/site-kit-tabler-unprefixed.css`
 *
 * 2. **Theme** (this provider) — `ik-theme-toggle` writes `data-bs-theme="dark|light"` on <html>
 *    (Tabler's switch; in `auto` it writes the OS answer and follows it live) instead of the kit's
 *    `app-dark` class. Pass `storageKey` to share the mode with the app's own theme script.
 *
 * ```ts
 * // app.config.ts
 * providers: [ provideSiteKit(cfg), provideSiteKitTabler({ storageKey: 'mtls-theme' }) ]
 * ```
 * Leave `config.theme` unset on a Tabler app — the palette is Tabler's (`provideSiteKit` would put
 * `config.theme` on <html> as global variables).
 */
function provideSiteKitTabler(opts = {}) {
    return makeEnvironmentProviders([
        {
            provide: IK_THEME_OPTIONS,
            useValue: {
                storageKey: opts.storageKey ?? 'theme',
                darkClass: opts.darkClass ?? null,
                attributes: opts.attributes ?? ['data-bs-theme'],
            },
        },
    ]);
}

/**
 * Pure, dependency-free core for the authorship validator. Everything runs in the
 * browser via WebCrypto — files never leave the machine. The component layers a UI
 * and localized copy on top; these functions return NEUTRAL outcomes (status + codes
 * + counts) so they stay i18n-free and unit-testable.
 *
 * Ported from deposit.mayday.software's verify page (WHAT/WHEN checks).
 */
// ── hashing (WebCrypto SHA-256) ──────────────────────────────
function bufferToHex(buffer) {
    let hex = '';
    for (const byte of new Uint8Array(buffer))
        hex += byte.toString(16).padStart(2, '0');
    return hex;
}
// Internal primitive — the public hashing helpers below build on it; not re-exported.
async function sha256OfArrayBuffer(buffer) {
    return bufferToHex(await crypto.subtle.digest('SHA-256', buffer));
}
async function sha256OfString(input) {
    return sha256OfArrayBuffer(new TextEncoder().encode(input).buffer);
}
async function sha256OfFile(file) {
    return sha256OfArrayBuffer(await file.arrayBuffer());
}
/** Path used to match a file against the manifest (folder-relative if available). */
function filePath(file) {
    const rel = file.webkitRelativePath;
    return rel || file.name;
}
// ── WHAT — content integrity vs CITATION.cff ─────────────────
/** Extract `- path: …` / `sha256: …` pairs from a CITATION.cff (1.2.0) manifest. */
function parseManifestHashes(manifestText) {
    const fileRegex = /^ {2}- path:\s*"?(.+?)"?\s*$/gm;
    const hashRegex = /^ {4}sha256:\s*"?([0-9a-f]{64})"?\s*$/gm;
    const paths = [...manifestText.matchAll(fileRegex)].map((m) => m[1]).filter((p) => !!p);
    const hashes = [...manifestText.matchAll(hashRegex)].map((m) => m[1]).filter((h) => !!h);
    const out = new Map();
    for (let i = 0; i < Math.min(paths.length, hashes.length); i++)
        out.set(paths[i], hashes[i]); // safe: i bounded by Math.min(paths.length, hashes.length)
    return out;
}
/** Re-hash each source and compare against the manifest. No sources → skipped. */
async function checkWhat(manifestText, sources) {
    const expected = parseManifestHashes(manifestText);
    if (!sources.length)
        return { status: 'skipped', matched: 0, total: expected.size, mismatchPaths: [] };
    let matched = 0;
    const mismatchPaths = [];
    for (const file of sources) {
        const path = filePath(file);
        const want = expected.get(path);
        if (!want)
            continue;
        const got = await sha256OfFile(file);
        if (got === want)
            matched++;
        else
            mismatchPaths.push(path);
    }
    return {
        status: mismatchPaths.length ? 'failed' : 'passed',
        matched,
        total: expected.size,
        mismatchPaths,
    };
}
const OTS_MAGIC_LEN = 31;
/** Parse an OpenTimestamps `.ots`: checks the SHA-256 op + that its digest is the manifest hash. */
function parseOts(bytes, manifestHash, name = 'proof.ots') {
    if (bytes.length < OTS_MAGIC_LEN + 2 + 32)
        return { name, status: 'failed', code: 'ots-short' };
    const version = bytes[OTS_MAGIC_LEN];
    const hashOp = bytes[OTS_MAGIC_LEN + 1];
    if (hashOp !== 0x08)
        return { name, status: 'failed', code: 'ots-badop' };
    const digest = Array.from(bytes.slice(OTS_MAGIC_LEN + 2, OTS_MAGIC_LEN + 2 + 32))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    if (digest !== manifestHash)
        return { name, status: 'failed', code: 'ots-mismatch', digestHead: digest.slice(0, 16) };
    return { name, status: 'passed', code: 'ots-ok', version };
}
/** Parse an RFC 3161 `.tsr`: a minimal DER sanity check (SEQUENCE header). */
function parseTsr(bytes, name = 'proof.tsr') {
    if (bytes.length < 10 || bytes[0] !== 0x30)
        return { name, status: 'failed', code: 'tsr-invalid' };
    return { name, status: 'passed', code: 'tsr-ok' };
}
/** Dispatch each proof file to the right parser. No proofs → one skipped outcome. */
async function checkWhen(proofs, manifestText) {
    if (!proofs.length)
        return [{ name: '', status: 'skipped', code: 'unknown' }];
    const manifestHash = await sha256OfString(manifestText);
    const out = [];
    for (const proof of proofs) {
        const bytes = new Uint8Array(await proof.arrayBuffer());
        if (proof.name.endsWith('.ots'))
            out.push(parseOts(bytes, manifestHash, proof.name));
        else if (proof.name.includes('.tsr'))
            out.push(parseTsr(bytes, proof.name));
        else
            out.push({ name: proof.name, status: 'skipped', code: 'unknown' });
    }
    return out;
}

/**
 * WHO check — detached GPG signature verification via `openpgp`.
 *
 * openpgp is an OPTIONAL peer dependency: it's loaded lazily with a dynamic
 * `import('openpgp')` (its own chunk, fetched only when a signature is verified).
 * If it isn't installed / fails to load, the validator degrades gracefully — the
 * WHO check reports "unavailable" rather than throwing.
 *
 * Typed loosely (`any`) on purpose so the library compiles without a hard type
 * dependency on openpgp.
 */
const GPG_PASSPHRASE_REQUIRED = 'GPG_PASSPHRASE_REQUIRED';
/* eslint-disable @typescript-eslint/no-explicit-any */
let cached; // undefined = not tried, null = unavailable
async function loadOpenpgp() {
    if (cached !== undefined)
        return cached;
    try {
        cached = await import('openpgp');
    }
    catch {
        cached = null;
    }
    return cached;
}
/** Whether GPG verification is usable in this environment (openpgp resolved). */
async function gpgAvailable() {
    return (await loadOpenpgp()) !== null;
}
/** True only when the uploaded key is a passphrase-locked PRIVATE key. */
async function needsPassphrase(armoredKey) {
    const openpgp = await loadOpenpgp();
    if (!openpgp)
        return false;
    try {
        const key = await openpgp.readKey({ armoredKey });
        const maybePrivate = key;
        return typeof maybePrivate.isDecrypted === 'function' && !maybePrivate.isDecrypted();
    }
    catch {
        return false;
    }
}
/** Verify a detached ASCII-armored signature over the manifest with the given key. */
async function verifyGpg(manifestText, armoredSignature, armoredKey, passphrase) {
    const openpgp = await loadOpenpgp();
    if (!openpgp)
        return { available: false, valid: false, keyId: '', userId: '', signedAt: null };
    try {
        let key = await openpgp.readKey({ armoredKey });
        // Coerce a private key (encrypted or not) down to public material.
        const maybePrivate = key;
        if (typeof maybePrivate.isDecrypted === 'function') {
            if (!maybePrivate.isDecrypted()) {
                if (!passphrase)
                    throw new Error(GPG_PASSPHRASE_REQUIRED);
                const decrypted = await openpgp.decryptKey({ privateKey: key, passphrase });
                key = decrypted.toPublic();
            }
            else {
                key = key.toPublic();
            }
        }
        const message = await openpgp.createMessage({ text: manifestText });
        const signature = await openpgp.readSignature({ armoredSignature });
        const result = await openpgp.verify({ message, signature, verificationKeys: key });
        const sig = result.signatures?.[0];
        if (!sig)
            throw new Error('verification produced no signature');
        let valid = false;
        try {
            await sig.verified;
            valid = true;
        }
        catch {
            /* invalid signature */
        }
        const userIdPacket = key.users?.[0]?.userID;
        const userId = userIdPacket
            ? [userIdPacket.name, userIdPacket.email ? `<${userIdPacket.email}>` : '']
                .filter(Boolean)
                .join(' ')
            : 'Unknown';
        const resolvedSig = await sig.signature;
        const created = resolvedSig.packets?.[0]?.created ?? null;
        return {
            available: true,
            valid,
            keyId: key.getKeyID().toHex().toUpperCase(),
            userId,
            signedAt: created instanceof Date ? created : null,
        };
    }
    catch (e) {
        return {
            available: true,
            valid: false,
            keyId: '',
            userId: '',
            signedAt: null,
            error: e instanceof Error ? e.message : String(e),
        };
    }
}

/**
 * WHO check — a detached SSH signature (`ssh-keygen -Y sign`, the SSHSIG format, PROTOCOL.sshsig),
 * verified with WebCrypto: no dependency, nothing loaded. Made for keys that live on a hardware
 * token and sign through ssh-agent (a YubiKey PIV slot, ECDSA P-256), where an OpenPGP key isn't
 * there to sign with.
 *
 *   ssh-keygen -Y sign -n file -f key.pub CITATION.cff     → CITATION.cff.sig
 *   ssh-keygen -Y check-novalidate -n file -f key.pub -s CITATION.cff.sig < CITATION.cff
 *
 * Supported keys: ecdsa-sha2-nistp256/384/521 and ssh-ed25519 (Ed25519 needs a browser with
 * WebCrypto Ed25519). The public key the visitor gives (an OpenSSH key line, or an allowed_signers
 * line) must be byte-for-byte the key inside the signature, and the namespace must be `file`, so a
 * signature made for something else (a git commit is `git`) does not pass.
 */
/** The namespace an attestation is signed in (`ssh-keygen -Y sign -n file`). */
const SSHSIG_NAMESPACE = 'file';
const ECDSA = {
    nistp256: { curve: 'P-256', hash: 'SHA-256', size: 32 },
    nistp384: { curve: 'P-384', hash: 'SHA-384', size: 48 },
    nistp521: { curve: 'P-521', hash: 'SHA-512', size: 66 },
};
/** True when the text is an armored SSH signature (as opposed to an OpenPGP one). */
function isSshSignature(text) {
    return /-----BEGIN SSH SIGNATURE-----/.test(text);
}
const b64 = (s) => Uint8Array.from(atob(s.replace(/\s+/g, '')), (c) => c.charCodeAt(0));
/** A reader over the SSH wire format: uint32 lengths, length-prefixed strings. */
class Wire {
    buf;
    at = 0;
    constructor(buf) {
        this.buf = buf;
    }
    u32() {
        if (this.at + 4 > this.buf.length)
            throw new Error('SSH signature is truncated');
        const v = new DataView(this.buf.buffer, this.buf.byteOffset + this.at, 4).getUint32(0);
        this.at += 4;
        return v;
    }
    bytes(n) {
        if (this.at + n > this.buf.length)
            throw new Error('SSH signature is truncated');
        const v = this.buf.subarray(this.at, this.at + n);
        this.at += n;
        return v;
    }
    str() {
        return this.bytes(this.u32());
    }
    text() {
        return new TextDecoder().decode(this.str());
    }
    get done() {
        return this.at === this.buf.length;
    }
}
const enc = (s) => new TextEncoder().encode(s);
function sshString(b) {
    const out = new Uint8Array(4 + b.length);
    new DataView(out.buffer).setUint32(0, b.length);
    out.set(b, 4);
    return out;
}
function concat(...parts) {
    const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
    let at = 0;
    for (const p of parts) {
        out.set(p, at);
        at += p.length;
    }
    return out;
}
const equal = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
/** An SSH mpint (big-endian, maybe a leading 0x00) as a fixed-size unsigned integer. */
function fixed(mpint, size) {
    let v = mpint;
    while (v.length > size && v[0] === 0)
        v = v.subarray(1);
    if (v.length > size)
        throw new Error('bad ECDSA signature integer');
    const out = new Uint8Array(size);
    out.set(v, size - v.length);
    return out;
}
/** WebCrypto wants a BufferSource backed by a plain ArrayBuffer. */
const ab = (u) => u.slice().buffer;
/** The first OpenSSH public key in a file: `type base64 [comment]`, or an allowed_signers line. */
function parsePublicKey(text) {
    for (const line of text.split(/\r?\n/)) {
        const t = line.trim().split(/\s+/);
        const i = t.findIndex((w) => /^(ssh-ed25519|ecdsa-sha2-nistp(256|384|521))$/.test(w));
        const type = t[i];
        const key = t[i + 1];
        if (type && key)
            return { type, blob: b64(key), comment: t.slice(i + 2).join(' ') };
    }
    throw new Error('no OpenSSH public key (ssh-ed25519 / ecdsa-sha2-nistp*) in the key file');
}
async function fingerprintOf(blob) {
    const d = new Uint8Array(await crypto.subtle.digest('SHA-256', ab(blob)));
    return 'SHA256:' + btoa(String.fromCharCode(...d)).replace(/=+$/, '');
}
/** Verify a detached SSHSIG over the manifest with the given OpenSSH public key. */
async function verifySshSig(manifestText, armoredSignature, publicKeyText, namespace = SSHSIG_NAMESPACE) {
    const out = { valid: false, fingerprint: '', comment: '', keyType: '' };
    try {
        const pub = parsePublicKey(publicKeyText);
        out.comment = pub.comment;
        out.keyType = pub.type;
        out.fingerprint = await fingerprintOf(pub.blob);
        const body = /-----BEGIN SSH SIGNATURE-----([\s\S]*?)-----END SSH SIGNATURE-----/.exec(armoredSignature);
        if (!body?.[1])
            throw new Error('not an armored SSH signature');
        const w = new Wire(b64(body[1]));
        if (new TextDecoder().decode(w.bytes(6)) !== 'SSHSIG')
            throw new Error('not an SSHSIG signature');
        if (w.u32() !== 1)
            throw new Error('unsupported SSHSIG version');
        const sigKey = w.str();
        const ns = w.text();
        const reserved = w.str();
        const hashAlg = w.text();
        const sigBlob = w.str();
        if (!w.done)
            throw new Error('trailing data after the SSH signature');
        if (!equal(sigKey, pub.blob))
            throw new Error('signed with a different key');
        if (ns !== namespace)
            throw new Error(`signature namespace is "${ns}", expected "${namespace}"`);
        const hash = hashAlg === 'sha512' ? 'SHA-512' : hashAlg === 'sha256' ? 'SHA-256' : null;
        if (!hash)
            throw new Error(`unsupported hash "${hashAlg}"`);
        const digest = new Uint8Array(await crypto.subtle.digest(hash, ab(enc(manifestText))));
        const signed = concat(enc('SSHSIG'), sshString(enc(ns)), sshString(reserved), sshString(enc(hashAlg)), sshString(digest));
        const s = new Wire(sigBlob);
        const sigType = s.text();
        const sig = s.str();
        const k = new Wire(pub.blob);
        const keyType = k.text();
        if (sigType !== keyType)
            throw new Error(`signature type ${sigType} does not match the ${keyType} key`);
        if (keyType === 'ssh-ed25519') {
            const key = await crypto.subtle.importKey('raw', ab(k.str()), { name: 'Ed25519' }, false, [
                'verify',
            ]);
            out.valid = await crypto.subtle.verify({ name: 'Ed25519' }, key, ab(sig), ab(signed));
            return out;
        }
        const curveName = k.text();
        const c = ECDSA[curveName];
        if (!c || keyType !== `ecdsa-sha2-${curveName}`)
            throw new Error(`unsupported key ${keyType}`);
        const key = await crypto.subtle.importKey('raw', ab(k.str()), { name: 'ECDSA', namedCurve: c.curve }, false, ['verify']);
        const rs = new Wire(sig);
        const raw = concat(fixed(rs.str(), c.size), fixed(rs.str(), c.size));
        out.valid = await crypto.subtle.verify({ name: 'ECDSA', hash: c.hash }, key, ab(raw), ab(signed));
        return out;
    }
    catch (e) {
        return { ...out, valid: false, error: e instanceof Error ? e.message : String(e) };
    }
}

const VALIDATOR_STRINGS = {
    en: {
        title: 'Authorship validator',
        subtitle: 'Verify a proof locally — files never leave your browser.',
        back: 'Back to site',
        dropManifest: 'Manifest (CITATION.cff)',
        dropSources: 'Source files',
        dropProofs: 'Timestamp proofs',
        dropKey: 'Public key',
        dropSignature: 'Signature',
        manifestHint: '.cff · .yaml · .yml',
        sourcesHint: 'Optional — add the sources to also check content integrity (WHAT)',
        proofsHint: '.ots · .tsr',
        keyHint: '.asc · .gpg · .pub',
        sigHint: '.asc · .sig',
        passphrase: 'Key passphrase',
        passphraseHint: 'Only to read a passphrase-locked private key — never sent anywhere.',
        run: 'Verify',
        verifying: 'Verifying…',
        required: 'required',
        readiness: 'Readiness',
        readinessHint: 'Manifest is required; the rest unlock WHO/WHEN checks.',
        what: 'Content',
        who: 'Authorship',
        when: 'Timestamp',
        whatTag: 'WHAT · integrity',
        whoTag: 'WHO · signature',
        whenTag: 'WHEN · time',
        passed: 'passed',
        failed: 'failed',
        skipped: 'skipped',
        allPassed: 'All checks passed',
        someFailed: 'Some checks failed',
        hashMatch: 'match',
        hashMismatch: 'mismatch',
        sigValid: 'Signature valid',
        sigInvalid: 'Signature invalid',
        gpgUnavailable: 'GPG unavailable (openpgp not installed)',
        passphraseRequired: 'This private key needs a passphrase',
        otsOk: 'OpenTimestamps digest matches',
        otsMismatch: 'OTS digest does not match the manifest',
        otsBad: 'Unexpected OTS structure',
        tsrOk: 'RFC 3161 timestamp parsed',
        tsrInvalid: 'Invalid RFC 3161 timestamp',
        unknownProof: 'Unknown proof format',
        noProofs: 'No proofs provided',
    },
    ru: {
        title: 'Валидатор авторства',
        subtitle: 'Проверка доказательства локально — файлы не покидают браузер.',
        back: 'Назад на сайт',
        dropManifest: 'Манифест (CITATION.cff)',
        dropSources: 'Исходные файлы',
        dropProofs: 'Таймстемпы',
        dropKey: 'Публичный ключ',
        dropSignature: 'Подпись',
        manifestHint: '.cff · .yaml · .yml',
        sourcesHint: 'Необязательно — добавьте исходники, чтобы проверить и целостность (WHAT)',
        proofsHint: '.ots · .tsr',
        keyHint: '.asc · .gpg · .pub',
        sigHint: '.asc · .sig',
        passphrase: 'Пароль ключа',
        passphraseHint: 'Только чтобы прочитать запароленный приватный ключ — никуда не отправляется.',
        run: 'Проверить',
        verifying: 'Проверка…',
        required: 'обязательно',
        readiness: 'Готовность',
        readinessHint: 'Манифест обязателен; остальное включает проверки WHO/WHEN.',
        what: 'Содержимое',
        who: 'Авторство',
        when: 'Время',
        whatTag: 'WHAT · целостность',
        whoTag: 'WHO · подпись',
        whenTag: 'WHEN · время',
        passed: 'пройдено',
        failed: 'провалено',
        skipped: 'пропущено',
        allPassed: 'Все проверки пройдены',
        someFailed: 'Часть проверок не пройдена',
        hashMatch: 'совпадает',
        hashMismatch: 'не совпадает',
        sigValid: 'Подпись действительна',
        sigInvalid: 'Подпись недействительна',
        gpgUnavailable: 'GPG недоступен (openpgp не установлен)',
        passphraseRequired: 'Этому приватному ключу нужен пароль',
        otsOk: 'Дайджест OpenTimestamps совпадает',
        otsMismatch: 'Дайджест OTS не совпадает с манифестом',
        otsBad: 'Неожиданная структура OTS',
        tsrOk: 'Таймстемп RFC 3161 разобран',
        tsrInvalid: 'Некорректный таймстемп RFC 3161',
        unknownProof: 'Неизвестный формат пруфа',
        noProofs: 'Пруфы не предоставлены',
    },
};
/**
 * Client-side authorship validator (ported from deposit.mayday.software). Drop a
 * CITATION.cff manifest + sources + proofs + GPG key/signature and it checks, all in
 * the browser: WHAT (SHA-256 integrity), WHO (a GPG signature via lazy openpgp, or an SSH
 * signature — `ssh-keygen -Y sign -n file` — via WebCrypto),
 * WHEN (OTS/RFC-3161 timestamps). Localized en/ru with an optional [strings] override.
 */
class AuthorshipValidator {
    lang = input('en', ...(ngDevMode ? [{ debugName: "lang" }] : /* istanbul ignore next */ []));
    strings = input(null, ...(ngDevMode ? [{ debugName: "strings" }] : /* istanbul ignore next */ []));
    /**
     * Optional PUBLISHED proof bundle — each value is a URL. When `manifest` is set the
     * component fetches the bundle on load, fills the zones and runs verification
     * automatically, so a visitor sees the result ("✓ authorship verified") without
     * dropping anything. Manual drag-drop still works as a fallback.
     */
    proof = input(null, ...(ngDevMode ? [{ debugName: "proof" }] : /* istanbul ignore next */ []));
    /** A "← back" link in the header. Defaults to the site home ('/'); pass a custom URL,
     *  or `null` to hide it. */
    homeHref = input('/', ...(ngDevMode ? [{ debugName: "homeHref" }] : /* istanbul ignore next */ []));
    constructor() {
        /* istanbul ignore next -- network/DOM auto-load glue; the verify pipeline it feeds is unit-tested */
        afterNextRender(() => void this.autoload());
        /* istanbul ignore next -- re-localises an already-run result when the language changes
           (the result strings are built at verify time); not exercised in unit tests */
        effect(() => {
            this.lang(); // re-run when the language switches
            if (untracked(() => this.checks().length > 0 && !!this.manifestFile())) {
                void this.runVerification();
            }
        });
    }
    /* istanbul ignore next -- fetches the published bundle in the browser; not exercised in unit tests */
    async autoload() {
        const p = this.proof();
        if (!p?.manifest)
            return;
        const toFile = async (url) => {
            const res = await fetch(url, { cache: 'no-store' });
            if (!res.ok)
                throw new Error(`fetch ${url}: ${res.status}`);
            const blob = await res.blob();
            return new File([blob], url.split('/').pop() || 'file', { type: blob.type });
        };
        try {
            this.setManifest([await toFile(p.manifest)]);
            if (p.key)
                await this.setKey([await toFile(p.key)]);
            if (p.signature)
                this.setSignature([await toFile(p.signature)]);
            if (p.proofs?.length)
                this.setProofs(await Promise.all(p.proofs.map(toFile)));
            if (p.sources?.length)
                this.setSources(await Promise.all(p.sources.map(toFile)));
            await this.runVerification();
        }
        catch {
            /* leave the manual drop zones available */
        }
    }
    manifestFile = signal(null, ...(ngDevMode ? [{ debugName: "manifestFile" }] : /* istanbul ignore next */ []));
    sourceFiles = signal([], ...(ngDevMode ? [{ debugName: "sourceFiles" }] : /* istanbul ignore next */ []));
    proofFiles = signal([], ...(ngDevMode ? [{ debugName: "proofFiles" }] : /* istanbul ignore next */ []));
    publicKeyFile = signal(null, ...(ngDevMode ? [{ debugName: "publicKeyFile" }] : /* istanbul ignore next */ []));
    signatureFile = signal(null, ...(ngDevMode ? [{ debugName: "signatureFile" }] : /* istanbul ignore next */ []));
    keyNeedsPassphrase = signal(false, ...(ngDevMode ? [{ debugName: "keyNeedsPassphrase" }] : /* istanbul ignore next */ []));
    keyPassphrase = '';
    verifying = signal(false, ...(ngDevMode ? [{ debugName: "verifying" }] : /* istanbul ignore next */ []));
    checks = signal([], ...(ngDevMode ? [{ debugName: "checks" }] : /* istanbul ignore next */ []));
    str = computed(() => {
        const base = VALIDATOR_STRINGS[this.lang() === 'ru' ? 'ru' : 'en'];
        const ov = this.strings()?.[this.lang()];
        return ov ? { ...base, ...ov } : base;
    }, ...(ngDevMode ? [{ debugName: "str" }] : /* istanbul ignore next */ []));
    zonesFilled = computed(() => (this.manifestFile() ? 1 : 0) +
        (this.sourceFiles().length ? 1 : 0) +
        (this.proofFiles().length ? 1 : 0) +
        (this.publicKeyFile() ? 1 : 0) +
        (this.signatureFile() ? 1 : 0), ...(ngDevMode ? [{ debugName: "zonesFilled" }] : /* istanbul ignore next */ []));
    allPassed = computed(() => {
        const c = this.checks();
        return c.length > 0 && c.every((ch) => ch.status !== 'failed');
    }, ...(ngDevMode ? [{ debugName: "allPassed" }] : /* istanbul ignore next */ []));
    t(key) {
        return this.str()[key];
    }
    // ── file pickers ──────────────────────────────────────────
    pick(e) {
        const i = e.target;
        return i.files ? Array.from(i.files) : [];
    }
    drop(e) {
        e.preventDefault();
        return e.dataTransfer?.files ? Array.from(e.dataTransfer.files) : [];
    }
    asValue(e) {
        return e.target.value;
    }
    /** SHA-256 of the loaded manifest — shown so the user sees the exact bytes that are
     *  signed (WHO) and timestamped (WHEN). Display-only; verification uses the file itself. */
    manifestHash = signal('', ...(ngDevMode ? [{ debugName: "manifestHash" }] : /* istanbul ignore next */ []));
    async setManifest(files) {
        const f = files[0] ?? null;
        this.manifestFile.set(f);
        this.manifestHash.set(f ? await sha256OfFile(f) : '');
    }
    /** "name · 1.2 KB" for a single loaded file (so a zone shows what's in it). */
    info(f) {
        return f ? `${f.name} · ${this.fmtBytes(f.size)}` : '';
    }
    /** Single → name · size; many → "N files · total". */
    multiInfo(files) {
        if (!files.length)
            return '';
        if (files.length === 1)
            return this.info(files[0]);
        const total = files.reduce((s, f) => s + f.size, 0);
        return `${files.length} files · ${this.fmtBytes(total)}`;
    }
    fmtBytes(n) {
        return n < 1024
            ? `${n} B`
            : n < 1048576
                ? `${(n / 1024).toFixed(1)} KB`
                : `${(n / 1048576).toFixed(1)} MB`;
    }
    setSources(files) {
        if (files.length)
            this.sourceFiles.set(files);
    }
    setProofs(files) {
        if (files.length)
            this.proofFiles.set(files);
    }
    setSignature(files) {
        this.signatureFile.set(files[0] ?? null);
    }
    async setKey(files) {
        const file = files[0] ?? null;
        this.publicKeyFile.set(file);
        this.keyNeedsPassphrase.set(false);
        this.keyPassphrase = '';
        if (!file)
            return;
        try {
            this.keyNeedsPassphrase.set(await needsPassphrase(await file.text()));
        }
        catch {
            /* surfaces on verify */
        }
    }
    // ── run ───────────────────────────────────────────────────
    async runVerification() {
        const manifest = this.manifestFile();
        if (!manifest)
            return;
        this.verifying.set(true);
        this.checks.set([]);
        const results = [];
        try {
            const text = await manifest.text();
            results.push(await this.buildWhat(text));
            results.push(await this.buildWho(text));
            results.push(...(await this.buildWhen(text)));
        }
        catch (e) {
            results.push({
                kind: 'what',
                label: this.t('what'),
                status: 'failed',
                details: e instanceof Error ? e.message : String(e),
            });
        }
        this.checks.set(results);
        this.verifying.set(false);
    }
    async buildWhat(text) {
        const o = await checkWhat(text, this.sourceFiles());
        const label = this.t('what');
        if (o.status === 'skipped')
            return { kind: 'what', label, status: 'skipped', details: this.t('skipped') };
        if (o.status === 'failed') {
            return {
                kind: 'what',
                label,
                status: 'failed',
                details: `${o.matched} ${this.t('hashMatch')}, ${o.mismatchPaths.length} ${this.t('hashMismatch')}: ${o.mismatchPaths.join(', ')}`,
            };
        }
        return {
            kind: 'what',
            label,
            status: 'passed',
            details: `${o.matched}/${o.total} ${this.t('hashMatch')}`,
        };
    }
    async buildWho(text) {
        const label = this.t('who');
        const key = this.publicKeyFile();
        const sig = this.signatureFile();
        if (!key || !sig)
            return { kind: 'who', label, status: 'skipped', details: this.t('skipped') };
        const [keyText, sigText] = await Promise.all([key.text(), sig.text()]);
        if (isSshSignature(sigText)) {
            // an SSH signature (ssh-keygen -Y sign -n file): a hardware key signing through ssh-agent
            const s = await verifySshSig(text, sigText, keyText);
            if (s.valid)
                return {
                    kind: 'who',
                    label,
                    status: 'passed',
                    details: [this.t('sigValid'), s.fingerprint, s.comment].filter(Boolean).join(' · '),
                };
            return { kind: 'who', label, status: 'failed', details: s.error ?? this.t('sigInvalid') };
        }
        const r = await verifyGpg(text, sigText, keyText, this.keyPassphrase.trim() || undefined);
        if (!r.available)
            return { kind: 'who', label, status: 'skipped', details: this.t('gpgUnavailable') };
        if (r.error)
            return {
                kind: 'who',
                label,
                status: 'failed',
                details: r.error === GPG_PASSPHRASE_REQUIRED ? this.t('passphraseRequired') : r.error,
            };
        if (r.valid)
            return {
                kind: 'who',
                label,
                status: 'passed',
                details: `${this.t('sigValid')} · ${r.keyId} · ${r.userId}`,
            };
        return { kind: 'who', label, status: 'failed', details: this.t('sigInvalid') };
    }
    async buildWhen(text) {
        const proofs = this.proofFiles();
        if (!proofs.length)
            return [{ kind: 'when', label: this.t('when'), status: 'skipped', details: this.t('noProofs') }];
        const outcomes = await checkWhen(proofs, text);
        return outcomes.map((o) => ({
            kind: 'when',
            label: o.name ? `${this.t('when')} · ${o.name}` : this.t('when'),
            status: o.status,
            details: this.whenDetail(o),
        }));
    }
    whenDetail(o) {
        switch (o.code) {
            case 'ots-ok':
                return `${this.t('otsOk')}${o.version != null ? ' · v' + o.version : ''}`;
            case 'ots-mismatch':
                return `${this.t('otsMismatch')}${o.digestHead ? ' (' + o.digestHead + '…)' : ''}`;
            case 'ots-short':
            case 'ots-badop':
                return this.t('otsBad');
            case 'tsr-ok':
                return this.t('tsrOk');
            case 'tsr-invalid':
                return this.t('tsrInvalid');
            default:
                return this.t('unknownProof');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: AuthorshipValidator, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: AuthorshipValidator, isStandalone: true, selector: "ik-authorship-validator", inputs: { lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, strings: { classPropertyName: "strings", publicName: "strings", isSignal: true, isRequired: false, transformFunction: null }, proof: { classPropertyName: "proof", publicName: "proof", isSignal: true, isRequired: false, transformFunction: null }, homeHref: { classPropertyName: "homeHref", publicName: "homeHref", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
        <section class="ik-av">
            @if (homeHref(); as href) {
                <a class="av-back" [href]="href">← {{ t('back') }}</a>
            }
            <header class="av-head">
                <h2>{{ t('title') }}</h2>
                <p>{{ t('subtitle') }}</p>
            </header>

            <div class="av-grid">
                <div class="zones">
                    <label
                        class="zone req"
                        [class.filled]="!!manifestFile()"
                        (dragover)="$event.preventDefault()"
                        (drop)="setManifest(drop($event))"
                    >
                        <input
                            type="file"
                            accept=".cff,.yaml,.yml"
                            (change)="setManifest(pick($event))"
                            hidden
                        />
                        <span class="z-top"
                            ><b>{{ t('dropManifest') }}</b
                            ><span class="req-tag">{{ t('required') }}</span></span
                        >
                        <span class="z-hint">{{
                            manifestFile() ? info(manifestFile()) : t('manifestHint')
                        }}</span>
                        @if (manifestHash()) {
                            <span class="z-hash">sha256 · {{ manifestHash().slice(0, 16) }}…</span>
                        }
                    </label>

                    <label
                        class="zone"
                        [class.filled]="!!sourceFiles().length"
                        (dragover)="$event.preventDefault()"
                        (drop)="setSources(drop($event))"
                    >
                        <input type="file" multiple (change)="setSources(pick($event))" hidden />
                        <span class="z-top"
                            ><b>{{ t('dropSources') }}</b></span
                        >
                        <span class="z-hint">{{
                            sourceFiles().length ? multiInfo(sourceFiles()) : t('sourcesHint')
                        }}</span>
                    </label>

                    <label
                        class="zone"
                        [class.filled]="!!proofFiles().length"
                        (dragover)="$event.preventDefault()"
                        (drop)="setProofs(drop($event))"
                    >
                        <input
                            type="file"
                            accept=".ots,.tsr"
                            multiple
                            (change)="setProofs(pick($event))"
                            hidden
                        />
                        <span class="z-top"
                            ><b>{{ t('dropProofs') }}</b></span
                        >
                        <span class="z-hint">{{
                            proofFiles().length ? multiInfo(proofFiles()) : t('proofsHint')
                        }}</span>
                    </label>

                    <label
                        class="zone"
                        [class.filled]="!!publicKeyFile()"
                        (dragover)="$event.preventDefault()"
                        (drop)="setKey(drop($event))"
                    >
                        <input
                            type="file"
                            accept=".asc,.gpg,.pgp,.pub,.key"
                            (change)="setKey(pick($event))"
                            hidden
                        />
                        <span class="z-top"
                            ><b>{{ t('dropKey') }}</b></span
                        >
                        <span class="z-hint">{{
                            publicKeyFile() ? info(publicKeyFile()) : t('keyHint')
                        }}</span>
                    </label>

                    @if (keyNeedsPassphrase()) {
                        <div class="passbox">
                            <label class="pass-label"
                                >{{ t('passphrase') }}
                                <input
                                    type="password"
                                    autocomplete="off"
                                    spellcheck="false"
                                    [value]="keyPassphrase"
                                    (input)="keyPassphrase = asValue($event)"
                                />
                            </label>
                            <p class="z-hint">{{ t('passphraseHint') }}</p>
                        </div>
                    }

                    <label
                        class="zone"
                        [class.filled]="!!signatureFile()"
                        (dragover)="$event.preventDefault()"
                        (drop)="setSignature(drop($event))"
                    >
                        <input type="file" accept=".asc,.sig" (change)="setSignature(pick($event))" hidden />
                        <span class="z-top"
                            ><b>{{ t('dropSignature') }}</b></span
                        >
                        <span class="z-hint">{{
                            signatureFile() ? info(signatureFile()) : t('sigHint')
                        }}</span>
                    </label>
                </div>

                <aside class="side">
                    <div class="ready">
                        <div class="r-head">
                            <b>{{ t('readiness') }}</b
                            ><span>{{ zonesFilled() }}/5</span>
                        </div>
                        <p class="z-hint">{{ t('readinessHint') }}</p>
                        <button
                            type="button"
                            class="run"
                            [disabled]="!manifestFile() || verifying()"
                            (click)="runVerification()"
                        >
                            {{ verifying() ? t('verifying') : t('run') }}
                        </button>
                    </div>
                </aside>
            </div>

            @if (checks().length) {
                <div class="results">
                    <div class="summary" [class.ok]="allPassed()" [class.fail]="!allPassed()">
                        <span class="s-mark">{{ allPassed() ? '✓' : '✗' }}</span>
                        <span>{{ allPassed() ? t('allPassed') : t('someFailed') }}</span>
                    </div>
                    <div class="check-grid">
                        @for (c of checks(); track $index) {
                            <div class="check s-{{ c.status }}">
                                <div class="c-head">
                                    <span class="c-icon">{{
                                        c.status === 'passed' ? '✓' : c.status === 'failed' ? '✗' : '—'
                                    }}</span>
                                    <div>
                                        <b>{{ c.label }}</b>
                                        <span class="c-tag">{{
                                            c.kind === 'what'
                                                ? t('whatTag')
                                                : c.kind === 'who'
                                                  ? t('whoTag')
                                                  : t('whenTag')
                                        }}</span>
                                    </div>
                                </div>
                                <p class="c-details">{{ c.details }}</p>
                            </div>
                        }
                    </div>
                </div>
            }
        </section>
    `, isInline: true, styles: [":host{display:block}.ik-av{border:1px solid var(--border);border-radius:var(--r-lg, 16px);background:var(--bg-elev);padding:var(--sp-6)}.av-back{display:inline-flex;align-items:center;gap:.3em;margin-bottom:var(--sp-4);font-size:var(--fs-sm);color:var(--text-mute);text-decoration:none}.av-back:hover{color:var(--brand)}.av-head h2{margin:0 0 var(--sp-1);font-size:var(--fs-xl, 1.25rem)}.av-head p{margin:0 0 var(--sp-5);color:var(--text-mute);font-size:var(--fs-sm)}.av-grid{display:grid;grid-template-columns:minmax(0,1fr) 16rem;gap:var(--sp-4)}@media(max-width:48rem){.av-grid{grid-template-columns:1fr}}.zones{display:flex;flex-direction:column;gap:var(--sp-2)}.zone{display:flex;flex-direction:column;gap:.15rem;padding:var(--sp-3) var(--sp-4);border:1px dashed var(--border-strong);border-radius:var(--r-md);cursor:pointer;background:var(--bg);transition:border-color .15s,background .15s}.zone:hover{border-color:var(--brand);background:color-mix(in srgb,var(--brand) 4%,var(--bg))}.zone.req{border-style:solid}.zone.filled{border-style:solid;border-color:color-mix(in srgb,var(--success, #16a34a) 55%,var(--border-strong));background:color-mix(in srgb,var(--success, #16a34a) 8%,var(--bg))}.zone.filled .z-top:after{content:\"\\2713\";margin-left:auto;color:var(--success, #16a34a);font-weight:var(--fw-bold)}.zone.filled .req-tag{display:none}.z-top{display:flex;align-items:center;gap:var(--sp-2)}.z-top b{font-size:var(--fs-sm)}.req-tag{font-size:var(--fs-xs);color:var(--brand);border:1px solid var(--brand);border-radius:var(--r-full);padding:0 .5em}.z-hint{font-size:var(--fs-xs);color:var(--text-dim);font-family:var(--font-mono);word-break:break-all}.z-hash{font-size:var(--fs-xs);color:var(--text-dim);font-family:var(--font-mono);opacity:.7;word-break:break-all}.passbox{display:flex;flex-direction:column;gap:.2rem;padding:0 var(--sp-1)}.pass-label{display:flex;flex-direction:column;gap:.15rem;font-size:var(--fs-xs);color:var(--text-mute)}.pass-label input{font:inherit;padding:var(--sp-1) var(--sp-2);border:1px solid var(--border-strong);border-radius:var(--r-sm);background:var(--bg);color:var(--text)}.side{display:flex;flex-direction:column}.ready{position:sticky;top:var(--sp-4);border:1px solid var(--border);border-radius:var(--r-md);padding:var(--sp-4);background:var(--bg)}.r-head{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:var(--sp-1)}.run{width:100%;margin-top:var(--sp-3);padding:var(--sp-2) var(--sp-4);border:1px solid var(--brand);border-radius:var(--r-md);background:var(--brand);color:var(--text-on-brand, #fff);font:inherit;font-weight:var(--fw-semi);cursor:pointer}.run:disabled{opacity:.5;cursor:not-allowed}.results{margin-top:var(--sp-5);display:flex;flex-direction:column;gap:var(--sp-3)}.summary{display:flex;align-items:center;gap:var(--sp-2);padding:var(--sp-3) var(--sp-4);border-radius:var(--r-md);font-weight:var(--fw-semi)}.summary.ok{color:var(--success, #16a34a);background:color-mix(in srgb,var(--success, #16a34a) 10%,transparent)}.summary.fail{color:var(--danger, #dc2626);background:color-mix(in srgb,var(--danger, #dc2626) 10%,transparent)}.s-mark{font-size:var(--fs-lg)}.check-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(15rem,1fr));gap:var(--sp-3)}.check{border:1px solid var(--border);border-radius:var(--r-md);padding:var(--sp-4);background:var(--bg)}.check.s-passed{border-color:color-mix(in srgb,var(--success, #16a34a) 55%,var(--border));background:color-mix(in srgb,var(--success, #16a34a) 10%,var(--bg))}.check.s-skipped{border-color:color-mix(in srgb,var(--warning, #f59e0b) 50%,var(--border));background:color-mix(in srgb,var(--warning, #f59e0b) 9%,var(--bg))}.check.s-failed{border-color:color-mix(in srgb,var(--danger, #dc2626) 55%,var(--border));background:color-mix(in srgb,var(--danger, #dc2626) 10%,var(--bg))}.c-head{display:flex;align-items:flex-start;gap:var(--sp-2)}.c-icon{width:1.4rem;height:1.4rem;display:grid;place-items:center;border-radius:var(--r-full);font-weight:var(--fw-bold)}.s-passed .c-icon{color:var(--success, #16a34a)}.s-failed .c-icon{color:var(--danger, #dc2626)}.s-skipped .c-icon{color:var(--warning, #f59e0b)}.c-tag{display:block;font-size:var(--fs-xs);color:var(--text-dim);letter-spacing:.04em}.c-details{margin:var(--sp-2) 0 0;font-size:var(--fs-sm);color:var(--text-mute);word-break:break-word}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: AuthorshipValidator, decorators: [{
            type: Component,
            args: [{ selector: 'ik-authorship-validator', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <section class="ik-av">
            @if (homeHref(); as href) {
                <a class="av-back" [href]="href">← {{ t('back') }}</a>
            }
            <header class="av-head">
                <h2>{{ t('title') }}</h2>
                <p>{{ t('subtitle') }}</p>
            </header>

            <div class="av-grid">
                <div class="zones">
                    <label
                        class="zone req"
                        [class.filled]="!!manifestFile()"
                        (dragover)="$event.preventDefault()"
                        (drop)="setManifest(drop($event))"
                    >
                        <input
                            type="file"
                            accept=".cff,.yaml,.yml"
                            (change)="setManifest(pick($event))"
                            hidden
                        />
                        <span class="z-top"
                            ><b>{{ t('dropManifest') }}</b
                            ><span class="req-tag">{{ t('required') }}</span></span
                        >
                        <span class="z-hint">{{
                            manifestFile() ? info(manifestFile()) : t('manifestHint')
                        }}</span>
                        @if (manifestHash()) {
                            <span class="z-hash">sha256 · {{ manifestHash().slice(0, 16) }}…</span>
                        }
                    </label>

                    <label
                        class="zone"
                        [class.filled]="!!sourceFiles().length"
                        (dragover)="$event.preventDefault()"
                        (drop)="setSources(drop($event))"
                    >
                        <input type="file" multiple (change)="setSources(pick($event))" hidden />
                        <span class="z-top"
                            ><b>{{ t('dropSources') }}</b></span
                        >
                        <span class="z-hint">{{
                            sourceFiles().length ? multiInfo(sourceFiles()) : t('sourcesHint')
                        }}</span>
                    </label>

                    <label
                        class="zone"
                        [class.filled]="!!proofFiles().length"
                        (dragover)="$event.preventDefault()"
                        (drop)="setProofs(drop($event))"
                    >
                        <input
                            type="file"
                            accept=".ots,.tsr"
                            multiple
                            (change)="setProofs(pick($event))"
                            hidden
                        />
                        <span class="z-top"
                            ><b>{{ t('dropProofs') }}</b></span
                        >
                        <span class="z-hint">{{
                            proofFiles().length ? multiInfo(proofFiles()) : t('proofsHint')
                        }}</span>
                    </label>

                    <label
                        class="zone"
                        [class.filled]="!!publicKeyFile()"
                        (dragover)="$event.preventDefault()"
                        (drop)="setKey(drop($event))"
                    >
                        <input
                            type="file"
                            accept=".asc,.gpg,.pgp,.pub,.key"
                            (change)="setKey(pick($event))"
                            hidden
                        />
                        <span class="z-top"
                            ><b>{{ t('dropKey') }}</b></span
                        >
                        <span class="z-hint">{{
                            publicKeyFile() ? info(publicKeyFile()) : t('keyHint')
                        }}</span>
                    </label>

                    @if (keyNeedsPassphrase()) {
                        <div class="passbox">
                            <label class="pass-label"
                                >{{ t('passphrase') }}
                                <input
                                    type="password"
                                    autocomplete="off"
                                    spellcheck="false"
                                    [value]="keyPassphrase"
                                    (input)="keyPassphrase = asValue($event)"
                                />
                            </label>
                            <p class="z-hint">{{ t('passphraseHint') }}</p>
                        </div>
                    }

                    <label
                        class="zone"
                        [class.filled]="!!signatureFile()"
                        (dragover)="$event.preventDefault()"
                        (drop)="setSignature(drop($event))"
                    >
                        <input type="file" accept=".asc,.sig" (change)="setSignature(pick($event))" hidden />
                        <span class="z-top"
                            ><b>{{ t('dropSignature') }}</b></span
                        >
                        <span class="z-hint">{{
                            signatureFile() ? info(signatureFile()) : t('sigHint')
                        }}</span>
                    </label>
                </div>

                <aside class="side">
                    <div class="ready">
                        <div class="r-head">
                            <b>{{ t('readiness') }}</b
                            ><span>{{ zonesFilled() }}/5</span>
                        </div>
                        <p class="z-hint">{{ t('readinessHint') }}</p>
                        <button
                            type="button"
                            class="run"
                            [disabled]="!manifestFile() || verifying()"
                            (click)="runVerification()"
                        >
                            {{ verifying() ? t('verifying') : t('run') }}
                        </button>
                    </div>
                </aside>
            </div>

            @if (checks().length) {
                <div class="results">
                    <div class="summary" [class.ok]="allPassed()" [class.fail]="!allPassed()">
                        <span class="s-mark">{{ allPassed() ? '✓' : '✗' }}</span>
                        <span>{{ allPassed() ? t('allPassed') : t('someFailed') }}</span>
                    </div>
                    <div class="check-grid">
                        @for (c of checks(); track $index) {
                            <div class="check s-{{ c.status }}">
                                <div class="c-head">
                                    <span class="c-icon">{{
                                        c.status === 'passed' ? '✓' : c.status === 'failed' ? '✗' : '—'
                                    }}</span>
                                    <div>
                                        <b>{{ c.label }}</b>
                                        <span class="c-tag">{{
                                            c.kind === 'what'
                                                ? t('whatTag')
                                                : c.kind === 'who'
                                                  ? t('whoTag')
                                                  : t('whenTag')
                                        }}</span>
                                    </div>
                                </div>
                                <p class="c-details">{{ c.details }}</p>
                            </div>
                        }
                    </div>
                </div>
            }
        </section>
    `, styles: [":host{display:block}.ik-av{border:1px solid var(--border);border-radius:var(--r-lg, 16px);background:var(--bg-elev);padding:var(--sp-6)}.av-back{display:inline-flex;align-items:center;gap:.3em;margin-bottom:var(--sp-4);font-size:var(--fs-sm);color:var(--text-mute);text-decoration:none}.av-back:hover{color:var(--brand)}.av-head h2{margin:0 0 var(--sp-1);font-size:var(--fs-xl, 1.25rem)}.av-head p{margin:0 0 var(--sp-5);color:var(--text-mute);font-size:var(--fs-sm)}.av-grid{display:grid;grid-template-columns:minmax(0,1fr) 16rem;gap:var(--sp-4)}@media(max-width:48rem){.av-grid{grid-template-columns:1fr}}.zones{display:flex;flex-direction:column;gap:var(--sp-2)}.zone{display:flex;flex-direction:column;gap:.15rem;padding:var(--sp-3) var(--sp-4);border:1px dashed var(--border-strong);border-radius:var(--r-md);cursor:pointer;background:var(--bg);transition:border-color .15s,background .15s}.zone:hover{border-color:var(--brand);background:color-mix(in srgb,var(--brand) 4%,var(--bg))}.zone.req{border-style:solid}.zone.filled{border-style:solid;border-color:color-mix(in srgb,var(--success, #16a34a) 55%,var(--border-strong));background:color-mix(in srgb,var(--success, #16a34a) 8%,var(--bg))}.zone.filled .z-top:after{content:\"\\2713\";margin-left:auto;color:var(--success, #16a34a);font-weight:var(--fw-bold)}.zone.filled .req-tag{display:none}.z-top{display:flex;align-items:center;gap:var(--sp-2)}.z-top b{font-size:var(--fs-sm)}.req-tag{font-size:var(--fs-xs);color:var(--brand);border:1px solid var(--brand);border-radius:var(--r-full);padding:0 .5em}.z-hint{font-size:var(--fs-xs);color:var(--text-dim);font-family:var(--font-mono);word-break:break-all}.z-hash{font-size:var(--fs-xs);color:var(--text-dim);font-family:var(--font-mono);opacity:.7;word-break:break-all}.passbox{display:flex;flex-direction:column;gap:.2rem;padding:0 var(--sp-1)}.pass-label{display:flex;flex-direction:column;gap:.15rem;font-size:var(--fs-xs);color:var(--text-mute)}.pass-label input{font:inherit;padding:var(--sp-1) var(--sp-2);border:1px solid var(--border-strong);border-radius:var(--r-sm);background:var(--bg);color:var(--text)}.side{display:flex;flex-direction:column}.ready{position:sticky;top:var(--sp-4);border:1px solid var(--border);border-radius:var(--r-md);padding:var(--sp-4);background:var(--bg)}.r-head{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:var(--sp-1)}.run{width:100%;margin-top:var(--sp-3);padding:var(--sp-2) var(--sp-4);border:1px solid var(--brand);border-radius:var(--r-md);background:var(--brand);color:var(--text-on-brand, #fff);font:inherit;font-weight:var(--fw-semi);cursor:pointer}.run:disabled{opacity:.5;cursor:not-allowed}.results{margin-top:var(--sp-5);display:flex;flex-direction:column;gap:var(--sp-3)}.summary{display:flex;align-items:center;gap:var(--sp-2);padding:var(--sp-3) var(--sp-4);border-radius:var(--r-md);font-weight:var(--fw-semi)}.summary.ok{color:var(--success, #16a34a);background:color-mix(in srgb,var(--success, #16a34a) 10%,transparent)}.summary.fail{color:var(--danger, #dc2626);background:color-mix(in srgb,var(--danger, #dc2626) 10%,transparent)}.s-mark{font-size:var(--fs-lg)}.check-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(15rem,1fr));gap:var(--sp-3)}.check{border:1px solid var(--border);border-radius:var(--r-md);padding:var(--sp-4);background:var(--bg)}.check.s-passed{border-color:color-mix(in srgb,var(--success, #16a34a) 55%,var(--border));background:color-mix(in srgb,var(--success, #16a34a) 10%,var(--bg))}.check.s-skipped{border-color:color-mix(in srgb,var(--warning, #f59e0b) 50%,var(--border));background:color-mix(in srgb,var(--warning, #f59e0b) 9%,var(--bg))}.check.s-failed{border-color:color-mix(in srgb,var(--danger, #dc2626) 55%,var(--border));background:color-mix(in srgb,var(--danger, #dc2626) 10%,var(--bg))}.c-head{display:flex;align-items:flex-start;gap:var(--sp-2)}.c-icon{width:1.4rem;height:1.4rem;display:grid;place-items:center;border-radius:var(--r-full);font-weight:var(--fw-bold)}.s-passed .c-icon{color:var(--success, #16a34a)}.s-failed .c-icon{color:var(--danger, #dc2626)}.s-skipped .c-icon{color:var(--warning, #f59e0b)}.c-tag{display:block;font-size:var(--fs-xs);color:var(--text-dim);letter-spacing:.04em}.c-details{margin:var(--sp-2) 0 0;font-size:var(--fs-sm);color:var(--text-mute);word-break:break-word}\n"] }]
        }], ctorParameters: () => [], propDecorators: { lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], strings: [{ type: i0.Input, args: [{ isSignal: true, alias: "strings", required: false }] }], proof: [{ type: i0.Input, args: [{ isSignal: true, alias: "proof", required: false }] }], homeHref: [{ type: i0.Input, args: [{ isSignal: true, alias: "homeHref", required: false }] }] } });

/** Local strings (en/ru + en fallback) — kept off IK_STRINGS, like the validator. */
const STR = {
    en: { label: 'Verify authorship', hint: 'Check this site’s files locally' },
    ru: { label: 'Проверить авторство', hint: 'Проверьте файлы сайта локально' },
};
const SHIELD_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">` +
    `<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg>`;
/**
 * Trust badge linking to the site's authorship-validation page. Click → the
 * in-site `/verify` (or `config.deploy.routes.verify`) where `ik-authorship-validator`
 * runs locally. Drop it anywhere (footer, hero):
 *
 * ```html
 * <ik-verify-badge [lang]="translate.currentLang" />
 * <ik-verify-badge href="/kit/verify.html" />   <!-- explicit target -->
 * ```
 */
class VerifyBadge {
    cfg = inject(SITE_KIT_CONFIG, { optional: true });
    sanitizer = inject(DomSanitizer);
    /** Active language (en/ru; falls back to en). */
    lang = input(...(ngDevMode ? [undefined, { debugName: "lang" }] : /* istanbul ignore next */ []));
    /** Explicit target URL. Defaults to `config.deploy.routes.verify`, else `/verify`. */
    href = input(...(ngDevMode ? [undefined, { debugName: "href" }] : /* istanbul ignore next */ []));
    /** Icon-only: a green shield in a circle (for footer social rows). */
    iconOnly = input(false, ...(ngDevMode ? [{ debugName: "iconOnly" }] : /* istanbul ignore next */ []));
    shieldIcon = this.sanitizer.bypassSecurityTrustHtml(SHIELD_ICON);
    copy = computed(() => {
        const l = this.lang() ?? this.cfg?.defaultLang ?? 'en';
        return STR[l] ?? STR['en']; // safe: 'en' is a fixed key of STR
    }, ...(ngDevMode ? [{ debugName: "copy" }] : /* istanbul ignore next */ []));
    /** Resolved verify-page URL: explicit input → deploy route → /verify. */
    target = computed(() => this.href() ?? this.cfg?.deploy?.routes?.['verify'] ?? '/verify', ...(ngDevMode ? [{ debugName: "target" }] : /* istanbul ignore next */ []));
    external() {
        return /^https?:\/\//i.test(this.target());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: VerifyBadge, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: VerifyBadge, isStandalone: true, selector: "ik-verify-badge", inputs: { lang: { classPropertyName: "lang", publicName: "lang", isSignal: true, isRequired: false, transformFunction: null }, href: { classPropertyName: "href", publicName: "href", isSignal: true, isRequired: false, transformFunction: null }, iconOnly: { classPropertyName: "iconOnly", publicName: "iconOnly", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ik-verify-badge" }, ngImport: i0, template: `
        <a
            class="vb"
            [class.vb--icon]="iconOnly()"
            [href]="target()"
            [attr.target]="external() ? '_blank' : null"
            [attr.rel]="external() ? 'noopener noreferrer' : null"
            [attr.aria-label]="copy().label"
            [attr.title]="copy().label"
        >
            <span class="vb__ico" [innerHTML]="shieldIcon"></span>
            @if (!iconOnly()) {
                <span class="vb__text">
                    <span class="vb__title">{{ copy().label }}</span>
                    <span class="vb__by">site-kit</span>
                </span>
            }
        </a>
    `, isInline: true, styles: [":host{display:inline-block}.vb{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);padding:.4rem .7rem .4rem .55rem;border:1px solid var(--border, #e5e5e9);border-radius:var(--r-full, 999px);background:var(--bg-elev, #fff);color:var(--text, #09090f);text-decoration:none;transition:border-color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.vb:hover{border-color:color-mix(in oklch,var(--success, #16a34a) 45%,transparent);background:color-mix(in oklch,var(--success, #16a34a) 8%,var(--bg-elev, #fff));transform:translateY(-1px)}.vb__ico{display:inline-flex;width:1.15rem;height:1.15rem;flex-shrink:0;color:var(--success, #16a34a)}.vb__ico ::ng-deep svg{width:100%;height:100%}.vb__text{display:inline-flex;flex-direction:column;line-height:1.1;min-width:0}.vb__title{font-size:var(--fs-sm, .875rem);font-weight:var(--fw-semi, 600)}.vb__by{font-size:var(--fs-xs, .75rem);font-weight:var(--fw-bold, 700);letter-spacing:var(--ls-wide, .06em);text-transform:lowercase;color:var(--text-dim, #8e8ea0)}.vb--icon{width:36px;height:36px;padding:0;justify-content:center;border-radius:50%}.vb--icon .vb__ico{width:1rem;height:1rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: VerifyBadge, decorators: [{
            type: Component,
            args: [{ selector: 'ik-verify-badge', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        <a
            class="vb"
            [class.vb--icon]="iconOnly()"
            [href]="target()"
            [attr.target]="external() ? '_blank' : null"
            [attr.rel]="external() ? 'noopener noreferrer' : null"
            [attr.aria-label]="copy().label"
            [attr.title]="copy().label"
        >
            <span class="vb__ico" [innerHTML]="shieldIcon"></span>
            @if (!iconOnly()) {
                <span class="vb__text">
                    <span class="vb__title">{{ copy().label }}</span>
                    <span class="vb__by">site-kit</span>
                </span>
            }
        </a>
    `, host: { class: 'ik-verify-badge' }, styles: [":host{display:inline-block}.vb{display:inline-flex;align-items:center;gap:var(--sp-2, .5rem);padding:.4rem .7rem .4rem .55rem;border:1px solid var(--border, #e5e5e9);border-radius:var(--r-full, 999px);background:var(--bg-elev, #fff);color:var(--text, #09090f);text-decoration:none;transition:border-color var(--dur-fast, .15s) var(--ease-out, ease),background var(--dur-fast, .15s) var(--ease-out, ease),transform var(--dur-fast, .15s) var(--ease-out, ease)}.vb:hover{border-color:color-mix(in oklch,var(--success, #16a34a) 45%,transparent);background:color-mix(in oklch,var(--success, #16a34a) 8%,var(--bg-elev, #fff));transform:translateY(-1px)}.vb__ico{display:inline-flex;width:1.15rem;height:1.15rem;flex-shrink:0;color:var(--success, #16a34a)}.vb__ico ::ng-deep svg{width:100%;height:100%}.vb__text{display:inline-flex;flex-direction:column;line-height:1.1;min-width:0}.vb__title{font-size:var(--fs-sm, .875rem);font-weight:var(--fw-semi, 600)}.vb__by{font-size:var(--fs-xs, .75rem);font-weight:var(--fw-bold, 700);letter-spacing:var(--ls-wide, .06em);text-transform:lowercase;color:var(--text-dim, #8e8ea0)}.vb--icon{width:36px;height:36px;padding:0;justify-content:center;border-radius:50%}.vb--icon .vb__ico{width:1rem;height:1rem}\n"] }]
        }], propDecorators: { lang: [{ type: i0.Input, args: [{ isSignal: true, alias: "lang", required: false }] }], href: [{ type: i0.Input, args: [{ isSignal: true, alias: "href", required: false }] }], iconOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOnly", required: false }] }] } });

const LICENSE_BUILD = "719c74c 2026-05-28";
const LICENSE_CATALOG = {
    "mit": {
        "name": "MIT License",
        "text": "MIT License\n\nCopyright (c) {{YEARS}} Ilia Arestov (https://ilia.ae/en/)\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE."
    },
    "proprietary": {
        "name": "Proprietary License",
        "text": "PROPRIETARY SOFTWARE LICENSE / ЛИЦЕНЗИЯ НА ПРОПРИЕТАРНОЕ ПО\n\nCopyright (c) {{YEARS}} Ilia Arestov (https://ilia.ae/en/). All rights reserved.\nCopyright (c) {{YEARS}} Ilia Arestov (https://ilia.ae/en/). Все права защищены.\n\n======================================================================\nENGLISH\n======================================================================\n\n1. GRANT OF USE\n   This software is provided solely for personal use by the original\n   purchaser (the \"Licensee\") who has paid the applicable license fee\n   to the author (the \"Author\"). The Licensee is granted a limited,\n   non-exclusive, non-transferable right to use this software in\n   accordance with this license.\n\n2. RESTRICTIONS\n   The Licensee SHALL NOT, without prior written consent from the\n   Author:\n   a) Copy, reproduce, distribute, sublicense, sell, lease, lend,\n      or otherwise transfer this software or any portion thereof to\n      any third party;\n   b) Modify, adapt, translate, reverse-engineer, decompile,\n      disassemble, or create derivative works based on this software;\n   c) Remove, alter, or obscure any proprietary notices, labels, or\n      marks on this software;\n   d) Use this software for any commercial purpose beyond the scope\n      agreed upon with the Author;\n   e) Make this software available on any public or shared network,\n      repository, or file-sharing service;\n   f) Deploy additional instances of this software beyond what is\n      authorized by the Author.\n\n3. PAYMENT\n   Use of this software requires payment of the license fee to the\n   Author. Unauthorized use without payment constitutes a violation\n   of this license and applicable copyright laws.\n\n4. AUTHOR APPROVAL REQUIRED\n   Any action not explicitly permitted by this license — including\n   but not limited to redistribution, modification, public display,\n   deployment on additional servers, or granting access to third\n   parties — requires prior written approval from the Author.\n\n5. OWNERSHIP\n   This software and all copies thereof remain the exclusive property\n   of the Author. No title or ownership rights are transferred to the\n   Licensee.\n\n6. TERMINATION\n   This license is effective until terminated. It will terminate\n   automatically without notice if the Licensee fails to comply with\n   any provision of this license. Upon termination, the Licensee must\n   destroy all copies of the software in their possession.\n\n7. DISCLAIMER OF WARRANTY\n   THIS SOFTWARE IS PROVIDED \"AS IS\" WITHOUT WARRANTY OF ANY KIND,\n   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF\n   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND\n   NONINFRINGEMENT.\n\n8. LIMITATION OF LIABILITY\n   IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES, OR\n   OTHER LIABILITY ARISING FROM THE USE OR INABILITY TO USE THIS\n   SOFTWARE.\n\n9. GOVERNING LAW\n   This license shall be governed by and construed in accordance with\n   applicable copyright and intellectual property laws.\n\n======================================================================\nРУССКИЙ\n======================================================================\n\n1. ПРЕДОСТАВЛЕНИЕ ПРАВА ИСПОЛЬЗОВАНИЯ\n   Данное программное обеспечение предоставляется исключительно для\n   личного использования первоначальным покупателем («Лицензиат»),\n   оплатившим соответствующий лицензионный сбор автору («Автор»).\n   Лицензиату предоставляется ограниченное, неисключительное,\n   непередаваемое право на использование данного ПО в соответствии\n   с настоящей лицензией.\n\n2. ОГРАНИЧЕНИЯ\n   Лицензиат НЕ ИМЕЕТ ПРАВА без предварительного письменного согласия\n   Автора:\n   а) Копировать, воспроизводить, распространять, сублицензировать,\n      продавать, сдавать в аренду, предоставлять в пользование или\n      иным образом передавать данное ПО или его части третьим лицам;\n   б) Модифицировать, адаптировать, переводить, выполнять обратную\n      разработку, декомпилировать, дизассемблировать или создавать\n      производные произведения на основе данного ПО;\n   в) Удалять, изменять или скрывать какие-либо уведомления о\n      правах собственности, метки или знаки на данном ПО;\n   г) Использовать данное ПО в коммерческих целях, выходящих за\n      рамки согласованных с Автором;\n   д) Размещать данное ПО в любой публичной или общей сети,\n      репозитории или файлообменном сервисе;\n   е) Развёртывать дополнительные экземпляры данного ПО сверх\n      разрешённых Автором.\n\n3. ОПЛАТА\n   Использование данного ПО требует оплаты лицензионного сбора\n   Автору. Несанкционированное использование без оплаты является\n   нарушением настоящей лицензии и применимых законов об авторском\n   праве.\n\n4. ТРЕБУЕТСЯ СОГЛАСОВАНИЕ С АВТОРОМ\n   Любые действия, явно не разрешённые настоящей лицензией, включая,\n   но не ограничиваясь: распространение, модификация, публичный\n   показ, развёртывание на дополнительных серверах или предоставление\n   доступа третьим лицам — требуют предварительного письменного\n   согласия Автора.\n\n5. ПРАВО СОБСТВЕННОСТИ\n   Данное ПО и все его копии остаются исключительной собственностью\n   Автора. Никакие права собственности не передаются Лицензиату.\n\n6. ПРЕКРАЩЕНИЕ ДЕЙСТВИЯ\n   Настоящая лицензия действует до её прекращения. Она прекращает\n   действие автоматически без уведомления в случае нарушения\n   Лицензиатом любого положения настоящей лицензии. При прекращении\n   действия Лицензиат обязан уничтожить все копии ПО.\n\n7. ОТКАЗ ОТ ГАРАНТИЙ\n   ДАННОЕ ПО ПРЕДОСТАВЛЯЕТСЯ «КАК ЕСТЬ» БЕЗ КАКИХ-ЛИБО ГАРАНТИЙ,\n   ЯВНЫХ ИЛИ ПОДРАЗУМЕВАЕМЫХ, ВКЛЮЧАЯ, НО НЕ ОГРАНИЧИВАЯСЬ\n   ГАРАНТИЯМИ ТОВАРНОЙ ПРИГОДНОСТИ, ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЁННОЙ\n   ЦЕЛИ И НЕНАРУШЕНИЯ ПРАВ.\n\n8. ОГРАНИЧЕНИЕ ОТВЕТСТВЕННОСТИ\n   НИ ПРИ КАКИХ ОБСТОЯТЕЛЬСТВАХ АВТОР НЕ НЕСЁТ ОТВЕТСТВЕННОСТИ ЗА\n   ЛЮБЫЕ ПРЕТЕНЗИИ, УБЫТКИ ИЛИ ИНУЮ ОТВЕТСТВЕННОСТЬ, ВОЗНИКАЮЩУЮ\n   В СВЯЗИ С ИСПОЛЬЗОВАНИЕМ ИЛИ НЕВОЗМОЖНОСТЬЮ ИСПОЛЬЗОВАНИЯ\n   ДАННОГО ПО.\n\n9. ПРИМЕНИМОЕ ПРАВО\n   Настоящая лицензия регулируется и толкуется в соответствии с\n   применимыми законами об авторском праве и интеллектуальной\n   собственности."
    },
    "polyform-nc": {
        "name": "PolyForm Noncommercial 1.0.0",
        "text": "Required Notice: Copyright (c) {{YEARS}} Ilia Arestov (https://ilia.ae/en/)\nFor commercial licensing inquiries: code@ilia.ae\n\n# PolyForm Noncommercial License 1.0.0\n\n<https://polyformproject.org/licenses/noncommercial/1.0.0>\n\n## Acceptance\n\nIn order to get any license under these terms, you must agree\nto them as both strict obligations and conditions to all your\nlicenses.\n\n## Copyright License\n\nThe licensor grants you a copyright license for the software\nto do everything you might do with the software that would\notherwise infringe the licensor's copyright in it for any\npermitted purpose. However, you may only distribute the software\naccording to [Distribution License](#distribution-license) and\nmake changes or new works based on the software according to\n[Changes and New Works License](#changes-and-new-works-license).\n\n## Distribution License\n\nThe licensor grants you an additional copyright license to\ndistribute copies of the software. Your license to distribute\ncovers distributing the software with changes and new works\npermitted by [Changes and New Works License](#changes-and-new-works-license).\n\n## Notices\n\nYou must ensure that anyone who gets a copy of any part of the\nsoftware from you also gets a copy of these terms or the URL\nfor them above, as well as copies of any plain-text lines\nbeginning with `Required Notice:` that the licensor provided\nwith the software. For example:\n\n> Required Notice: Copyright Yoyodyne, Inc. (http://example.com)\n\n## Changes and New Works License\n\nThe licensor grants you an additional copyright license to make\nchanges and new works based on the software for any permitted\npurpose.\n\n## Patent License\n\nThe licensor grants you a patent license for the software that\ncovers patent claims the licensor can license, or becomes able\nto license, that you would infringe by using the software.\n\n## Noncommercial Purposes\n\nAny noncommercial purpose is a permitted purpose.\n\n## Personal Uses\n\nPersonal use for research, experiment, and testing for the\nbenefit of public knowledge, personal study, private\nentertainment, hobby projects, amateur pursuits, or religious\nobservance, without any anticipated commercial application,\nis use for a permitted purpose.\n\n## Noncommercial Organizations\n\nUse by any charitable organization, educational institution,\npublic research organization, public safety or health\norganization, environmental protection organization, or\ngovernment institution is use for a permitted purpose regardless\nof the source of funding or obligations resulting from the\nfunding.\n\n## Fair Use\n\nYou may have \"fair use\" rights for the software under the law.\nThese terms do not limit them.\n\n## No Other Rights\n\nThese terms do not allow you to sublicense or transfer any of\nyour licenses to anyone else, or prevent the licensor from\ngranting licenses to anyone else. These terms do not imply any\nother licenses.\n\n## Patent Defense\n\nIf you make any written claim that the software infringes or\ncontributes to infringement of any patent, your patent license\nfor the software granted under these terms ends immediately. If\nyour company makes such a claim, your patent license ends\nimmediately for work on behalf of your company.\n\n## Violations\n\nThe first time you are notified in writing that you have\nviolated any of these terms, or done anything with the software\nnot covered by your licenses, your licenses can nonetheless\ncontinue if you come into full compliance with these terms, and\ntake practical steps to correct past violations, within 32 days\nof receiving notice. Otherwise, all your licenses end\nimmediately.\n\n## No Liability\n\n***As far as the law allows, the software comes as is, without\nany warranty or condition, and the licensor will not be liable\nto you for any damages arising out of these terms or the use\nor nature of the software, under any kind of legal claim.***\n\n## Definitions\n\nThe **licensor** is the individual or entity offering these\nterms, and the **software** is the software the licensor makes\navailable under these terms.\n\n**You** refers to the individual or entity agreeing to these\nterms.\n\n**Your company** is any legal entity, sole proprietorship, or\nother kind of organization that you work for, plus all\norganizations that have control over, are under the control of,\nor are under common control with that organization. **Control**\nmeans ownership of substantially all the assets of an entity,\nor the power to direct its management and policies by vote,\ncontract, or otherwise. Control can be direct or indirect.\n\n**Your licenses** are all the licenses granted to you for the\nsoftware under these terms.\n\n**Use** means anything you do with the software requiring one\nof your licenses."
    },
    "nda-confidential": {
        "name": "INTEGRA NDA Confidential",
        "text": "PLACEHOLDER: INTEGRA NDA Confidential\nRequired by: integra.supply\nSource: https://github.com/ilia-ae/uae-stars/blob/main/LICENSE\n\nBilingual NDA / confidential-platform license — the full text is maintained in the\nproject's OWN repo (see Source above), not consolidated into this bank yet.\nReplace this placeholder with the real LICENSE text to ship it via the kit.",
        "stub": true,
        "source": "https://github.com/ilia-ae/uae-stars/blob/main/LICENSE"
    },
    "source-available-commercial": {
        "name": "Source-Available Commercial v1",
        "text": "PLACEHOLDER: Source-Available Commercial v1\nRequired by: aliro.mayday.software\nSource: https://github.com/ilia-ae/aliro-mayday-software/blob/main/LICENSE\n\nBespoke source-available commercial license — the full text is maintained in the\nproject's OWN repo (see Source above), not consolidated into this bank yet.\nReplace this placeholder with the real LICENSE text to ship it via the kit.",
        "stub": true,
        "source": "https://github.com/ilia-ae/aliro-mayday-software/blob/main/LICENSE"
    }
};

/** Resolve `config.license` → its catalog entry, substituting `{{YEARS}}` from `copyright.startYear`.
 *  `lang` localizes the display NAME (the license TEXT stays as authored in the bank). */
function resolveLicense(cfg, currentYear = new Date().getFullYear(), lang) {
    const key = cfg?.license;
    if (!key)
        return undefined;
    const localized = (fallback) => (lang && LICENSE_NAME_I18N[key]?.[lang]) || fallback;
    const entry = LICENSE_CATALOG[key];
    if (!entry)
        return { key, name: localized(key), text: '', stub: true };
    const start = cfg?.copyright?.startYear;
    const years = start && start < currentYear ? `${start}–${currentYear}` : String(currentYear);
    return {
        key,
        name: localized(entry.name),
        text: entry.text.replace(/\{\{YEARS\}\}/g, years),
        stub: !!entry.stub,
        source: entry.source,
    };
}
/**
 * Full license page/section — renders the resolved license text (or, for a stub, a link to the
 * canonical text in its repo). Reads `config.license` + `config.copyright` from SITE_KIT_CONFIG.
 */
class IkLicense {
    cfg = inject(SITE_KIT_CONFIG, { optional: true });
    /** Optional explicit license (else resolved from SITE_KIT_CONFIG). */
    license = input(undefined, ...(ngDevMode ? [{ debugName: "license" }] : /* istanbul ignore next */ []));
    /** Note shown for a stub license (overridable for i18n). */
    noteLabel = input('The full text is maintained in the project repository:', ...(ngDevMode ? [{ debugName: "noteLabel" }] : /* istanbul ignore next */ []));
    lic = computed(() => this.license() ?? resolveLicense(this.cfg), ...(ngDevMode ? [{ debugName: "lic" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: IkLicense, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: IkLicense, isStandalone: true, selector: "ik-license", inputs: { license: { classPropertyName: "license", publicName: "license", isSignal: true, isRequired: false, transformFunction: null }, noteLabel: { classPropertyName: "noteLabel", publicName: "noteLabel", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
        @if (lic(); as l) {
            <article class="ik-license">
                <h1 class="ik-license__name">{{ l.name }}</h1>
                @if (l.stub) {
                    <p class="ik-license__note">
                        {{ noteLabel() }}
                        @if (l.source) {
                            <a
                                class="ik-license__src"
                                [href]="l.source"
                                target="_blank"
                                rel="noopener noreferrer"
                                >{{ l.source }} ↗</a
                            >
                        }
                    </p>
                } @else {
                    <pre class="ik-license__text">{{ l.text }}</pre>
                }
            </article>
        }
    `, isInline: true, styles: [".ik-license{max-width:52rem;margin-inline:auto;padding:var(--sp-8, 2rem) var(--sp-6, 1.5rem)}.ik-license__name{margin:0 0 var(--sp-5, 1.25rem);font-size:var(--fs-2xl, 1.5rem);font-weight:var(--fw-bold, 700)}.ik-license__text{margin:0;padding:var(--sp-5, 1.25rem);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 12px);background:var(--bg-elev, #fff);color:var(--text, #09090f);font-family:var(--font-mono, ui-monospace, monospace);font-size:var(--fs-sm, .875rem);line-height:1.6;white-space:pre-wrap;word-break:break-word;overflow-x:auto}.ik-license__note{color:var(--text-mute, #555);font-size:var(--fs-sm, .875rem)}.ik-license__src{display:block;margin-top:var(--sp-2, .5rem);color:var(--brand, #6d28d9);word-break:break-all}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: IkLicense, decorators: [{
            type: Component,
            args: [{ selector: 'ik-license', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
        @if (lic(); as l) {
            <article class="ik-license">
                <h1 class="ik-license__name">{{ l.name }}</h1>
                @if (l.stub) {
                    <p class="ik-license__note">
                        {{ noteLabel() }}
                        @if (l.source) {
                            <a
                                class="ik-license__src"
                                [href]="l.source"
                                target="_blank"
                                rel="noopener noreferrer"
                                >{{ l.source }} ↗</a
                            >
                        }
                    </p>
                } @else {
                    <pre class="ik-license__text">{{ l.text }}</pre>
                }
            </article>
        }
    `, styles: [".ik-license{max-width:52rem;margin-inline:auto;padding:var(--sp-8, 2rem) var(--sp-6, 1.5rem)}.ik-license__name{margin:0 0 var(--sp-5, 1.25rem);font-size:var(--fs-2xl, 1.5rem);font-weight:var(--fw-bold, 700)}.ik-license__text{margin:0;padding:var(--sp-5, 1.25rem);border:1px solid var(--border, #e5e5e9);border-radius:var(--r-lg, 12px);background:var(--bg-elev, #fff);color:var(--text, #09090f);font-family:var(--font-mono, ui-monospace, monospace);font-size:var(--fs-sm, .875rem);line-height:1.6;white-space:pre-wrap;word-break:break-word;overflow-x:auto}.ik-license__note{color:var(--text-mute, #555);font-size:var(--fs-sm, .875rem)}.ik-license__src{display:block;margin-top:var(--sp-2, .5rem);color:var(--brand, #6d28d9);word-break:break-all}\n"] }]
        }], propDecorators: { license: [{ type: i0.Input, args: [{ isSignal: true, alias: "license", required: false }] }], noteLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "noteLabel", required: false }] }] } });

/**
 * Starter Privacy / Terms copy you can drop straight into `config.legal[].body` so the
 * footer's in-app policy panels have real text on day one (the kit only ships built-in text
 * for the LICENSE and the cookie policy — Privacy/Terms are site-specific, see the footer docs).
 *
 * ⚠️ These are TEMPLATES, not legal advice and not one-size-fits-all. They describe a
 * privacy-first, mostly-static site that collects little/no personal data. **Read and adapt
 * them to your product and jurisdiction before shipping** — e.g. if you add forms, accounts,
 * analytics, payments, a wallet connect or a token sale, expand the data/processing and
 * liability sections accordingly. Blank lines separate paragraphs (the panel splits on them).
 *
 * ```ts
 * import { SAMPLE_LEGAL_LINKS } from '@ilia-ae/site-kit';
 * provideSiteKit({ …, legal: SAMPLE_LEGAL_LINKS });
 * // or one at a time:
 * import { SAMPLE_PRIVACY } from '@ilia-ae/site-kit';
 * legal: [{ label: { en: 'Privacy', ru: 'Конфиденциальность' }, body: SAMPLE_PRIVACY, updated: '2026-06-19T00:00:00Z' }]
 * ```
 */
const SAMPLE_PRIVACY = {
    en: 'Minimal data\n\n' +
        'We do not collect, store, log, or sell your personal data. This site runs in your browser; ' +
        'we run no accounts, advertising networks, or third-party analytics.\n\n' +
        'No tracking\n\n' +
        'We set no tracking or advertising cookies. The only thing kept is your theme and language ' +
        'preference, stored locally in your browser — it never reaches our servers.\n\n' +
        'Third-party services\n\n' +
        'The site is delivered over a CDN and may load assets (fonts, embedded media) from third ' +
        'parties. Your browser requests those directly, so those providers may process technical data ' +
        'such as your IP address under their own privacy policies; we do not proxy, see, or store it.\n\n' +
        'Contact\n\n' +
        'If you reach us through a channel linked here (email, messenger), that conversation is handled ' +
        'by the provider of that service. For any privacy question, use the contacts in the footer.',
    ru: 'Минимум данных\n\n' +
        'Мы не собираем, не храним, не логируем и не продаём ваши персональные данные. Сайт работает в ' +
        'вашем браузере; у нас нет аккаунтов, рекламных сетей и сторонней аналитики.\n\n' +
        'Без отслеживания\n\n' +
        'Мы не используем трекинговые и рекламные куки. Единственное, что хранится, — выбранные тема и ' +
        'язык; они остаются локально в вашем браузере и не попадают на наши серверы.\n\n' +
        'Сторонние сервисы\n\n' +
        'Сайт раздаётся через CDN и может загружать ресурсы (шрифты, встроенные медиа) со сторонних ' +
        'сервисов. Браузер обращается к ним напрямую, поэтому эти провайдеры могут обрабатывать ' +
        'технические данные (например, ваш IP) согласно своим политикам; мы их не проксируем, не видим ' +
        'и не храним.\n\n' +
        'Контакты\n\n' +
        'Если вы пишете нам через указанный здесь канал (email, мессенджер), переписка обрабатывается ' +
        'провайдером соответствующего сервиса. По вопросам конфиденциальности используйте контакты в футере.',
};
const SAMPLE_TERMS = {
    en: 'As-is, no warranty\n\n' +
        'This site and its content are provided "as is", without warranty of any kind, express or ' +
        'implied, for informational purposes only.\n\n' +
        'Your responsibility\n\n' +
        'You use the site at your own risk. We are not liable for any decisions, damages, or losses ' +
        'arising from its use or content.\n\n' +
        'Acceptable use\n\n' +
        'Use the site lawfully. Do not attempt to disrupt, overload, reverse-engineer, or misuse it, ' +
        'and do not use it to infringe the rights of others.\n\n' +
        'Changes\n\n' +
        'We may update these terms from time to time; continued use of the site means you accept the ' +
        'current version.',
    ru: 'Как есть, без гарантий\n\n' +
        'Сайт и его содержимое предоставляются «как есть», без каких-либо гарантий, явных или ' +
        'подразумеваемых, и только в информационных целях.\n\n' +
        'Ваша ответственность\n\n' +
        'Вы используете сайт на свой риск. Мы не несём ответственности за решения, ущерб или потери, ' +
        'связанные с его использованием или содержимым.\n\n' +
        'Допустимое использование\n\n' +
        'Используйте сайт законно. Не пытайтесь нарушать его работу, перегружать, декомпилировать или ' +
        'использовать не по назначению, а также нарушать права других лиц.\n\n' +
        'Изменения\n\n' +
        'Мы можем время от времени обновлять эти условия; продолжая пользоваться сайтом, вы принимаете ' +
        'текущую версию.',
};
/** Ready-to-drop `config.legal` array (Privacy + Terms) using the sample bodies above as
 *  in-app policy panels. Set your own `updated` timestamp and adapt the text before shipping. */
const SAMPLE_LEGAL_LINKS = [
    { label: { en: 'Privacy Policy', ru: 'Политика конфиденциальности' }, body: SAMPLE_PRIVACY },
    { label: { en: 'Terms of Service', ru: 'Условия использования' }, body: SAMPLE_TERMS },
];

/*
 * Public API surface of @ilia-ae/site-kit
 * Everything a consuming app may import lives here.
 */
// ── Configuration ────────────────────────────────────────────

/**
 * Generated bundle index. Do not edit.
 */

export { AuthorshipValidator, ContactQr, CookieConsent, DEFAULT_REDIRECT_SECONDS, FamilyLinks, Footer, IK_FAMILY, IK_FAMILY_ORDER, IK_LANGUAGES, IK_STRINGS, IK_THEME_OPTIONS, IkClose, IkCountdown, IkLicense, Install, IntegrityService, LICENSE_BUILD, LICENSE_CATALOG, LangSwitcher, Nav, PWA_SPLASH_DEVICES, Projects, ProjectsList, Pwa, SAMPLE_LEGAL_LINKS, SAMPLE_PRIVACY, SAMPLE_TERMS, SITE_KIT_ACCENT, SITE_KIT_BUILD_DATE, SITE_KIT_CONFIG, SITE_KIT_GLYPH, SITE_KIT_NAME, SITE_KIT_SCHEMA_VERSION, SITE_KIT_VERSION, SSHSIG_NAMESPACE, STATUS_ENTRIES, STATUS_LANGUAGES, Seo, SocialLinks, StatusPage, TECH_FALLBACK, TECH_ICONS, TechnoBg, Technologies, ThemeToggle, VerifyBadge, VerifyMark, applyFaviconTags, applyPwaTags, buildManifest, buildOgSvg, buildSeoTags, checkWhat, checkWhen, faviconSourceSvg, faviconTags, formatPhone, gpgAvailable, ikLanguage, ikLanguages, ikString, isIos, isRtl, isSshSignature, isStandalone, licenseName, localizeText, localizeUrl, needsPassphrase, parseManifestHashes, parseOts, parseTsr, pickHostKey, provideSiteKit, provideSiteKitForHost, provideSiteKitPwa, provideSiteKitTabler, pwaMetaTags, pwaSplashLinks, resolveLicense, resolveLinkHref, resolveSiteKitConfig, sha256OfFile, sha256OfString, splashMedia, statusCopy, statusEntry, verifyGpg, verifySshSig };
//# sourceMappingURL=ilia-ae-site-kit.mjs.map
