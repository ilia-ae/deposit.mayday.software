import * as _angular_core from '@angular/core';
import { InjectionToken, EnvironmentProviders, OnDestroy, OnInit, AfterViewInit } from '@angular/core';
import * as _ilia_ae_site_kit from '@ilia-ae/site-kit';
import { SafeHtml } from '@angular/platform-browser';

/**
 * @ilia-ae/site-kit — shared configuration contract.
 *
 * ONE settings object per site, provided via `provideSiteKit({...})`. Two layers:
 *   • Look & feel  → CSS custom properties (defined by the host app; inherited).
 *   • Content/data → this object (brand, links, projects, contact, copyright…).
 *
 * Content AND design are both modifiable: design via CSS variables / per-block
 * class hooks; content via this config. Multi-domain sites use
 * `provideSiteKitForHost({...})` to auto-pick the right config by hostname.
 */
/**
 * A user-facing string that may be a single value OR a per-language map, so one
 * config holds every translation: `'Privacy'` or `{ en: 'Privacy', ru: 'Конфиденциальность' }`.
 * Resolved by the active language via `localizeText()`.
 */
type LocalizedString = string | Record<string, string>;
/**
 * A link whose URL adapts to the active language. Resolution precedence (see
 * `resolveLinkHref`): `urls` → `pathByLang` → `localize` → `url`.
 *   { url: 'https://ilia.ae', localize: true }              → ru: ilia.ae · en: ilia.ae/en
 *   { url: 'https://ilia.ae', pathByLang: { en: '/en/' } }  → ru: ilia.ae · en: ilia.ae/en/
 *   { url: 'https://ilia.ae', pathByLang: { ru: '/', en: '/en/' } } → both get a modifier
 *   { url: '...', urls: { en: 'https://ilia.ae/en' } }      → explicit full per-lang URL
 * `label` may itself be a per-language map (LocalizedString).
 */
interface SiteKitLink {
    label: LocalizedString;
    url: string;
    /** Insert `/<lang>` for non-default languages. */
    localize?: boolean;
    /**
     * Per-language path modifier appended to the URL's domain: `domain(url) + modifier`.
     * Languages absent from the map fall back to the bare `url`, so a modifier can apply
     * to one language, none, or both. E.g. `{ en: '/en/' }` → ru: domain · en: domain/en/.
     */
    pathByLang?: Record<string, string>;
    /** Explicit per-language URLs (wins over everything). */
    urls?: Record<string, string>;
    /** Force open in a new tab. Auto-detected for http(s) when omitted. */
    external?: boolean;
}
interface SiteKitBrand {
    name: string;
    /** Logo URL or inline SVG data-uri. */
    logoUrl?: string;
    /**
     * Inline SVG glyph whose paths use `currentColor` (e.g. a brand mark/icon).
     * Rendered in the QR card's header mark (in `--brand`) and centre emblem (in
     * white on the brand gradient), so it inherits the right colour in each spot.
     * Preferred over `logoUrl` for those two places; `logoUrl` still drives nav/footer.
     */
    glyph?: string;
    /** Single-letter/short monogram fallback when there's no logo. */
    monogram?: string;
    url?: string;
    tagline?: LocalizedString;
    /**
     * Hide the brand NAME label in nav + footer, leaving only the logo/glyph/monogram
     * mark. For minimal, icon-only brands (e.g. a tool whose mark stands alone). The
     * name still feeds alt text, OG, the QR card and copyright — only the visible
     * topbar/footer label is suppressed.
     */
    nameHidden?: boolean;
}
interface SiteKitCopyright {
    holder?: string;
    startYear?: number;
    suffix?: LocalizedString;
}
interface SiteKitQr {
    /** Value ENCODED into the generated QR (URL or vCard). Defaults to `brand.url`. */
    data?: string;
    /**
     * Make the encoded value locale-aware (like SiteKitLink): for non-default
     * languages the QR points to `/<lang>` of `data`. Lets one QR page serve a
     * different target per language — `?lang=en` → site/en, `?lang=ru` → site.
     */
    localize?: boolean;
    /** Explicit per-language QR targets (wins over `localize`): `{ en: 'https://site/en' }`. */
    urls?: Record<string, string>;
    /** Pre-rendered image instead of generating (URL / data-uri). Overrides `data`. */
    src?: string;
    /**
     * Lede text shown ABOVE the QR (value proposition). A plain string, or a
     * per-language map `{ en: '…', ru: '…' }` so it translates with `[lang]`.
     */
    lede?: string | Record<string, string>;
    /**
     * Hint shown BELOW the QR (italic). String or per-language map. Falls back
     * to a localized "Scan to connect".
     */
    caption?: string | Record<string, string>;
    alt?: string;
    /** Click-through target wrapping the QR. */
    href?: string;
    /**
     * Overlay a small brand badge (monogram/logo) at the QR center. Stays
     * scannable thanks to 'H' error-correction (~30%). Defaults ON when the
     * brand has a monogram or logo; set `false` to opt out.
     */
    badge?: boolean;
    /** Decorative L-corner accents around the white QR frame. Default 'none'. */
    corners?: 'none' | 'dashed' | 'solid';
}
interface SiteKitContact {
    qr?: SiteKitQr;
    email?: string;
    telegram?: string;
    /** WhatsApp: a phone number or a wa.me link. */
    whatsapp?: string;
    phone?: string;
    /** The site itself, shown as a contact channel (e.g. "Website"). */
    website?: string;
    /** Link to a contact form / "write us" page. */
    contactForm?: string;
    /** Person / role / company / location for a contact card. */
    person?: string;
    role?: string;
    company?: string;
    location?: string;
    /** Quick links shown under the QR (site, blog, …) — locale-aware. */
    quickLinks?: SiteKitLink[];
    /** Which share channels to offer (defaults to a sensible set). */
    share?: SiteKitShareKind[];
    /**
     * Per-channel accent OVERRIDES (any CSS colour), keyed by share kind:
     * `{ linkedin: '#0a66c2', telegram: '#229ED9' }`. By default every chip inherits
     * the theme `--brand` (one colour for all); set a channel here to opt it into a
     * custom tint. Surfaced as `--chip-accent` (icon tint in the 'color' theme, hover
     * tint everywhere).
     */
    shareColors?: Partial<Record<SiteKitShareKind, string>>;
    /**
     * Share-button layout: 'grid' (vertical icon-over-label tiles, default) or
     * 'inline' (horizontal icon-left/label-right rows). The `ik-contact-qr`
     * `shareLayout` input overrides this per-usage.
     */
    shareLayout?: 'grid' | 'inline';
    /**
     * Share icon colour theme: 'mono' (neutral icons, brand accent only on hover,
     * default) or 'color' (icons tinted with the theme `--brand` at rest — one colour
     * for all chips unless `shareColors` overrides a channel). Overridable via the
     * `ik-contact-qr` `shareTheme` input.
     */
    shareTheme?: 'mono' | 'color';
    /**
     * Section-divider style for the share/links headers under the QR:
     *   • 'top'           — small label left-aligned with a rule above it (default)
     *   • 'center'        — label centred, a solid hairline runs left & right of it
     *   • 'center-dashed' — same, but the flanking rule is dashed
     * Overridable via the `ik-contact-qr` `sectionDivider` input.
     */
    sectionDivider?: 'top' | 'center' | 'center-dashed';
}
type SiteKitShareKind = 'native' | 'copy' | 'telegram' | 'whatsapp' | 'x' | 'linkedin' | 'facebook' | 'vk' | 'email';
type SiteKitSocialKind = 'telegram' | 'whatsapp' | 'email' | 'phone' | 'github' | 'linkedin' | 'x' | 'instagram' | 'youtube' | 'website' | 'custom';
interface SiteKitSocialLink {
    kind: SiteKitSocialKind;
    url: string;
    /** Accessible name; a string or per-language map. Default: the channel's name in the active
     *  language (Russian for `ru`, else English — "Сайт" / "Website"). */
    label?: LocalizedString;
    /** Inline SVG markup or icon URL. Required only for `kind: 'custom'`. */
    icon?: string;
    /** Locale-aware URL, same rules as SiteKitLink: `urls` → `pathByLang` → `localize` → `url`. */
    localize?: boolean;
    pathByLang?: Record<string, string>;
    urls?: Record<string, string>;
}
interface SiteKitLegalLink {
    label: LocalizedString;
    /** Link target. With `body` set this becomes the OPTIONAL "open full version" link in the panel. */
    href?: string;
    /**
     * Inline policy text shown in an in-app panel (same UX as the cookie policy panel) when the
     * link is clicked — a string or per-language map; blank lines separate paragraphs. Omit for a
     * plain link to `href`. When both are set, the panel shows `body` + an "open full" link to `href`.
     */
    body?: LocalizedString;
    /**
     * ISO-8601 timestamp of the last revision. Rendered in the panel as a full UTC datetime
     * ("Last updated: 16 Jun 2026, 18:30 UTC") — not just a year. Omit to hide the line.
     */
    updated?: string;
}
interface SiteKitVerify {
    /**
     * URL of the integrity manifest (JSON `{ commit, bundles: [{ name, sha256, url? }] }`). The
     * kit's `IntegrityService` fetches it, SHA-256-hashes the running bundles and compares —
     * surfacing verified/mismatch/… on `ik-verify-mark`. Omit to leave the mark static.
     */
    manifestUrl?: string;
    /** Hostnames treated as dev (check suppressed → `dev` status). Defaults to localhost / 127.* / *.local. */
    devHosts?: string[];
}
interface SiteKitFooterColumn {
    /** Column heading (e.g. "Proof", "Source", "Legal") — per-language aware. */
    title: LocalizedString;
    /**
     * Column entries. A plain `SiteKitLink`, OR a `SiteKitLegalLink` (one with `body`) that opens
     * the in-app policy panel on click — so About / Privacy can live INSIDE a column instead of the
     * bottom bar. Body-less entries render as normal links; `body` entries render as a panel button.
     */
    links: (SiteKitLink | SiteKitLegalLink)[];
    /**
     * Append every `config.legal` entry (About / Privacy …) to this column, rendered as policy-panel
     * buttons. A convenience for hosting the legal links inside a column without duplicating them;
     * pair with `footer.barLegal: false` to remove them from the bottom bar.
     */
    appendLegal?: boolean;
    /**
     * Expose this column as its own `<nav>` landmark (aria-label = title). Defaults to `true`
     * (backward-compatible). Set `false` for utility/legal columns so the landmark menu isn't
     * flooded — the column still renders its `<h4>` heading + `<ul>`, just not as a landmark.
     */
    landmark?: boolean;
}
/**
 * Optional rich footer: brand column (logo + subtitle + disclaimer + social
 * slot) · link columns · a bottom bar (copyright + brand tagline + tech badges).
 * With no `columns`, the footer degrades to a brand + bottom-bar strip.
 */
/** The library's signature badge ("IA · site-kit") shown in the footer by default. */
interface SiteKitSignature {
    /** Link target. Default `https://ilia.ae`. */
    href?: string;
    /** Visible label next to the monogram. Default `site-kit`. */
    label?: string;
    /** Monogram chip text. Default `IA`. */
    mono?: string;
}
/**
 * PageSpeed Insights performance score(s) shown as footer badge chip(s) — you fill the numbers in
 * by hand from your latest PSI run (no live API call), and each chip links back to PSI to RE-TEST
 * the site (`https://pagespeed.web.dev/report?url=…`). Give `mobile` and/or `desktop` — a chip is
 * rendered for each one provided (so one or both). Numbers are colour-banded like Lighthouse
 * (green ≥90 · amber 50–89 · red <50). Omit the whole object to show nothing.
 */
interface SiteKitPageSpeed {
    /** Performance score (0–100) for the mobile form factor. Omit to skip the mobile chip. */
    mobile?: number;
    /** Performance score (0–100) for the desktop form factor. Omit to skip the desktop chip. */
    desktop?: number;
    /** URL fed to the re-test link. Defaults to `seo.siteUrl` → `brand.url`. */
    url?: string;
    /** Visible label prefix on the chip tooltip. Default `PageSpeed`. */
    label?: string;
}
interface SiteKitFooter {
    /** Small line under the brand name (e.g. "by mayday.software") — per-language aware. */
    subtitle?: LocalizedString;
    /** Privacy/disclaimer paragraph shown in the brand column — per-language aware. */
    disclaimer?: LocalizedString;
    /** Link columns. Falls back to a "Legal" column built from `config.legal`. */
    columns?: SiteKitFooterColumn[];
    /**
     * Single-strip footer: drop the brand column + link columns and render ONE compact
     * row — brand mark (glyph/logo, if any) · © year · disclaimer · tech badges. For
     * minimal sites whose footer is just a bottom bar. `subtitle`/`columns` are ignored
     * in this mode; the disclaimer moves inline into the strip.
     */
    compact?: boolean;
    /**
     * Drop the brand column (logo · name · subtitle · disclaimer · social slot) in the FULL
     * footer and go straight to the link columns. For sites whose header already shows the
     * brand, so repeating it in the footer is redundant. Ignored when `compact`.
     */
    hideBrand?: boolean;
    /**
     * Render the link columns stacked in ONE column instead of the responsive auto-fit grid.
     * A tidy single-column footer (headings + links flow vertically). Ignored when `compact`.
     */
    stackColumns?: boolean;
    /**
     * Show the legal links (`config.legal`) in the bottom bar. Default `true`. Set `false` to keep
     * the bar clean (just © · disclaimer · badges) — e.g. when a column uses `appendLegal` to host
     * About / Privacy instead. Applies to both the full and compact footer.
     */
    barLegal?: boolean;
    /**
     * Built-in "our projects" row — the ILIA family of sites as real-logo chips (from the kit's
     * `IK_FAMILY` catalogue) with per-active-language URLs. `true`/`'all'` → the whole family;
     * an array picks/orders specific keys (`['mayday','deposit']`); omit/`false` → off. The CURRENT
     * site is auto-excluded (its `brand.url` origin is dropped) so a footer never links to itself.
     * Keys: ilia · mayday · deposit · aliro · monolith · netcheck · integra.
     */
    projects?: boolean | 'all' | string[];
    /**
     * Where the full footer puts its icon row — the `slot=extra` icons (social, verify shield) and
     * the "our projects" chips. `'row'` (default): one centered row under the brand + columns grid.
     * `'brand'`: at the foot of the brand column, left-aligned, under the disclaimer — keep it to
     * six icons or so (e.g. a verify shield + five `projects`) so they stay on one line at every width. Ignored with `hideBrand` or `compact`.
     */
    extras?: 'row' | 'brand';
    /**
     * Opt-in utility affordances rendered in the footer (all default off — backward-compatible):
     */
    /** Show a "Cookie settings" link in the legal cluster that re-opens the consent banner
     *  (`ik-cookie-consent.reopen()`, wired via a document `ik:cookie-settings` event + the
     *  footer's `(cookieSettings)` output). GDPR/CCPA: withdrawing consent must be as easy as giving it. */
    cookieSettings?: boolean;
    /** Render the built-in `ik-lang-switcher` in a footer utility row; re-emits via `(langChange)`. */
    langSwitcher?: boolean;
    /** Render the built-in `ik-theme-toggle` in a footer utility row; re-emits via `(themeChange)`. */
    themeToggle?: boolean;
    /** Surface a contact block (company · location · phone · email) from `config.contact`, with
     *  schema.org Organization microdata. */
    contact?: boolean;
    /** Show a labelled "Back to top" button (moves focus to `<main>`/top, honours reduced-motion). */
    backToTop?: boolean;
}
interface SiteKitNavItem extends SiteKitLink {
    /** Highlighted call-to-action styling. */
    cta?: boolean;
    /** Nested items → dropdown (desktop) / accordion section (mobile). */
    children?: SiteKitNavItem[];
}
/**
 * A technology used by the site — rendered as a linked badge (icon + name) by
 * `ik-technologies` (and auto-shown in the footer). `kind` picks a built-in icon
 * + a canonical URL; `name`/`url`/`icon` override those.
 *   { kind: 'angular' }                              → Angular · angular.dev · built-in icon
 *   { name: 'PrimeNG', url: 'https://primeng.org' }  → custom badge, fallback glyph
 *   { name: 'Acme', icon: '<svg…>' or 'https://…png' } → custom icon
 */
interface SiteKitTech {
    /** Known tech slug for a built-in icon + default URL (e.g. 'angular', 'typescript', 'cloudflare'). */
    kind?: string;
    /** Display name. Defaults to the kind's label. */
    name?: string;
    /** Link to the technology's site. Defaults to the kind's canonical URL. */
    url?: string;
    /** Inline SVG markup or an icon image URL — overrides the built-in kind icon. */
    icon?: string;
    /** Brand accent (hex) used to tint the badge on hover. Defaults to the kind's colour. */
    color?: string;
    /** Optional version (e.g. `'21'`, `'5.9'`) — shown as a tooltip on the badge (`Name v21`). */
    version?: string;
}
interface SiteKitProject {
    name: string;
    description?: string;
    url: string;
    /** Locale-aware URL (see SiteKitLink). */
    localize?: boolean;
    urls?: Record<string, string>;
    tags?: string[];
    status?: 'live' | 'wip' | 'archived';
    /** Logo/icon URL; falls back to a monogram of `name`. */
    logoUrl?: string;
}
/** Default auto-redirect countdown (seconds) when `status.redirect` is not configured. */
declare const DEFAULT_REDIRECT_SECONDS = 15;
interface SiteKitStatusRedirect {
    /** Seconds before auto-redirecting to home (live countdown). Omit → {@link DEFAULT_REDIRECT_SECONDS}; `0` = disabled. */
    delaySeconds?: number;
    /** Where to go. Defaults to `status.homeHref`. */
    href?: string;
}
interface SiteKitStatusOptions {
    homeHref?: string;
    /** "Home" button label. Localized; omit to use the built-in localized "home". */
    homeLabel?: LocalizedString;
    /** Support line under the error. Localized. */
    supportLine?: LocalizedString;
    /** Languages to render simultaneously on a status page. Defaults to `languages`. */
    languages?: string[];
    /** Auto-redirect to home after a visible countdown. ON by default ({@link DEFAULT_REDIRECT_SECONDS}s);
     *  set `{ delaySeconds: 0 }` to turn it off, or `{ delaySeconds }` to customise. */
    redirect?: SiteKitStatusRedirect;
    /** Show a "back" button (browser history.back). Default true. */
    showBack?: boolean;
}
/**
 * Delivery method for a site's generated error/QR pages + public config.
 *   • git        — pages committed to the site's repo, shipped to disk by its git
 *                  pipeline (aaPanel / Coolify); updates (incl. config) via git.
 *   • cloudflare — a Worker with the HTML hardcoded inline; intercepts origin
 *                  responses (incl. origin-down → 5xx). Everything lives in git.
 *   • wp         — a ready bundle the user uploads manually + edits config by hand.
 */
type SiteKitDeployTarget = 'git' | 'cloudflare' | 'wp';
interface SiteKitDeploy {
    target: SiteKitDeployTarget;
    /** Base folder, relative to the site root. Default '/kit'. */
    path?: string;
    /**
     * Per-route absolute-path overrides so a page can live OUTSIDE the base folder:
     * `{ qr: '/qr', '404': '/404.html' }`. Keys: status codes, 'qr', 'verify',
     * 'manifest', 'config', 'tokens'. A route with no extension (`/qr`) → served as
     * `<route>/`. `verify` is where `ik-verify-badge` points (default `<base>/verify.html`).
     */
    routes?: Record<string, string>;
    /** Cloudflare zone/route the Worker guards (informational; used by wrangler.toml). */
    zone?: string;
}
/**
 * Favicon + web-app-icon set, generated "from one SVG" the modern way (the 2026
 * evilmartians/RealFaviconGenerator minimal standard — no legacy 16-file bloat):
 *   • icon.svg               — scalable, dark-mode aware (primary for desktop tabs)
 *   • favicon.ico            — single 32×32, legacy + the bare `/favicon.ico` convention
 *   • apple-touch-icon.png   — 180×180, opaque background (iOS flattens alpha)
 *   • icon-192/512.png       — PWA install / Android (`purpose: any`)
 *   • icon-mask.png          — 512×512 maskable (separate file, 80% safe zone)
 *   • manifest.webmanifest   — name/short_name/icons/theme — PWA installability
 * The raster set is produced at build time (`tools/lib/favicon.mjs`, via sharp);
 * the runtime/static side only emits the `<link>`/`<meta theme-color>` head tags.
 * Adaptive: with no `favicon`, nothing is emitted; with `favicon: {}` the source
 * falls back to `brand.glyph` (tinted on the theme `--brand`) then a monogram tile.
 */
interface SiteKitFavicon {
    /**
     * Source SQUARE SVG the whole set is rasterized from — a path (resolved against
     * the config/CWD), inline `<svg…>` markup, or a `data:image/svg+xml` URI. Omit to
     * derive one from `brand.glyph` (on a `--brand` tile) or `brand.monogram`/initial.
     */
    src?: string;
    /**
     * Solid background for the rasterized PNGs (apple-touch MUST be opaque; the
     * maskable icon needs full-bleed). Any CSS colour. Defaults to the theme
     * `--brand`, then `#ffffff`.
     */
    background?: string;
    /** Foreground/tint when the icon is DERIVED from `brand.glyph` (the glyph uses currentColor). Defaults to `#ffffff`. */
    color?: string;
    /** Browser-UI `theme-color`. A single colour, or `{ light, dark }` for `prefers-color-scheme`. Defaults to the theme `--brand`. */
    themeColor?: string | {
        light?: string;
        dark?: string;
    };
    /** Public base path the generated assets are served from (e.g. `/`, `/kit`). Defaults to `deploy.path` or `/`. */
    path?: string;
    /** Emit a web manifest + 192/512/maskable icons for PWA installability. Default true. */
    manifest?: boolean;
    /** Manifest `display` mode. Default `standalone`. */
    display?: 'standalone' | 'minimal-ui' | 'fullscreen' | 'browser';
    /** Manifest `name` (defaults to `brand.name`); `short_name` defaults to `name`. */
    name?: string;
    shortName?: string;
}
/**
 * The entity a site represents — drives the JSON-LD entity node. `Organization`/`Person`
 * emit an org/person node (+ `WebSite`); `SoftwareApplication`/`Product` emit a product
 * rich-result node (with `offers`, `applicationCategory`, …). The product-only fields are
 * ignored for `Organization`/`Person`, and vice-versa.
 */
interface SiteKitSeoEntity {
    /**
     * `Organization` (company), `Person` (personal site), or `SoftwareApplication`/`Product`
     * (product rich-results). Default `Organization`.
     */
    type?: 'Organization' | 'Person' | 'SoftwareApplication' | 'Product';
    /** Entity name. Defaults to `brand.name`. */
    name?: string;
    /** Job title — `Person` only. Localized. */
    jobTitle?: LocalizedString;
    /** Logo/avatar/app icon (absolute URL or path resolved against `siteUrl`). Defaults to `brand.logoUrl`. ≥112×112 for Google. */
    image?: string;
    /** Profile URLs (`sameAs`). Defaults to the `social[]` URLs. `Organization`/`Person` only. */
    sameAs?: string[];
    /** Contact email. Defaults to `contact.email`. `Organization`/`Person` only. */
    email?: string;
    /** App category, e.g. `'BusinessApplication'`. `SoftwareApplication`/`Product`. */
    applicationCategory?: string;
    /** App sub-category, e.g. `'AI Business Process Management'`. */
    applicationSubCategory?: string;
    /** Supported OS, e.g. `'Any'`. Defaults to `'Any'` for `SoftwareApplication`. */
    operatingSystem?: string;
    /** Languages the app supports (`inLanguage`). Defaults to `config.languages`. */
    inLanguage?: string[];
    /** A single `Offer` (price + availability) for product rich-results. */
    offers?: {
        /** Numeric price as a string, e.g. `'100'`. */
        price: string;
        /** ISO 4217 currency code, e.g. `'USD'`. */
        priceCurrency: string;
        /** Schema.org availability URL, e.g. `'https://schema.org/PreOrder'` | `InStock`. */
        availability?: string;
        /** Optional offer URL. */
        url?: string;
    };
}
/**
 * Everything-SEO for a site: head meta + Open Graph + Twitter/X cards + multilingual
 * hreflang + JSON-LD structured data, plus `sitemap.xml`/`robots.txt` generation. All
 * externally validatable (Rich Results Test, schema.org validator, Lighthouse SEO).
 * Content fields accept a `LocalizedString` so one config covers every language.
 * Adaptive: with no `seo`, only sensible derivations from `brand` are emitted.
 */
interface SiteKitSeo {
    /** `<title>`. Localized. Falls back to `brand.name` (+ `· tagline`). */
    title?: LocalizedString;
    /** Title template for inner pages, `%s` = page title: `'%s — ilia.ae'`. */
    titleTemplate?: string;
    /** Meta description (~150–160 chars). Localized. Falls back to `brand.tagline`. */
    description?: LocalizedString;
    /**
     * Absolute site origin, no trailing slash: `'https://ilia.ae'`. Drives canonical,
     * `og:url`, hreflang and the sitemap. Falls back to `brand.url`.
     */
    siteUrl?: string;
    /** `robots` directive. Default `'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'`. */
    robots?: string;
    /** `<meta name="author">` (e.g. the company/person behind the site). */
    author?: string;
    /** `<meta name="referrer">` policy (e.g. `'strict-origin-when-cross-origin'`). */
    referrer?: string;
    /** Social share image — 1200×630 (absolute URL or path resolved against `siteUrl`). */
    image?: string;
    /**
     * Auto-generate the OG banner (1200×630) from brand + theme (no hand-made image):
     * the build emits `og.svg`/`og.png` next to the favicons and `og:image` points at
     * `<favicon.path>/og.png`. An explicit `image` always wins. See tools/lib/og.mjs.
     */
    ogImage?: boolean;
    /** `og:image:alt` / `twitter:image:alt`. Localized. */
    imageAlt?: LocalizedString;
    /** `og:type`. Default `'website'`. */
    ogType?: string;
    /** Twitter card type. Default `'summary_large_image'` when an image exists, else `'summary'`. */
    twitterCard?: 'summary' | 'summary_large_image';
    /** `@handle` for `twitter:site` (the site's account). */
    twitterSite?: string;
    /** `@handle` for `twitter:creator` (the author). */
    twitterCreator?: string;
    /** Structured-data entity → JSON-LD `@graph` (entity + `WebSite`). Omit to skip JSON-LD. */
    entity?: SiteKitSeoEntity;
    /** Emit `hreflang` alternates (incl. `x-default`) from `languages`/`defaultLang`. Default true when >1 language. */
    hreflang?: boolean;
    /**
     * Map a language code to an `og:locale` territory value (underscore form):
     * `{ en: 'en_US', ru: 'ru_RU' }`. Built-in defaults cover the kit's 7 languages.
     */
    locales?: Record<string, string>;
    /** Emit `sitemap.xml` + `robots.txt` (static generator). Default true when `siteUrl` is known. */
    sitemap?: boolean;
}
/** A manifest app-shortcut (jump-list entry). */
interface SiteKitPwaShortcut {
    name: string;
    shortName?: string;
    description?: string;
    /** In-app URL the shortcut opens (e.g. `/verify`, `/#contact`). */
    url: string;
}
/**
 * Installable-app (PWA) module — **Angular sites only** (uses `@angular/service-worker`
 * / ngsw; not available for the static WP/aaPanel output). Turns a kit-driven Angular
 * app into an installable PWA: an enriched web manifest (display/shortcuts/categories…),
 * a service worker (ngsw), an install prompt (`ik-install` + `Pwa` service), iOS
 * `apple-mobile-web-app-*` chrome + splash screens. Icons come from `config.favicon`.
 *
 * Enable with `provideSiteKitPwa()` in the app config (+ `serviceWorker: "ngsw-config.json"`
 * in angular.json). The static generator ignores this block.
 */
interface SiteKitPwa {
    /** Manifest `name` (defaults to `favicon.name` / `brand.name`). */
    name?: string;
    /** Manifest `short_name` (defaults to `name`). */
    shortName?: string;
    /** Manifest `description`. Localized. Falls back to `seo.description` / `brand.tagline`. */
    description?: LocalizedString;
    /** `display` mode. Default `standalone`. */
    display?: 'standalone' | 'minimal-ui' | 'fullscreen' | 'browser';
    /** `display_override` progressive list, e.g. `['window-controls-overlay', 'standalone']`. */
    displayOverride?: string[];
    /** `orientation`. Default `any`. */
    orientation?: 'any' | 'natural' | 'portrait' | 'landscape' | 'portrait-primary' | 'landscape-primary';
    /** `start_url`. Default `/`. */
    startUrl?: string;
    /** `scope`. Default `/`. */
    scope?: string;
    /** App-store `categories`, e.g. `['productivity', 'utilities']`. */
    categories?: string[];
    /** App `shortcuts` (jump list). */
    shortcuts?: SiteKitPwaShortcut[];
    /** Splash `background_color` (default `favicon.background` → theme `--brand` → `#ffffff`). */
    backgroundColor?: string;
    /** iOS status-bar style. Default `black-translucent`. */
    appleStatusBarStyle?: 'default' | 'black' | 'black-translucent';
    /** Generate + link `apple-touch-startup-image` splash screens (from the favicon SVG). Default true. */
    splash?: boolean;
    /** Register the service worker (ngsw). Default true. */
    serviceWorker?: boolean;
    /** Show the install UI (`ik-install`). Default true. */
    install?: boolean;
}
/**
 * Cookie / privacy consent banner — ANGULAR-ONLY (`ik-cookie-consent`). Self-contained:
 * remembers the choice in localStorage, GDPR-symmetric Accept/Reject, a close (×) that
 * means "essential only" (= reject), an optional `autoCloseMs` timer (also = reject), and
 * a "learn more" button that opens the FULL localized cookie policy in-app (`policyBody`),
 * optionally with a per-language link to the official full version (`policyHref`). Built-in
 * texts localize across the 7 languages; override any per language. Non-Angular sites use
 * their own banner.
 */
/** A locale-aware URL (no label) — the URL adapts to the site language. Resolved by `resolveLinkHref`. */
interface SiteKitLocalizedUrl {
    url: string;
    /** Insert `/<lang>` for non-default languages. */
    localize?: boolean;
    /** Per-language path modifier appended to the URL's domain. */
    pathByLang?: Record<string, string>;
    /** Explicit per-language URLs (wins over everything). */
    urls?: Record<string, string>;
}
interface SiteKitCookie {
    /** The FULL cookie policy, shown in the in-app "learn more" panel. Localized; blank lines separate paragraphs. Omit to use the built-in localized full policy. */
    policyBody?: LocalizedString;
    /**
     * Optional link to the OFFICIAL full policy, shown inside the panel. Locale-aware, same
     * rules as {@link SiteKitLink}: `urls` → `pathByLang` → `localize` → `url`. The URL adapts
     * to the site language (e.g. `{ url: 'https://site/privacy', localize: true }` → en: `/en/privacy`).
     */
    policyHref?: SiteKitLocalizedUrl;
    /** Banner body text. Localized; omit to use the built-in localized copy. */
    message?: LocalizedString;
    /** Accept-all button label. Localized. */
    accept?: LocalizedString;
    /** Reject (essential-only) button label. Localized. */
    reject?: LocalizedString;
    /** "Learn more" link label. Localized. */
    more?: LocalizedString;
    /** Banner placement. `bottom` (centered bar, default) or `corner` (bottom-left card). */
    position?: 'bottom' | 'corner';
    /** Auto-dismiss after N ms — treated as REJECT (essential only). Omit/0 = no timer. */
    autoCloseMs?: number;
}
/**
 * Schema version of the config CONTRACT. Bump when the shape gains/changes fields.
 * Each site's data file should declare the `schemaVersion` it was written for; the
 * inventory dashboard (tools/inventory.mjs) compares it to this to flag stale data.
 *   1 = initial config (status/footer/contact/social/legal)
 *   2 = + nav, projects, languages/defaultLang, locale links, rich contact
 *   3 = + theme design layer, status redirect/back, strings overrides
 *   4 = + deploy layer: target git/cloudflare/wp, configurable /kit path
 *   5 = + technologies tech-stack block / footer badges
 *   6 = + favicon icon-set + seo head/OG/Twitter/hreflang/JSON-LD/sitemap
 *   7 = + pwa installable-app module — Angular-only: manifest/ngsw/install/splash
 *   8 = + seo.ogImage — auto-generated OG banner from brand/theme
 *   9 = + cookie consent module (Angular-only) — config.cookie
 *  10 = + cookie.policyBody — in-app localized "learn more" policy panel
 *  11 = cookie "learn more" = FULL in-app localized policy; removed cookie.policyHref
 *  12 = status auto-redirect ON by default (DEFAULT_REDIRECT_SECONDS); { delaySeconds: 0 } disables
 *  13 = cookie.policyHref — optional locale-aware link to the official full policy
 *  14 = config.license — license type key (text pulled from the license bank)
 *  15 = brand.nameHidden / footer.compact — minimal chrome + compact footer mode
 *  16 = verify — live build-integrity status on the brand/footer surfaces
 *  17 = footer.projects — built-in "our projects" family row (real-logo chips)
 *  18 = seo.entity.type 'SoftwareApplication'/'Product' — product rich-results (offers, category)
 */
declare const SITE_KIT_SCHEMA_VERSION = 18;
/** Module version (kept in sync with package.json; stamped into a <meta> for the live dashboard check). */
declare const SITE_KIT_VERSION = "1.52.0";
interface SiteKitConfig {
    /** Schema version this data file targets (see SITE_KIT_SCHEMA_VERSION). */
    schemaVersion?: number;
    brand: SiteKitBrand;
    copyright?: SiteKitCopyright;
    contact?: SiteKitContact;
    social?: SiteKitSocialLink[];
    legal?: SiteKitLegalLink[];
    /** License type key (e.g. 'mit', 'proprietary', 'source-available-commercial') — its text
     *  lives in the license bank (../main/github_inventory/licenses); shown as a footer/notice. */
    license?: string;
    /** Rich multi-column footer (brand + columns + bottom bar). */
    footer?: SiteKitFooter;
    /**
     * "IA · site-kit" signature badge in the footer — the library's own mark (this kit IS
     * the badge). Shown by DEFAULT in every project; set `false` to hide, or pass an object
     * to customise the link/label/monogram.
     */
    signature?: boolean | SiteKitSignature;
    nav?: SiteKitNavItem[];
    projects?: SiteKitProject[];
    /** Tech stack — rendered as linked badges by `ik-technologies` (and the footer). */
    technologies?: SiteKitTech[];
    /** PageSpeed Insights score badge(s) in the footer bottom-bar (mobile/desktop), with a re-test link. */
    pageSpeed?: SiteKitPageSpeed;
    status?: SiteKitStatusOptions;
    /** Codes of languages this site offers (subset of IK_LANGUAGES). Defaults to all 7. */
    languages?: string[];
    /** Default language — links for it are NOT prefixed. */
    defaultLang?: string;
    /** Override built-in UI strings per language: `{ ru: { share: '…' } }`. */
    strings?: Record<string, Record<string, string>>;
    /**
     * DESIGN layer — CSS custom properties applied to <html> for this bundle, so
     * one config drives content AND design: `{ '--brand': '#5b43ad', '--r-lg': '20px' }`.
     * Base these on each site's real brand (e.g. mayday red, monolith #5b43ad).
     */
    theme?: Record<string, string>;
    /** How the static error/QR bundle is delivered (git / cloudflare / wp) + its path. */
    deploy?: SiteKitDeploy;
    /** Favicon + app-icon set generated from one SVG (head `<link>`s + manifest). */
    favicon?: SiteKitFavicon;
    /** All-site SEO: head meta + Open Graph + Twitter + hreflang + JSON-LD + sitemap. */
    seo?: SiteKitSeo;
    /** Installable-app (PWA) module — ANGULAR-ONLY (ngsw + manifest + install + splash). */
    pwa?: SiteKitPwa;
    /** Cookie/privacy consent banner — ANGULAR-ONLY (localized text, policy link, auto-close). */
    cookie?: SiteKitCookie;
    /** Live build-integrity check (manifest fetch + SHA-256 of running bundles) → `ik-verify-mark`. */
    verify?: SiteKitVerify;
}
/** Resolved shape: defaults applied so components never face `undefined` for derivable fields. */
interface ResolvedSiteKitConfig extends SiteKitConfig {
    copyright: Required<Pick<SiteKitCopyright, 'holder'>> & SiteKitCopyright;
    social: SiteKitSocialLink[];
    legal: SiteKitLegalLink[];
    nav: SiteKitNavItem[];
    projects: SiteKitProject[];
    technologies: SiteKitTech[];
    languages: string[];
    defaultLang: string;
    status: Required<Pick<SiteKitStatusOptions, 'homeHref' | 'languages'>> & SiteKitStatusOptions;
    deploy: Required<Pick<SiteKitDeploy, 'target' | 'path'>> & SiteKitDeploy;
}
/** DI token holding the resolved, defaults-applied configuration. */
declare const SITE_KIT_CONFIG: InjectionToken<ResolvedSiteKitConfig>;
/**
 * Applies derived defaults so consumers can pass a minimal config. Pure, no side effects.
 * NOTE: `static/generate.mjs` mirrors this logic inline (a .mjs can't import this .ts) —
 * keep the two in sync when changing defaults.
 */
declare function resolveSiteKitConfig(config: SiteKitConfig): ResolvedSiteKitConfig;

/**
 * Registers the site-kit configuration for the application.
 *
 * ```ts
 * // app.config.ts
 * providers: [
 *   provideSiteKit({
 *     brand:   { name: 'ilia.ae', url: 'https://ilia.ae', tagline: 'Fractional CTO' },
 *     schemaVersion: 2,
 *     languages: ['ru', 'en', 'ar'],
 *     defaultLang: 'ru',
 *     nav:     [{ label: 'Blog', url: 'https://ilia.ae/blog', localize: true }],
 *     projects:[{ name: 'Mayday', url: 'https://mayday.software', status: 'live' }],
 *     contact: { qr: { data: 'https://t.me/ilia_ae' }, email: 'hi@ilia.ae' },
 *   }),
 * ]
 * ```
 */
declare function provideSiteKit(config: SiteKitConfig): EnvironmentProviders;
/**
 * Multi-domain variant — automatically picks the config whose key matches the
 * current hostname. One built artifact serves every site:
 *
 * ```ts
 * provideSiteKitForHost({
 *   'ilia.ae':          iliaConfig,
 *   'mayday.software':  maydayConfig,
 *   'monolith.plus':    monolithConfig,
 *   'aliro':            aliroConfig,
 * }, { fallback: 'ilia.ae' });
 * ```
 *
 * Matching order: exact hostname → `www.` stripped → longest key that is a
 * suffix of (or contained in) the hostname → `fallback` → first entry.
 */
declare function provideSiteKitForHost(configs: Record<string, SiteKitConfig>, opts?: {
    fallback?: string;
    hostname?: string;
}): EnvironmentProviders;
/**
 * Resolves which config key best matches a hostname.
 * @internal Exported for testing and `provideSiteKitForHost`; not part of the committed public API.
 */
declare function pickHostKey(hostname: string, configs: Record<string, unknown>, fallback?: string): string;

/**
 * Favicon HEAD tags — the modern "from one SVG" minimal set (2026 standard).
 *
 * This is the SOURCE for the favicon `<link>`/`<meta theme-color>` markup. The raster
 * ASSETS (icon.svg, .ico, apple-touch, 192/512, maskable, manifest) are produced at
 * build time by tools/lib/favicon.mjs (sharp) — this module only computes the tags
 * that reference them, applied to the live `<head>` from `config.favicon`.
 *
 * NOTE: tools/lib/favicon.mjs holds the JS mirror of `joinPath`/`resolveThemeColor`/
 * `faviconTags` (a .mjs can't import this .ts) — keep the two in sync; locked by
 * tools/favicon.test.mjs.
 */
/** A single head tag descriptor — a `<link>` or a `<meta>`. */
type FaviconTag = {
    tag: 'link';
    rel: string;
    href: string;
    type?: string;
    sizes?: string;
} | {
    tag: 'meta';
    name: string;
    content: string;
    media?: string;
};
/**
 * Canonical favicon head tags from config — the single source shared by the Angular
 * runtime and the static generator. Order matters: SVG-capable browsers prefer
 * `icon.svg`, legacy falls back to `favicon.ico`.
 */
declare function faviconTags(favicon: SiteKitFavicon | undefined, opts?: {
    basePath?: string;
    theme?: Record<string, string>;
}): FaviconTag[];
/**
 * Browser-safe derivation of the SQUARE source SVG (no file IO) — the icon shown in
 * previews and the basis for the rasterized set. Resolution: inline `favicon.src`
 * `<svg…>` / `data:image/svg+xml` → `brand.glyph` (tinted on a `--brand` tile) →
 * `brand.monogram`/initial letter tile. The build-time tools/lib/favicon.mjs mirror
 * adds the file-path case on top of this same logic.
 */
declare function faviconSourceSvg(favicon: SiteKitFavicon | undefined, brand?: SiteKitBrand, theme?: Record<string, string>): string;
/**
 * Apply favicon tags to a document `<head>`, idempotently. Kit-managed nodes carry
 * `data-ik-favicon` so a re-apply (e.g. multi-domain host swap) replaces cleanly and
 * never collides with the app's own tags. SSR/no-DOM safe (caller wraps in try/catch).
 */
declare function applyFaviconTags(doc: Document, tags: FaviconTag[]): void;

/**
 * SEO tag builder — the single source of head metadata for a page, in any language.
 *
 * Produces an ordered descriptor list (title · meta · link · JSON-LD) following the
 * 2026 standard: core meta + Open Graph (ogp.me) + Twitter/X cards + multilingual
 * hreflang (incl. x-default) + schema.org JSON-LD `@graph`. The Angular `Seo` service
 * applies these to the live `<head>`; the static generator emits the same set.
 *
 * Externally validatable: Google Rich Results Test, validator.schema.org, Lighthouse
 * SEO, the Facebook Sharing Debugger. `property=` is used for Open Graph and `name=`
 * for Twitter/standard meta (the #1 markup bug if mixed up).
 *
 * NOTE: tools/lib/seo.mjs holds the JS mirror of this logic (a .mjs can't import this
 * .ts) — keep the two in sync; locked by tools/seo.test.mjs.
 */
/** A single head descriptor — title, a `<meta>`, a `<link>`, or a JSON-LD `<script>`. */
type SeoTag = {
    tag: 'title';
    text: string;
} | {
    tag: 'meta';
    name?: string;
    property?: string;
    content: string;
    media?: string;
} | {
    tag: 'link';
    rel: string;
    href: string;
    hreflang?: string;
} | {
    tag: 'jsonld';
    json: unknown;
};
/** Per-page context + overrides layered on top of the site-wide `config.seo` defaults. */
interface SeoContext {
    /** Active language. Defaults to `config.defaultLang`. */
    lang?: string;
    /** Page path relative to the site root (`'/'`, `'/about'`). Drives canonical/OG url. */
    path?: string;
    /** Per-page title (runs through `seo.titleTemplate`, else `'<title> — <brand>'`). */
    title?: string;
    /** Per-page description override. */
    description?: string;
    /** Per-page share-image override (absolute or path). */
    image?: string;
    /** Per-page robots override (e.g. `'noindex'` for error pages). */
    robots?: string;
    /** Per-page `og:type` override. */
    ogType?: string;
}
/**
 * Build the full SEO head for one page+language from a site config.
 * Returns `[]` when there's nothing meaningful to emit (no brand/seo signal).
 *
 * @remarks Low-level builder (advanced API): the high-level `Seo` directive applies these tags at
 * runtime. Exported for the static generator and SSR/custom-rendering consumers — most apps should
 * use `Seo` instead.
 */
declare function buildSeoTags(config: SiteKitConfig | ResolvedSiteKitConfig, ctx?: SeoContext): SeoTag[];

/**
 * Live SEO head manager for kit-driven Angular apps.
 *
 * Applies the `buildSeoTags()` output (title · meta · canonical/hreflang · JSON-LD)
 * to the document `<head>` from `config.seo`, and lets routes refine it per page:
 *
 * ```ts
 * private readonly seo = inject(Seo);
 * ngOnInit() { this.seo.update({ lang: 'ru', path: '/about', title: 'Обо мне' }); }
 * ```
 *
 * Site-wide defaults are applied at boot by `provideSiteKit` (when `config.seo` is
 * present). Kit-managed nodes carry `data-ik-seo`, so every `update()` replaces the
 * previous set cleanly and never clobbers the app's own tags. SSR/no-DOM safe.
 */
declare class Seo {
    private readonly doc;
    private readonly title;
    private readonly config;
    /** Recompute and apply the head for a page/language (merges over `config.seo`). */
    update(ctx?: SeoContext): void;
    /** Apply a pre-built descriptor list (e.g. from a shared computation). */
    applyTags(tags: SeoTag[]): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Seo, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<Seo>;
}

/**
 * Build the OG banner SVG (1200×630) for a site config + language.
 *
 * @remarks Low-level builder (advanced API): exported for the static generator (which rasterizes it
 * to PNG) and SSR/custom-rendering consumers.
 */
declare function buildOgSvg(config: SiteKitConfig, opts?: {
    lang?: string;
}): string;

/**
 * Installable-app service (Angular-only). Captures the `beforeinstallprompt` event,
 * exposes `canInstall`/`install()`, detects standalone/installed + iOS (which has no
 * prompt → needs the manual "Add to Home Screen" hint), and surfaces ngsw update
 * availability. Registered + head-applied by `provideSiteKitPwa()`.
 */
declare class Pwa {
    private readonly doc;
    private readonly config;
    private readonly destroyRef;
    private readonly swUpdate;
    private readonly promptEvent;
    /** True once the app is installed / running standalone. */
    readonly installed: _angular_core.WritableSignal<boolean>;
    /** A new service-worker version is ready (offer a "reload to update"). */
    readonly updateAvailable: _angular_core.WritableSignal<boolean>;
    /** iOS Safari — no `beforeinstallprompt`, so show the manual hint instead. */
    readonly isIosSafari: _angular_core.WritableSignal<boolean>;
    /** Show the install button (a prompt is queued and we're not installed). */
    readonly canInstall: _angular_core.Signal<boolean>;
    /** Show the iOS "Add to Home Screen" hint. */
    readonly needsIosHint: _angular_core.Signal<boolean>;
    constructor();
    /** Show the native install prompt. Returns the outcome (`'unavailable'` if no prompt queued). */
    install(): Promise<'accepted' | 'dismissed' | 'unavailable'>;
    /** Activate a ready ngsw update and reload to it. */
    applyUpdate(): Promise<void>;
    /** Apply the iOS/chrome PWA `<meta>` + splash `<link>`s to `<head>` (called at boot). */
    applyHead(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Pwa, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<Pwa>;
}

/**
 * `<ik-install>` — install affordance for the PWA module (Angular-only).
 *   • installable (Chrome/Edge/Android): an "Install app" button → native prompt.
 *   • iOS Safari (no prompt): the manual "Add to Home Screen" hint.
 *   • already installed/standalone: renders nothing.
 * When a new service-worker version is ready it offers a reload-to-update button.
 */
declare class Install {
    protected readonly pwa: Pwa;
    /** Active language for the button label / iOS hint. */
    readonly lang: _angular_core.InputSignal<string>;
    protected readonly t: _angular_core.Signal<{
        label: string;
        ios: string;
        update: string;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Install, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Install, "ik-install", never, { "lang": { "alias": "lang"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Enables the installable-app (PWA) module for a kit-driven **Angular** app:
 * registers the ngsw service worker and applies the iOS/chrome PWA `<meta>` + splash
 * `<link>`s from `config.pwa` (icons come from `config.favicon`).
 *
 * ```ts
 * // app.config.ts
 * providers: [ provideSiteKit(cfg), provideSiteKitPwa() ]
 * ```
 * Also set `"serviceWorker": "ngsw-config.json"` in angular.json (a reference config
 * ships at `@ilia-ae/site-kit/ngsw-config.json`) and generate the manifest/splash
 * assets with the kit's build tooling. Not available for the static (WP) target.
 */
declare function provideSiteKitPwa(opts?: {
    enabled?: boolean;
    registrationStrategy?: string;
}): EnvironmentProviders;

/**
 * PWA head/meta builders — the pure core of the installable-app module (Angular-only).
 *
 * Produces the iOS/chrome `<meta>` tags (`apple-mobile-web-app-*`, `application-name`,
 * `color-scheme`…) and the `apple-touch-startup-image` splash `<link>`s. The web
 * manifest itself is built at BUILD time (tools/lib/pwa.mjs, mirror of this) and the
 * splash PNGs are rasterized there from the favicon SVG. The `Pwa` service applies
 * these tags to the live `<head>` and drives the install prompt.
 *
 * NOTE: tools/lib/pwa.mjs holds the JS mirror (manifest + splash media + meta) — keep
 * in sync; locked by tools/pwa.test.mjs.
 */
interface PwaMetaTag {
    name: string;
    content: string;
}
interface PwaLinkTag {
    rel: string;
    href: string;
    media?: string;
}
/**
 * Apple splash-screen device matrix (physical px + DPR). CSS size = px / ratio; the
 * media query matches `device-width`/`device-height` in CSS px at that pixel ratio.
 * A focused set covering current iPhone/iPad classes (portrait).
 */
declare const PWA_SPLASH_DEVICES: {
    id: string;
    w: number;
    h: number;
    ratio: number;
}[];
/** Portrait media query for an apple-touch-startup-image link (CSS px). */
declare function splashMedia(d: {
    w: number;
    h: number;
    ratio: number;
}): string;
/**
 * Build the ENRICHED web manifest (icons from `config.favicon` + PWA fields from
 * `config.pwa`). The single source for the demo inspector, the build tooling
 * (tools/lib/pwa.mjs mirror) and tests. Returns `null` when `config.pwa` is absent.
 *
 * @remarks Low-level builder (advanced API): `provideSiteKitPwa()` / the `Pwa` component wire PWA
 * up for apps. Exported for the static generator and build tooling — most apps don't call it directly.
 */
declare function buildManifest(config: SiteKitConfig): Record<string, unknown> | null;
/** iOS/chrome `<meta>` tags from `config.pwa` (the app-shell chrome a manifest can't set). */
declare function pwaMetaTags(config: SiteKitConfig): PwaMetaTag[];
/** `apple-touch-startup-image` splash `<link>`s (empty when `pwa.splash === false`). */
declare function pwaSplashLinks(config: SiteKitConfig, basePath?: string): PwaLinkTag[];
/** Is the app running as an installed/standalone PWA? (display-mode + iOS navigator.standalone) */
declare function isStandalone(win: Window): boolean;
/** iOS Safari (no `beforeinstallprompt` → needs the manual "Add to Home Screen" hint). */
declare function isIos(nav: Navigator): boolean;
/** Apply PWA meta + splash links to a document `<head>`, idempotently (`data-ik-pwa`). */
declare function applyPwaTags(doc: Document, metas: PwaMetaTag[], links: PwaLinkTag[]): void;

/**
 * Canonical language set — mirrors Integra / UAE STARS
 * (`frontend/src/app/core/services/i18n.service.ts`). Use this as the default
 * list for <ik-lang-switcher>; sites that need fewer languages pass a subset.
 */
interface IkLanguage {
    /** BCP-47-ish code: 'en', 'ru', 'ar', 'kk', 'zh', 'hi', 'ur'. */
    code: string;
    /** English name, e.g. 'Arabic'. */
    name: string;
    /** Native label shown in the UI, e.g. 'العربية'. */
    nativeName: string;
    /** Writing direction — drives `dir="rtl"` for Arabic/Urdu. */
    direction: 'ltr' | 'rtl';
    /** Emoji flag. */
    flag: string;
    /** ISO country code for CSS sprite flags ('gb', 'ru', 'ae', …). */
    flagCode: string;
}
declare const IK_LANGUAGES: readonly IkLanguage[];
/** Look up a language descriptor by code. */
declare function ikLanguage(code: string): IkLanguage | undefined;
/** Convenience: is this language right-to-left (Arabic, Urdu)? */
declare function isRtl(code: string): boolean;
/** Resolve a subset of IK_LANGUAGES from codes (unknown codes dropped), preserving order. */
declare function ikLanguages(codes?: readonly string[]): IkLanguage[];
/**
 * Locale-aware URL: for the default language returns `url` unchanged; for any
 * other language inserts the code as a path prefix after the origin.
 *   localizeUrl('https://ilia.ae', 'en', {defaultLang:'ru'})  → 'https://ilia.ae/en'
 *   localizeUrl('https://ilia.ae/blog', 'en', …)              → 'https://ilia.ae/en/blog'
 *   localizeUrl('/about', 'en', …)                            → '/en/about'
 * Hash-only / mailto: / tel: links pass through untouched. Already-prefixed
 * URLs are left as-is so it's idempotent.
 */
/**
 * Resolve a `LocalizedString` (plain string OR `{ en, ru }` map) for the active
 * language — falls back to the default language, then the first value, so one
 * config holds every translation. Returns `undefined` only for nullish input.
 */
declare function localizeText(value: string | Record<string, string> | undefined | null, lang: string | undefined, defaultLang?: string): string | undefined;
declare function localizeUrl(url: string, lang: string, opts?: {
    defaultLang?: string;
}): string;
/**
 * Resolve a link's href for the active language. Precedence:
 *   1. `urls[lang]`       — explicit full per-language URL
 *   2. `pathByLang[lang]` — `domain(url) + modifier`; languages absent → bare `url`
 *   3. `localize`         — auto `/<lang>` for non-default languages
 *   4. `url`              — the base
 */
declare function resolveLinkHref(link: {
    url: string;
    localize?: boolean;
    pathByLang?: Record<string, string>;
    urls?: Record<string, string>;
}, lang: string, defaultLang?: string): string;

/** Build date (UTC, YYYY-MM-DD) stamped at build time. */
declare const SITE_KIT_BUILD_DATE = "2026-11-07";

/** Group a phone number for display. Returns the input unchanged for too-short / empty values. */
declare function formatPhone(raw: string): string;

/**
 * "IA kit" — the library's brand mark. A 2×2 cluster of distinct primitives:
 *   ◣ triangle (top-left) · ▢ square (top-right) · ▢ square (bottom-left) · ● circle (bottom-right)
 * The diagonal triangle↔circle gives it identity; the two squares read as "modular blocks".
 * Trusted library constant (rendered via innerHTML); `currentColor` so it adapts to its mark.
 */
declare const SITE_KIT_GLYPH = "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M6.5 3 10 10 3 10Z\"/><rect x=\"14\" y=\"3\" width=\"7\" height=\"7\" rx=\"2\"/><rect x=\"3\" y=\"14\" width=\"7\" height=\"7\" rx=\"2\"/><circle cx=\"17.5\" cy=\"17.5\" r=\"3.5\"/></svg>";
/** The library's signature accent — warm sand (the IA kit brand colour); tints the badge hover. */
declare const SITE_KIT_ACCENT = "#ad7729";
/** Display name of the library's signature badge. */
declare const SITE_KIT_NAME = "IA kit";

type IkStringKey = 'home' | 'back' | 'redirect' | 'scan' | 'shareTitle' | 'linksTitle' | 'share' | 'copy' | 'copied' | 'email' | 'website' | 'contactForm' | 'cookieText' | 'cookieAccept' | 'cookieReject' | 'cookieMore' | 'menu' | 'language' | 'tags' | 'cookieLabel' | 'close' | 'cookiePolicyTitle' | 'cookiePolicyBody' | 'cookieFullPolicy';
type Dict = Record<IkStringKey, string>;
/** Keys of the shared chrome: status page, nav, footer, language and theme switchers. */
type IkChromeKey = 'home' | 'back' | 'redirect' | 'menu' | 'language' | 'tags' | 'close';
/**
 * Every built-in string, per language (en, ru, es, pt, ar, kk, zh, hi, ur). Built inside a pure
 * IIFE, so it costs nothing unless an app imports it.
 */
declare const IK_STRINGS: Record<string, Dict>;
/**
 * Resolve a built-in UI (chrome) string. The kit's OWN chrome is maintained in four
 * languages — English, Russian, Spanish and Portuguese; every other language resolves to
 * English. (Per-MODULE content — status copy, config-provided localized fields — stays
 * multilingual via `localizeText`/catalogs; this only governs the shared kit labels.)
 * Apps may still override any chrome string via `config.strings`.
 *
 * Inside the kit, components call the group lookup instead (chromeString / cookieString /
 * qrString), which keeps the other groups out of an app's bundle; this one reaches them all.
 */
declare function ikString(lang: string | undefined, key: IkStringKey, overrides?: Record<string, Partial<Dict>>): string;

/** A status key is either an HTTP code or a non-HTTP pseudo-state. */
type StatusKey = number | 'maintenance' | 'offline';
/** Localized copy for one status in one language. */
interface StatusCopy {
    title: string;
    message: string;
}
interface StatusEntry {
    code: StatusKey;
    /** Big decorative glyph (the code itself, or an emoji for pseudo-states). */
    glyph: string;
    /** Copy keyed by language code (e.g. 'en', 'ru', 'ar'). */
    i18n: Record<string, StatusCopy>;
}
/** Languages the catalog ships copy for, in display order. */
declare const STATUS_LANGUAGES: readonly string[];
/** All known status entries, in catalog order. */
declare const STATUS_ENTRIES: readonly StatusEntry[];
/** Returns the entry for a code, falling back to a generic error entry. */
declare function statusEntry(code: StatusKey): StatusEntry;
/** Resolves copy for a language, falling back to `fallback`, then to the first available. */
declare function statusCopy(entry: StatusEntry, lang: string, fallback?: string): StatusCopy;

/** One language's resolved copy for the page (primary + secondary share this shape). */
interface StatusRow {
    lang: string;
    rtl: boolean;
    title: string;
    message: string;
}
/**
 * Universal, multilingual status / error page — one component drives 404, 403,
 * 500, 503, maintenance, offline and every other code in the catalog, and it
 * renders the copy in EVERY configured language at once: the primary language
 * large up top, the rest stacked below smaller and dimmed (each with its own
 * `dir`, so Arabic / Urdu read correctly).
 *
 * ```html
 * <ik-status-page [code]="404" />
 * <ik-status-page [code]="503" title="Скоро вернёмся" [lang]="'ru'" />
 * <ik-status-page code="maintenance" [languages]="['en','ar']" [showHome]="false" />
 * ```
 *
 * A floating "techno" background sits behind a centred glass panel. Theming is
 * inherited from the host app's CSS custom properties (`--brand`, `--bg`,
 * `--text`, `--border`, `--grad-brand` …); fallbacks keep it readable with no
 * theme present. Honours `prefers-reduced-motion`.
 *
 * Driven by `config.status`:
 *   • `redirect: { delaySeconds, href? }` → live countdown then auto-navigate
 *     home; any page interaction (click / focus / key) cancels the countdown.
 *   • `showBack` (default true) → a secondary "← Back" button (history.back()).
 * When `lang` is not supplied it is auto-detected from `navigator.language`.
 */
declare class StatusPage implements OnDestroy {
    protected readonly cfg: _ilia_ae_site_kit.ResolvedSiteKitConfig;
    private readonly doc;
    /** HTTP code (404, 500 …) or pseudo-state ('maintenance' | 'offline'). */
    readonly code: _angular_core.InputSignal<StatusKey>;
    /** Override the PRIMARY language title for this instance. */
    readonly title: _angular_core.InputSignal<string | undefined>;
    /** Override the PRIMARY language message for this instance. */
    readonly message: _angular_core.InputSignal<string | undefined>;
    /** Languages to render simultaneously; defaults to `config.status.languages`. */
    readonly languages: _angular_core.InputSignal<string[] | undefined>;
    /** Active / primary language. Defaults to auto-detect, then `config.defaultLang`. */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    /** Show the "go home" button. */
    readonly showHome: _angular_core.InputSignal<boolean>;
    /**
     * Preview/demo mode: the redirect countdown still renders, but it does NOT
     * actually navigate away when it elapses. Lets a playground show error pages
     * (and the redirect copy) without the page being whisked off to home.
     */
    readonly preview: _angular_core.InputSignal<boolean>;
    protected readonly glyph: _angular_core.Signal<string>;
    /** Home-button label: explicit config, else localized to the primary language. */
    protected readonly homeLabel: _angular_core.Signal<string>;
    /** Support line, localized to the primary language. */
    protected readonly supportLine: _angular_core.Signal<string | undefined>;
    /** "Back" button label, localized to the primary language. */
    protected readonly backLabel: _angular_core.Signal<string>;
    /** Render the Back button unless explicitly disabled in config. */
    protected readonly showBack: _angular_core.Signal<boolean>;
    /** Resolved, deduped language list — falls back to the configured default. */
    private readonly langList;
    /**
     * The effective active language: the explicit `lang` input when given,
     * otherwise auto-detected from the browser (first 2 chars of
     * `navigator.language`) IF that language is configured for this site.
     * SSR-safe — `navigator` is guarded.
     */
    private readonly resolvedLang;
    /** Primary language: the resolved active lang if present in the list, else the first entry. */
    private readonly primaryLang;
    /** Primary row — `title`/`message` inputs override the catalog copy here only. Null while the
     *  language's copy is still loading (status-copy.ts), so no other language flashes first. */
    protected readonly primary: _angular_core.Signal<StatusRow | null>;
    /** Every other configured language, in order, with un-overridden catalog copy. */
    protected readonly secondary: _angular_core.Signal<StatusRow[]>;
    /** Seconds left in the live countdown (0 = elapsed/inactive). */
    private readonly remaining;
    private timerId;
    /** True while a redirect countdown is running and has time left. */
    protected readonly countdownActive: _angular_core.Signal<boolean>;
    /** Total redirect delay (s) — drives the home-button fill animation duration. */
    protected readonly redirectSeconds: _angular_core.WritableSignal<number>;
    /** Localized "You'll be redirected to home in N s" — replaces the support line. */
    protected readonly redirectText: _angular_core.Signal<string>;
    constructor();
    /** One countdown tick: step down, or (at zero) hand off to navigateHome. */
    private tick;
    /** Cancel the auto-redirect (inline button, or a focus/click on the page). */
    protected cancelRedirect(): void;
    /** Pause/cancel the countdown when the user interacts with the page. In preview the
     *  countdown is a looping demo, so interaction must NOT cancel it. */
    protected onUserIntent(): void;
    /** Go to the previous page in browser history. SSR-safe. */
    protected goBack(): void;
    private navigateHome;
    private clearTimer;
    ngOnDestroy(): void;
    /** Bumped as each language's copy arrives, so the rows recompute. */
    private readonly copyArrived;
    /** Fetch the copy of every language the page shows (and the default, its fallback). */
    private readonly loadCopy;
    /**
     * The copy of this code in a language: that language, else the site's default, else English,
     * else the generic error (as statusCopy() falls back). Null while a language it should use is
     * still loading.
     */
    private copyFor;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StatusPage, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StatusPage, "ik-status-page", never, { "code": { "alias": "code"; "required": true; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "languages": { "alias": "languages"; "required": false; "isSignal": true; }; "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "showHome": { "alias": "showHome"; "required": false; "isSignal": true; }; "preview": { "alias": "preview"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** A nav item with its resolved, locale-aware href and externality precomputed. */
interface ResolvedNavItem {
    item: SiteKitNavItem;
    /** Label resolved for the active language. */
    label: string;
    href: string;
    external: boolean;
    children: ResolvedNavItem[];
    /** Stable key for tracking + accordion open-state. */
    key: string;
}

/**
 * Shared site navigation — fixed glass topbar with brand, a desktop link row
 * (CTA highlight + hover/focus dropdowns) and a full-screen mobile overlay with
 * numbered links, hover-in arrows and expandable accordion sections.
 *
 * Items come from `config.nav`; hrefs are resolved locale-aware against `lang`.
 * Right-side controls are projected so the host drops in its own switchers:
 *
 * ```html
 * <ik-nav [lang]="translate.currentLang">
 *   <ik-lang-switcher slot="actions" />
 *   <ik-theme-toggle slot="actions" />
 * </ik-nav>
 * ```
 */
declare class Nav {
    private readonly host;
    protected readonly cfg: _ilia_ae_site_kit.ResolvedSiteKitConfig;
    private readonly sanitizer;
    /** Trusted inline brand glyph (rendered in an inverted mark, like the reference topbar). */
    protected readonly brandGlyph: _angular_core.Signal<SafeHtml | null>;
    /** Active language code; host binds `[lang]="translate.currentLang"`. */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    /** Pin the bar to the top of the viewport. */
    readonly sticky: _angular_core.InputSignal<boolean>;
    /**
     * Use a consumer-projected brand instead of the config brand mark — project the
     * element via `<… slot="brand">`. For apps whose logo is bespoke or stateful
     * (e.g. an SVG tinted by a live status) that the config brand can't express.
     */
    readonly customBrand: _angular_core.InputSignal<boolean>;
    protected readonly menuOpen: _angular_core.WritableSignal<boolean>;
    private readonly activeLang;
    protected readonly monogram: _angular_core.Signal<string>;
    protected readonly items: _angular_core.Signal<ResolvedNavItem[]>;
    /** Localized UI string for the active language (with per-app overrides). */
    protected t(key: IkChromeKey): string;
    protected toggle(event: Event): void;
    protected onDocClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Nav, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Nav, "ik-nav", never, { "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "sticky": { "alias": "sticky"; "required": false; "isSignal": true; }; "customBrand": { "alias": "customBrand"; "required": false; "isSignal": true; }; }, {}, never, ["[slot=brand]", "[slot=actions]"], true, never>;
}

interface RenderProject {
    project: SiteKitProject;
    href: string;
    external: boolean;
    monogram: string;
    /** Localised, single-word status label (empty when no status). */
    statusLabel: string;
}
/**
 * "Our projects" directory — a responsive grid of project cards driven by
 * `config.projects` (`SiteKitProject[]`).
 *
 * Each card is a locale-aware link (urls?.[lang] → localize → url). Cards show a
 * logo or a brand-gradient monogram, the name, a 2-line-clamped description,
 * tag chips, and a colour-coded status badge (live / wip / archived). Renders
 * nothing when there are no projects.
 *
 * ```html
 * <ik-projects [lang]="translate.currentLang" heading="What we build" />
 * <ik-projects [columns]="3" />
 * ```
 */
declare class Projects {
    private readonly cfg;
    /** Active language for locale-aware links. Defaults to the config default. */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    /** Optional section title rendered above the grid. */
    readonly heading: _angular_core.InputSignal<string | undefined>;
    /** Fixed column count; omit for responsive auto-fill. */
    readonly columns: _angular_core.InputSignal<number | undefined>;
    private readonly activeLang;
    /** Localized aria-label for the per-project tag list. */
    protected readonly tagsLabel: _angular_core.Signal<string>;
    protected readonly projects: _angular_core.Signal<RenderProject[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Projects, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Projects, "ik-projects", never, { "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface RenderItem {
    project: SiteKitProject;
    href: string;
    external: boolean;
    monogram: string;
}
/**
 * Compact "our projects" list (icon/logo + name + status dot), driven by
 * `config.projects` — the same data as the `ik-projects` grid, rendered as a small
 * linked list for reuse in footers, sidebars, etc. Locale-aware links. Renders
 * nothing when there are no projects.
 *
 * ```html
 * <ik-projects-list [lang]="lang" heading="Проекты" />
 * ```
 */
declare class ProjectsList {
    private readonly cfg;
    /** Active language for locale-aware links. Defaults to the config default. */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    /** Optional heading above the list. */
    readonly heading: _angular_core.InputSignal<string | undefined>;
    private readonly activeLang;
    protected readonly items: _angular_core.Signal<RenderItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProjectsList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProjectsList, "ik-projects-list", never, { "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface RenderTech {
    name: string;
    url: string;
    external: boolean;
    /** Trusted inline SVG (built-in or custom <svg>). */
    svg: SafeHtml | null;
    /** Icon image URL (custom non-SVG icon). */
    imgUrl: string | null;
    /** Brand accent for the hover tint (null → falls back to --brand). */
    accent: string | null;
    /** Optional tooltip override (defaults to `name`); the IA-kit badge shows its version here. */
    title?: string;
}
/** One form-factor's score inside the single PageSpeed badge (mobile/desktop). */
interface PageSpeedChip {
    /** Form factor — the `track` key. */
    factor: 'mobile' | 'desktop';
    /** Author-supplied Performance score 0–100. */
    score: number;
    /** Lighthouse colour band, shown as a small dot (green ≥90 · amber 50–89 · red <50). */
    band: string;
    /** Inline device glyph (phone / monitor). */
    icon: SafeHtml;
}
/**
 * Tech-stack badges, driven by `config.technologies`. Each is a link (icon + name)
 * to the technology's site. `kind` selects a built-in icon + canonical URL; `name`,
 * `url`, `icon` override. Renders nothing when there are no technologies.
 *
 * The footer auto-includes this, so a project only needs to list its stack in config.
 *
 * ```html
 * <ik-technologies />
 * <ik-technologies size="sm" />
 * ```
 */
declare class Technologies {
    private readonly cfg;
    private readonly sanitizer;
    /** Visual size hint, reflected to a host attribute for CSS. */
    readonly size: _angular_core.InputSignal<"sm" | "md">;
    /** Center the (wrapping) badge rows — for the standalone section vs the footer. */
    readonly center: _angular_core.InputSignal<boolean>;
    /** Append the library's own "site-kit" badge as the LAST technology (the footer does this). */
    readonly appendSiteKit: _angular_core.InputSignal<boolean>;
    /** Render PageSpeed score chips (from `config.pageSpeed`) JUST BEFORE the IA-kit badge. Footer-only. */
    readonly showPageSpeed: _angular_core.InputSignal<boolean>;
    /** Active language — localizes the PageSpeed chip tooltip ("re-test" / "перепроверить"). */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    protected readonly items: _angular_core.Signal<RenderTech[]>;
    /** The library's own "site-kit" signature badge — rendered LAST (after any PageSpeed chips).
     *  Null unless `appendSiteKit` is set and `config.signature` isn't `false`. */
    protected readonly siteKitBadge: _angular_core.Signal<RenderTech | null>;
    /** PageSpeed score badge from `config.pageSpeed` (only when `showPageSpeed`) — ONE chip holding
     *  the mobile + desktop scores, linking to PSI to RE-TEST the live URL (defaults to `seo.siteUrl`
     *  → `brand.url`). Numbers are author-supplied; each gets a Lighthouse colour-band dot. */
    protected readonly pageSpeed: _angular_core.Signal<{
        href: string;
        title: string;
        accent: string;
        chips: PageSpeedChip[];
    } | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Technologies, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Technologies, "ik-technologies", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "center": { "alias": "center"; "required": false; "isSignal": true; }; "appendSiteKit": { "alias": "appendSiteKit"; "required": false; "isSignal": true; }; "showPageSpeed": { "alias": "showPageSpeed"; "required": false; "isSignal": true; }; "lang": { "alias": "lang"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Built-in technology catalog — label + canonical URL + inline SVG (currentColor)
 * per known `kind`. Trusted constants (rendered via innerHTML), exactly like
 * social-icons. A config tech with an unknown/absent kind falls back to TECH_FALLBACK
 * (a generic tag glyph) and can override the icon/url itself.
 *
 * Brand marks (angular/typescript/go/bitcoin) are real single-path logos (Simple Icons, CC0); the rest use
 * clean geometric glyphs — the badge always shows the NAME, so meaning never depends
 * on the icon alone. Override any with `{ icon: '<svg…>' | 'https://…' }`.
 */
interface TechMeta {
    label: string;
    url: string;
    svg: string;
}
declare const TECH_ICONS: Record<string, TechMeta>;
/** Generic tag glyph for technologies without a built-in icon. */
declare const TECH_FALLBACK = "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20.6 13.4 11 3.8a2 2 0 0 0-1.4-.6H4a1 1 0 0 0-1 1v5.6a2 2 0 0 0 .6 1.4l9.6 9.6a2 2 0 0 0 2.8 0l4.6-4.6a2 2 0 0 0 0-2.8Z\"/><circle cx=\"7.5\" cy=\"7.5\" r=\"1.3\" fill=\"currentColor\"/></svg>";

interface RenderFamily {
    name: string;
    url: string;
    icon: string;
    accent: string;
}
/**
 * "Our projects" row — the ILIA family of sites as real-logo chips, from the built-in
 * `IK_FAMILY` catalogue (same marks the panel shows), with per-active-language URLs. No host
 * markup or per-project config: the footer auto-embeds this when `footer.projects` is set.
 *
 * ```html
 * <ik-family-links />
 * <ik-family-links size="sm" [keys]="['mayday','deposit']" />
 * ```
 */
declare class FamilyLinks {
    private readonly cfg;
    /** Visual size hint, reflected to a host attribute for CSS. */
    readonly size: _angular_core.InputSignal<"sm" | "md">;
    /** Active language for per-language URLs. */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    /** Which family keys to render, in order. Defaults to the whole family (`IK_FAMILY_ORDER`). */
    readonly keys: _angular_core.InputSignal<readonly string[] | undefined>;
    private readonly activeLang;
    protected readonly items: _angular_core.Signal<RenderFamily[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FamilyLinks, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FamilyLinks, "ik-family-links", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "keys": { "alias": "keys"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Built-in catalogue of the ILIA family of sites — real brand logos (the SAME marks the panel
 * dashboard shows) + canonical / per-language URLs. Drives the footer's "our projects" row
 * (`footer.projects: true`) so every consumer gets icon chips out of the box, never letter
 * monograms. Mirrors the tech-icons.ts catalogue pattern.
 *
 * Icons are self-contained brand tiles baked as data-URIs (SVG inline-encoded; the two raster
 * logos as base64 PNG) so the package ships them with zero external requests / no asset copying.
 * Generated from playground/src/assets/brands/<host>/logo.{svg,png}. Only ilia.ae has distinct
 * per-language pages (ru / · en /en/).
 */
interface FamilyProjectMeta {
    /** Display label / chip title. */
    name: string;
    /** Canonical (default-language) URL. */
    url: string;
    /** Explicit per-language full URLs (only ilia.ae needs it); resolved via resolveLinkHref. */
    urls?: Record<string, string>;
    /** Brand-mark accent (hover tint), may differ from the site's theme --brand. */
    accent: string;
    /** Self-contained brand logo as a data-URI (rendered via <img>). */
    icon: string;
}
/** The ILIA family, keyed by stable slug (NOT host — avoids monogram/host collisions). */
declare const IK_FAMILY: Record<string, FamilyProjectMeta>;
/** Canonical order for the footer "our projects" row. */
declare const IK_FAMILY_ORDER: readonly ["ilia", "mayday", "deposit", "aliro", "mirador", "monolith", "netcheck", "integra"];

type IkThemeMode = 'light' | 'dark' | 'auto';
/**
 * Three-state theme toggle (light → dark → auto), mirroring the apps'
 * `ThemeService`: it toggles the `app-dark` class on <html>, persists the mode
 * under `theme`, and in `auto` mode follows the OS preference live. Where it writes
 * is configurable (`IK_THEME_OPTIONS`) — `provideSiteKitTabler()` makes it drive
 * Tabler's `data-bs-theme` instead.
 *
 * Click cycles the mode. `(themeChange)` emits the new mode.
 *
 * ```html
 * <ik-theme-toggle (themeChange)="onTheme($event)" />
 * ```
 */
declare class ThemeToggle implements OnInit, OnDestroy {
    private readonly doc;
    private readonly opts;
    private readonly storageKey;
    private readonly darkClass;
    private readonly attributes;
    /** Compact mode: small borderless button for in-card chrome (matches the reference). */
    readonly compact: _angular_core.InputSignal<boolean>;
    /** Active language for the aria-label / title (falls back to English). */
    readonly lang: _angular_core.InputSignal<string>;
    /** Localized "Theme: <mode>" accessible name. */
    protected readonly label: _angular_core.Signal<string>;
    /** Emits the active mode whenever it changes (and once on init). */
    readonly themeChange: _angular_core.OutputEmitterRef<IkThemeMode>;
    protected readonly mode: _angular_core.WritableSignal<IkThemeMode>;
    private mql;
    private readonly onOsChange;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    protected cycle(): void;
    private applyMode;
    private applyDark;
    private safeRead;
    private safeStore;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ThemeToggle, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ThemeToggle, "ik-theme-toggle", never, { "compact": { "alias": "compact"; "required": false; "isSignal": true; }; "lang": { "alias": "lang"; "required": false; "isSignal": true; }; }, { "themeChange": "themeChange"; }, never, never, true, never>;
}

/** What the build-integrity dialog shows: the footer reads it off IntegrityService. */
interface FooterVerifyView {
    title: string;
    /** verified / mismatch / dev / … (a CSS modifier). */
    status: string;
    statusLabel: string;
    summary: string | null;
    checks: readonly {
        name: string;
        matched: boolean | null;
        expected: string;
        actual: string | null;
    }[];
}

interface RenderColumn {
    /** Stable, language-neutral slug for the part id (data-ik-part must not change per language). */
    key: string;
    title: string;
    /** Column entries; an entry with `paras` opens the in-app policy panel (like a legal link). */
    links: RenderLegal[];
    /** Render as its own `<nav>` landmark (default true; `landmark:false` → plain container). */
    landmark: boolean;
}
/** A compact-strip legal link; with `paras` it opens an in-app policy panel. */
interface RenderLegal {
    /** Stable, language-neutral slug for the part id (NOT the localized label). */
    key: string;
    label: string;
    href?: string;
    external: boolean;
    paras: string[];
    updated: string;
}
/**
 * Site footer — rich, multi-column (mirrors the apps' public footer):
 *   • brand column: logo + name + subtitle + disclaimer + social slot
 *   • link columns: `config.footer.columns` (Proof / Source / Legal …)
 *   • bottom bar: live-dot + auto-ranged copyright + brand tagline + tech badges
 *
 * With no `config.footer.columns` it degrades to a brand + bottom-bar strip.
 *
 * ```html
 * <ik-footer><ik-social-links slot="extra" /></ik-footer>
 * ```
 */
declare class Footer {
    protected readonly cfg: _ilia_ae_site_kit.ResolvedSiteKitConfig;
    private readonly sanitizer;
    private readonly destroyRef;
    private readonly doc;
    private readonly barTopRef;
    /** Compact-footer marquee runs ONLY when the disclaimer doesn't fit its line
     *  (small screens); where it fits, the text is shown static. Measured below. */
    protected readonly marquee: _angular_core.WritableSignal<boolean>;
    /** Bottom-bar tagline marquee — runs only when the tagline is wider than its line. */
    protected readonly tagMarquee: _angular_core.WritableSignal<boolean>;
    constructor();
    private initMarquee;
    /** Trusted inline brand glyph (rendered in an inverted mark). */
    protected readonly brandGlyph: _angular_core.Signal<SafeHtml | null>;
    /** Active language for locale-aware footer links. */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    /** Override the auto-detected current year (mostly for tests/snapshots). */
    readonly currentYear: _angular_core.InputSignal<number>;
    protected readonly activeLang: _angular_core.Signal<string>;
    /** Resolve a LocalizedString for the active language. */
    private lt;
    /** Brand-column text (all per-language aware). */
    protected readonly subtitle: _angular_core.Signal<string | undefined>;
    protected readonly disclaimer: _angular_core.Signal<string | undefined>;
    /** Single-strip footer (no brand/link columns) — see SiteKitFooter.compact. */
    protected readonly compact: _angular_core.Signal<boolean>;
    /** The icon row (slot=extra + "our projects") in the brand column — SiteKitFooter.extras. */
    protected readonly extrasInBrand: _angular_core.Signal<boolean>;
    /** Drop the brand column in the full footer — see SiteKitFooter.hideBrand. */
    protected readonly hideBrand: _angular_core.Signal<boolean>;
    /** Stack the link columns into one — see SiteKitFooter.stackColumns. */
    protected readonly stackColumns: _angular_core.Signal<boolean>;
    /** Brand tagline shown in the bottom bar (per-language aware). */
    protected readonly tagline: _angular_core.Signal<string | undefined>;
    /** Resolved nav columns from `footer.columns` (titles + labels localized). Legal links are
     *  NOT a column — they render in the bottom bar (`legalLinks()`), so a body-only policy entry
     *  opens its in-app panel in both full and compact modes. */
    /** Render a footer entry (column link OR legal link). A plain link resolves its locale-aware
     *  `url`; a legal entry (with `body`) becomes a panel opener (paras + UTC "updated"), with its
     *  optional `href` kept as the "open full version" link. Shared by columns() and legalLinks(). */
    private renderEntry;
    protected readonly columns: _angular_core.Signal<RenderColumn[]>;
    /** Show legal links in the bottom bar? Default yes; `footer.barLegal: false` keeps the bar clean
     *  (e.g. when a column hosts them via `appendLegal`). */
    protected readonly barLegal: _angular_core.Signal<boolean>;
    /** "Our projects" family keys to render (footer.projects), with the CURRENT site auto-excluded
     *  (its brand.url origin is dropped) so a footer never links to itself. */
    protected readonly familyKeys: _angular_core.Signal<string[]>;
    private originOf;
    /** Flat legal links (Privacy · Terms …) for the bottom bar — labels localized; links with
     *  `body` open an in-app policy panel (paras split on blank lines) with a full-UTC "updated". */
    protected readonly legalLinks: _angular_core.Signal<RenderLegal[]>;
    /** Format an ISO timestamp as a full UTC datetime, e.g. "Last updated: 16 Jun 2026, 18:30 UTC". */
    private fmtUpdated;
    /** Whether a live build-integrity check is configured — gates the clickable © (verify). */
    protected readonly hasVerify: _angular_core.Signal<boolean>;
    /** The © button's name when it opens the build-integrity result. */
    protected readonly verifyTitle: _angular_core.Signal<"Проверка целостности" | "Build integrity">;
    /** Live build-integrity check (config.verify.manifestUrl) — the © result. */
    private readonly integrity;
    /** The build-integrity dialog's content, read off the live check. The © dialog only opens when
     *  verify is configured, so the status is never 'none' here. */
    protected readonly verifyView: _angular_core.Signal<FooterVerifyView>;
    protected readonly openFullLabel: _angular_core.Signal<"Открыть полную версию ↗" | "Open full version ↗">;
    /** Localized accessible label for the dialog's Close button. */
    protected readonly closeLabel: _angular_core.Signal<"Close" | "Закрыть">;
    /** Open legal policy panel (null = closed). */
    protected readonly policyDoc: _angular_core.WritableSignal<RenderLegal | null>;
    /** The control that opened a dialog — focus is restored to it on close (ARIA dialog pattern). */
    private lastFocused;
    protected openPolicy(l: RenderLegal): void;
    /** Build-integrity result (opened from ©). */
    protected readonly verifyOpen: _angular_core.WritableSignal<boolean>;
    protected openVerify(): void;
    /** A dialog closed (Escape, backdrop, close button): back to the control that opened it. */
    protected closeDialog(): void;
    /** Auto-ranged year — rendered as a (secret) link to the QR page, like the reference footer. */
    protected readonly yearRange: _angular_core.Signal<string>;
    /** Holder + suffix after the year ("Acme. All rights reserved.") — suffix localized.
     *  With brand.nameHidden the holder is dropped (just "© year" + optional suffix). */
    protected readonly crRest: _angular_core.Signal<string>;
    /** The clickable year's target — the QR page (deploy.routes.qr, else /qr). */
    protected readonly qrHref: _angular_core.Signal<string>;
    /** Localized accessible name for the secret year→QR link (was a bare, ambiguous "QR"). */
    protected readonly qrLabel: _angular_core.Signal<"Открыть QR-код" | "Show QR code">;
    /** Optional authorship/verify PAGE the © glyph links to (deploy.routes.verify). When a live
     *  integrity check (verify.manifestUrl) is configured the © opens that modal instead; with
     *  neither, the © is plain text. Lets a site point © at a proof page (e.g. ik-authorship-validator). */
    protected readonly verifyRoute: _angular_core.Signal<string | undefined>;
    /** Localized title for the © → verify-page link. */
    protected readonly verifyLinkTitle: _angular_core.Signal<"Проверка подлинности" | "Verify authenticity">;
    /** The licence's name (config.license → catalog, no text) + its page route — a footer link. */
    protected readonly license: _angular_core.Signal<{
        key: string;
        name: string;
    } | undefined>;
    protected readonly licenseHref: _angular_core.Signal<string>;
    /** Localized aria-label for the bottom-bar legal `<nav>` landmark (#10). */
    protected readonly legalNavLabel: _angular_core.Signal<"Правовая информация" | "Legal">;
    /** "Cookie settings" re-open link (#6) — needs `footer.cookieSettings`. */
    protected readonly showCookieSettings: _angular_core.Signal<boolean>;
    protected readonly cookieSettingsLabel: _angular_core.Signal<"Настройки cookie" | "Cookie settings">;
    /** Emits when the user asks to re-open the consent banner; also dispatched as a document
     *  `ik:cookie-settings` event so `ik-cookie-consent` re-opens with zero host wiring. */
    readonly cookieSettings: _angular_core.OutputEmitterRef<void>;
    protected openCookieSettings(): void;
    /** Footer lang switcher / theme toggle (#7) — re-emit the inner components' events. */
    protected readonly showLangSwitcher: _angular_core.Signal<boolean>;
    protected readonly showThemeToggle: _angular_core.Signal<boolean>;
    readonly langChange: _angular_core.OutputEmitterRef<string>;
    readonly themeChange: _angular_core.OutputEmitterRef<IkThemeMode>;
    /** Contact block (#8) — surfaced from `config.contact` when `footer.contact` is on. Returns
     *  null when nothing is displayable. `phoneHref` is the dialable form (digits + leading +). */
    protected readonly contact: _angular_core.Signal<{
        company: string;
        location: string;
        phone: string;
        phoneHref: string;
        email: string;
    } | null>;
    /** Back-to-top button (#9) — needs `footer.backToTop`. */
    protected readonly showBackToTop: _angular_core.Signal<boolean>;
    protected readonly backTopLabel: _angular_core.Signal<"Наверх" | "Back to top">;
    protected backToTop(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Footer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Footer, "ik-footer", never, { "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "currentYear": { "alias": "currentYear"; "required": false; "isSignal": true; }; }, { "cookieSettings": "cookieSettings"; "langChange": "langChange"; "themeChange": "themeChange"; }, never, ["[slot=extra]"], true, never>;
}

interface ShareButton {
    kind: SiteKitShareKind;
    label: string;
    icon: SafeHtml;
    /**
     * Explicit per-channel accent override (`config.contact.shareColors`), exposed as
     * `--chip-accent`. Null when unset → the chip inherits the theme `--brand`, so every
     * share button is ONE colour (the site's brand) unless a channel is overridden.
     */
    accent: string | null;
}
interface QuickLink {
    label: string;
    href: string;
    external: boolean;
    /** Leading icon (contact channels only; quick links have none). */
    icon?: SafeHtml;
}
/**
 * Rich contact card built around a QR code.
 *
 * The QR is generated client-side from `config.contact.qr.data` (or `brand.url`)
 * with a crisp custom renderer (error-correction 'H', single black path on a
 * white quiet-zone) — unless `config.contact.qr.src` is set, in which case that
 * image is shown verbatim. The QR always sits on a white frame so it stays
 * scannable in dark theme. With `showDetails` it also lists the contact
 * channels, locale-aware quick links and a row of share buttons.
 *
 * Chrome labels (scan hint, section titles, copy/share/email/website) are
 * localized via `qrString(effLang, …)`; brand channel names stay literal.
 *
 * ```html
 * <ik-contact-qr [lang]="translate.currentLang" />
 * <ik-contact-qr [showDetails]="false" />
 * ```
 */
declare class ContactQr {
    protected readonly cfg: _ilia_ae_site_kit.ResolvedSiteKitConfig;
    private readonly sanitizer;
    private readonly document;
    private readonly share;
    /** Show the channel list, quick links and share buttons under the QR. */
    readonly showDetails: _angular_core.InputSignal<boolean>;
    /** Active language code (host binds `[lang]="translate.currentLang"`). */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    /**
     * Small pill in the top-right of the header (e.g. "CARD"). Content, so it accepts
     * a per-language map and translates with `[lang]`: `{ en: 'CARD', ru: 'ВИЗИТКА' }`.
     */
    readonly eyebrow: _angular_core.InputSignal<LocalizedString | undefined>;
    /**
     * Share-button layout override: 'grid' (vertical icon-over-label tiles) or
     * 'inline' (horizontal icon-left/label-right rows). When unset, falls back to
     * `config.contact.shareLayout`, then 'grid'.
     */
    readonly shareLayout: _angular_core.InputSignal<"grid" | "inline" | undefined>;
    /**
     * Share icon colour theme override: 'mono' (neutral, accent on hover) or
     * 'color' (brand colours at rest). Unset → `config.contact.shareTheme` → 'mono'.
     */
    readonly shareTheme: _angular_core.InputSignal<"mono" | "color" | undefined>;
    /**
     * Section-divider style override ('top' | 'center' | 'center-dashed'). Unset →
     * `config.contact.sectionDivider` → 'top'.
     */
    readonly sectionDivider: _angular_core.InputSignal<"top" | "center" | "center-dashed" | undefined>;
    protected readonly copied: _angular_core.WritableSignal<boolean>;
    /** Resolved presentation knobs: explicit input wins, else config, else default. */
    protected readonly effShareLayout: _angular_core.Signal<"grid" | "inline">;
    protected readonly effShareTheme: _angular_core.Signal<"mono" | "color">;
    protected readonly effDivider: _angular_core.Signal<"top" | "center" | "center-dashed">;
    /** Eyebrow pill text resolved for the active language. */
    protected readonly effEyebrow: _angular_core.Signal<string | null>;
    /** Library-constant SVGs → safe to trust once. */
    protected readonly checkIcon: SafeHtml;
    protected readonly arrowIcon: SafeHtml;
    protected readonly extArrowIcon: SafeHtml;
    /** Effective language: explicit input wins, else the config default. */
    private readonly effLang;
    protected readonly monogram: _angular_core.Signal<string>;
    /** Trusted inline brand glyph (paths use currentColor) for the mark + emblem. */
    protected readonly brandGlyph: _angular_core.Signal<SafeHtml | null>;
    /**
     * Header subtitle on the QR card — an explicit `contact.company` ONLY.
     * Deliberately NOT the brand tagline (that's the site's hero line, used in
     * nav/footer): a card that wants a subtitle sets `contact.company`; deposit
     * leaves it empty → the brand word stands alone (matches the reference card).
     */
    protected readonly subtitle: _angular_core.Signal<string | null>;
    /** Lede shown above the QR (config.contact.qr.lede) — per-language aware. */
    protected readonly lede: _angular_core.Signal<string | null>;
    /** Resolve a string-or-per-language-map field for the active language. */
    private pickLang;
    protected readonly person: _angular_core.Signal<{
        person: string | undefined;
        role: string | undefined;
        location: string | undefined;
    } | null>;
    /** Scan hint under the QR: explicit caption (per-language) wins, else localized 'scan'. */
    protected readonly scanHint: _angular_core.Signal<string>;
    protected readonly linksTitle: _angular_core.Signal<string>;
    protected readonly shareTitle: _angular_core.Signal<string>;
    protected readonly copiedLabel: _angular_core.Signal<string>;
    /**
     * QR-encoded value for a language: explicit per-lang `qr.urls[lang]` wins,
     * else `qr.localize` adds the `/<lang>` prefix to `data`, else `data`/brand.
     * So switching language (slotted lang-switcher) re-points the QR.
     */
    private qrTarget;
    /** Value encoded into the QR (or the click-through fallback). */
    private readonly qrData;
    /** Pre-rendered image source — when set, skip generation entirely. */
    protected readonly qrImg: _angular_core.Signal<string | null>;
    protected readonly qrHref: _angular_core.Signal<string | null>;
    protected readonly alt: _angular_core.Signal<string>;
    /** Decorative L-corner accents around the white frame. Default 'none'. */
    protected readonly corners: _angular_core.Signal<"none" | "dashed" | "solid">;
    /**
     * Center brand badge model, or null when off. Opt-OUT (`badge: false`);
     * default ON when the brand has a logo or a monogram/name to show. Prefers
     * the brand logo image, else the monogram letter on a brand gradient.
     */
    protected readonly badge: _angular_core.Signal<{
        logo: string | null;
        mono: string;
    } | null>;
    /** The QR generator: a lazy chunk (qrcode-loader.ts), set when it arrives; the SVG renders then. */
    private readonly qrcode;
    constructor();
    /**
     * Generated QR SVG (only consulted when `qrImg()` is null). Custom renderer
     * for crisp output: error-correction 'H', a 2-module quiet margin, and a
     * single black `<path>` on a white background. Failures degrade to empty.
     */
    protected readonly qrSvg: _angular_core.Signal<SafeHtml>;
    /** Contact channels (telegram/whatsapp/email/phone/website/contact-form) as icon links. */
    protected readonly channels: _angular_core.Signal<QuickLink[]>;
    /** WhatsApp: a wa.me link as-is, else build one from the digits. */
    private waHref;
    private waLabel;
    /** Config quick links, resolved locale-aware. */
    protected readonly quickLinks: _angular_core.Signal<QuickLink[]>;
    /** Hostname of a URL (resolved against brand.url for relative paths); '' if unparseable. */
    private hostOf;
    /** Share chips — exactly `config.contact.share` when set, else the default set. */
    protected readonly shareButtons: _angular_core.Signal<ShareButton[]>;
    /** Target encoded into every share intent (locale-aware, mirrors the QR). */
    private shareTarget;
    private pageUrl;
    protected onShare(kind: SiteKitShareKind): void;
    private tr;
    /** Brand channels stay literal; functional chips are localized. */
    private shareLabel;
    private shareText;
    private resolveLink;
    private isExternal;
    private prettyTelegram;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ContactQr, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ContactQr, "ik-contact-qr", never, { "showDetails": { "alias": "showDetails"; "required": false; "isSignal": true; }; "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "eyebrow": { "alias": "eyebrow"; "required": false; "isSignal": true; }; "shareLayout": { "alias": "shareLayout"; "required": false; "isSignal": true; }; "shareTheme": { "alias": "shareTheme"; "required": false; "isSignal": true; }; "sectionDivider": { "alias": "sectionDivider"; "required": false; "isSignal": true; }; }, {}, never, ["[slot=actions]"], true, never>;
}

interface RenderLink {
    link: SiteKitSocialLink;
    label: string;
    /** Locale-aware resolved href. */
    href: string;
    /** Trusted inline SVG for known kinds (null for custom-with-url). */
    svg: SafeHtml | null;
    /** Icon URL for custom kind. */
    imgUrl: string | null;
}
/**
 * Row of social / contact channels, driven by `config.social`.
 *
 * Known kinds render a built-in icon; `kind: 'custom'` renders the `icon`
 * URL via <img>. External links get `rel="noopener noreferrer"`.
 *
 * ```html
 * <ik-social-links />
 * <ik-social-links size="lg" />
 * ```
 */
declare class SocialLinks {
    private readonly cfg;
    private readonly sanitizer;
    /** Visual size hint, reflected to a host attribute for CSS. */
    readonly size: _angular_core.InputSignal<"sm" | "md" | "lg">;
    /** Active language for locale-aware hrefs (localize / pathByLang / urls). */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    protected readonly links: _angular_core.Signal<RenderLink[]>;
    protected isExternal(url: string): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SocialLinks, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SocialLinks, "ik-social-links", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "lang": { "alias": "lang"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type IkConsent = 'accepted' | 'rejected';
/**
 * Cookie / privacy consent banner — ANGULAR-ONLY. GDPR-minded: symmetric Accept /
 * Reject, a close (×) that means "essential only" (= reject), an optional auto-close
 * timer (also = reject — never an implicit accept), a "learn more" button that opens the
 * FULL localized cookie policy in an in-app panel (no external link), and Escape-to-dismiss.
 * Remembers the choice in localStorage; `reopen()` re-shows it. Texts/policy come from
 * `config.cookie` (or inputs), else the built-in localized copy.
 *
 * ```html
 * <ik-cookie-consent [lang]="translate.currentLang" (consentChange)="onConsent($event)" />
 * ```
 */
declare class CookieConsent implements OnInit, OnDestroy {
    private readonly doc;
    private readonly cfg;
    private timerId;
    /** Active language (for built-in text). Defaults to the config's default language. */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    /** Optional explicit overrides; when omitted, `config.cookie` then built-in localized text is used. */
    readonly messageText: _angular_core.InputSignal<string | undefined>;
    readonly acceptText: _angular_core.InputSignal<string | undefined>;
    readonly rejectText: _angular_core.InputSignal<string | undefined>;
    readonly moreText: _angular_core.InputSignal<string | undefined>;
    /** Policy-panel body override; else `config.cookie.policyBody`, else the built-in localized full policy. Blank lines = paragraphs. */
    readonly policyBodyText: _angular_core.InputSignal<string | undefined>;
    /** Direct full-policy URL override; else `config.cookie.policyHref` resolved for the active language. */
    readonly policyHref: _angular_core.InputSignal<string | undefined>;
    /** Placement override; else `config.cookie.position`, else `bottom`. */
    readonly placement: _angular_core.InputSignal<"bottom" | "corner" | undefined>;
    /** Auto-dismiss (as REJECT) after N ms; else `config.cookie.autoCloseMs`. 0 = off. */
    readonly autoClose: _angular_core.InputSignal<number | undefined>;
    /** Emits once the user makes (or has made) a choice. */
    readonly consentChange: _angular_core.OutputEmitterRef<IkConsent>;
    private readonly effLang;
    private readonly cc;
    private readonly def;
    protected readonly msg: _angular_core.Signal<string>;
    protected readonly accept: _angular_core.Signal<string>;
    protected readonly reject: _angular_core.Signal<string>;
    protected readonly more: _angular_core.Signal<string>;
    protected readonly barLabel: _angular_core.Signal<string>;
    protected readonly position: _angular_core.Signal<"bottom" | "corner">;
    protected readonly policyTitle: _angular_core.Signal<string>;
    protected readonly dismissLabel: _angular_core.Signal<string>;
    protected readonly fullPolicy: _angular_core.Signal<string>;
    /** Optional link to the official full policy — resolved for the active language (input → config). */
    protected readonly policy: _angular_core.Signal<string | undefined>;
    protected readonly policyParas: _angular_core.Signal<string[]>;
    /** Effective auto-close delay (ms): input → config → 0 (off). Drives the countdown bar. */
    protected readonly timerMs: _angular_core.Signal<number>;
    protected readonly visible: _angular_core.WritableSignal<boolean>;
    protected readonly policyOpen: _angular_core.WritableSignal<boolean>;
    protected readonly counting: _angular_core.WritableSignal<boolean>;
    /** Re-open requested from elsewhere (e.g. the footer's "Cookie settings" link, which
     *  dispatches a document `ik:cookie-settings` event) — re-show the banner with no host wiring. */
    private readonly onReopenRequest;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Re-show the banner so the user can change their choice (e.g. a "Cookie settings" link). */
    reopen(): void;
    /** Open the localized "learn more" policy panel; pauses the auto-close timer while reading. */
    openPolicy(): void;
    /** Close the policy panel (the banner stays as it was). */
    closePolicy(): void;
    protected decide(choice: IkConsent): void;
    /** Auto-dismiss as REJECT after the configured delay (never an implicit accept). */
    private armTimer;
    private clearTimer;
    private safeRead;
    private safeStore;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CookieConsent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CookieConsent, "ik-cookie-consent", never, { "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "messageText": { "alias": "messageText"; "required": false; "isSignal": true; }; "acceptText": { "alias": "acceptText"; "required": false; "isSignal": true; }; "rejectText": { "alias": "rejectText"; "required": false; "isSignal": true; }; "moreText": { "alias": "moreText"; "required": false; "isSignal": true; }; "policyBodyText": { "alias": "policyBodyText"; "required": false; "isSignal": true; }; "policyHref": { "alias": "policyHref"; "required": false; "isSignal": true; }; "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "autoClose": { "alias": "autoClose"; "required": false; "isSignal": true; }; }, { "consentChange": "consentChange"; }, never, never, true, never>;
}

/**
 * Shared "close" affordance — ONE definition for every dismiss control in the kit
 * (mobile-menu close, cookie-policy panel ×, …). A bordered round chip with the ×
 * glyph; the consumer supplies the localized label and listens for `closed`.
 *
 * ```html
 * <ik-close [label]="t('close')" (closed)="dismiss()" />
 * ```
 */
declare class IkClose implements AfterViewInit {
    /** Accessible label (localized by the consumer). */
    readonly label: _angular_core.InputSignal<string>;
    /** Focus the button once rendered — for dialogs/panels that open on demand. */
    readonly autoFocus: _angular_core.InputSignal<boolean>;
    /** Fired on click. */
    readonly closed: _angular_core.OutputEmitterRef<Event>;
    private readonly btn;
    ngAfterViewInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IkClose, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IkClose, "ik-close", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "autoFocus": { "alias": "autoFocus"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, never, true, never>;
}

/**
 * Shared "draining countdown" fill — ONE definition for every timed control in the kit
 * (cookie auto-close on the reject button, status auto-redirect on the home button, …).
 * A full-bleed overlay that shrinks `scaleX(1 → 0)` over `durationMs`; drop it inside a
 * `position: relative; overflow: hidden` button and keep the label above it (`z-index: 1`).
 * Colour comes from `--ik-countdown-fill` (defaults to a tint of the button's text colour).
 *
 * ```html
 * <button style="position:relative; overflow:hidden; --ik-countdown-fill: …">
 *   @if (active()) { <ik-countdown [durationMs]="ms" [loop]="preview()" /> }
 *   <span style="position:relative; z-index:1">Label</span>
 * </button>
 * ```
 */
declare class IkCountdown {
    /** Total drain time in milliseconds. */
    readonly durationMs: _angular_core.InputSignal<number>;
    /** Loop forever (e.g. a demo/preview) instead of draining once. */
    readonly loop: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IkCountdown, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IkCountdown, "ik-countdown", never, { "durationMs": { "alias": "durationMs"; "required": true; "isSignal": true; }; "loop": { "alias": "loop"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Language switcher — DEPENDENCY-FREE on i18n engines. It renders the language
 * list (flag + native name) and emits the chosen code; the host wires it to
 * its translator.
 *
 * Defaults: shows the site's configured languages (from `provideSiteKit`'s
 * `languages`), or the full Integra set (en/ru/ar/kk/zh/hi/ur) when standalone.
 *
 * ```html
 * <ik-lang-switcher [current]="translate.currentLang" (langChange)="translate.use($event)" />
 * ```
 */
declare class LangSwitcher {
    private readonly cfg;
    private readonly host;
    /** Languages to offer. Defaults to the site's configured set, else all of IK_LANGUAGES. */
    readonly languages: _angular_core.InputSignal<IkLanguage[]>;
    /** Active language code (controlled by the host). */
    readonly current: _angular_core.InputSignal<string | undefined>;
    /**
     * Compact mode: render a single text button showing the NEXT language's code
     * (click cycles to it) instead of the flag + dropdown. With 2 languages this
     * is a plain RU/EN toggle; with 3+ it cycles. Matches the reference QR card.
     */
    readonly compact: _angular_core.InputSignal<boolean>;
    /** Emits the selected language code. */
    readonly langChange: _angular_core.OutputEmitterRef<string>;
    protected readonly open: _angular_core.WritableSignal<boolean>;
    /** Localized aria-label ("Language" / "Язык" / …) for the active language. */
    protected readonly switcherLabel: _angular_core.Signal<string>;
    protected readonly currentLang: _angular_core.Signal<IkLanguage | undefined>;
    /** The language the compact toggle advances to (wraps around the list). */
    protected readonly nextLang: _angular_core.Signal<IkLanguage | undefined>;
    protected choose(code: string): void;
    /** Open/close the listbox; on open, move focus to the active (or first) option
     *  so the popup is keyboard-operable per the WAI-ARIA listbox pattern. */
    protected toggle(): void;
    /** Arrow-key roving focus between options (wraps top↔bottom). */
    protected move(dir: number, ev: Event): void;
    /** Escape: close the popup and return focus to the trigger. */
    protected closeToTrigger(): void;
    protected onDocClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LangSwitcher, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LangSwitcher, "ik-lang-switcher", never, { "languages": { "alias": "languages"; "required": false; "isSignal": true; }; "current": { "alias": "current"; "required": false; "isSignal": true; }; "compact": { "alias": "compact"; "required": false; "isSignal": true; }; }, { "langChange": "langChange"; }, never, never, true, never>;
}

/**
 * How `ik-theme-toggle` writes the theme to the page. The default matches the apps' `ThemeService`
 * (class `app-dark` on <html>, mode under `localStorage['theme']`); `provideSiteKitTabler()` swaps
 * it for Tabler's `data-bs-theme`.
 */
interface IkThemeOptions {
    /** localStorage key for the mode (`light` | `dark` | `auto`). Default `'theme'`. */
    storageKey?: string;
    /** Class toggled on <html> while dark. `null` = none. Default `'app-dark'`. */
    darkClass?: string | null;
    /**
     * Attributes on <html> set to `dark` / `light` (in `auto`, the OS answer) — e.g.
     * `['data-bs-theme']` for Tabler / Bootstrap. Default none.
     */
    attributes?: readonly string[];
}
declare const IK_THEME_OPTIONS: InjectionToken<IkThemeOptions>;

/**
 * Runs the kit inside a **Tabler** (Bootstrap 5) app. Two halves:
 *
 * 1. **Styles** — load ONE bridge stylesheet after Tabler (and NOT `site-kit-tokens.css`): kit
 *    components then take Tabler's colours, fonts, radii, shadows and its light/dark theme. Kit
 *    tokens are declared on the `ik-*` elements only, so the app's own custom properties stay as
 *    they are.
 *    - Tabler from `tabler.min.css` (`--tblr-*` variables):
 *      `node_modules/@ilia-ae/site-kit/src/lib/styles/site-kit-tabler.css`
 *    - Tabler built from its Sass sources (unprefixed `--body-bg`, `--primary`):
 *      `node_modules/@ilia-ae/site-kit/src/lib/styles/site-kit-tabler-unprefixed.css`
 *
 * 2. **Theme** (this provider) — `ik-theme-toggle` writes `data-bs-theme="dark|light"` on <html>
 *    (Tabler's switch; in `auto` it writes the OS answer and follows it live) instead of the kit's
 *    `app-dark` class. Pass `storageKey` to share the mode with the app's own theme script.
 *
 * ```ts
 * // app.config.ts
 * providers: [ provideSiteKit(cfg), provideSiteKitTabler({ storageKey: 'mtls-theme' }) ]
 * ```
 * Leave `config.theme` unset on a Tabler app — the palette is Tabler's (`provideSiteKit` would put
 * `config.theme` on <html> as global variables).
 */
declare function provideSiteKitTabler(opts?: IkThemeOptions): EnvironmentProviders;

/**
 * Decorative animated "techno" background — floating brand glows, a faint grid
 * masked toward the centre, and a subtle noise layer. Mirrors the look of the
 * apps' QR page background. Purely cosmetic (`aria-hidden`), token-driven, and
 * it honours `prefers-reduced-motion`.
 *
 * Drop it as the first child of a positioned container:
 * ```html
 * <div style="position:relative">
 *   <ik-techno-bg />
 *   …content…
 * </div>
 * ```
 */
declare class TechnoBg {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TechnoBg, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TechnoBg, "ik-techno-bg", never, {}, {}, never, never, true, never>;
}

/**
 * Pure, dependency-free core for the authorship validator. Everything runs in the
 * browser via WebCrypto — files never leave the machine. The component layers a UI
 * and localized copy on top; these functions return NEUTRAL outcomes (status + codes
 * + counts) so they stay i18n-free and unit-testable.
 *
 * Ported from deposit.mayday.software's verify page (WHAT/WHEN checks).
 */
type CheckStatus = 'passed' | 'failed' | 'skipped';
type CheckKind = 'what' | 'who' | 'when';
declare function sha256OfString(input: string): Promise<string>;
declare function sha256OfFile(file: File): Promise<string>;
/** Extract `- path: …` / `sha256: …` pairs from a CITATION.cff (1.2.0) manifest. */
declare function parseManifestHashes(manifestText: string): Map<string, string>;
interface WhatOutcome {
    status: CheckStatus;
    matched: number;
    total: number;
    mismatchPaths: string[];
}
/** Re-hash each source and compare against the manifest. No sources → skipped. */
declare function checkWhat(manifestText: string, sources: File[]): Promise<WhatOutcome>;
type WhenCode = 'ots-ok' | 'ots-mismatch' | 'ots-short' | 'ots-badop' | 'tsr-ok' | 'tsr-invalid' | 'unknown';
interface WhenOutcome {
    name: string;
    status: CheckStatus;
    code: WhenCode;
    /** OTS protocol version when parsed. */
    version?: number;
    /** First 16 hex chars of the embedded digest (for mismatch display). */
    digestHead?: string;
}
/** Parse an OpenTimestamps `.ots`: checks the SHA-256 op + that its digest is the manifest hash. */
declare function parseOts(bytes: Uint8Array, manifestHash: string, name?: string): WhenOutcome;
/** Parse an RFC 3161 `.tsr`: a minimal DER sanity check (SEQUENCE header). */
declare function parseTsr(bytes: Uint8Array, name?: string): WhenOutcome;
/** Dispatch each proof file to the right parser. No proofs → one skipped outcome. */
declare function checkWhen(proofs: File[], manifestText: string): Promise<WhenOutcome[]>;

interface CheckResult {
    kind: CheckKind;
    label: string;
    status: CheckStatus;
    details: string;
}
type StrKey = 'title' | 'subtitle' | 'back' | 'dropManifest' | 'dropSources' | 'dropProofs' | 'dropKey' | 'dropSignature' | 'manifestHint' | 'sourcesHint' | 'proofsHint' | 'keyHint' | 'sigHint' | 'passphrase' | 'passphraseHint' | 'run' | 'verifying' | 'required' | 'readiness' | 'readinessHint' | 'what' | 'who' | 'when' | 'whatTag' | 'whoTag' | 'whenTag' | 'passed' | 'failed' | 'skipped' | 'allPassed' | 'someFailed' | 'hashMatch' | 'hashMismatch' | 'sigValid' | 'sigInvalid' | 'gpgUnavailable' | 'passphraseRequired' | 'otsOk' | 'otsMismatch' | 'otsBad' | 'tsrOk' | 'tsrInvalid' | 'unknownProof' | 'noProofs';
type Strings = Record<StrKey, string>;
/**
 * Client-side authorship validator (ported from deposit.mayday.software). Drop a
 * CITATION.cff manifest + sources + proofs + GPG key/signature and it checks, all in
 * the browser: WHAT (SHA-256 integrity), WHO (a GPG signature via lazy openpgp, or an SSH
 * signature — `ssh-keygen -Y sign -n file` — via WebCrypto),
 * WHEN (OTS/RFC-3161 timestamps). Localized en/ru with an optional [strings] override.
 */
declare class AuthorshipValidator {
    readonly lang: _angular_core.InputSignal<string>;
    readonly strings: _angular_core.InputSignal<Record<string, Partial<Strings>> | null>;
    /**
     * Optional PUBLISHED proof bundle — each value is a URL. When `manifest` is set the
     * component fetches the bundle on load, fills the zones and runs verification
     * automatically, so a visitor sees the result ("✓ authorship verified") without
     * dropping anything. Manual drag-drop still works as a fallback.
     */
    readonly proof: _angular_core.InputSignal<{
        manifest?: string;
        sources?: string[];
        proofs?: string[];
        key?: string;
        signature?: string;
    } | null>;
    /** A "← back" link in the header. Defaults to the site home ('/'); pass a custom URL,
     *  or `null` to hide it. */
    readonly homeHref: _angular_core.InputSignal<string | null>;
    constructor();
    private autoload;
    protected readonly manifestFile: _angular_core.WritableSignal<File | null>;
    protected readonly sourceFiles: _angular_core.WritableSignal<File[]>;
    protected readonly proofFiles: _angular_core.WritableSignal<File[]>;
    protected readonly publicKeyFile: _angular_core.WritableSignal<File | null>;
    protected readonly signatureFile: _angular_core.WritableSignal<File | null>;
    protected readonly keyNeedsPassphrase: _angular_core.WritableSignal<boolean>;
    protected keyPassphrase: string;
    protected readonly verifying: _angular_core.WritableSignal<boolean>;
    protected readonly checks: _angular_core.WritableSignal<CheckResult[]>;
    private readonly str;
    protected readonly zonesFilled: _angular_core.Signal<number>;
    protected readonly allPassed: _angular_core.Signal<boolean>;
    protected t(key: StrKey): string;
    protected pick(e: Event): File[];
    protected drop(e: DragEvent): File[];
    protected asValue(e: Event): string;
    /** SHA-256 of the loaded manifest — shown so the user sees the exact bytes that are
     *  signed (WHO) and timestamped (WHEN). Display-only; verification uses the file itself. */
    protected readonly manifestHash: _angular_core.WritableSignal<string>;
    protected setManifest(files: File[]): Promise<void>;
    /** "name · 1.2 KB" for a single loaded file (so a zone shows what's in it). */
    protected info(f: File | null): string;
    /** Single → name · size; many → "N files · total". */
    protected multiInfo(files: File[]): string;
    protected fmtBytes(n: number): string;
    protected setSources(files: File[]): void;
    protected setProofs(files: File[]): void;
    protected setSignature(files: File[]): void;
    protected setKey(files: File[]): Promise<void>;
    protected runVerification(): Promise<void>;
    private buildWhat;
    private buildWho;
    private buildWhen;
    private whenDetail;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AuthorshipValidator, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AuthorshipValidator, "ik-authorship-validator", never, { "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "strings": { "alias": "strings"; "required": false; "isSignal": true; }; "proof": { "alias": "proof"; "required": false; "isSignal": true; }; "homeHref": { "alias": "homeHref"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Trust badge linking to the site's authorship-validation page. Click → the
 * in-site `/verify` (or `config.deploy.routes.verify`) where `ik-authorship-validator`
 * runs locally. Drop it anywhere (footer, hero):
 *
 * ```html
 * <ik-verify-badge [lang]="translate.currentLang" />
 * <ik-verify-badge href="/kit/verify.html" />   <!-- explicit target -->
 * ```
 */
declare class VerifyBadge {
    private readonly cfg;
    private readonly sanitizer;
    /** Active language (en/ru; falls back to en). */
    readonly lang: _angular_core.InputSignal<string | undefined>;
    /** Explicit target URL. Defaults to `config.deploy.routes.verify`, else `/verify`. */
    readonly href: _angular_core.InputSignal<string | undefined>;
    /** Icon-only: a green shield in a circle (for footer social rows). */
    readonly iconOnly: _angular_core.InputSignal<boolean>;
    protected readonly shieldIcon: SafeHtml;
    protected readonly copy: _angular_core.Signal<{
        label: string;
        hint: string;
    }>;
    /** Resolved verify-page URL: explicit input → deploy route → /verify. */
    protected readonly target: _angular_core.Signal<string>;
    protected external(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VerifyBadge, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<VerifyBadge, "ik-verify-badge", never, { "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Live build-integrity / authorship status, surfaced as a tint on a brand mark.
 * Mirrors the lifecycle of a client-side integrity check (fetch a signed manifest,
 * hash the running bundles, compare):
 *   - `verified` — bundles match the published manifest (green);
 *   - `mismatch` — at least one bundle differs, i.e. tampered (red);
 *   - `dev`      — dev/localhost build, check intentionally suppressed (amber);
 *   - `pending`  — check in flight; `offline` — manifest unreachable; `unknown` — inconclusive;
 *   - `none`     — no status (render the mark plainly).
 */
type VerifyStatus = 'verified' | 'mismatch' | 'pending' | 'offline' | 'unknown' | 'dev' | 'none';
/** Localized status labels (used for the tooltip / screen-reader name). */
interface VerifyMarkLabels {
    verified: string;
    mismatch: string;
    pending: string;
    offline: string;
    unknown: string;
    dev: string;
}
/**
 * `ik-verify-mark` — wraps a brand glyph (projected, or passed as an inline-SVG string via
 * `[glyph]`) and tints it by a live {@link VerifyStatus}, with a small status dot and a
 * localized tooltip. The sanctioned way to surface build-integrity / authorship status on a
 * site's logo — the right fit for minimal chrome where there is no footer to carry
 * {@link VerifyBadge}. Drop it into `ik-nav`'s `[customBrand]` slot (or anywhere):
 *
 * ```html
 * <a slot="brand" routerLink="/" aria-label="Home">
 *   <ik-verify-mark [status]="integrity.status()" [lang]="lang.current()" [summary]="integrity.summary()">
 *     <svg …>…eye…</svg>
 *   </ik-verify-mark>
 * </a>
 * ```
 *
 * The status colour is applied via `color`, so a `currentColor`-based glyph tints automatically.
 * It owns no data: feed it a status from your own integrity service (or any verify source).
 */
declare class VerifyMark {
    private readonly sanitizer;
    /** Live integrity / authorship status. Defaults to `none` (plain mark, no tint/dot/tooltip). */
    readonly status: _angular_core.InputSignal<VerifyStatus>;
    /** Active language for the tooltip label (en/ru maintained; others fall back to en). */
    readonly lang: _angular_core.InputSignal<string>;
    /** Optional inline-SVG glyph; when set it renders instead of projected content. */
    readonly glyph: _angular_core.InputSignal<string | undefined>;
    /** Mark size in px (square). The projected/innerHTML SVG scales to fill it. */
    readonly size: _angular_core.InputSignal<number>;
    /** Extra tooltip detail appended after the status label (e.g. commit / SHA summary). */
    readonly summary: _angular_core.InputSignal<string | undefined>;
    /** Per-language label overrides (deep-merged over the built-in en/ru set). */
    readonly labels: _angular_core.InputSignal<Record<string, Partial<VerifyMarkLabels>> | undefined>;
    /** Show the live-status popover on hover/focus. Default true; set false for the bare mark. */
    readonly popover: _angular_core.InputSignal<boolean>;
    /** Localized status label alone (no summary). Empty when status is `none`. */
    protected readonly label: _angular_core.Signal<string>;
    /** Trusted inline glyph, when provided as a string. */
    protected readonly glyphHtml: _angular_core.Signal<SafeHtml | null>;
    protected readonly showDot: _angular_core.Signal<boolean>;
    /** Resolved tooltip: localized status label, optionally `· summary`. Empty when status is `none`. */
    protected readonly tooltip: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VerifyMark, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<VerifyMark, "ik-verify-mark", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; "lang": { "alias": "lang"; "required": false; "isSignal": true; }; "glyph": { "alias": "glyph"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "summary": { "alias": "summary"; "required": false; "isSignal": true; }; "labels": { "alias": "labels"; "required": false; "isSignal": true; }; "popover": { "alias": "popover"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** One bundle entry in the integrity manifest. */
interface IntegrityBundle {
    name: string;
    sha256: string;
    url?: string | null;
    size?: number | null;
}
/** The published integrity manifest (`config.verify.manifestUrl`). */
interface IntegrityManifest {
    project?: string;
    commit?: string;
    commitFull?: string | null;
    branch?: string | null;
    builtAt?: string;
    publishedAt?: string;
    bundles: IntegrityBundle[];
    publicSourceUrl?: string | null;
}
/** Per-bundle comparison result (expected vs the SHA-256 of the actually-loaded bytes). */
interface IntegrityCheck {
    name: string;
    expected: string;
    actual: string | null;
    matched: boolean | null;
}
/**
 * Live build-integrity check — the data behind `ik-verify-mark`. On load (browser, non-dev)
 * it fetches `config.verify.manifestUrl`, SHA-256-hashes the bundles the page actually
 * loaded and compares them to the manifest:
 *   verified — all match · mismatch — at least one differs (tampered/outdated manifest) ·
 *   dev — localhost (suppressed) · pending — in flight · offline — manifest unreachable ·
 *   unknown — inconclusive · none — no `verify.manifestUrl` configured.
 *
 * Generalises each site's bespoke integrity service into one config-driven kit service.
 * Bind it to the mark: `<ik-verify-mark [status]="integrity.status()" [summary]="integrity.summary()">`.
 */
declare class IntegrityService {
    private readonly cfg;
    readonly status: _angular_core.WritableSignal<VerifyStatus>;
    readonly manifest: _angular_core.WritableSignal<IntegrityManifest | null>;
    readonly checks: _angular_core.WritableSignal<IntegrityCheck[]>;
    readonly checkedAt: _angular_core.WritableSignal<string | null>;
    /** Human-readable one-liner for the tooltip/popover (commit · published · SHA · status). */
    readonly summary: _angular_core.Signal<string>;
    constructor();
    private start;
    /** Fetch the manifest, hash the running bundles and set the status. Exposed for testing. */
    run(url: string, deps?: IntegrityDeps): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IntegrityService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<IntegrityService>;
}
/** Injected I/O for {@link IntegrityService.run} — swapped in tests. */
interface IntegrityDeps {
    fetch: (url: string, init?: {
        cache?: string;
    }) => Promise<{
        ok: boolean;
        status: number;
        json: () => Promise<unknown>;
        arrayBuffer: () => Promise<ArrayBuffer>;
    }>;
    /** SHA-256 of bytes → lowercase hex, or null when WebCrypto is unavailable. */
    digest: ((buf: ArrayBuffer) => Promise<string>) | null;
    /** Resolve a manifest bundle name to the URL the page actually loaded (or null). */
    findBundle: (name: string) => string | null;
    now: () => string;
}

/**
 * WHO check — detached GPG signature verification via `openpgp`.
 *
 * openpgp is an OPTIONAL peer dependency: it's loaded lazily with a dynamic
 * `import('openpgp')` (its own chunk, fetched only when a signature is verified).
 * If it isn't installed / fails to load, the validator degrades gracefully — the
 * WHO check reports "unavailable" rather than throwing.
 *
 * Typed loosely (`any`) on purpose so the library compiles without a hard type
 * dependency on openpgp.
 */
interface GpgResult {
    available: boolean;
    valid: boolean;
    keyId: string;
    userId: string;
    signedAt: Date | null;
    error?: string;
}
/** Whether GPG verification is usable in this environment (openpgp resolved). */
declare function gpgAvailable(): Promise<boolean>;
/** True only when the uploaded key is a passphrase-locked PRIVATE key. */
declare function needsPassphrase(armoredKey: string): Promise<boolean>;
/** Verify a detached ASCII-armored signature over the manifest with the given key. */
declare function verifyGpg(manifestText: string, armoredSignature: string, armoredKey: string, passphrase?: string): Promise<GpgResult>;

/**
 * WHO check — a detached SSH signature (`ssh-keygen -Y sign`, the SSHSIG format, PROTOCOL.sshsig),
 * verified with WebCrypto: no dependency, nothing loaded. Made for keys that live on a hardware
 * token and sign through ssh-agent (a YubiKey PIV slot, ECDSA P-256), where an OpenPGP key isn't
 * there to sign with.
 *
 *   ssh-keygen -Y sign -n file -f key.pub CITATION.cff     → CITATION.cff.sig
 *   ssh-keygen -Y check-novalidate -n file -f key.pub -s CITATION.cff.sig < CITATION.cff
 *
 * Supported keys: ecdsa-sha2-nistp256/384/521 and ssh-ed25519 (Ed25519 needs a browser with
 * WebCrypto Ed25519). The public key the visitor gives (an OpenSSH key line, or an allowed_signers
 * line) must be byte-for-byte the key inside the signature, and the namespace must be `file`, so a
 * signature made for something else (a git commit is `git`) does not pass.
 */
interface SshSigResult {
    valid: boolean;
    /** OpenSSH-style fingerprint of the signing key: `SHA256:<base64>`. */
    fingerprint: string;
    /** The key line's comment (what follows the key), e.g. `code-signing-p2`; empty if none. */
    comment: string;
    keyType: string;
    error?: string;
}
/** The namespace an attestation is signed in (`ssh-keygen -Y sign -n file`). */
declare const SSHSIG_NAMESPACE = "file";
/** True when the text is an armored SSH signature (as opposed to an OpenPGP one). */
declare function isSshSignature(text: string): boolean;
/** Verify a detached SSHSIG over the manifest with the given OpenSSH public key. */
declare function verifySshSig(manifestText: string, armoredSignature: string, publicKeyText: string, namespace?: string): Promise<SshSigResult>;

/** A license resolved for a site: catalog text with `{{YEARS}}` filled from the copyright. */
interface ResolvedLicense {
    key: string;
    name: string;
    /** Full text (empty for a stub — see `source`). */
    text: string;
    /** True when only a placeholder exists in the bank (full text lives in `source`). */
    stub: boolean;
    source?: string;
}
/** Resolve `config.license` → its catalog entry, substituting `{{YEARS}}` from `copyright.startYear`.
 *  `lang` localizes the display NAME (the license TEXT stays as authored in the bank). */
declare function resolveLicense(cfg: {
    license?: string;
    copyright?: {
        startYear?: number;
    };
} | null | undefined, currentYear?: number, lang?: string): ResolvedLicense | undefined;
/**
 * Full license page/section — renders the resolved license text (or, for a stub, a link to the
 * canonical text in its repo). Reads `config.license` + `config.copyright` from SITE_KIT_CONFIG.
 */
declare class IkLicense {
    private readonly cfg;
    /** Optional explicit license (else resolved from SITE_KIT_CONFIG). */
    readonly license: _angular_core.InputSignal<ResolvedLicense | undefined>;
    /** Note shown for a stub license (overridable for i18n). */
    readonly noteLabel: _angular_core.InputSignal<string>;
    protected readonly lic: _angular_core.Signal<ResolvedLicense | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IkLicense, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IkLicense, "ik-license", never, { "license": { "alias": "license"; "required": false; "isSignal": true; }; "noteLabel": { "alias": "noteLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** `config.license` → its key and localized display name, without the licence text: what the footer
 *  links. Its own module, apart from license.ts and the catalog's 25 kB of texts, which an app then
 *  carries only when it renders a licence (ik-license, resolveLicense). */
declare function licenseName(cfg: {
    license?: string;
} | null | undefined, lang?: string): {
    key: string;
    name: string;
} | undefined;

interface LicenseEntry {
    name: string;
    text: string;
    stub?: boolean;
    source?: string;
}
declare const LICENSE_BUILD = "719c74c 2026-05-28";
declare const LICENSE_CATALOG: Record<string, LicenseEntry>;

/**
 * Starter Privacy / Terms copy you can drop straight into `config.legal[].body` so the
 * footer's in-app policy panels have real text on day one (the kit only ships built-in text
 * for the LICENSE and the cookie policy — Privacy/Terms are site-specific, see the footer docs).
 *
 * ⚠️ These are TEMPLATES, not legal advice and not one-size-fits-all. They describe a
 * privacy-first, mostly-static site that collects little/no personal data. **Read and adapt
 * them to your product and jurisdiction before shipping** — e.g. if you add forms, accounts,
 * analytics, payments, a wallet connect or a token sale, expand the data/processing and
 * liability sections accordingly. Blank lines separate paragraphs (the panel splits on them).
 *
 * ```ts
 * import { SAMPLE_LEGAL_LINKS } from '@ilia-ae/site-kit';
 * provideSiteKit({ …, legal: SAMPLE_LEGAL_LINKS });
 * // or one at a time:
 * import { SAMPLE_PRIVACY } from '@ilia-ae/site-kit';
 * legal: [{ label: { en: 'Privacy', ru: 'Конфиденциальность' }, body: SAMPLE_PRIVACY, updated: '2026-06-19T00:00:00Z' }]
 * ```
 */
declare const SAMPLE_PRIVACY: LocalizedString;
declare const SAMPLE_TERMS: LocalizedString;
/** Ready-to-drop `config.legal` array (Privacy + Terms) using the sample bodies above as
 *  in-app policy panels. Set your own `updated` timestamp and adapt the text before shipping. */
declare const SAMPLE_LEGAL_LINKS: SiteKitLegalLink[];

export { AuthorshipValidator, ContactQr, CookieConsent, DEFAULT_REDIRECT_SECONDS, FamilyLinks, Footer, IK_FAMILY, IK_FAMILY_ORDER, IK_LANGUAGES, IK_STRINGS, IK_THEME_OPTIONS, IkClose, IkCountdown, IkLicense, Install, IntegrityService, LICENSE_BUILD, LICENSE_CATALOG, LangSwitcher, Nav, PWA_SPLASH_DEVICES, Projects, ProjectsList, Pwa, SAMPLE_LEGAL_LINKS, SAMPLE_PRIVACY, SAMPLE_TERMS, SITE_KIT_ACCENT, SITE_KIT_BUILD_DATE, SITE_KIT_CONFIG, SITE_KIT_GLYPH, SITE_KIT_NAME, SITE_KIT_SCHEMA_VERSION, SITE_KIT_VERSION, SSHSIG_NAMESPACE, STATUS_ENTRIES, STATUS_LANGUAGES, Seo, SocialLinks, StatusPage, TECH_FALLBACK, TECH_ICONS, TechnoBg, Technologies, ThemeToggle, VerifyBadge, VerifyMark, applyFaviconTags, applyPwaTags, buildManifest, buildOgSvg, buildSeoTags, checkWhat, checkWhen, faviconSourceSvg, faviconTags, formatPhone, gpgAvailable, ikLanguage, ikLanguages, ikString, isIos, isRtl, isSshSignature, isStandalone, licenseName, localizeText, localizeUrl, needsPassphrase, parseManifestHashes, parseOts, parseTsr, pickHostKey, provideSiteKit, provideSiteKitForHost, provideSiteKitPwa, provideSiteKitTabler, pwaMetaTags, pwaSplashLinks, resolveLicense, resolveLinkHref, resolveSiteKitConfig, sha256OfFile, sha256OfString, splashMedia, statusCopy, statusEntry, verifyGpg, verifySshSig };
export type { CheckKind, CheckStatus, FamilyProjectMeta, FaviconTag, GpgResult, IkConsent, IkLanguage, IkStringKey, IkThemeMode, IkThemeOptions, IntegrityBundle, IntegrityCheck, IntegrityDeps, IntegrityManifest, LicenseEntry, LocalizedString, PwaLinkTag, PwaMetaTag, ResolvedLicense, ResolvedSiteKitConfig, SeoContext, SeoTag, SiteKitBrand, SiteKitConfig, SiteKitContact, SiteKitCookie, SiteKitCopyright, SiteKitDeploy, SiteKitDeployTarget, SiteKitFavicon, SiteKitFooter, SiteKitFooterColumn, SiteKitLegalLink, SiteKitLink, SiteKitLocalizedUrl, SiteKitNavItem, SiteKitPageSpeed, SiteKitProject, SiteKitPwa, SiteKitPwaShortcut, SiteKitQr, SiteKitSeo, SiteKitSeoEntity, SiteKitShareKind, SiteKitSignature, SiteKitSocialKind, SiteKitSocialLink, SiteKitStatusOptions, SiteKitTech, SshSigResult, StatusCopy, StatusEntry, StatusKey, TechMeta, VerifyMarkLabels, VerifyStatus, WhatOutcome, WhenCode, WhenOutcome };
